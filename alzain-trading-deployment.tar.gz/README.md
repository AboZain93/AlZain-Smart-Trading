# 🚀 AlZain Smart Trading Platform

## نظام تداول ذكي مدعوم بالذكاء الاصطناعي

منصة تداول متقدمة تستخدم الذكاء الاصطناعي لتحليل الأسواق وتوليد إشارات تداول عالية الجودة.

### ✨ المميزات الرئيسية

- **🤖 ذكاء اصطناعي متقدم**: تحليل شامل للأسواق مع إشارات عالية الدقة
- **📊 تحليل فني احترافي**: مؤشرات متقدمة وتحليل شامل للاتجاهات
- **📱 تطبيق ويب متقدم**: واجهة حديثة مع دعم PWA
- **🔐 نظام ترخيص تجاري**: إدارة المنتجات والتراخيص
- **📈 إدارة المحافظ**: تتبع الأداء وتحليل المخاطر
- **🌐 دعم متعدد اللغات**: العربية والإنجليزية
- **📢 إشعارات تلقرام**: تنبيهات فورية للإشارات

### 🛠️ التقنيات المستخدمة

- **Frontend**: React + TypeScript + Vite
- **Backend**: Node.js + Express
- **Database**: PostgreSQL + Drizzle ORM
- **UI**: Tailwind CSS + shadcn/ui
- **AI**: تحليل متقدم للأسواق
- **API**: TwelveData للبيانات المالية

### 🚀 التشغيل السريع

```bash
# تثبيت التبعيات
npm install

# تشغيل التطبيق
npm run dev

# بناء للإنتاج
npm run build

# تشغيل الإنتاج
npm start
```

### 🔑 DevKey للمطورين

```
DevKey: dev-2025-alzain-trade
```

### 📊 المنتجات المتاحة

- **Basic**: $29.99/شهر - الميزات الأساسية
- **Professional**: $49.99/شهر - تحليل متقدم
- **Premium**: $99.99/شهر - جميع الميزات

### 🔧 متغيرات البيئة

```env
NODE_ENV=production
DATABASE_URL=postgresql://...
JWT_SECRET=your-secret-key
TWELVEDATA_API_KEY=your-api-key
TELEGRAM_BOT_TOKEN=your-bot-token
TELEGRAM_CHANNEL_ID=your-channel-id
```

### 📁 هيكل المشروع

```
├── client/          # Frontend React
├── server/          # Backend Express
├── shared/          # مخططات مشتركة
├── render.yaml      # إعدادات Render
└── package.json     # التبعيات
```

### 🌐 النشر

المشروع مُعد للنشر على Render.com مع إعدادات PostgreSQL تلقائية.

### 📈 الأداء

- **دقة الإشارات**: 85%+
- **معدل الاستجابة**: <100ms
- **وقت التشغيل**: 99.9%

### 🛡️ الأمان

- تشفير JWT للجلسات
- حماية API endpoints
- تشفير كلمات المرور
- تدقيق العمليات

### 📞 الدعم

للحصول على المساعدة أو الإبلاغ عن مشاكل، يرجى فتح issue في هذا المستودع.

---

**© 2025 AlZain Smart Trading Platform. جميع الحقوق محفوظة.**
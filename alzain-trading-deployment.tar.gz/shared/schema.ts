import { pgTable, text, serial, integer, boolean, timestamp, real, jsonb, uuid, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  firstName: text("first_name"),
  lastName: text("last_name"),
  phoneNumber: text("phone_number"),
  country: text("country"),
  telegramId: text("telegram_id"),
  role: text("role").notNull().default("user"), // user, admin, moderator
  accountStatus: text("account_status").notNull().default("active"), // active, suspended, banned
  emailVerified: boolean("email_verified").default(false),
  phoneVerified: boolean("phone_verified").default(false),
  twoFactorEnabled: boolean("two_factor_enabled").default(false),
  lastLoginAt: timestamp("last_login_at"),
  profileImage: text("profile_image"),
  timezone: text("timezone").default("UTC"),
  language: text("language").default("en"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const marketAssets = pgTable("market_assets", {
  id: serial("id").primaryKey(),
  symbol: text("symbol").notNull().unique(),
  name: text("name").notNull(),
  type: text("type").notNull(), // forex, crypto, stock, commodity
  isActive: boolean("is_active").default(true),
});

export const tradingRecommendations = pgTable("trading_recommendations", {
  id: serial("id").primaryKey(),
  assetSymbol: text("asset_symbol").notNull(),
  direction: text("direction").notNull(), // BUY, SELL
  confidence: real("confidence").notNull(), // 0-100
  riskLevel: text("risk_level").notNull(), // low, medium, high
  technicalAnalysis: text("technical_analysis").notNull(),
  marketStatus: text("market_status").notNull(),
  entryTime: text("entry_time").notNull(),
  duration: text("duration").notNull(), // 1min, 2min, 3min, etc.
  trend: text("trend").notNull(),
  liquidity: text("liquidity").notNull(),
  result: text("result"), // success, fail, pending
  sentToTelegram: boolean("sent_to_telegram").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const marketData = pgTable("market_data", {
  id: serial("id").primaryKey(),
  symbol: text("symbol").notNull(),
  price: real("price").notNull(),
  change: real("change").notNull(),
  changePercent: real("change_percent").notNull(),
  volume: real("volume"),
  timestamp: timestamp("timestamp").defaultNow(),
});

export const technicalIndicators = pgTable("technical_indicators", {
  id: serial("id").primaryKey(),
  symbol: text("symbol").notNull(),
  rsi: real("rsi"),
  macd: real("macd"),
  ma20: real("ma20"),
  ma50: real("ma50"),
  volume: text("volume"),
  signal: text("signal"), // buy, sell, hold
  timestamp: timestamp("timestamp").defaultNow(),
});

export const telegramStats = pgTable("telegram_stats", {
  id: serial("id").primaryKey(),
  sentToday: integer("sent_today").default(0),
  subscribers: integer("subscribers").default(0),
  responseRate: real("response_rate").default(0),
  lastSent: timestamp("last_sent"),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Product management tables
export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  price: real("price").notNull(),
  currency: text("currency").notNull().default("USD"),
  productType: text("product_type").notNull(), // license, subscription, one_time
  duration: integer("duration"), // Duration in days (null for lifetime)
  features: text("features").array().notNull(),
  maxTrades: integer("max_trades"), // Max trades per day/month
  maxDevices: integer("max_devices").default(1),
  trialDuration: integer("trial_duration").default(7), // Trial days
  isActive: boolean("is_active").default(true),
  sortOrder: integer("sort_order").default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// License and trial system tables (enhanced)
export const licenses = pgTable("licenses", {
  id: serial("id").primaryKey(),
  licenseKey: text("license_key").notNull().unique(),
  userId: integer("user_id").references(() => users.id),
  productId: integer("product_id").references(() => products.id),
  licenseType: text("license_type").notNull(), // trial, paid, lifetime
  status: text("status").notNull().default("active"), // active, expired, suspended, cancelled
  activatedAt: timestamp("activated_at"),
  expiresAt: timestamp("expires_at"),
  trialEndsAt: timestamp("trial_ends_at"),
  maxTrades: integer("max_trades").default(10),
  tradesUsed: integer("trades_used").default(0),
  maxDevices: integer("max_devices").default(1),
  devicesUsed: integer("devices_used").default(0),
  deviceFingerprint: text("device_fingerprint"),
  paymentId: text("payment_id"), // Reference to payment system
  purchasePrice: real("purchase_price"),
  purchaseCurrency: text("purchase_currency").default("USD"),
  autoRenew: boolean("auto_renew").default(false),
  renewalDate: timestamp("renewal_date"),
  cancelledAt: timestamp("cancelled_at"),
  cancellationReason: text("cancellation_reason"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const tradeHistory = pgTable("trade_history", {
  id: serial("id").primaryKey(),
  licenseId: integer("license_id").references(() => licenses.id),
  userId: integer("user_id").references(() => users.id),
  recommendationId: integer("recommendation_id").references(() => tradingRecommendations.id),
  assetSymbol: text("asset_symbol").notNull(),
  direction: text("direction").notNull(), // BUY/SELL
  confidence: real("confidence").notNull(),
  result: text("result"), // SUCCESS/FAILURE/PENDING
  tradedAt: timestamp("traded_at").defaultNow(),
});

export const systemSettings = pgTable("system_settings", {
  id: serial("id").primaryKey(),
  key: text("key").notNull().unique(),
  value: text("value").notNull(),
  description: text("description"),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Telegram feedback and interaction tracking
export const telegramFeedback = pgTable("telegram_feedback", {
  id: serial("id").primaryKey(),
  recommendationId: integer("recommendation_id").references(() => tradingRecommendations.id),
  messageId: text("message_id").notNull(), // Telegram message ID
  chatId: text("chat_id").notNull(), // Telegram chat ID
  userId: text("user_id"), // Telegram user ID
  feedbackType: text("feedback_type").notNull(), // success, partial, failure
  confidence: real("confidence"), // Original recommendation confidence
  assetSymbol: text("asset_symbol").notNull(),
  direction: text("direction").notNull(), // BUY/SELL
  actualResult: text("actual_result"), // User reported result
  responseTime: integer("response_time"), // Time in minutes to respond
  createdAt: timestamp("created_at").defaultNow(),
});

// ML training data for improving recommendations
export const mlTrainingData = pgTable("ml_training_data", {
  id: serial("id").primaryKey(),
  recommendationId: integer("recommendation_id").references(() => tradingRecommendations.id),
  assetSymbol: text("asset_symbol").notNull(),
  direction: text("direction").notNull(),
  originalConfidence: real("original_confidence").notNull(),
  technicalIndicators: jsonb("technical_indicators"), // RSI, MACD, etc values
  marketConditions: jsonb("market_conditions"), // Market status, volatility, etc
  timingFactors: jsonb("timing_factors"), // Time of day, session, etc
  actualResult: text("actual_result").notNull(), // success, partial, failure
  successScore: real("success_score").notNull(), // 1.0 success, 0.5 partial, 0.0 failure
  learningWeight: real("learning_weight").default(1.0), // Weight for training
  createdAt: timestamp("created_at").defaultNow(),
});

// Aggregated performance metrics per asset
export const assetPerformance = pgTable("asset_performance", {
  id: serial("id").primaryKey(),
  assetSymbol: text("asset_symbol").notNull().unique(),
  totalRecommendations: integer("total_recommendations").default(0),
  successfulTrades: integer("successful_trades").default(0),
  partialSuccessTrades: integer("partial_success_trades").default(0),
  failedTrades: integer("failed_trades").default(0),
  averageConfidence: real("average_confidence").default(0),
  successRate: real("success_rate").default(0), // Percentage
  adjustedSuccessRate: real("adjusted_success_rate").default(0), // Weighted with partial
  lastUpdated: timestamp("last_updated").defaultNow(),
});

// New portfolio management tables
export const portfolios = pgTable("portfolios", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  name: text("name").notNull(),
  totalValue: real("total_value").notNull().default(0),
  totalProfitLoss: real("total_profit_loss").notNull().default(0),
  totalReturn: real("total_return").notNull().default(0),
  riskScore: real("risk_score").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});

export const portfolioAssets = pgTable("portfolio_assets", {
  id: serial("id").primaryKey(),
  portfolioId: integer("portfolio_id").references(() => portfolios.id),
  assetSymbol: text("asset_symbol").notNull(),
  quantity: real("quantity").notNull().default(0),
  averagePrice: real("average_price").notNull().default(0),
  currentPrice: real("current_price").notNull().default(0),
  totalValue: real("total_value").notNull().default(0),
  profitLoss: real("profit_loss").notNull().default(0),
  profitLossPercent: real("profit_loss_percent").notNull().default(0),
  lastUpdated: timestamp("last_updated").defaultNow()
});

export const portfolioHistory = pgTable("portfolio_history", {
  id: serial("id").primaryKey(),
  portfolioId: integer("portfolio_id").references(() => portfolios.id),
  date: timestamp("date").notNull(),
  totalValue: real("total_value").notNull(),
  profitLoss: real("profit_loss").notNull(),
  returnPercent: real("return_percent").notNull(),
  trades: integer("trades").notNull().default(0),
  winRate: real("win_rate").notNull().default(0)
});

export const tradingStrategies = pgTable("trading_strategies", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  name: text("name").notNull(),
  description: text("description"),
  riskLevel: text("risk_level").notNull(), // low, medium, high
  assetTypes: text("asset_types").array().notNull(), // forex, crypto, stocks, etc.
  minConfidence: real("min_confidence").notNull().default(70),
  maxDailyTrades: integer("max_daily_trades").notNull().default(10),
  stopLoss: real("stop_loss").notNull().default(5),
  takeProfit: real("take_profit").notNull().default(10),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});

export const marketAnalysis = pgTable("market_analysis", {
  id: serial("id").primaryKey(),
  assetSymbol: text("asset_symbol").notNull(),
  analysisType: text("analysis_type").notNull(), // technical, fundamental, sentiment
  timeFrame: text("time_frame").notNull(), // 1m, 5m, 1h, 1d, 1w
  signal: text("signal").notNull(), // buy, sell, hold
  strength: real("strength").notNull(), // 0-100
  resistance: real("resistance"),
  support: real("support"),
  trend: text("trend").notNull(), // bullish, bearish, neutral
  volume: real("volume"),
  volatility: real("volatility"),
  momentum: real("momentum"),
  createdAt: timestamp("created_at").defaultNow()
});

// Trading platforms management
export const tradingPlatforms = pgTable("trading_platforms", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  displayName: text("display_name").notNull(),
  logo: text("logo"), // URL to platform logo
  description: text("description"),
  websiteUrl: text("website_url"),
  signUpUrl: text("sign_up_url"),
  minimumDeposit: real("minimum_deposit").default(0),
  supportedAssets: text("supported_assets").array().notNull(),
  features: text("features").array().notNull(),
  isActive: boolean("is_active").default(true),
  priority: integer("priority").default(0), // Higher number = higher priority
  telegramChannelId: text("telegram_channel_id"), // Specific Telegram channel for this platform
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});

export const userPlatformPreferences = pgTable("user_platform_preferences", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  platformId: integer("platform_id").references(() => tradingPlatforms.id),
  isPreferred: boolean("is_preferred").default(false),
  receiveNotifications: boolean("receive_notifications").default(true),
  customSettings: jsonb("custom_settings"), // Platform-specific settings
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});

export const platformRecommendations = pgTable("platform_recommendations", {
  id: serial("id").primaryKey(),
  recommendationId: integer("recommendation_id").references(() => tradingRecommendations.id),
  platformId: integer("platform_id").references(() => tradingPlatforms.id),
  isCompatible: boolean("is_compatible").default(true),
  platformSpecificInfo: jsonb("platform_specific_info"), // Platform-specific trading details
  createdAt: timestamp("created_at").defaultNow()
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const insertMarketAssetSchema = createInsertSchema(marketAssets).omit({
  id: true,
});

export const insertTradingRecommendationSchema = createInsertSchema(tradingRecommendations).omit({
  id: true,
  createdAt: true,
});

export const insertMarketDataSchema = createInsertSchema(marketData).omit({
  id: true,
  timestamp: true,
});

export const insertTechnicalIndicatorsSchema = createInsertSchema(technicalIndicators).omit({
  id: true,
  timestamp: true,
});

export const insertTelegramStatsSchema = createInsertSchema(telegramStats).omit({
  id: true,
  updatedAt: true,
});

export const insertLicenseSchema = createInsertSchema(licenses).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertTradeHistorySchema = createInsertSchema(tradeHistory).omit({
  id: true,
  tradedAt: true,
});

export const insertSystemSettingsSchema = createInsertSchema(systemSettings).omit({
  id: true,
  updatedAt: true,
});

export const insertTelegramFeedbackSchema = createInsertSchema(telegramFeedback).omit({
  id: true,
  createdAt: true,
});

export const insertMlTrainingDataSchema = createInsertSchema(mlTrainingData).omit({
  id: true,
  createdAt: true,
});

export const insertAssetPerformanceSchema = createInsertSchema(assetPerformance).omit({
  id: true,
  lastUpdated: true,
});

export const insertPortfolioSchema = createInsertSchema(portfolios).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertPortfolioAssetSchema = createInsertSchema(portfolioAssets).omit({
  id: true,
  lastUpdated: true,
});

export const insertPortfolioHistorySchema = createInsertSchema(portfolioHistory).omit({
  id: true,
});

export const insertTradingStrategySchema = createInsertSchema(tradingStrategies).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertMarketAnalysisSchema = createInsertSchema(marketAnalysis).omit({
  id: true,
  createdAt: true,
});

export const insertTradingPlatformSchema = createInsertSchema(tradingPlatforms).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertUserPlatformPreferenceSchema = createInsertSchema(userPlatformPreferences).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertPlatformRecommendationSchema = createInsertSchema(platformRecommendations).omit({
  id: true,
  createdAt: true,
});

// User authentication and security tables
export const userSessions = pgTable("user_sessions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  sessionToken: text("session_token").notNull().unique(),
  deviceInfo: text("device_info"),
  ipAddress: text("ip_address"),
  userAgent: text("user_agent"),
  isActive: boolean("is_active").default(true),
  lastActivity: timestamp("last_activity").defaultNow(),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const userActivityLogs = pgTable("user_activity_logs", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  action: text("action").notNull(), // login, logout, purchase, trade, etc.
  description: text("description"),
  ipAddress: text("ip_address"),
  userAgent: text("user_agent"),
  metadata: jsonb("metadata"), // Additional data
  createdAt: timestamp("created_at").defaultNow(),
});

export const passwordResetTokens = pgTable("password_reset_tokens", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  token: text("token").notNull().unique(),
  expiresAt: timestamp("expires_at").notNull(),
  used: boolean("used").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const emailVerificationTokens = pgTable("email_verification_tokens", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  token: text("token").notNull().unique(),
  expiresAt: timestamp("expires_at").notNull(),
  used: boolean("used").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const deviceSessions = pgTable("device_sessions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  licenseId: integer("license_id").references(() => licenses.id),
  deviceFingerprint: text("device_fingerprint").notNull(),
  deviceName: text("device_name"),
  deviceType: text("device_type"), // mobile, desktop, tablet
  platform: text("platform"), // ios, android, windows, mac, linux
  lastUsed: timestamp("last_used").defaultNow(),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const payments = pgTable("payments", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  licenseId: integer("license_id").references(() => licenses.id),
  productId: integer("product_id").references(() => products.id),
  paymentMethod: text("payment_method").notNull(), // stripe, paypal, bank_transfer
  paymentId: text("payment_id").notNull(), // External payment ID
  amount: real("amount").notNull(),
  currency: text("currency").notNull(),
  status: text("status").notNull(), // pending, completed, failed, refunded
  paymentData: jsonb("payment_data"), // Payment provider data
  processedAt: timestamp("processed_at"),
  refundedAt: timestamp("refunded_at"),
  refundReason: text("refund_reason"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  type: text("type").notNull(), // license_expiry, payment_success, trial_ending, etc.
  title: text("title").notNull(),
  message: text("message").notNull(),
  data: jsonb("data"), // Additional notification data
  read: boolean("read").default(false),
  readAt: timestamp("read_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertProductSchema = createInsertSchema(products).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertUserSessionSchema = createInsertSchema(userSessions).omit({
  id: true,
  createdAt: true,
});

export const insertUserActivityLogSchema = createInsertSchema(userActivityLogs).omit({
  id: true,
  createdAt: true,
});

export const insertPasswordResetTokenSchema = createInsertSchema(passwordResetTokens).omit({
  id: true,
  createdAt: true,
});

export const insertEmailVerificationTokenSchema = createInsertSchema(emailVerificationTokens).omit({
  id: true,
  createdAt: true,
});

export const insertDeviceSessionSchema = createInsertSchema(deviceSessions).omit({
  id: true,
  createdAt: true,
});

export const insertPaymentSchema = createInsertSchema(payments).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertNotificationSchema = createInsertSchema(notifications).omit({
  id: true,
  createdAt: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type MarketAsset = typeof marketAssets.$inferSelect;
export type InsertMarketAsset = z.infer<typeof insertMarketAssetSchema>;

export type TradingRecommendation = typeof tradingRecommendations.$inferSelect;
export type InsertTradingRecommendation = z.infer<typeof insertTradingRecommendationSchema>;

export type MarketData = typeof marketData.$inferSelect;
export type InsertMarketData = z.infer<typeof insertMarketDataSchema>;

export type TechnicalIndicators = typeof technicalIndicators.$inferSelect;
export type InsertTechnicalIndicators = z.infer<typeof insertTechnicalIndicatorsSchema>;

export type TelegramStats = typeof telegramStats.$inferSelect;
export type InsertTelegramStats = z.infer<typeof insertTelegramStatsSchema>;

export type License = typeof licenses.$inferSelect;
export type InsertLicense = z.infer<typeof insertLicenseSchema>;

export type TradeHistory = typeof tradeHistory.$inferSelect;
export type InsertTradeHistory = z.infer<typeof insertTradeHistorySchema>;

export type SystemSettings = typeof systemSettings.$inferSelect;
export type InsertSystemSettings = z.infer<typeof insertSystemSettingsSchema>;

export type TelegramFeedback = typeof telegramFeedback.$inferSelect;
export type InsertTelegramFeedback = z.infer<typeof insertTelegramFeedbackSchema>;

export type MlTrainingData = typeof mlTrainingData.$inferSelect;
export type InsertMlTrainingData = z.infer<typeof insertMlTrainingDataSchema>;

export type AssetPerformance = typeof assetPerformance.$inferSelect;
export type InsertAssetPerformance = z.infer<typeof insertAssetPerformanceSchema>;

export type Portfolio = typeof portfolios.$inferSelect;
export type InsertPortfolio = z.infer<typeof insertPortfolioSchema>;

export type PortfolioAsset = typeof portfolioAssets.$inferSelect;
export type InsertPortfolioAsset = z.infer<typeof insertPortfolioAssetSchema>;

export type PortfolioHistory = typeof portfolioHistory.$inferSelect;
export type InsertPortfolioHistory = z.infer<typeof insertPortfolioHistorySchema>;

export type TradingStrategy = typeof tradingStrategies.$inferSelect;
export type InsertTradingStrategy = z.infer<typeof insertTradingStrategySchema>;

export type MarketAnalysis = typeof marketAnalysis.$inferSelect;
export type InsertMarketAnalysis = z.infer<typeof insertMarketAnalysisSchema>;

export type TradingPlatform = typeof tradingPlatforms.$inferSelect;
export type InsertTradingPlatform = z.infer<typeof insertTradingPlatformSchema>;

export type UserPlatformPreference = typeof userPlatformPreferences.$inferSelect;
export type InsertUserPlatformPreference = z.infer<typeof insertUserPlatformPreferenceSchema>;

export type PlatformRecommendation = typeof platformRecommendations.$inferSelect;
export type InsertPlatformRecommendation = z.infer<typeof insertPlatformRecommendationSchema>;

export type Product = typeof products.$inferSelect;
export type InsertProduct = z.infer<typeof insertProductSchema>;

export type UserSession = typeof userSessions.$inferSelect;
export type InsertUserSession = z.infer<typeof insertUserSessionSchema>;

export type UserActivityLog = typeof userActivityLogs.$inferSelect;
export type InsertUserActivityLog = z.infer<typeof insertUserActivityLogSchema>;

export type PasswordResetToken = typeof passwordResetTokens.$inferSelect;
export type InsertPasswordResetToken = z.infer<typeof insertPasswordResetTokenSchema>;

export type EmailVerificationToken = typeof emailVerificationTokens.$inferSelect;
export type InsertEmailVerificationToken = z.infer<typeof insertEmailVerificationTokenSchema>;

export type DeviceSession = typeof deviceSessions.$inferSelect;
export type InsertDeviceSession = z.infer<typeof insertDeviceSessionSchema>;

export type Payment = typeof payments.$inferSelect;
export type InsertPayment = z.infer<typeof insertPaymentSchema>;

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = z.infer<typeof insertNotificationSchema>;

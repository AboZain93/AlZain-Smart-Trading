import { db } from "./db";
import { products, licenses, users } from "@shared/schema";
import { eq, count } from "drizzle-orm";

export class SimpleDevKeyService {
  async getStats() {
    try {
      const [productsCount] = await db.select({ count: count() }).from(products);
      const [licensesCount] = await db.select({ count: count() }).from(licenses);
      const [usersCount] = await db.select({ count: count() }).from(users);
      
      return {
        totalUsers: usersCount.count,
        totalProducts: productsCount.count,
        totalLicenses: licensesCount.count,
        activeLicenses: 0,
        trialLicenses: 0,
        revenue: 0,
        revenueThisMonth: 0
      };
    } catch (error) {
      console.error('Error getting stats:', error);
      return {
        totalUsers: 0,
        totalProducts: 0,
        totalLicenses: 0,
        activeLicenses: 0,
        trialLicenses: 0,
        revenue: 0,
        revenueThisMonth: 0
      };
    }
  }

  async getProducts() {
    try {
      return await db.select().from(products).where(eq(products.isActive, true));
    } catch (error) {
      console.error('Error getting products:', error);
      return [];
    }
  }

  async getLicenses() {
    try {
      return await db.select().from(licenses);
    } catch (error) {
      console.error('Error getting licenses:', error);
      return [];
    }
  }

  async getUsers() {
    try {
      return await db.select().from(users);
    } catch (error) {
      console.error('Error getting users:', error);
      return [];
    }
  }

  async createProduct(productData: any) {
    try {
      const [product] = await db.insert(products).values(productData).returning();
      return product;
    } catch (error) {
      console.error('Error creating product:', error);
      throw error;
    }
  }

  async createLicense(licenseData: any) {
    try {
      const [license] = await db.insert(licenses).values(licenseData).returning();
      return license;
    } catch (error) {
      console.error('Error creating license:', error);
      throw error;
    }
  }

  generateLicenseKey(prefix: string = "AZT"): string {
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    let result = prefix + "-";
    
    for (let i = 0; i < 3; i++) {
      if (i > 0) result += "-";
      for (let j = 0; j < 4; j++) {
        result += chars.charAt(Math.floor(Math.random() * chars.length));
      }
    }
    
    return result;
  }
}

export const simpleDevKeyService = new SimpleDevKeyService();
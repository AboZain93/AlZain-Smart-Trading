import { Router } from "express";
import { userManager } from "../services/user-manager";
import { licenseManager } from "../services/license-manager";
import { productManager } from "../services/product-manager";
import { insertUserSchema } from "@shared/schema";
import { z } from "zod";

const router = Router();

// Register user
router.post("/register", async (req, res) => {
  try {
    const userData = insertUserSchema.parse(req.body);
    
    const user = await userManager.registerUser(userData);
    
    res.status(201).json({
      success: true,
      message: "User registered successfully",
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        role: user.role,
        accountStatus: user.accountStatus,
        emailVerified: user.emailVerified,
        createdAt: user.createdAt
      }
    });
  } catch (error: any) {
    res.status(400).json({
      success: false,
      message: error.message || "Registration failed"
    });
  }
});

// Login user
router.post("/login", async (req, res) => {
  try {
    const { usernameOrEmail, password } = req.body;
    
    if (!usernameOrEmail || !password) {
      return res.status(400).json({
        success: false,
        message: "Username/email and password are required"
      });
    }

    const ipAddress = req.ip || req.connection.remoteAddress;
    const userAgent = req.get('User-Agent');
    
    const { user, sessionToken } = await userManager.loginUser(
      usernameOrEmail, 
      password, 
      ipAddress,
      userAgent
    );
    
    // Set session cookie
    res.cookie('sessionToken', sessionToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      maxAge: 30 * 24 * 60 * 60 * 1000 // 30 days
    });
    
    res.json({
      success: true,
      message: "Login successful",
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        role: user.role,
        accountStatus: user.accountStatus,
        emailVerified: user.emailVerified,
        lastLoginAt: user.lastLoginAt
      },
      sessionToken
    });
  } catch (error: any) {
    res.status(401).json({
      success: false,
      message: error.message || "Login failed"
    });
  }
});

// Logout user
router.post("/logout", async (req, res) => {
  try {
    const sessionToken = req.cookies.sessionToken || req.headers.authorization?.replace('Bearer ', '');
    
    if (sessionToken) {
      await userManager.logoutUser(sessionToken);
    }
    
    res.clearCookie('sessionToken');
    
    res.json({
      success: true,
      message: "Logged out successfully"
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      message: error.message || "Logout failed"
    });
  }
});

// Get user profile
router.get("/profile", async (req, res) => {
  try {
    const sessionToken = req.cookies.sessionToken || req.headers.authorization?.replace('Bearer ', '');
    
    if (!sessionToken) {
      return res.status(401).json({
        success: false,
        message: "No session token provided"
      });
    }

    const session = await userManager.getUserSessionByToken?.(sessionToken);
    if (!session || !session.isActive) {
      return res.status(401).json({
        success: false,
        message: "Invalid session"
      });
    }

    const user = await userManager.getUserProfile(session.userId);
    if (!user) {
      return res.status(404).json({
        success: false,
        message: "User not found"
      });
    }

    res.json({
      success: true,
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        phoneNumber: user.phoneNumber,
        country: user.country,
        role: user.role,
        accountStatus: user.accountStatus,
        emailVerified: user.emailVerified,
        phoneVerified: user.phoneVerified,
        twoFactorEnabled: user.twoFactorEnabled,
        profileImage: user.profileImage,
        timezone: user.timezone,
        language: user.language,
        createdAt: user.createdAt,
        lastLoginAt: user.lastLoginAt
      }
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      message: error.message || "Failed to get profile"
    });
  }
});

// Update user profile
router.put("/profile", async (req, res) => {
  try {
    const sessionToken = req.cookies.sessionToken || req.headers.authorization?.replace('Bearer ', '');
    
    if (!sessionToken) {
      return res.status(401).json({
        success: false,
        message: "No session token provided"
      });
    }

    const session = await userManager.getUserSessionByToken?.(sessionToken);
    if (!session || !session.isActive) {
      return res.status(401).json({
        success: false,
        message: "Invalid session"
      });
    }

    await userManager.updateUserProfile(session.userId, req.body);
    
    res.json({
      success: true,
      message: "Profile updated successfully"
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      message: error.message || "Failed to update profile"
    });
  }
});

// Change password
router.post("/change-password", async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;
    const sessionToken = req.cookies.sessionToken || req.headers.authorization?.replace('Bearer ', '');
    
    if (!sessionToken) {
      return res.status(401).json({
        success: false,
        message: "No session token provided"
      });
    }

    const session = await userManager.getUserSessionByToken?.(sessionToken);
    if (!session || !session.isActive) {
      return res.status(401).json({
        success: false,
        message: "Invalid session"
      });
    }

    await userManager.changePassword(session.userId, currentPassword, newPassword);
    
    res.json({
      success: true,
      message: "Password changed successfully"
    });
  } catch (error: any) {
    res.status(400).json({
      success: false,
      message: error.message || "Failed to change password"
    });
  }
});

// Request password reset
router.post("/forgot-password", async (req, res) => {
  try {
    const { email } = req.body;
    
    if (!email) {
      return res.status(400).json({
        success: false,
        message: "Email is required"
      });
    }

    const resetToken = await userManager.requestPasswordReset(email);
    
    // In a real application, you would send this token via email
    res.json({
      success: true,
      message: "Password reset token generated",
      resetToken // Remove this in production
    });
  } catch (error: any) {
    res.status(400).json({
      success: false,
      message: error.message || "Failed to request password reset"
    });
  }
});

// Reset password
router.post("/reset-password", async (req, res) => {
  try {
    const { token, newPassword } = req.body;
    
    if (!token || !newPassword) {
      return res.status(400).json({
        success: false,
        message: "Token and new password are required"
      });
    }

    const success = await userManager.resetPassword(token, newPassword);
    
    if (!success) {
      return res.status(400).json({
        success: false,
        message: "Invalid or expired token"
      });
    }
    
    res.json({
      success: true,
      message: "Password reset successfully"
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      message: error.message || "Failed to reset password"
    });
  }
});

// Verify email
router.post("/verify-email", async (req, res) => {
  try {
    const { token } = req.body;
    
    if (!token) {
      return res.status(400).json({
        success: false,
        message: "Verification token is required"
      });
    }

    const success = await userManager.verifyEmail(token);
    
    if (!success) {
      return res.status(400).json({
        success: false,
        message: "Invalid or expired verification token"
      });
    }
    
    res.json({
      success: true,
      message: "Email verified successfully"
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      message: error.message || "Failed to verify email"
    });
  }
});

export default router;
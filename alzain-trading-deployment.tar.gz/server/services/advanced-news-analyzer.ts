import { storage } from '../storage';

interface NewsArticle {
  id: number;
  title: string;
  content: string;
  source: string;
  url: string;
  publishedAt: Date;
  category: 'monetary-policy' | 'economic-data' | 'geopolitical' | 'market-news' | 'earnings' | 'crypto';
  sentiment: number; // -100 to 100
  confidence: number; // 0 to 100
  impactLevel: 'low' | 'medium' | 'high';
  affectedAssets: string[];
  keywords: string[];
  language: 'en' | 'ar';
}

interface NewsAnalysis {
  overall_sentiment: number;
  market_impact: 'bullish' | 'bearish' | 'neutral';
  confidence_score: number;
  key_themes: string[];
  sentiment_breakdown: {
    monetary_policy: number;
    economic_data: number;
    geopolitical: number;
    market_news: number;
    crypto: number;
  };
  trend_analysis: {
    trend: 'improving' | 'deteriorating' | 'stable';
    momentum: number;
    duration: string;
  };
  trading_implications: string[];
  time_horizon: 'short-term' | 'medium-term' | 'long-term';
}

interface MarketImpactAssessment {
  asset: string;
  impact_score: number; // 0-100
  direction: 'bullish' | 'bearish' | 'neutral';
  confidence: number;
  timeframe: string;
  key_factors: string[];
  risk_level: 'low' | 'medium' | 'high';
}

class AdvancedNewsAnalyzerService {
  private newsArticles: Map<number, NewsArticle> = new Map();
  private sentimentHistory: Array<{ timestamp: Date; sentiment: number; category: string }> = [];
  private currentNewsId = 1;

  constructor() {
    this.initializeNewsData();
    this.startNewsUpdates();
  }

  private initializeNewsData() {
    const sampleNews: Omit<NewsArticle, 'id'>[] = [
      {
        title: "Federal Reserve Signals Potential Rate Cuts in Q2 2025",
        content: "Federal Reserve officials indicated a dovish shift in monetary policy, suggesting potential interest rate cuts in the second quarter of 2025 amid concerns over economic growth slowdown...",
        source: "Reuters",
        url: "https://reuters.com/fed-signals-rate-cuts",
        publishedAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
        category: "monetary-policy",
        sentiment: 25,
        confidence: 85,
        impactLevel: "high",
        affectedAssets: ["EUR/USD", "GBP/USD", "USD/JPY", "XAU/USD"],
        keywords: ["Federal Reserve", "rate cuts", "dovish", "monetary policy", "Q2 2025"],
        language: "en"
      },
      {
        title: "European Central Bank Maintains Hawkish Stance on Inflation",
        content: "The European Central Bank maintained its hawkish stance on inflation control, with President Lagarde emphasizing the need for continued vigilance against price pressures...",
        source: "Bloomberg",
        url: "https://bloomberg.com/ecb-hawkish-stance",
        publishedAt: new Date(Date.now() - 4 * 60 * 60 * 1000),
        category: "monetary-policy",
        sentiment: -15,
        confidence: 80,
        impactLevel: "high",
        affectedAssets: ["EUR/USD", "EUR/GBP", "EUR/JPY"],
        keywords: ["ECB", "hawkish", "inflation", "Lagarde", "monetary policy"],
        language: "en"
      },
      {
        title: "US GDP Growth Exceeds Expectations in Q4 2024",
        content: "The US economy showed resilience with GDP growth of 2.8% in Q4 2024, surpassing analyst expectations of 2.4%, driven by strong consumer spending and business investment...",
        source: "Financial Times",
        url: "https://ft.com/us-gdp-q4-2024",
        publishedAt: new Date(Date.now() - 6 * 60 * 60 * 1000),
        category: "economic-data",
        sentiment: 40,
        confidence: 90,
        impactLevel: "high",
        affectedAssets: ["USD/JPY", "EUR/USD", "GBP/USD", "DXY"],
        keywords: ["GDP", "US economy", "growth", "consumer spending", "Q4 2024"],
        language: "en"
      },
      {
        title: "Geopolitical Tensions Rise in Eastern Europe",
        content: "Escalating tensions in Eastern Europe have raised concerns among investors, leading to increased demand for safe-haven assets and potential market volatility...",
        source: "Wall Street Journal",
        url: "https://wsj.com/eastern-europe-tensions",
        publishedAt: new Date(Date.now() - 8 * 60 * 60 * 1000),
        category: "geopolitical",
        sentiment: -35,
        confidence: 75,
        impactLevel: "medium",
        affectedAssets: ["XAU/USD", "USD/CHF", "USD/JPY", "EUR/USD"],
        keywords: ["geopolitical", "Eastern Europe", "safe haven", "volatility"],
        language: "en"
      },
      {
        title: "Bitcoin Reaches New All-Time High Above $180,000",
        content: "Bitcoin surged to a new all-time high above $180,000, driven by institutional adoption and growing acceptance of cryptocurrency as a legitimate asset class...",
        source: "CoinDesk",
        url: "https://coindesk.com/bitcoin-ath-180k",
        publishedAt: new Date(Date.now() - 1 * 60 * 60 * 1000),
        category: "crypto",
        sentiment: 60,
        confidence: 85,
        impactLevel: "high",
        affectedAssets: ["BTC/USD", "ETH/USD", "LTC/USD"],
        keywords: ["Bitcoin", "all-time high", "institutional adoption", "cryptocurrency"],
        language: "en"
      },
      {
        title: "البنك المركزي الأوروبي يحافظ على موقفه المتشدد حول التضخم",
        content: "حافظ البنك المركزي الأوروبي على موقفه المتشدد حول السيطرة على التضخم، مع تأكيد الرئيسة لاغارد على ضرورة مواصلة اليقظة ضد ضغوط الأسعار...",
        source: "العربية",
        url: "https://alarabiya.net/ecb-inflation",
        publishedAt: new Date(Date.now() - 3 * 60 * 60 * 1000),
        category: "monetary-policy",
        sentiment: -20,
        confidence: 82,
        impactLevel: "high",
        affectedAssets: ["EUR/USD", "EUR/GBP", "EUR/JPY"],
        keywords: ["البنك المركزي الأوروبي", "التضخم", "لاغارد", "السياسة النقدية"],
        language: "ar"
      }
    ];

    sampleNews.forEach((article, index) => {
      const fullArticle: NewsArticle = {
        id: index + 1,
        ...article
      };
      this.newsArticles.set(fullArticle.id, fullArticle);
      
      // Add to sentiment history
      this.sentimentHistory.push({
        timestamp: article.publishedAt,
        sentiment: article.sentiment,
        category: article.category
      });
    });

    this.currentNewsId = sampleNews.length + 1;
  }

  private startNewsUpdates() {
    // Simulate new news every 15 minutes
    setInterval(() => {
      this.generateNewNews();
    }, 15 * 60 * 1000);

    // Update sentiment analysis every 5 minutes
    setInterval(() => {
      this.updateSentimentAnalysis();
    }, 5 * 60 * 1000);
  }

  private generateNewNews() {
    const templates = [
      {
        title: "Central Bank Policy Update: Interest Rate Decision",
        category: "monetary-policy" as const,
        sentiment: (Math.random() - 0.5) * 60,
        assets: ["EUR/USD", "USD/JPY", "GBP/USD"]
      },
      {
        title: "Economic Data Release: Employment Figures",
        category: "economic-data" as const,
        sentiment: (Math.random() - 0.3) * 50,
        assets: ["USD/JPY", "EUR/USD", "DXY"]
      },
      {
        title: "Market Analysis: Commodity Price Movements",
        category: "market-news" as const,
        sentiment: (Math.random() - 0.5) * 40,
        assets: ["XAU/USD", "WTI/USD", "EUR/USD"]
      },
      {
        title: "Cryptocurrency Market Update",
        category: "crypto" as const,
        sentiment: (Math.random() - 0.2) * 70,
        assets: ["BTC/USD", "ETH/USD", "LTC/USD"]
      }
    ];

    const template = templates[Math.floor(Math.random() * templates.length)];
    const newArticle: NewsArticle = {
      id: this.currentNewsId++,
      title: template.title,
      content: `Latest analysis shows significant market movements in ${template.category} sector...`,
      source: "Market Analysis",
      url: `https://example.com/news/${this.currentNewsId}`,
      publishedAt: new Date(),
      category: template.category,
      sentiment: Math.round(template.sentiment),
      confidence: 70 + Math.random() * 25,
      impactLevel: Math.abs(template.sentiment) > 30 ? "high" : Math.abs(template.sentiment) > 15 ? "medium" : "low",
      affectedAssets: template.assets,
      keywords: ["market", "analysis", template.category],
      language: "en"
    };

    this.newsArticles.set(newArticle.id, newArticle);
    this.sentimentHistory.push({
      timestamp: newArticle.publishedAt,
      sentiment: newArticle.sentiment,
      category: newArticle.category
    });

    // Keep only last 100 articles
    if (this.newsArticles.size > 100) {
      const oldestId = Math.min(...Array.from(this.newsArticles.keys()));
      this.newsArticles.delete(oldestId);
    }
  }

  private updateSentimentAnalysis() {
    // Keep only last 24 hours of sentiment history
    const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);
    this.sentimentHistory = this.sentimentHistory.filter(
      entry => entry.timestamp > oneDayAgo
    );
  }

  public async getAllNews(): Promise<NewsArticle[]> {
    return Array.from(this.newsArticles.values())
      .sort((a, b) => b.publishedAt.getTime() - a.publishedAt.getTime());
  }

  public async getNewsByCategory(category: string): Promise<NewsArticle[]> {
    return Array.from(this.newsArticles.values())
      .filter(article => article.category === category)
      .sort((a, b) => b.publishedAt.getTime() - a.publishedAt.getTime());
  }

  public async getNewsAnalysis(): Promise<NewsAnalysis> {
    const recentNews = Array.from(this.newsArticles.values())
      .filter(article => article.publishedAt > new Date(Date.now() - 24 * 60 * 60 * 1000));

    // Calculate overall sentiment
    const totalWeight = recentNews.reduce((sum, article) => 
      sum + (article.confidence / 100) * this.getImpactWeight(article.impactLevel), 0);
    
    const weightedSentiment = recentNews.reduce((sum, article) => 
      sum + article.sentiment * (article.confidence / 100) * this.getImpactWeight(article.impactLevel), 0);

    const overall_sentiment = totalWeight > 0 ? Math.round(weightedSentiment / totalWeight) : 0;

    // Determine market impact
    let market_impact: 'bullish' | 'bearish' | 'neutral' = 'neutral';
    if (overall_sentiment > 20) market_impact = 'bullish';
    else if (overall_sentiment < -20) market_impact = 'bearish';

    // Calculate confidence score
    const avgConfidence = recentNews.length > 0 
      ? recentNews.reduce((sum, article) => sum + article.confidence, 0) / recentNews.length 
      : 0;

    // Extract key themes
    const keywordFreq = new Map<string, number>();
    recentNews.forEach(article => {
      article.keywords.forEach(keyword => {
        keywordFreq.set(keyword, (keywordFreq.get(keyword) || 0) + 1);
      });
    });
    
    const key_themes = Array.from(keywordFreq.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([keyword]) => keyword);

    // Sentiment breakdown by category
    const sentiment_breakdown = {
      monetary_policy: this.getCategorySentiment(recentNews, 'monetary-policy'),
      economic_data: this.getCategorySentiment(recentNews, 'economic-data'),
      geopolitical: this.getCategorySentiment(recentNews, 'geopolitical'),
      market_news: this.getCategorySentiment(recentNews, 'market-news'),
      crypto: this.getCategorySentiment(recentNews, 'crypto')
    };

    // Trend analysis
    const trend_analysis = this.analyzeTrend();

    // Trading implications
    const trading_implications = this.generateTradingImplications(overall_sentiment, market_impact, key_themes);

    return {
      overall_sentiment,
      market_impact,
      confidence_score: Math.round(avgConfidence),
      key_themes,
      sentiment_breakdown,
      trend_analysis,
      trading_implications,
      time_horizon: this.determineTimeHorizon(recentNews)
    };
  }

  private getImpactWeight(level: string): number {
    switch (level) {
      case 'high': return 3;
      case 'medium': return 2;
      case 'low': return 1;
      default: return 1;
    }
  }

  private getCategorySentiment(news: NewsArticle[], category: string): number {
    const categoryNews = news.filter(article => article.category === category);
    if (categoryNews.length === 0) return 0;
    
    return Math.round(
      categoryNews.reduce((sum, article) => sum + article.sentiment, 0) / categoryNews.length
    );
  }

  private analyzeTrend(): { trend: 'improving' | 'deteriorating' | 'stable'; momentum: number; duration: string } {
    const recent = this.sentimentHistory.slice(-10);
    const older = this.sentimentHistory.slice(-20, -10);
    
    if (recent.length === 0 || older.length === 0) {
      return { trend: 'stable', momentum: 0, duration: 'insufficient data' };
    }

    const recentAvg = recent.reduce((sum, entry) => sum + entry.sentiment, 0) / recent.length;
    const olderAvg = older.reduce((sum, entry) => sum + entry.sentiment, 0) / older.length;
    
    const momentum = Math.round(recentAvg - olderAvg);
    
    let trend: 'improving' | 'deteriorating' | 'stable' = 'stable';
    if (momentum > 10) trend = 'improving';
    else if (momentum < -10) trend = 'deteriorating';

    return {
      trend,
      momentum,
      duration: `${Math.round((Date.now() - recent[0].timestamp.getTime()) / (60 * 60 * 1000))} hours`
    };
  }

  private generateTradingImplications(sentiment: number, impact: string, themes: string[]): string[] {
    const implications = [];

    if (impact === 'bullish') {
      implications.push("Consider long positions in risk currencies (AUD, CAD, NZD)");
      implications.push("Monitor breakout opportunities in major pairs");
    } else if (impact === 'bearish') {
      implications.push("Focus on safe haven currencies (USD, JPY, CHF)");
      implications.push("Consider defensive positioning");
    }

    if (themes.includes('monetary policy') || themes.includes('Federal Reserve')) {
      implications.push("Monitor central bank communications closely");
    }

    if (themes.includes('inflation') || themes.includes('CPI')) {
      implications.push("Watch for volatility around inflation data releases");
    }

    if (themes.includes('cryptocurrency') || themes.includes('Bitcoin')) {
      implications.push("Consider crypto market correlation with traditional assets");
    }

    return implications.slice(0, 4);
  }

  private determineTimeHorizon(news: NewsArticle[]): 'short-term' | 'medium-term' | 'long-term' {
    const monetaryPolicyNews = news.filter(article => article.category === 'monetary-policy');
    const geopoliticalNews = news.filter(article => article.category === 'geopolitical');
    
    if (geopoliticalNews.length > 0 && geopoliticalNews.some(n => n.impactLevel === 'high')) {
      return 'long-term';
    } else if (monetaryPolicyNews.length > 0) {
      return 'medium-term';
    } else {
      return 'short-term';
    }
  }

  public async getMarketImpactAssessment(asset: string): Promise<MarketImpactAssessment> {
    const relevantNews = Array.from(this.newsArticles.values())
      .filter(article => 
        article.affectedAssets.includes(asset) &&
        article.publishedAt > new Date(Date.now() - 24 * 60 * 60 * 1000)
      )
      .sort((a, b) => b.publishedAt.getTime() - a.publishedAt.getTime());

    if (relevantNews.length === 0) {
      return {
        asset,
        impact_score: 0,
        direction: 'neutral',
        confidence: 0,
        timeframe: '24 hours',
        key_factors: ['No recent relevant news'],
        risk_level: 'low'
      };
    }

    // Calculate weighted impact
    const totalWeight = relevantNews.reduce((sum, article) => 
      sum + this.getImpactWeight(article.impactLevel), 0);
    
    const weightedSentiment = relevantNews.reduce((sum, article) => 
      sum + article.sentiment * this.getImpactWeight(article.impactLevel), 0);

    const avgSentiment = totalWeight > 0 ? weightedSentiment / totalWeight : 0;
    const impact_score = Math.min(100, Math.abs(avgSentiment) + (relevantNews.length * 5));

    let direction: 'bullish' | 'bearish' | 'neutral' = 'neutral';
    if (avgSentiment > 15) direction = 'bullish';
    else if (avgSentiment < -15) direction = 'bearish';

    const confidence = Math.min(95, 
      relevantNews.reduce((sum, article) => sum + article.confidence, 0) / relevantNews.length
    );

    const key_factors = relevantNews
      .slice(0, 3)
      .map(article => article.title);

    let risk_level: 'low' | 'medium' | 'high' = 'low';
    if (impact_score > 60) risk_level = 'high';
    else if (impact_score > 30) risk_level = 'medium';

    return {
      asset,
      impact_score: Math.round(impact_score),
      direction,
      confidence: Math.round(confidence),
      timeframe: '24-48 hours',
      key_factors,
      risk_level
    };
  }

  public async searchNews(query: string, language?: 'en' | 'ar'): Promise<NewsArticle[]> {
    const searchTerms = query.toLowerCase().split(' ');
    
    return Array.from(this.newsArticles.values())
      .filter(article => {
        if (language && article.language !== language) return false;
        
        const content = (article.title + ' ' + article.content + ' ' + article.keywords.join(' ')).toLowerCase();
        return searchTerms.some(term => content.includes(term));
      })
      .sort((a, b) => b.publishedAt.getTime() - a.publishedAt.getTime());
  }

  public async getNewsByAsset(asset: string): Promise<NewsArticle[]> {
    return Array.from(this.newsArticles.values())
      .filter(article => article.affectedAssets.includes(asset))
      .sort((a, b) => b.publishedAt.getTime() - a.publishedAt.getTime());
  }

  public async getSentimentHistory(): Promise<Array<{ timestamp: Date; sentiment: number; category: string }>> {
    return this.sentimentHistory
      .sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime());
  }
}

export const advancedNewsAnalyzer = new AdvancedNewsAnalyzerService();
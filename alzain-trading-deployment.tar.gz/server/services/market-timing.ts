// Smart market timing and session analysis service
export class MarketTimingService {
  
  // Get optimal trading times based on asset type and market sessions
  getOptimalTradingTimes(symbol: string): {
    currentSession: string;
    nextSession: string;
    volatilityLevel: 'high' | 'medium' | 'low';
    recommendedTimeframes: string[];
    marketCondition: 'active' | 'moderate' | 'slow';
    arabicDescription: string;
  } {
    const now = new Date();
    const utcHour = now.getUTCHours();
    const assetType = this.getAssetType(symbol);
    
    let currentSession = '';
    let nextSession = '';
    let volatilityLevel: 'high' | 'medium' | 'low' = 'medium';
    let recommendedTimeframes: string[] = [];
    let marketCondition: 'active' | 'moderate' | 'slow' = 'moderate';
    let arabicDescription = '';

    if (assetType === 'crypto') {
      // Crypto markets are 24/7
      if (utcHour >= 8 && utcHour < 16) {
        currentSession = 'London/European';
        nextSession = 'New York';
        volatilityLevel = 'high';
        arabicDescription = 'جلسة لندن - نشاط مرتفع للعملات الرقمية';
      } else if (utcHour >= 16 && utcHour < 22) {
        currentSession = 'New York';
        nextSession = 'Asian';
        volatilityLevel = 'high';
        arabicDescription = 'جلسة نيويورك - أفضل أوقات التداول للعملات الرقمية';
      } else {
        currentSession = 'Asian/Pacific';
        nextSession = 'London';
        volatilityLevel = 'medium';
        arabicDescription = 'جلسة آسيا - نشاط متوسط للعملات الرقمية';
      }
      recommendedTimeframes = ['1م', '2م', '5م', '15م'];
      marketCondition = 'active';
      
    } else if (assetType === 'forex') {
      // Forex market sessions
      if (utcHour >= 0 && utcHour < 7) {
        currentSession = 'Asian (Tokyo)';
        nextSession = 'European (London)';
        volatilityLevel = 'medium';
        arabicDescription = 'جلسة طوكيو - مناسبة لأزواج الين';
        recommendedTimeframes = ['5م', '15م', '30م'];
        marketCondition = 'moderate';
      } else if (utcHour >= 7 && utcHour < 16) {
        currentSession = 'European (London)';
        nextSession = 'American (New York)';
        volatilityLevel = 'high';
        arabicDescription = 'جلسة لندن - أفضل وقت لتداول العملات الأوروبية';
        recommendedTimeframes = ['1م', '2م', '5م'];
        marketCondition = 'active';
      } else if (utcHour >= 16 && utcHour < 21) {
        currentSession = 'American (New York)';
        nextSession = 'Asian (Tokyo)';
        volatilityLevel = 'high';
        arabicDescription = 'جلسة نيويورك - تداول مكثف للدولار الأمريكي';
        recommendedTimeframes = ['1م', '2م', '5م'];
        marketCondition = 'active';
      } else {
        currentSession = 'Market Transition';
        nextSession = 'Asian (Tokyo)';
        volatilityLevel = 'low';
        arabicDescription = 'فترة انتقالية - حذر من انخفاض السيولة';
        recommendedTimeframes = ['15م', '30م', '1س'];
        marketCondition = 'slow';
      }
      
    } else if (assetType === 'stock' || assetType === 'index') {
      // Stock market hours
      if (utcHour >= 14 && utcHour < 21) {
        currentSession = 'US Market Open';
        nextSession = 'After Hours';
        volatilityLevel = 'high';
        arabicDescription = 'افتتاح السوق الأمريكي - أعلى نشاط للأسهم';
        recommendedTimeframes = ['1م', '2م', '5م'];
        marketCondition = 'active';
      } else if (utcHour >= 8 && utcHour < 14) {
        currentSession = 'European Markets';
        nextSession = 'US Pre-Market';
        volatilityLevel = 'medium';
        arabicDescription = 'الأسواق الأوروبية مفتوحة';
        recommendedTimeframes = ['2م', '5م', '15م'];
        marketCondition = 'moderate';
      } else {
        currentSession = 'Market Closed';
        nextSession = 'Asian Markets';
        volatilityLevel = 'low';
        arabicDescription = 'الأسواق مغلقة - تداول محدود';
        recommendedTimeframes = ['15م', '30م', '1س'];
        marketCondition = 'slow';
      }
      
    } else if (assetType === 'commodity') {
      // Commodity trading hours
      if (utcHour >= 7 && utcHour < 20) {
        currentSession = 'Active Trading';
        nextSession = 'Overnight';
        volatilityLevel = 'high';
        arabicDescription = 'ساعات التداول النشطة للسلع';
        recommendedTimeframes = ['2م', '5م', '15م'];
        marketCondition = 'active';
      } else {
        currentSession = 'Limited Trading';
        nextSession = 'Active Trading';
        volatilityLevel = 'low';
        arabicDescription = 'تداول محدود للسلع';
        recommendedTimeframes = ['15م', '30م', '1س'];
        marketCondition = 'slow';
      }
    }

    return {
      currentSession,
      nextSession,
      volatilityLevel,
      recommendedTimeframes,
      marketCondition,
      arabicDescription
    };
  }

  // Determine best duration for trades based on market conditions
  getOptimalTradeDuration(volatilityLevel: 'high' | 'medium' | 'low', assetType: string): {
    duration: string;
    reasoning: string;
  } {
    const durations = {
      high: {
        crypto: { duration: '2 دقيقة', reasoning: 'تقلبات عالية - مدة قصيرة للاستفادة السريعة' },
        forex: { duration: '1 دقيقة', reasoning: 'سيولة مرتفعة - استغلال التحركات السريعة' },
        stock: { duration: '3 دقائق', reasoning: 'نشاط مرتفع - مدة متوسطة للاستقرار' },
        commodity: { duration: '5 دقائق', reasoning: 'تحركات قوية - مدة أطول للتأكيد' },
        index: { duration: '2 دقيقة', reasoning: 'تحرك المؤشرات سريع' }
      },
      medium: {
        crypto: { duration: '5 دقائق', reasoning: 'تقلبات متوسطة - وقت كافي لتطور الاتجاه' },
        forex: { duration: '3 دقائق', reasoning: 'نشاط معتدل - توازن بين السرعة والاستقرار' },
        stock: { duration: '5 دقائق', reasoning: 'نشاط متوسط - انتظار تطور الحركة' },
        commodity: { duration: '10 دقائق', reasoning: 'تحركات بطيئة - وقت أطول للتأكيد' },
        index: { duration: '5 دقائق', reasoning: 'تحرك متوسط للمؤشرات' }
      },
      low: {
        crypto: { duration: '10 دقائق', reasoning: 'تقلبات منخفضة - انتظار فرص أفضل' },
        forex: { duration: '15 دقيقة', reasoning: 'سيولة منخفضة - مدة أطول للتأكد' },
        stock: { duration: '30 دقيقة', reasoning: 'السوق مغلق أو بطيء' },
        commodity: { duration: '1 ساعة', reasoning: 'حركة محدودة - صبر أكثر' },
        index: { duration: '30 دقيقة', reasoning: 'حركة بطيئة للمؤشرات' }
      }
    };

    const volatilityData = durations[volatilityLevel];
    const assetData = volatilityData[assetType as keyof typeof volatilityData];
    return assetData || { duration: '5 دقائق', reasoning: 'مدة افتراضية متوازنة' };
  }

  // Economic calendar impact assessment
  getEconomicImpact(symbol: string): {
    hasHighImpactNews: boolean;
    newsEvents: string[];
    tradingAdvice: string;
    riskLevel: 'high' | 'medium' | 'low';
  } {
    const now = new Date();
    const dayOfWeek = now.getDay();
    const hour = now.getHours();
    
    // Simulate economic calendar data (in real implementation, this would fetch from economic calendar API)
    const highImpactHours = [8, 10, 14, 16, 20]; // Common news release times
    const hasHighImpactNews = highImpactHours.includes(hour);
    
    let newsEvents: string[] = [];
    let tradingAdvice = '';
    let riskLevel: 'high' | 'medium' | 'low' = 'low';

    if (hasHighImpactNews) {
      newsEvents = ['تقرير البطالة الأمريكي', 'بيانات التضخم', 'قرارات البنك المركزي'];
      tradingAdvice = 'حذر شديد - توقع تقلبات حادة خلال النصف ساعة القادمة';
      riskLevel = 'high';
    } else if (dayOfWeek === 1 || dayOfWeek === 5) {
      // Monday or Friday
      newsEvents = ['بداية/نهاية الأسبوع'];
      tradingAdvice = 'حذر متوسط - قد تحدث تحركات غير متوقعة';
      riskLevel = 'medium';
    } else {
      tradingAdvice = 'ظروف طبيعية للتداول';
      riskLevel = 'low';
    }

    return {
      hasHighImpactNews,
      newsEvents,
      tradingAdvice,
      riskLevel
    };
  }

  private getAssetType(symbol: string): string {
    if (symbol.includes('/')) {
      if (symbol.includes('BTC') || symbol.includes('ETH') || symbol.includes('LTC')) return 'crypto';
      if (symbol.includes('XAU') || symbol.includes('XAG') || symbol.includes('CRUDE')) return 'commodity';
      return 'forex';
    }
    if (['SPX', 'DJI', 'IXIC', 'FTSE', 'DAX'].includes(symbol)) return 'index';
    if (['AAPL', 'GOOGL', 'MSFT', 'TSLA'].includes(symbol)) return 'stock';
    return 'forex';
  }

  // Generate time-based confidence adjustment
  getTimeBasedConfidence(symbol: string): {
    adjustment: number;
    reasoning: string;
  } {
    const timing = this.getOptimalTradingTimes(symbol);
    const economic = this.getEconomicImpact(symbol);
    
    let adjustment = 0;
    let reasoning = '';

    // Market condition adjustments
    if (timing.marketCondition === 'active') {
      adjustment += 10;
      reasoning += 'السوق نشط (+10). ';
    } else if (timing.marketCondition === 'slow') {
      adjustment -= 15;
      reasoning += 'السوق بطيء (-15). ';
    }

    // Volatility adjustments
    if (timing.volatilityLevel === 'high') {
      adjustment += 5;
      reasoning += 'تقلبات عالية (+5). ';
    } else if (timing.volatilityLevel === 'low') {
      adjustment -= 10;
      reasoning += 'تقلبات منخفضة (-10). ';
    }

    // Economic news adjustments
    if (economic.hasHighImpactNews) {
      adjustment -= 20;
      reasoning += 'أخبار مهمة متوقعة (-20). ';
    }

    return {
      adjustment: Math.max(-30, Math.min(20, adjustment)),
      reasoning: reasoning.trim()
    };
  }
}

export const marketTimingService = new MarketTimingService();
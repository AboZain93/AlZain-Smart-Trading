import { storage } from '../storage';
import { 
  type TelegramFeedback, 
  type MlTrainingData, 
  type AssetPerformance, 
  type TradingRecommendation,
  type InsertMlTrainingData,
  type InsertAssetPerformance
} from '@shared/schema';

export class MlLearningService {
  // Convert feedback result to success score
  private getSuccessScore(feedbackType: string): number {
    switch (feedbackType.toLowerCase()) {
      case 'success': return 1.0;
      case 'partial': return 0.5;
      case 'failure': return 0.0;
      default: return 0.0;
    }
  }

  // Process Telegram feedback and create training data
  async processTelegramFeedback(feedback: TelegramFeedback): Promise<void> {
    try {
      // Get the original recommendation
      const recommendation = feedback.recommendationId 
        ? await storage.getTradingRecommendation(feedback.recommendationId)
        : null;

      if (!recommendation) {
        console.warn('No recommendation found for feedback:', feedback.id);
        return;
      }

      // Get current technical indicators for the asset
      const technicalIndicators = await storage.getTechnicalIndicatorsBySymbol(feedback.assetSymbol);
      const marketData = await storage.getMarketDataBySymbol(feedback.assetSymbol);

      // Create ML training data
      const trainingData: InsertMlTrainingData = {
        recommendationId: recommendation.id,
        assetSymbol: feedback.assetSymbol,
        direction: feedback.direction,
        originalConfidence: feedback.confidence || recommendation.confidence,
        technicalIndicators: technicalIndicators ? {
          rsi: technicalIndicators.rsi,
          macd: technicalIndicators.macd,
          ma20: technicalIndicators.ma20,
          ma50: technicalIndicators.ma50,
          signal: technicalIndicators.signal
        } : null,
        marketConditions: {
          riskLevel: recommendation.riskLevel,
          marketStatus: recommendation.marketStatus,
          trend: recommendation.trend,
          liquidity: recommendation.liquidity,
          price: marketData?.price,
          changePercent: marketData?.changePercent
        },
        timingFactors: {
          duration: recommendation.duration,
          entryTime: recommendation.entryTime,
          responseTime: feedback.responseTime,
          dayOfWeek: new Date().getDay(),
          hourOfDay: new Date().getHours()
        },
        actualResult: feedback.feedbackType,
        successScore: this.getSuccessScore(feedback.feedbackType),
        learningWeight: this.calculateLearningWeight(feedback)
      };

      await storage.createMlTrainingData(trainingData);
      
      // Update asset performance metrics
      await this.updateAssetPerformance(feedback.assetSymbol, feedback.feedbackType);
      
      console.log('Successfully processed feedback for ML learning:', {
        asset: feedback.assetSymbol,
        result: feedback.feedbackType,
        confidence: feedback.confidence
      });

    } catch (error) {
      console.error('Error processing telegram feedback for ML:', error);
    }
  }

  // Calculate learning weight based on feedback quality
  private calculateLearningWeight(feedback: TelegramFeedback): number {
    let weight = 1.0;

    // Higher weight for faster responses (more reliable)
    if (feedback.responseTime && feedback.responseTime < 30) {
      weight += 0.2; // Quick response bonus
    }

    // Higher weight for extreme confidence levels
    if (feedback.confidence) {
      if (feedback.confidence >= 90 || feedback.confidence <= 30) {
        weight += 0.1; // Extreme confidence bonus
      }
    }

    return Math.min(weight, 2.0); // Cap at 2.0
  }

  // Update asset performance metrics
  async updateAssetPerformance(assetSymbol: string, result: string): Promise<void> {
    try {
      let performance = await storage.getAssetPerformance(assetSymbol);

      if (!performance) {
        // Create new performance record
        const newPerformance: InsertAssetPerformance = {
          assetSymbol,
          totalRecommendations: 1,
          successfulTrades: result === 'success' ? 1 : 0,
          partialSuccessTrades: result === 'partial' ? 1 : 0,
          failedTrades: result === 'failure' ? 1 : 0,
          averageConfidence: 0, // Will be calculated later
          successRate: result === 'success' ? 100 : 0,
          adjustedSuccessRate: this.calculateAdjustedSuccessRate(
            result === 'success' ? 1 : 0,
            result === 'partial' ? 1 : 0,
            1
          )
        };
        
        await storage.createAssetPerformance(newPerformance);
      } else {
        // Update existing performance
        const newTotal = (performance.totalRecommendations || 0) + 1;
        const newSuccessful = (performance.successfulTrades || 0) + (result === 'success' ? 1 : 0);
        const newPartial = (performance.partialSuccessTrades || 0) + (result === 'partial' ? 1 : 0);
        const newFailed = (performance.failedTrades || 0) + (result === 'failure' ? 1 : 0);

        const successRate = (newSuccessful / newTotal) * 100;
        const adjustedSuccessRate = this.calculateAdjustedSuccessRate(newSuccessful, newPartial, newTotal);

        await storage.updateAssetPerformance(assetSymbol, {
          totalRecommendations: newTotal,
          successfulTrades: newSuccessful,
          partialSuccessTrades: newPartial,
          failedTrades: newFailed,
          successRate,
          adjustedSuccessRate
        });
      }
    } catch (error) {
      console.error('Error updating asset performance:', error);
    }
  }

  // Calculate adjusted success rate (partial = 0.5 success)
  private calculateAdjustedSuccessRate(successful: number, partial: number, total: number): number {
    if (total === 0) return 0;
    return ((successful + (partial * 0.5)) / total) * 100;
  }

  // Get recommendations for improving confidence
  async getConfidenceAdjustments(assetSymbol: string): Promise<{
    baseConfidence: number;
    adjustment: number;
    reason: string;
  }> {
    try {
      const performance = await storage.getAssetPerformance(assetSymbol);
      const recentTraining = await storage.getMlTrainingDataByAsset(assetSymbol, 10);

      let adjustment = 0;
      let reason = 'No historical data available';

      if (performance && performance.totalRecommendations && performance.totalRecommendations > 3) {
        const successRate = performance.adjustedSuccessRate || 0;
        
        if (successRate > 80) {
          adjustment = +5; // Increase confidence for high-performing assets
          reason = `High success rate (${successRate.toFixed(1)}%) - increasing confidence`;
        } else if (successRate < 40) {
          adjustment = -10; // Decrease confidence for poor-performing assets
          reason = `Low success rate (${successRate.toFixed(1)}%) - decreasing confidence`;
        } else {
          reason = `Moderate success rate (${successRate.toFixed(1)}%) - maintaining confidence`;
        }
      }

      // Check recent trend
      if (recentTraining.length >= 3) {
        const recentSuccess = recentTraining.slice(0, 3).reduce((sum, data) => sum + data.successScore, 0) / 3;
        
        if (recentSuccess > 0.8) {
          adjustment += 3;
          reason += ' + recent improvement trend';
        } else if (recentSuccess < 0.3) {
          adjustment -= 5;
          reason += ' + recent decline trend';
        }
      }

      return {
        baseConfidence: 70, // Default base confidence
        adjustment: Math.max(-20, Math.min(15, adjustment)), // Cap adjustments
        reason
      };

    } catch (error) {
      console.error('Error calculating confidence adjustments:', error);
      return {
        baseConfidence: 70,
        adjustment: 0,
        reason: 'Error calculating adjustments'
      };
    }
  }

  // Get asset recommendations sorted by performance
  async getAssetRecommendations(): Promise<{
    topPerformers: string[];
    averagePerformers: string[];
    poorPerformers: string[];
  }> {
    try {
      const allPerformance = await storage.getAllAssetPerformance();
      
      // Filter assets with enough data
      const significantAssets = allPerformance.filter(
        p => (p.totalRecommendations || 0) >= 3
      );

      const topPerformers = significantAssets
        .filter(p => (p.adjustedSuccessRate || 0) >= 75)
        .sort((a, b) => (b.adjustedSuccessRate || 0) - (a.adjustedSuccessRate || 0))
        .map(p => p.assetSymbol);

      const poorPerformers = significantAssets
        .filter(p => (p.adjustedSuccessRate || 0) <= 40)
        .sort((a, b) => (a.adjustedSuccessRate || 0) - (b.adjustedSuccessRate || 0))
        .map(p => p.assetSymbol);

      const averagePerformers = significantAssets
        .filter(p => {
          const rate = p.adjustedSuccessRate || 0;
          return rate > 40 && rate < 75;
        })
        .map(p => p.assetSymbol);

      return {
        topPerformers,
        averagePerformers,
        poorPerformers
      };

    } catch (error) {
      console.error('Error getting asset recommendations:', error);
      return {
        topPerformers: [],
        averagePerformers: [],
        poorPerformers: []
      };
    }
  }

  // Generate insights for improving recommendations
  async generateLearningInsights(): Promise<{
    totalFeedback: number;
    overallSuccessRate: number;
    topAssets: Array<{ symbol: string; successRate: number; totalTrades: number }>;
    improvementSuggestions: string[];
  }> {
    try {
      const allPerformance = await storage.getAllAssetPerformance();
      const allTraining = await storage.getAllMlTrainingData(100);

      const totalFeedback = allTraining.length;
      const overallSuccessRate = totalFeedback > 0 
        ? (allTraining.reduce((sum, data) => sum + data.successScore, 0) / totalFeedback) * 100
        : 0;

      const topAssets = allPerformance
        .filter(p => (p.totalRecommendations || 0) >= 5)
        .sort((a, b) => (b.adjustedSuccessRate || 0) - (a.adjustedSuccessRate || 0))
        .slice(0, 5)
        .map(p => ({
          symbol: p.assetSymbol,
          successRate: p.adjustedSuccessRate || 0,
          totalTrades: p.totalRecommendations || 0
        }));

      const suggestions: string[] = [];

      // Generate improvement suggestions
      if (overallSuccessRate < 60) {
        suggestions.push('Overall performance is below target - consider adjusting technical analysis parameters');
      }

      if (topAssets.length < 3) {
        suggestions.push('Not enough trading data - focus on gathering more feedback');
      }

      const highVolumeAssets = allTraining
        .reduce((acc, data) => {
          acc[data.assetSymbol] = (acc[data.assetSymbol] || 0) + 1;
          return acc;
        }, {} as Record<string, number>);

      const mostTradedAsset = Object.entries(highVolumeAssets)
        .sort(([,a], [,b]) => b - a)[0];

      if (mostTradedAsset && mostTradedAsset[1] > 10) {
        const assetPerformance = allPerformance.find(p => p.assetSymbol === mostTradedAsset[0]);
        if (assetPerformance && (assetPerformance.adjustedSuccessRate || 0) > 70) {
          suggestions.push(`Focus more on ${mostTradedAsset[0]} - high volume with good performance`);
        }
      }

      return {
        totalFeedback,
        overallSuccessRate,
        topAssets,
        improvementSuggestions: suggestions
      };

    } catch (error) {
      console.error('Error generating learning insights:', error);
      return {
        totalFeedback: 0,
        overallSuccessRate: 0,
        topAssets: [],
        improvementSuggestions: ['Error generating insights']
      };
    }
  }

  // Advanced confidence calculation using ML insights
  async calculateAdvancedConfidence(
    assetSymbol: string,
    direction: string,
    baseConfidence: number,
    technicalIndicators: any
  ): Promise<{ 
    adjustedConfidence: number; 
    reasoning: string[];
    qualityScore: number;
  }> {
    try {
      const performance = await storage.getAssetPerformance(assetSymbol);
      const recentTraining = await storage.getMlTrainingDataByAsset(assetSymbol, 5);
      
      let adjustment = 0;
      const reasoning: string[] = [];
      let qualityScore = 0.5; // Base quality

      // Asset-specific performance adjustment
      if (performance && performance.totalRecommendations && performance.totalRecommendations >= 3) {
        const successRate = performance.adjustedSuccessRate || 0;
        
        if (successRate > 80) {
          adjustment += 8;
          reasoning.push(`Asset has high success rate (${successRate.toFixed(1)}%)`);
          qualityScore += 0.2;
        } else if (successRate < 40) {
          adjustment -= 15;
          reasoning.push(`Asset has low success rate (${successRate.toFixed(1)}%)`);
          qualityScore -= 0.3;
        } else {
          reasoning.push(`Asset has moderate success rate (${successRate.toFixed(1)}%)`);
        }
      } else {
        adjustment -= 5;
        reasoning.push('Limited historical data for this asset');
        qualityScore -= 0.1;
      }

      // Direction-specific analysis
      const directionSpecificData = recentTraining.filter(data => data.direction === direction);
      if (directionSpecificData.length >= 2) {
        const directionSuccess = directionSpecificData.reduce((sum, data) => sum + data.successScore, 0) / directionSpecificData.length;
        
        if (directionSuccess > 0.7) {
          adjustment += 5;
          reasoning.push(`Strong ${direction} signal performance for this asset`);
          qualityScore += 0.15;
        } else if (directionSuccess < 0.3) {
          adjustment -= 8;
          reasoning.push(`Weak ${direction} signal performance for this asset`);
          qualityScore -= 0.2;
        }
      }

      // Technical indicators strength
      if (technicalIndicators) {
        let technicalStrength = 0;
        let technicalCount = 0;

        // RSI analysis
        if (technicalIndicators.rsi) {
          technicalCount++;
          if ((direction === 'BUY' && technicalIndicators.rsi < 35) || 
              (direction === 'SELL' && technicalIndicators.rsi > 65)) {
            technicalStrength += 1;
            reasoning.push('RSI supports the signal direction');
          } else if ((direction === 'BUY' && technicalIndicators.rsi > 65) || 
                     (direction === 'SELL' && technicalIndicators.rsi < 35)) {
            technicalStrength -= 0.5;
            reasoning.push('RSI contradicts the signal direction');
          }
        }

        // MACD analysis
        if (technicalIndicators.macd) {
          technicalCount++;
          if ((direction === 'BUY' && technicalIndicators.macd > 0) || 
              (direction === 'SELL' && technicalIndicators.macd < 0)) {
            technicalStrength += 1;
            reasoning.push('MACD aligns with signal direction');
          } else {
            technicalStrength -= 0.5;
            reasoning.push('MACD diverges from signal direction');
          }
        }

        // Calculate technical adjustment
        if (technicalCount > 0) {
          const technicalScore = technicalStrength / technicalCount;
          adjustment += technicalScore * 10;
          qualityScore += technicalScore * 0.2;
        }
      }

      // Time-based analysis
      const currentHour = new Date().getUTCHours();
      if (currentHour >= 8 && currentHour <= 16) { // London/NY session
        adjustment += 3;
        reasoning.push('Trading during high-activity market hours');
        qualityScore += 0.1;
      } else if (currentHour >= 0 && currentHour <= 6) { // Asian session
        adjustment -= 2;
        reasoning.push('Trading during low-activity Asian session');
        qualityScore -= 0.05;
      }

      // Market volatility consideration
      const recentFeedback = await storage.getAllTelegramFeedback(20);
      const recentSuccessRate = recentFeedback.length > 0 
        ? recentFeedback.filter(f => f.feedbackType === 'success').length / recentFeedback.length
        : 0.5;

      if (recentSuccessRate > 0.7) {
        adjustment += 5;
        reasoning.push('Recent market conditions favorable');
        qualityScore += 0.1;
      } else if (recentSuccessRate < 0.3) {
        adjustment -= 5;
        reasoning.push('Recent market conditions challenging');
        qualityScore -= 0.1;
      }

      // Calculate final confidence
      const adjustedConfidence = Math.max(30, Math.min(95, baseConfidence + adjustment));
      const finalQualityScore = Math.max(0.1, Math.min(1.0, qualityScore));

      return {
        adjustedConfidence,
        reasoning,
        qualityScore: finalQualityScore
      };

    } catch (error) {
      console.error('Error calculating advanced confidence:', error);
      return {
        adjustedConfidence: baseConfidence,
        reasoning: ['Error in confidence calculation - using base confidence'],
        qualityScore: 0.5
      };
    }
  }

  // Real-time learning from feedback patterns
  async updateRealtimeLearning(feedback: TelegramFeedback): Promise<void> {
    try {
      // Get recent similar trades
      const similarTrades = await storage.getMlTrainingDataByAsset(feedback.assetSymbol, 10);
      
      if (similarTrades.length >= 3) {
        // Calculate trending performance
        const recentSuccessRate = similarTrades.slice(0, 3).reduce((sum, data) => sum + data.successScore, 0) / 3;
        const olderSuccessRate = similarTrades.slice(3, 6).reduce((sum, data) => sum + data.successScore, 0) / Math.max(1, similarTrades.slice(3, 6).length);
        
        const trend = recentSuccessRate - olderSuccessRate;
        
        if (Math.abs(trend) > 0.3) {
          console.log(`📊 Performance trend detected for ${feedback.assetSymbol}: ${trend > 0 ? 'improving' : 'declining'} (${(trend * 100).toFixed(1)}%)`);
          
          // Update system settings for dynamic adjustments
          await storage.updateSystemSetting(
            `ml_trend_${feedback.assetSymbol}`,
            JSON.stringify({
              trend: trend > 0 ? 'improving' : 'declining',
              strength: Math.abs(trend),
              lastUpdated: new Date().toISOString()
            }),
            `ML trend analysis for ${feedback.assetSymbol}`
          );
        }
      }

      // Pattern recognition for time-based performance
      const timingData = similarTrades.map(trade => ({
        hour: trade.createdAt ? new Date(trade.createdAt).getUTCHours() : new Date().getUTCHours(),
        success: trade.successScore
      }));

      if (timingData.length >= 5) {
        const hourlyPerformance = timingData.reduce((acc, data) => {
          acc[data.hour] = acc[data.hour] || { total: 0, success: 0 };
          acc[data.hour].total++;
          acc[data.hour].success += data.success;
          return acc;
        }, {} as Record<number, { total: number; success: number }>);

        // Find best and worst performing hours
        const hourlyRates = Object.entries(hourlyPerformance)
          .filter(([, data]) => data.total >= 2)
          .map(([hour, data]) => ({
            hour: parseInt(hour),
            rate: data.success / data.total
          }));

        if (hourlyRates.length >= 2) {
          const bestHour = hourlyRates.reduce((best, current) => 
            current.rate > best.rate ? current : best
          );
          
          const worstHour = hourlyRates.reduce((worst, current) => 
            current.rate < worst.rate ? current : worst
          );

          console.log(`⏰ Time analysis for ${feedback.assetSymbol}: Best hour ${bestHour.hour} (${(bestHour.rate * 100).toFixed(1)}%), Worst hour ${worstHour.hour} (${(worstHour.rate * 100).toFixed(1)}%)`);
        }
      }

    } catch (error) {
      console.error('Error in realtime learning update:', error);
    }
  }
}

export const mlLearningService = new MlLearningService();
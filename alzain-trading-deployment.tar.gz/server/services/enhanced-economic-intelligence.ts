import { storage } from '../storage';

export interface EconomicEvent {
  id: number;
  title: string;
  description: string;
  currency: string;
  importance: 'low' | 'medium' | 'high';
  actual?: number;
  forecast?: number;
  previous?: number;
  timestamp: Date;
  impact: 'bearish' | 'bullish' | 'neutral';
  affectedAssets: string[];
}

export interface MarketSentiment {
  asset: string;
  sentiment: number; // -100 to 100
  confidence: number; // 0 to 100
  factors: string[];
  timestamp: Date;
}

export interface EconomicIntelligence {
  marketRegime: 'bull' | 'bear' | 'sideways';
  riskAppetite: 'risk-on' | 'risk-off' | 'neutral';
  volatilityExpectation: 'low' | 'medium' | 'high';
  keyDrivers: string[];
  upcomingEvents: EconomicEvent[];
  marketSentiments: MarketSentiment[];
  tradingRecommendations: string[];
}

class EnhancedEconomicIntelligenceService {
  private economicEvents: EconomicEvent[] = [];
  private marketSentiments: Map<string, MarketSentiment> = new Map();
  
  constructor() {
    this.initializeEconomicData();
    this.startRealTimeUpdates();
  }

  private initializeEconomicData() {
    // Initialize with current week's major economic events
    const now = new Date();
    const events: Omit<EconomicEvent, 'id'>[] = [
      {
        title: "US NFP (Non-Farm Payrolls)",
        description: "Monthly employment data release showing job creation",
        currency: "USD",
        importance: "high",
        forecast: 185000,
        previous: 199000,
        timestamp: new Date(now.getTime() + 2 * 24 * 60 * 60 * 1000),
        impact: "neutral",
        affectedAssets: ["EUR/USD", "GBP/USD", "USD/JPY", "DXY"]
      },
      {
        title: "ECB Interest Rate Decision",
        description: "European Central Bank monetary policy meeting",
        currency: "EUR",
        importance: "high",
        forecast: 4.50,
        previous: 4.50,
        timestamp: new Date(now.getTime() + 3 * 24 * 60 * 60 * 1000),
        impact: "neutral",
        affectedAssets: ["EUR/USD", "EUR/GBP", "EUR/JPY"]
      },
      {
        title: "US CPI (Consumer Price Index)",
        description: "Monthly inflation data",
        currency: "USD",
        importance: "high",
        forecast: 2.4,
        previous: 2.6,
        timestamp: new Date(now.getTime() + 1 * 24 * 60 * 60 * 1000),
        impact: "bearish",
        affectedAssets: ["USD/JPY", "EUR/USD", "GBP/USD"]
      },
      {
        title: "UK GDP Growth Rate",
        description: "Quarterly economic growth data",
        currency: "GBP",
        importance: "medium",
        forecast: 0.2,
        previous: 0.1,
        timestamp: new Date(now.getTime() + 4 * 24 * 60 * 60 * 1000),
        impact: "bullish",
        affectedAssets: ["GBP/USD", "EUR/GBP", "GBP/JPY"]
      },
      {
        title: "Fed Chair Powell Speech",
        description: "Federal Reserve Chairman speaking at Jackson Hole",
        currency: "USD",
        importance: "high",
        timestamp: new Date(now.getTime() + 5 * 24 * 60 * 60 * 1000),
        impact: "neutral",
        affectedAssets: ["EUR/USD", "GBP/USD", "USD/JPY", "DXY"]
      }
    ];

    this.economicEvents = events.map((event, index) => ({
      id: index + 1,
      ...event
    }));
  }

  private startRealTimeUpdates() {
    // Update market sentiments every 5 minutes
    setInterval(() => {
      this.updateMarketSentiments();
    }, 5 * 60 * 1000);

    // Check for new economic events every hour
    setInterval(() => {
      this.fetchLatestEconomicEvents();
    }, 60 * 60 * 1000);
  }

  private async updateMarketSentiments() {
    const assets = ["EUR/USD", "GBP/USD", "USD/JPY", "AUD/USD", "USD/CAD", "BTC/USD", "ETH/USD"];
    
    for (const asset of assets) {
      const sentiment = this.calculateMarketSentiment(asset);
      this.marketSentiments.set(asset, sentiment);
    }
  }

  private calculateMarketSentiment(asset: string): MarketSentiment {
    // Advanced sentiment calculation based on multiple factors
    const baseFactors = [
      "Technical momentum",
      "Economic fundamentals", 
      "Central bank policy",
      "Market positioning",
      "Risk sentiment"
    ];

    // Simulate dynamic sentiment calculation
    const now = new Date();
    const hourOfDay = now.getHours();
    const dayOfWeek = now.getDay();
    
    // Factor in trading session activity
    let sessionMultiplier = 1;
    if (hourOfDay >= 8 && hourOfDay <= 16) sessionMultiplier = 1.2; // EU session
    if (hourOfDay >= 13 && hourOfDay <= 21) sessionMultiplier = 1.5; // US session
    if (hourOfDay >= 22 || hourOfDay <= 6) sessionMultiplier = 0.8; // Asia session

    // Weekend adjustment
    if (dayOfWeek === 0 || dayOfWeek === 6) sessionMultiplier *= 0.5;

    const baseSentiment = (Math.random() - 0.5) * 100 * sessionMultiplier;
    const confidence = Math.min(95, 60 + Math.abs(baseSentiment) * 0.3);

    return {
      asset,
      sentiment: Math.round(baseSentiment),
      confidence: Math.round(confidence),
      factors: baseFactors.slice(0, 3 + Math.floor(Math.random() * 3)),
      timestamp: now
    };
  }

  private async fetchLatestEconomicEvents() {
    // In production, this would fetch from economic calendar APIs
    // For now, we'll update existing events with "actual" values
    const now = new Date();
    
    this.economicEvents.forEach(event => {
      if (event.timestamp < now && !event.actual && event.forecast) {
        // Simulate actual vs forecast variance
        const variance = (Math.random() - 0.5) * 0.2; // ±10% variance
        event.actual = event.forecast * (1 + variance);
        
        // Update impact based on actual vs forecast
        if (event.actual > event.forecast) {
          event.impact = event.currency === 'USD' ? 'bullish' : 'bearish';
        } else if (event.actual < event.forecast) {
          event.impact = event.currency === 'USD' ? 'bearish' : 'bullish';
        }
      }
    });
  }

  public async getEconomicIntelligence(): Promise<EconomicIntelligence> {
    const marketSentiments = Array.from(this.marketSentiments.values());
    const avgSentiment = marketSentiments.length > 0 
      ? marketSentiments.reduce((sum, s) => sum + s.sentiment, 0) / marketSentiments.length 
      : 0;

    // Determine market regime
    let marketRegime: 'bull' | 'bear' | 'sideways' = 'sideways';
    if (avgSentiment > 30) marketRegime = 'bull';
    else if (avgSentiment < -30) marketRegime = 'bear';

    // Determine risk appetite
    let riskAppetite: 'risk-on' | 'risk-off' | 'neutral' = 'neutral';
    const riskAssets = marketSentiments.filter(s => s.asset.includes('AUD') || s.asset.includes('BTC'));
    const avgRiskSentiment = riskAssets.length > 0 
      ? riskAssets.reduce((sum, s) => sum + s.sentiment, 0) / riskAssets.length 
      : 0;
    
    if (avgRiskSentiment > 20) riskAppetite = 'risk-on';
    else if (avgRiskSentiment < -20) riskAppetite = 'risk-off';

    // Calculate volatility expectation
    const recentEvents = this.economicEvents.filter(
      event => Math.abs(event.timestamp.getTime() - Date.now()) < 24 * 60 * 60 * 1000
    );
    const highImpactEvents = recentEvents.filter(event => event.importance === 'high');
    
    let volatilityExpectation: 'low' | 'medium' | 'high' = 'low';
    if (highImpactEvents.length >= 2) volatilityExpectation = 'high';
    else if (highImpactEvents.length === 1 || recentEvents.length >= 3) volatilityExpectation = 'medium';

    // Generate key drivers
    const keyDrivers = this.generateKeyDrivers(marketRegime, riskAppetite, recentEvents);

    // Generate trading recommendations
    const tradingRecommendations = this.generateTradingRecommendations(
      marketRegime, 
      riskAppetite, 
      volatilityExpectation,
      marketSentiments
    );

    return {
      marketRegime,
      riskAppetite,
      volatilityExpectation,
      keyDrivers,
      upcomingEvents: this.getUpcomingEvents(),
      marketSentiments,
      tradingRecommendations
    };
  }

  private generateKeyDrivers(
    marketRegime: string, 
    riskAppetite: string, 
    recentEvents: EconomicEvent[]
  ): string[] {
    const drivers = [];
    
    if (marketRegime === 'bull') {
      drivers.push("Strong economic momentum driving risk appetite");
    } else if (marketRegime === 'bear') {
      drivers.push("Economic concerns weighing on market sentiment");
    }
    
    if (riskAppetite === 'risk-on') {
      drivers.push("Investors seeking higher-yielding assets");
    } else if (riskAppetite === 'risk-off') {
      drivers.push("Flight to safety in traditional havens");
    }
    
    const highImpactEvents = recentEvents.filter(e => e.importance === 'high');
    if (highImpactEvents.length > 0) {
      drivers.push(`Key focus on ${highImpactEvents[0].title}`);
    }
    
    drivers.push("Central bank policy expectations");
    drivers.push("Global trade developments");
    
    return drivers.slice(0, 4);
  }

  private generateTradingRecommendations(
    marketRegime: string,
    riskAppetite: string,
    volatilityExpectation: string,
    sentiments: MarketSentiment[]
  ): string[] {
    const recommendations = [];
    
    if (marketRegime === 'bull' && riskAppetite === 'risk-on') {
      recommendations.push("Consider long positions in risk currencies (AUD, CAD)");
      recommendations.push("Monitor breakouts in major currency pairs");
    } else if (marketRegime === 'bear' && riskAppetite === 'risk-off') {
      recommendations.push("Focus on safe haven currencies (USD, JPY, CHF)");
      recommendations.push("Consider defensive positioning");
    }
    
    if (volatilityExpectation === 'high') {
      recommendations.push("Implement wider stop losses due to increased volatility");
      recommendations.push("Consider volatility-based trading strategies");
    }
    
    // Asset-specific recommendations based on sentiment
    const strongBullish = sentiments.filter(s => s.sentiment > 50 && s.confidence > 70);
    const strongBearish = sentiments.filter(s => s.sentiment < -50 && s.confidence > 70);
    
    if (strongBullish.length > 0) {
      recommendations.push(`Bullish bias on ${strongBullish[0].asset}`);
    }
    if (strongBearish.length > 0) {
      recommendations.push(`Bearish bias on ${strongBearish[0].asset}`);
    }
    
    return recommendations.slice(0, 5);
  }

  private getUpcomingEvents(): EconomicEvent[] {
    const now = new Date();
    const next48Hours = new Date(now.getTime() + 48 * 60 * 60 * 1000);
    
    return this.economicEvents
      .filter(event => event.timestamp > now && event.timestamp <= next48Hours)
      .sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime())
      .slice(0, 5);
  }

  public async getEconomicEvents(): Promise<EconomicEvent[]> {
    return this.economicEvents.sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime());
  }

  public async getMarketSentiment(asset: string): Promise<MarketSentiment | undefined> {
    return this.marketSentiments.get(asset);
  }

  public async getAllMarketSentiments(): Promise<MarketSentiment[]> {
    return Array.from(this.marketSentiments.values());
  }

  // Economic impact analysis for trading recommendations
  public analyzeEconomicImpact(asset: string): {
    impactScore: number;
    riskLevel: 'low' | 'medium' | 'high';
    timeframe: string;
    description: string;
  } {
    const sentiment = this.marketSentiments.get(asset);
    const upcomingEvents = this.getUpcomingEvents();
    const relevantEvents = upcomingEvents.filter(event => 
      event.affectedAssets.includes(asset)
    );

    let impactScore = 0;
    if (sentiment) {
      impactScore = Math.abs(sentiment.sentiment) * (sentiment.confidence / 100);
    }

    // Factor in upcoming events
    const highImpactEvents = relevantEvents.filter(e => e.importance === 'high');
    if (highImpactEvents.length > 0) {
      impactScore += 30;
    }

    let riskLevel: 'low' | 'medium' | 'high' = 'low';
    if (impactScore > 60) riskLevel = 'high';
    else if (impactScore > 30) riskLevel = 'medium';

    const timeframe = relevantEvents.length > 0 
      ? `Next ${Math.ceil((relevantEvents[0].timestamp.getTime() - Date.now()) / (60 * 60 * 1000))} hours`
      : "24-48 hours";

    const description = relevantEvents.length > 0
      ? `${relevantEvents[0].title} expected to impact ${asset}`
      : `Standard market conditions for ${asset}`;

    return {
      impactScore: Math.round(impactScore),
      riskLevel,
      timeframe,
      description
    };
  }
}

export const enhancedEconomicIntelligence = new EnhancedEconomicIntelligenceService();
import axios from 'axios';

export class TelegramBotService {
  private botToken: string;
  private userId: string;
  private baseUrl: string;

  constructor() {
    this.botToken = process.env.TELEGRAM_BOT_TOKEN || '7941519639:AAHTOAxOP61HiV1bYsM8ICEw3YV4X1qsMno';
    this.userId = process.env.TELEGRAM_USER_ID || '1039954480';
    this.baseUrl = `https://api.telegram.org/bot${this.botToken}`;
  }

  async sendMessage(message: string, options?: {
    parse_mode?: 'HTML' | 'Markdown';
    reply_markup?: any;
  }): Promise<boolean> {
    try {
      const response = await axios.post(`${this.baseUrl}/sendMessage`, {
        chat_id: this.userId,
        text: message,
        parse_mode: options?.parse_mode || 'HTML',
        reply_markup: options?.reply_markup,
      });

      return response.data.ok;
    } catch (error) {
      console.error('Error sending Telegram message:', error);
      return false;
    }
  }

  async sendTradingRecommendation(recommendation: {
    assetSymbol: string;
    direction: string;
    confidence: number;
    riskLevel: string;
    technicalAnalysis: string;
    trend: string;
    liquidity: string;
    entryTime: string;
    marketStatus: string;
    duration?: string;
    marketCondition?: string;
    supportResistance?: {
      support: number;
      resistance: number;
      nearLevel: boolean;
    };
    strength?: string;
    timingAnalysis?: string;
  }): Promise<boolean> {
    const directionEmoji = recommendation.direction === 'BUY' ? '📈🟢' : '📉🔴';
    const riskEmoji = recommendation.riskLevel === 'low' ? '🟢' : 
                      recommendation.riskLevel === 'medium' ? '🟡' : '🔴';
    
    // Get confidence level emoji
    const confidenceEmoji = recommendation.confidence >= 90 ? '🔥' :
                           recommendation.confidence >= 80 ? '⭐' :
                           recommendation.confidence >= 70 ? '👍' : '⚠️';

    // Build enhanced message
    let message = `
🚀 <b>توصية تداول محسّنة بالذكاء الاصطناعي</b>

💎 <b>الأصل:</b> ${recommendation.assetSymbol} (${this.getAssetType(recommendation.assetSymbol)})
${directionEmoji} <b>الاتجاه:</b> ${recommendation.direction}
⏳ <b>مدة الصفقة المقترحة:</b> ${recommendation.duration || '5 دقائق'}
${confidenceEmoji} <b>نسبة الثقة:</b> ${recommendation.confidence}%
${riskEmoji} <b>درجة المخاطرة:</b> ${recommendation.riskLevel}
💪 <b>قوة الإشارة:</b> ${recommendation.strength || 'متوسطة'}

📊 <b>التحليل التقني:</b>
${recommendation.technicalAnalysis}

🌍 <b>حالة السوق:</b> ${recommendation.marketCondition || recommendation.marketStatus}
⏰ <b>وقت الدخول:</b> ${recommendation.entryTime}
    `;

    // Add support/resistance levels if available
    if (recommendation.supportResistance) {
      message += `
🎯 <b>مستويات مهمة:</b>
📌 الدعم: ${recommendation.supportResistance.support.toFixed(4)}
📌 المقاومة: ${recommendation.supportResistance.resistance.toFixed(4)}
${recommendation.supportResistance.nearLevel ? '⚡ <b>السعر قرب مستوى مهم!</b>' : ''}
      `;
    }

    message += `
🎯 <b>نصائح للتداول:</b>
• ${recommendation.direction === 'BUY' ? 'ابحث عن إشارات الدعم للدخول' : 'انتظر اختبار المقاومة للدخول'}
• ${recommendation.confidence >= 80 ? 'إشارة قوية - يمكن زيادة حجم الصفقة' : 'إشارة متوسطة - التزم بإدارة المخاطر'}

#الزين_التجاري #كيوتكس #تداول_ذكي
    `.trim();

    const keyboard = {
      inline_keyboard: [
        [
          { text: '✅ نجحت', callback_data: 'success' },
          { text: '🟡 جزئياً', callback_data: 'partial' },
          { text: '❌ فشلت', callback_data: 'failure' }
        ],
        [
          { text: '📊 تحليل إضافي', callback_data: `analysis_${recommendation.assetSymbol}` },
          { text: '⏰ تنبيه متابعة', callback_data: `reminder_${Date.now()}` }
        ],
        [
          { text: '🔄 طلب توصية جديدة', callback_data: `new_signal_${recommendation.assetSymbol}` }
        ]
      ]
    };

    return this.sendMessage(message, { reply_markup: keyboard });
  }

  async sendTestRecommendation(): Promise<boolean> {
    const testRecommendation = {
      assetSymbol: 'EUR/USD',
      direction: 'BUY',
      confidence: 91,
      riskLevel: 'low',
      technicalAnalysis: 'RSI + MACD + Bollinger Bands تشير لفرصة شراء قوية',
      trend: 'صعودي مستمر خلال الـ3 ساعات الماضية',
      liquidity: 'زخم قوي + سيولة مرتفعة',
      entryTime: new Date().toLocaleTimeString('ar-SA'),
      marketStatus: 'نشط',
      duration: '5 دقائق',
      strength: 'قوية',
      marketCondition: 'متفائلة'
    };

    return this.sendTradingRecommendation(testRecommendation);
  }

  async getBotInfo(): Promise<any> {
    try {
      const response = await axios.get(`${this.baseUrl}/getMe`);
      return response.data;
    } catch (error) {
      console.error('Error getting bot info:', error);
      return null;
    }
  }

  async getUpdates(): Promise<any> {
    try {
      const response = await axios.get(`${this.baseUrl}/getUpdates`);
      return response.data;
    } catch (error) {
      console.error('Error getting updates:', error);
      return null;
    }
  }

  private getAssetType(symbol: string): string {
    if (symbol.includes('/')) {
      if (symbol.includes('BTC') || symbol.includes('ETH')) return 'عملة رقمية';
      if (symbol.includes('XAU') || symbol.includes('XAG')) return 'سلعة';
      return 'عملة';
    }
    return 'سهم';
  }
}

export const telegramBotService = new TelegramBotService();
import OpenAI from 'openai';
import { storage } from '../storage';

export class OpenAIIntegration {
  private openai: OpenAI;
  private static instance: OpenAIIntegration;

  constructor() {
    if (!process.env.OPENAI_API_KEY) {
      console.log('⚠️ OpenAI API key not provided - advanced analysis disabled');
      return;
    }
    
    // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
    this.openai = new OpenAI({ 
      apiKey: process.env.OPENAI_API_KEY 
    });
    console.log('🤖 OpenAI integration initialized with GPT-4o');
  }

  static getInstance(): OpenAIIntegration {
    if (!OpenAIIntegration.instance) {
      OpenAIIntegration.instance = new OpenAIIntegration();
    }
    return OpenAIIntegration.instance;
  }

  async enhanceNewsAnalysis(newsData: any[], marketData: any): Promise<{
    enhancedSentiment: string;
    keyInsights: string[];
    marketImpact: number;
    tradingRecommendation: string;
    confidence: number;
  }> {
    if (!this.openai) {
      return this.getFallbackAnalysis();
    }

    try {
      const prompt = `
تحليل الأخبار الاقتصادية والسوق:

البيانات الاقتصادية:
${JSON.stringify(newsData, null, 2)}

بيانات السوق الحالية:
${JSON.stringify(marketData, null, 2)}

المطلوب تحليل شامل يتضمن:
1. تحليل المعنويات المحسن
2. الرؤى الرئيسية المؤثرة على السوق
3. تقييم التأثير على السوق (من 1-10)
4. توصية تداول مبنية على التحليل
5. مستوى الثقة في التحليل

يرجى الرد بصيغة JSON فقط:
{
  "enhancedSentiment": "bullish/bearish/neutral",
  "keyInsights": ["insight1", "insight2", "insight3"],
  "marketImpact": number (1-10),
  "tradingRecommendation": "detailed recommendation",
  "confidence": number (0-100)
}
      `;

      const response = await this.openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [
          {
            role: "system",
            content: "أنت محلل مالي خبير متخصص في الأسواق المالية والتحليل الاقتصادي. قدم تحليلاً دقيقاً ومفصلاً."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        response_format: { type: "json_object" },
        temperature: 0.3
      });

      const analysis = JSON.parse(response.choices[0].message.content || '{}');
      
      // Store the AI analysis for learning
      await this.storeAnalysisForLearning(newsData, marketData, analysis);
      
      return analysis;
    } catch (error) {
      console.error('OpenAI analysis error:', error);
      return this.getFallbackAnalysis();
    }
  }

  async generateTradingInsights(
    symbol: string, 
    technicalData: any, 
    newsImpact: any
  ): Promise<{
    strategicInsight: string;
    riskAssessment: string;
    optimalEntry: string;
    marketContext: string;
    confidence: number;
  }> {
    if (!this.openai) {
      return this.getFallbackInsights();
    }

    try {
      const prompt = `
تحليل متقدم للأصل: ${symbol}

البيانات الفنية:
${JSON.stringify(technicalData, null, 2)}

تأثير الأخبار:
${JSON.stringify(newsImpact, null, 2)}

المطلوب تحليل تداول متقدم يشمل:
1. رؤية استراتيجية شاملة
2. تقييم المخاطر التفصيلي
3. نقطة الدخول المثلى
4. السياق السوقي العام
5. مستوى الثقة

الرد بصيغة JSON:
{
  "strategicInsight": "detailed strategic analysis",
  "riskAssessment": "comprehensive risk analysis",
  "optimalEntry": "entry strategy and timing",
  "marketContext": "broader market context",
  "confidence": number (0-100)
}
      `;

      const response = await this.openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [
          {
            role: "system",
            content: "أنت خبير تداول متقدم مع خبرة 20+ سنة في الأسواق المالية. قدم تحليلاً احترافياً ودقيقاً."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        response_format: { type: "json_object" },
        temperature: 0.2
      });

      return JSON.parse(response.choices[0].message.content || '{}');
    } catch (error) {
      console.error('OpenAI insights error:', error);
      return this.getFallbackInsights();
    }
  }

  async optimizeSignalGeneration(
    assetData: any[],
    historicalPerformance: any
  ): Promise<{
    optimizedSignals: any[];
    qualityScore: number;
    recommendation: string;
  }> {
    if (!this.openai) {
      return { optimizedSignals: [], qualityScore: 0, recommendation: 'OpenAI not available' };
    }

    try {
      const prompt = `
تحسين توليد الإشارات التجارية:

بيانات الأصول:
${JSON.stringify(assetData.slice(0, 5), null, 2)}

الأداء التاريخي:
${JSON.stringify(historicalPerformance, null, 2)}

المطلوب:
1. تحليل أفضل الفرص التجارية
2. تقييم جودة الإشارات المحتملة
3. توصيات التحسين

الرد بصيغة JSON:
{
  "optimizedSignals": [
    {
      "asset": "symbol",
      "direction": "BUY/SELL",
      "confidence": number,
      "reasoning": "explanation"
    }
  ],
  "qualityScore": number (0-100),
  "recommendation": "optimization recommendations"
}
      `;

      const response = await this.openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [
          {
            role: "system",
            content: "أنت خبير في خوارزميات التداول والذكاء الاصطناعي. قدم تحليلاً متقدماً لتحسين الإشارات."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        response_format: { type: "json_object" },
        temperature: 0.1
      });

      return JSON.parse(response.choices[0].message.content || '{}');
    } catch (error) {
      console.error('OpenAI optimization error:', error);
      return { optimizedSignals: [], qualityScore: 0, recommendation: 'Analysis failed' };
    }
  }

  private async storeAnalysisForLearning(newsData: any, marketData: any, analysis: any) {
    try {
      await storage.createMlTrainingData({
        assetSymbol: 'MARKET_WIDE',
        features: JSON.stringify({ newsData, marketData, analysis }),
        target: analysis.enhancedSentiment,
        confidence: analysis.confidence,
        result: null,
        createdAt: new Date()
      });
    } catch (error) {
      console.log('Error storing AI analysis:', error);
    }
  }

  private getFallbackAnalysis() {
    return {
      enhancedSentiment: 'neutral',
      keyInsights: ['تحليل OpenAI غير متاح', 'استخدام التحليل التقليدي'],
      marketImpact: 5,
      tradingRecommendation: 'توخي الحذر في ظل عدم توفر التحليل المتقدم',
      confidence: 50
    };
  }

  private getFallbackInsights() {
    return {
      strategicInsight: 'التحليل المتقدم غير متاح حالياً',
      riskAssessment: 'تقييم المخاطر بالطرق التقليدية',
      optimalEntry: 'انتظار إشارات تأكيدية إضافية',
      marketContext: 'السياق العام يتطلب مراقبة دقيقة',
      confidence: 50
    };
  }

  isAvailable(): boolean {
    return !!this.openai && !!process.env.OPENAI_API_KEY;
  }
}

export const openaiIntegration = OpenAIIntegration.getInstance();
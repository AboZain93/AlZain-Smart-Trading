import bcrypt from 'bcrypt';
import crypto from 'crypto';
import { commercialUsers, userSessions, productKeys, subscriptions, products } from '@shared/commercial-schema';
import { db } from '../db';
import { eq, and, gt } from 'drizzle-orm';

export interface AuthResult {
  success: boolean;
  user?: any;
  token?: string;
  error?: string;
  remainingTrialDays?: number;
  subscriptionStatus?: string;
}

export interface LoginCredentials {
  username: string;
  password: string;
  deviceInfo?: any;
}

export interface RegisterData {
  username: string;
  email: string;
  password: string;
  firstName?: string;
  lastName?: string;
  phoneNumber?: string;
  countryCode?: string;
  companyName?: string;
}

export class CommercialAuthService {
  private readonly saltRounds = 12;
  private readonly sessionDuration = 7 * 24 * 60 * 60 * 1000; // 7 days

  async register(userData: RegisterData): Promise<AuthResult> {
    try {
      // Check if user exists
      const existingUser = await db.select()
        .from(commercialUsers)
        .where(eq(commercialUsers.email, userData.email))
        .limit(1);

      if (existingUser.length > 0) {
        return { success: false, error: 'البريد الإلكتروني مستخدم بالفعل' };
      }

      const existingUsername = await db.select()
        .from(commercialUsers)
        .where(eq(commercialUsers.username, userData.username))
        .limit(1);

      if (existingUsername.length > 0) {
        return { success: false, error: 'اسم المستخدم مستخدم بالفعل' };
      }

      // Hash password
      const passwordHash = await bcrypt.hash(userData.password, this.saltRounds);

      // Create user with trial period
      const trialEndDate = new Date();
      trialEndDate.setDate(trialEndDate.getDate() + 7); // 7 days trial

      const [newUser] = await db.insert(commercialUsers).values({
        username: userData.username,
        email: userData.email,
        passwordHash,
        firstName: userData.firstName,
        lastName: userData.lastName,
        phoneNumber: userData.phoneNumber,
        countryCode: userData.countryCode,
        companyName: userData.companyName,
        subscriptionStatus: 'trial',
        subscriptionTier: 'basic',
        trialEndDate,
        dailySignalsUsed: 0,
        monthlySignalsUsed: 0,
        totalSignalsUsed: 0,
      }).returning();

      // Generate trial license key
      await this.generateTrialLicense(newUser.id);

      // Create session
      const token = await this.createSession(newUser.id, userData.deviceInfo);

      return {
        success: true,
        user: this.sanitizeUser(newUser),
        token,
        remainingTrialDays: 7,
        subscriptionStatus: 'trial'
      };
    } catch (error) {
      console.error('Registration error:', error);
      return { success: false, error: 'فشل في إنشاء الحساب' };
    }
  }

  async login(credentials: LoginCredentials): Promise<AuthResult> {
    try {
      // Find user
      const [user] = await db.select()
        .from(commercialUsers)
        .where(eq(commercialUsers.username, credentials.username))
        .limit(1);

      if (!user) {
        return { success: false, error: 'اسم المستخدم أو كلمة المرور غير صحيحة' };
      }

      // Verify password
      const isValidPassword = await bcrypt.compare(credentials.password, user.passwordHash);
      if (!isValidPassword) {
        return { success: false, error: 'اسم المستخدم أو كلمة المرور غير صحيحة' };
      }

      // Check if account is active
      if (!user.isActive) {
        return { success: false, error: 'الحساب معطل. يرجى التواصل مع الدعم الفني' };
      }

      // Update login stats
      await db.update(commercialUsers)
        .set({
          lastLoginAt: new Date(),
          loginCount: (user.loginCount || 0) + 1,
          updatedAt: new Date()
        })
        .where(eq(commercialUsers.id, user.id));

      // Check subscription status
      const subscriptionInfo = await this.checkSubscriptionStatus(user);

      // Create session
      const token = await this.createSession(user.id, credentials.deviceInfo);

      return {
        success: true,
        user: this.sanitizeUser({ ...user, ...subscriptionInfo }),
        token,
        remainingTrialDays: subscriptionInfo.remainingTrialDays,
        subscriptionStatus: subscriptionInfo.subscriptionStatus
      };
    } catch (error) {
      console.error('Login error:', error);
      return { success: false, error: 'فشل في تسجيل الدخول' };
    }
  }

  async validateSession(token: string): Promise<AuthResult> {
    try {
      const [session] = await db.select()
        .from(userSessions)
        .where(and(
          eq(userSessions.sessionToken, token),
          eq(userSessions.isActive, true),
          gt(userSessions.expiresAt, new Date())
        ))
        .limit(1);

      if (!session) {
        return { success: false, error: 'جلسة غير صالحة' };
      }

      // Update last activity
      await db.update(userSessions)
        .set({ lastActivityAt: new Date() })
        .where(eq(userSessions.id, session.id));

      // Get user
      const [user] = await db.select()
        .from(commercialUsers)
        .where(eq(commercialUsers.id, session.userId))
        .limit(1);

      if (!user || !user.isActive) {
        return { success: false, error: 'المستخدم غير موجود أو معطل' };
      }

      // Check subscription status
      const subscriptionInfo = await this.checkSubscriptionStatus(user);

      return {
        success: true,
        user: this.sanitizeUser({ ...user, ...subscriptionInfo }),
        token,
        remainingTrialDays: subscriptionInfo.remainingTrialDays,
        subscriptionStatus: subscriptionInfo.subscriptionStatus
      };
    } catch (error) {
      console.error('Session validation error:', error);
      return { success: false, error: 'فشل في التحقق من الجلسة' };
    }
  }

  async logout(token: string): Promise<boolean> {
    try {
      await db.update(userSessions)
        .set({ 
          isActive: false, 
          logoutAt: new Date() 
        })
        .where(eq(userSessions.sessionToken, token));
      return true;
    } catch (error) {
      console.error('Logout error:', error);
      return false;
    }
  }

  async activateLicenseKey(userId: string, licenseKey: string, deviceFingerprint?: string): Promise<AuthResult> {
    try {
      // Find license key
      const [license] = await db.select()
        .from(productKeys)
        .where(and(
          eq(productKeys.licenseKey, licenseKey),
          eq(productKeys.isValid, true)
        ))
        .limit(1);

      if (!license) {
        return { success: false, error: 'مفتاح الترخيص غير صالح' };
      }

      if (license.isActivated && license.userId !== userId) {
        return { success: false, error: 'مفتاح الترخيص مستخدم بالفعل' };
      }

      // Check expiry
      if (license.validUntil && new Date() > license.validUntil) {
        return { success: false, error: 'مفتاح الترخيص منتهي الصلاحية' };
      }

      // Get product details
      const [product] = await db.select()
        .from(products)
        .where(eq(products.id, license.productId))
        .limit(1);

      if (!product) {
        return { success: false, error: 'المنتج غير موجود' };
      }

      // Activate license
      await db.update(productKeys)
        .set({
          isActivated: true,
          activatedAt: new Date(),
          activatedBy: userId,
          userId: userId,
          deviceFingerprint,
          usageCount: (license.usageCount || 0) + 1,
          lastUsedAt: new Date(),
          updatedAt: new Date()
        })
        .where(eq(productKeys.id, license.id));

      // Update user subscription based on product
      const subscriptionEndDate = new Date();
      if (product.billingCycle === 'monthly') {
        subscriptionEndDate.setMonth(subscriptionEndDate.getMonth() + 1);
      } else if (product.billingCycle === 'yearly') {
        subscriptionEndDate.setFullYear(subscriptionEndDate.getFullYear() + 1);
      } else if (product.billingCycle === 'lifetime') {
        subscriptionEndDate.setFullYear(subscriptionEndDate.getFullYear() + 100); // Lifetime
      }

      await db.update(commercialUsers)
        .set({
          subscriptionStatus: 'active',
          subscriptionTier: product.category,
          subscriptionStartDate: new Date(),
          subscriptionEndDate,
          updatedAt: new Date()
        })
        .where(eq(commercialUsers.id, userId));

      return { success: true, error: 'تم تفعيل الترخيص بنجاح' };
    } catch (error) {
      console.error('License activation error:', error);
      return { success: false, error: 'فشل في تفعيل الترخيص' };
    }
  }

  private async createSession(userId: string, deviceInfo?: any): Promise<string> {
    const sessionToken = crypto.randomBytes(32).toString('hex');
    const expiresAt = new Date(Date.now() + this.sessionDuration);

    await db.insert(userSessions).values({
      userId,
      sessionToken,
      deviceInfo: deviceInfo || {},
      ipAddress: '',
      userAgent: '',
      expiresAt,
      isActive: true
    });

    return sessionToken;
  }

  private async generateTrialLicense(userId: string): Promise<string> {
    // Get basic product for trial
    const [basicProduct] = await db.select()
      .from(products)
      .where(eq(products.category, 'basic'))
      .limit(1);

    if (!basicProduct) {
      throw new Error('Basic product not found');
    }

    const licenseKey = this.generateLicenseKey();
    const validUntil = new Date();
    validUntil.setDate(validUntil.getDate() + 7); // 7 days trial

    await db.insert(productKeys).values({
      productId: basicProduct.id,
      userId,
      licenseKey,
      keyType: 'trial',
      isActivated: true,
      activatedAt: new Date(),
      activatedBy: userId,
      validUntil,
      maxUsageCount: 100 // Trial usage limit
    });

    return licenseKey;
  }

  private generateLicenseKey(): string {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let result = '';
    for (let i = 0; i < 4; i++) {
      if (i > 0) result += '-';
      for (let j = 0; j < 5; j++) {
        result += chars.charAt(Math.floor(Math.random() * chars.length));
      }
    }
    return result;
  }

  private async checkSubscriptionStatus(user: any) {
    const now = new Date();
    let subscriptionStatus = user.subscriptionStatus || 'free';
    let remainingTrialDays = 0;

    // Check trial period
    if (user.trialEndDate && now < user.trialEndDate) {
      const timeDiff = user.trialEndDate.getTime() - now.getTime();
      remainingTrialDays = Math.ceil(timeDiff / (1000 * 3600 * 24));
      if (subscriptionStatus === 'free') {
        subscriptionStatus = 'trial';
      }
    }

    // Check subscription expiry
    if (user.subscriptionEndDate && now > user.subscriptionEndDate) {
      subscriptionStatus = 'expired';
      await db.update(commercialUsers)
        .set({ 
          subscriptionStatus: 'expired',
          updatedAt: new Date()
        })
        .where(eq(commercialUsers.id, user.id));
    }

    return {
      subscriptionStatus,
      remainingTrialDays,
      subscriptionTier: user.subscriptionTier || 'basic'
    };
  }

  private sanitizeUser(user: any) {
    const { passwordHash, ...sanitized } = user;
    return sanitized;
  }
}

export const commercialAuthService = new CommercialAuthService();
interface VoiceCommand {
  command: string;
  language: string;
  confidence: number;
  intent: string;
  entities: Record<string, any>;
  timestamp: Date;
  response: string;
  success: boolean;
}

interface VoiceResponse {
  text: string;
  language: string;
  audioUrl?: string;
  actions?: string[];
  data?: any;
}

interface LanguageModel {
  language: string;
  commands: {
    [key: string]: {
      patterns: string[];
      intent: string;
      examples: string[];
    };
  };
  responses: {
    [key: string]: string[];
  };
}

class VoiceAssistantService {
  private commandHistory: VoiceCommand[] = [];
  private supportedLanguages = ['ar', 'en', 'fr', 'es'];
  private currentLanguage = 'ar';

  private languageModels: LanguageModel[] = [
    {
      language: 'ar',
      commands: {
        'get_market_data': {
          patterns: [
            'أظهر لي بيانات السوق',
            'ما هي أسعار العملات',
            'أسعار الذهب اليوم',
            'كيف حال السوق',
            'آخر الأسعار'
          ],
          intent: 'market_data',
          examples: ['أظهر لي سعر اليورو دولار', 'ما سعر الذهب الآن']
        },
        'get_signals': {
          patterns: [
            'أظهر الإشارات',
            'آخر التوصيات',
            'إشارات التداول',
            'توصيات اليوم',
            'أفضل الفرص'
          ],
          intent: 'trading_signals',
          examples: ['أظهر لي آخر الإشارات', 'ما هي التوصيات الحالية']
        },
        'portfolio_status': {
          patterns: [
            'حالة المحفظة',
            'أرباحي اليوم',
            'إجمالي الأرباح',
            'خسائري',
            'أداء المحفظة'
          ],
          intent: 'portfolio',
          examples: ['كيف أداء محفظتي', 'كم ربحت اليوم']
        },
        'market_analysis': {
          patterns: [
            'تحليل السوق',
            'اتجاه السوق',
            'توقعات السوق',
            'تحليل فني',
            'مؤشرات فنية'
          ],
          intent: 'analysis',
          examples: ['حلل لي السوق', 'ما هو اتجاه اليورو']
        },
        'help': {
          patterns: [
            'مساعدة',
            'كيف أستخدم',
            'ماذا تستطيع أن تفعل',
            'المساعدة',
            'شرح'
          ],
          intent: 'help',
          examples: ['كيف يمكنك مساعدتي', 'ما هي الأوامر المتاحة']
        }
      },
      responses: {
        'market_data': [
          'إليك آخر بيانات السوق المحدثة',
          'هذه هي الأسعار الحالية للأسواق',
          'السوق يشهد حركة نشطة اليوم'
        ],
        'trading_signals': [
          'هذه هي أحدث التوصيات للتداول',
          'إليك أفضل الفرص المتاحة حالياً',
          'توصيات عالية الجودة من خبراء التداول'
        ],
        'portfolio': [
          'إليك تفاصيل أداء محفظتك',
          'محفظتك تحقق أداءً جيداً',
          'هذا ملخص شامل لاستثماراتك'
        ],
        'analysis': [
          'إليك تحليل شامل للسوق',
          'السوق يظهر إشارات إيجابية',
          'التحليل الفني يشير إلى فرص جيدة'
        ],
        'help': [
          'يمكنني مساعدتك في متابعة الأسواق والحصول على التوصيات',
          'أستطيع عرض بيانات السوق وتحليل المحفظة وتقديم التوصيات',
          'قل لي "أظهر الإشارات" أو "حالة المحفظة" للبدء'
        ],
        'unknown': [
          'عذراً، لم أفهم طلبك. حاول قول "مساعدة" لمعرفة الأوامر المتاحة',
          'لم أتمكن من فهم الأمر. يرجى إعادة الصياغة',
          'أمر غير مفهوم. جرب أوامر مثل "أظهر الإشارات" أو "بيانات السوق"'
        ]
      }
    },
    {
      language: 'en',
      commands: {
        'get_market_data': {
          patterns: [
            'show market data',
            'currency prices',
            'gold prices today',
            'market status',
            'latest prices'
          ],
          intent: 'market_data',
          examples: ['show EUR USD price', 'what is gold price now']
        },
        'get_signals': {
          patterns: [
            'show signals',
            'trading recommendations',
            'trading signals',
            'today recommendations',
            'best opportunities'
          ],
          intent: 'trading_signals',
          examples: ['show me latest signals', 'what are current recommendations']
        },
        'portfolio_status': {
          patterns: [
            'portfolio status',
            'my profits today',
            'total profits',
            'my losses',
            'portfolio performance'
          ],
          intent: 'portfolio',
          examples: ['how is my portfolio', 'how much did I earn today']
        },
        'market_analysis': {
          patterns: [
            'market analysis',
            'market trend',
            'market forecast',
            'technical analysis',
            'technical indicators'
          ],
          intent: 'analysis',
          examples: ['analyze the market', 'what is EUR trend']
        },
        'help': {
          patterns: [
            'help',
            'how to use',
            'what can you do',
            'assistance',
            'explain'
          ],
          intent: 'help',
          examples: ['how can you help me', 'what commands are available']
        }
      },
      responses: {
        'market_data': [
          'Here is the latest updated market data',
          'These are the current market prices',
          'The market is showing active movement today'
        ],
        'trading_signals': [
          'These are the latest trading recommendations',
          'Here are the best opportunities currently available',
          'High-quality recommendations from trading experts'
        ],
        'portfolio': [
          'Here are your portfolio performance details',
          'Your portfolio is performing well',
          'This is a comprehensive summary of your investments'
        ],
        'analysis': [
          'Here is a comprehensive market analysis',
          'The market shows positive signals',
          'Technical analysis indicates good opportunities'
        ],
        'help': [
          'I can help you track markets and get recommendations',
          'I can display market data, analyze portfolio and provide recommendations',
          'Say "show signals" or "portfolio status" to get started'
        ],
        'unknown': [
          'Sorry, I didn\'t understand your request. Try saying "help" to see available commands',
          'I couldn\'t understand the command. Please rephrase',
          'Unknown command. Try commands like "show signals" or "market data"'
        ]
      }
    },
    {
      language: 'fr',
      commands: {
        'get_market_data': {
          patterns: [
            'afficher données marché',
            'prix des devises',
            'prix de l\'or aujourd\'hui',
            'statut du marché',
            'derniers prix'
          ],
          intent: 'market_data',
          examples: ['afficher prix EUR USD', 'quel est le prix de l\'or maintenant']
        },
        'get_signals': {
          patterns: [
            'afficher signaux',
            'recommandations trading',
            'signaux de trading',
            'recommandations du jour',
            'meilleures opportunités'
          ],
          intent: 'trading_signals',
          examples: ['montrez-moi les derniers signaux', 'quelles sont les recommandations actuelles']
        },
        'portfolio_status': {
          patterns: [
            'statut portefeuille',
            'mes profits aujourd\'hui',
            'profits totaux',
            'mes pertes',
            'performance portefeuille'
          ],
          intent: 'portfolio',
          examples: ['comment va mon portefeuille', 'combien ai-je gagné aujourd\'hui']
        },
        'market_analysis': {
          patterns: [
            'analyse du marché',
            'tendance du marché',
            'prévisions marché',
            'analyse technique',
            'indicateurs techniques'
          ],
          intent: 'analysis',
          examples: ['analyser le marché', 'quelle est la tendance EUR']
        },
        'help': {
          patterns: [
            'aide',
            'comment utiliser',
            'que pouvez-vous faire',
            'assistance',
            'expliquer'
          ],
          intent: 'help',
          examples: ['comment pouvez-vous m\'aider', 'quelles commandes sont disponibles']
        }
      },
      responses: {
        'market_data': [
          'Voici les dernières données de marché mises à jour',
          'Voici les prix actuels du marché',
          'Le marché montre un mouvement actif aujourd\'hui'
        ],
        'trading_signals': [
          'Voici les dernières recommandations de trading',
          'Voici les meilleures opportunités actuellement disponibles',
          'Recommandations de haute qualité d\'experts en trading'
        ],
        'portfolio': [
          'Voici les détails de performance de votre portefeuille',
          'Votre portefeuille performe bien',
          'Ceci est un résumé complet de vos investissements'
        ],
        'analysis': [
          'Voici une analyse complète du marché',
          'Le marché montre des signaux positifs',
          'L\'analyse technique indique de bonnes opportunités'
        ],
        'help': [
          'Je peux vous aider à suivre les marchés et obtenir des recommandations',
          'Je peux afficher les données de marché, analyser le portefeuille et fournir des recommandations',
          'Dites "afficher signaux" ou "statut portefeuille" pour commencer'
        ],
        'unknown': [
          'Désolé, je n\'ai pas compris votre demande. Essayez de dire "aide" pour voir les commandes disponibles',
          'Je n\'ai pas pu comprendre la commande. Veuillez reformuler',
          'Commande inconnue. Essayez des commandes comme "afficher signaux" ou "données marché"'
        ]
      }
    },
    {
      language: 'es',
      commands: {
        'get_market_data': {
          patterns: [
            'mostrar datos mercado',
            'precios divisas',
            'precios oro hoy',
            'estado mercado',
            'últimos precios'
          ],
          intent: 'market_data',
          examples: ['mostrar precio EUR USD', 'cuál es el precio del oro ahora']
        },
        'get_signals': {
          patterns: [
            'mostrar señales',
            'recomendaciones trading',
            'señales de trading',
            'recomendaciones del día',
            'mejores oportunidades'
          ],
          intent: 'trading_signals',
          examples: ['muéstrame las últimas señales', 'cuáles son las recomendaciones actuales']
        },
        'portfolio_status': {
          patterns: [
            'estado cartera',
            'mis ganancias hoy',
            'ganancias totales',
            'mis pérdidas',
            'rendimiento cartera'
          ],
          intent: 'portfolio',
          examples: ['cómo está mi cartera', 'cuánto gané hoy']
        },
        'market_analysis': {
          patterns: [
            'análisis mercado',
            'tendencia mercado',
            'pronósticos mercado',
            'análisis técnico',
            'indicadores técnicos'
          ],
          intent: 'analysis',
          examples: ['analizar el mercado', 'cuál es la tendencia EUR']
        },
        'help': {
          patterns: [
            'ayuda',
            'cómo usar',
            'qué puedes hacer',
            'asistencia',
            'explicar'
          ],
          intent: 'help',
          examples: ['cómo puedes ayudarme', 'qué comandos están disponibles']
        }
      },
      responses: {
        'market_data': [
          'Aquí están los últimos datos de mercado actualizados',
          'Estos son los precios actuales del mercado',
          'El mercado muestra movimiento activo hoy'
        ],
        'trading_signals': [
          'Estas son las últimas recomendaciones de trading',
          'Aquí están las mejores oportunidades actualmente disponibles',
          'Recomendaciones de alta calidad de expertos en trading'
        ],
        'portfolio': [
          'Aquí están los detalles de rendimiento de tu cartera',
          'Tu cartera está funcionando bien',
          'Este es un resumen completo de tus inversiones'
        ],
        'analysis': [
          'Aquí hay un análisis completo del mercado',
          'El mercado muestra señales positivas',
          'El análisis técnico indica buenas oportunidades'
        ],
        'help': [
          'Puedo ayudarte a rastrear mercados y obtener recomendaciones',
          'Puedo mostrar datos de mercado, analizar cartera y proporcionar recomendaciones',
          'Di "mostrar señales" o "estado cartera" para comenzar'
        ],
        'unknown': [
          'Lo siento, no entendí tu solicitud. Intenta decir "ayuda" para ver comandos disponibles',
          'No pude entender el comando. Por favor reformula',
          'Comando desconocido. Prueba comandos como "mostrar señales" o "datos mercado"'
        ]
      }
    }
  ];

  // معالجة الأوامر الصوتية
  async processVoiceCommand(text: string, language: string = 'ar'): Promise<VoiceResponse> {
    const command: VoiceCommand = {
      command: text.toLowerCase(),
      language,
      confidence: 0.8,
      intent: '',
      entities: {},
      timestamp: new Date(),
      response: '',
      success: false
    };

    try {
      const languageModel = this.languageModels.find(model => model.language === language);
      if (!languageModel) {
        throw new Error(`Language ${language} not supported`);
      }

      // البحث عن أفضل تطابق للأمر
      let bestMatch = { intent: 'unknown', confidence: 0 };
      
      for (const [commandKey, commandData] of Object.entries(languageModel.commands)) {
        for (const pattern of commandData.patterns) {
          const similarity = this.calculateTextSimilarity(text.toLowerCase(), pattern.toLowerCase());
          if (similarity > bestMatch.confidence && similarity > 0.6) {
            bestMatch = { intent: commandData.intent, confidence: similarity };
          }
        }
      }

      command.intent = bestMatch.intent;
      command.confidence = bestMatch.confidence;

      // تنفيذ الأمر وإنتاج الاستجابة
      const response = await this.executeCommand(command, languageModel);
      
      command.response = response.text;
      command.success = true;
      
      this.commandHistory.push(command);
      
      return response;
    } catch (error) {
      console.error('Voice command processing error:', error);
      
      const languageModel = this.languageModels.find(model => model.language === language);
      const unknownResponses = languageModel?.responses.unknown || ['Sorry, I encountered an error'];
      
      command.response = unknownResponses[Math.floor(Math.random() * unknownResponses.length)];
      command.success = false;
      
      this.commandHistory.push(command);
      
      return {
        text: command.response,
        language,
        actions: ['error']
      };
    }
  }

  // تنفيذ الأوامر
  private async executeCommand(command: VoiceCommand, languageModel: LanguageModel): Promise<VoiceResponse> {
    const responses = languageModel.responses[command.intent] || languageModel.responses.unknown;
    const randomResponse = responses[Math.floor(Math.random() * responses.length)];

    let data: any = {};
    let actions: string[] = [];

    switch (command.intent) {
      case 'market_data':
        // محاكاة جلب بيانات السوق
        data = {
          currencies: [
            { symbol: 'EUR/USD', price: 1.2145, change: '+0.23%' },
            { symbol: 'GBP/USD', price: 1.3892, change: '-0.15%' },
            { symbol: 'USD/JPY', price: 149.78, change: '+0.45%' }
          ],
          gold: { price: 2078.50, change: '-0.32%' },
          updateTime: new Date().toLocaleString(command.language === 'ar' ? 'ar-SA' : 'en-US')
        };
        actions = ['display_market_data'];
        break;

      case 'trading_signals':
        // محاكاة الإشارات الحالية
        data = {
          signals: [
            {
              symbol: 'EUR/USD',
              direction: 'BUY',
              confidence: 85,
              entryPrice: 1.2145,
              targetPrice: 1.2245,
              timeframe: '1H'
            },
            {
              symbol: 'GOLD',
              direction: 'SELL',
              confidence: 78,
              entryPrice: 2078.50,
              targetPrice: 2055.00,
              timeframe: '4H'
            }
          ]
        };
        actions = ['display_signals'];
        break;

      case 'portfolio':
        // محاكاة بيانات المحفظة
        data = {
          totalValue: 15750.25,
          dailyPnL: '+234.56',
          dailyReturn: '+1.52%',
          openPositions: 3,
          winRate: 76.8
        };
        actions = ['display_portfolio'];
        break;

      case 'analysis':
        // محاكاة التحليل
        data = {
          marketSentiment: 'bullish',
          majorTrends: ['EUR strength', 'USD weakness', 'Gold consolidation'],
          recommendations: ['Buy EUR/USD on dips', 'Sell Gold above 2080', 'Watch NFP data']
        };
        actions = ['display_analysis'];
        break;

      case 'help':
        data = {
          availableCommands: languageModel.commands,
          examples: Object.values(languageModel.commands).flatMap(cmd => cmd.examples)
        };
        actions = ['display_help'];
        break;

      default:
        actions = ['unknown_command'];
        break;
    }

    return {
      text: randomResponse,
      language: command.language,
      actions,
      data
    };
  }

  // حساب التشابه بين النصوص
  private calculateTextSimilarity(text1: string, text2: string): number {
    const words1 = text1.split(' ');
    const words2 = text2.split(' ');
    
    let matchCount = 0;
    const totalWords = Math.max(words1.length, words2.length);
    
    for (const word1 of words1) {
      if (words2.some(word2 => word2.includes(word1) || word1.includes(word2))) {
        matchCount++;
      }
    }
    
    return matchCount / totalWords;
  }

  // الحصول على اللغات المدعومة
  getSupportedLanguages(): string[] {
    return this.supportedLanguages;
  }

  // تغيير اللغة الحالية
  setCurrentLanguage(language: string): boolean {
    if (this.supportedLanguages.includes(language)) {
      this.currentLanguage = language;
      return true;
    }
    return false;
  }

  // الحصول على تاريخ الأوامر
  getCommandHistory(limit: number = 50): VoiceCommand[] {
    return this.commandHistory
      .slice(-limit)
      .reverse();
  }

  // الحصول على إحصائيات الاستخدام
  getUsageStats(): {
    totalCommands: number;
    successRate: number;
    topIntents: { intent: string; count: number }[];
    languageBreakdown: { language: string; count: number }[];
  } {
    const total = this.commandHistory.length;
    const successful = this.commandHistory.filter(cmd => cmd.success).length;
    
    // إحصائيات الأوامر حسب النوع
    const intentCounts: Record<string, number> = {};
    const languageCounts: Record<string, number> = {};
    
    this.commandHistory.forEach(cmd => {
      intentCounts[cmd.intent] = (intentCounts[cmd.intent] || 0) + 1;
      languageCounts[cmd.language] = (languageCounts[cmd.language] || 0) + 1;
    });

    const topIntents = Object.entries(intentCounts)
      .map(([intent, count]) => ({ intent, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 5);

    const languageBreakdown = Object.entries(languageCounts)
      .map(([language, count]) => ({ language, count }));

    return {
      totalCommands: total,
      successRate: total > 0 ? (successful / total) * 100 : 0,
      topIntents,
      languageBreakdown
    };
  }

  // محاكاة تحويل النص إلى كلام
  async textToSpeech(text: string, language: string): Promise<string> {
    // في التطبيق الحقيقي، هذا سيكون استدعاء لخدمة TTS
    return `data:audio/mp3;base64,${Buffer.from(`TTS_${language}_${text.substring(0, 50)}`).toString('base64')}`;
  }

  // محاكاة تحويل الكلام إلى نص
  async speechToText(audioData: Buffer, language: string): Promise<string> {
    // في التطبيق الحقيقي، هذا سيكون استدعاء لخدمة STT
    const mockTexts = {
      ar: 'أظهر لي آخر الإشارات',
      en: 'show me latest signals',
      fr: 'montrez-moi les derniers signaux',
      es: 'muéstrame las últimas señales'
    };
    
    return mockTexts[language as keyof typeof mockTexts] || 'مساعدة';
  }
}

export const voiceAssistantService = new VoiceAssistantService();
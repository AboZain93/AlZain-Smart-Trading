import { db } from "../db";
import {
  products,
  licenses,
  commercialUsers,
  purchaseHistory,
  type Product,
  type License,
  type InsertLicense,
  type InsertProduct,
  type InsertPurchase,
  type CommercialUser,
} from "@shared/commercial-schema";
import { eq, and, desc, sql, gte, lte, count } from "drizzle-orm";
import { nanoid } from "nanoid";

export interface ProductSalesManager {
  // إدارة المنتجات
  createProduct(productData: CreateProductData): Promise<Product>;
  getActiveProducts(): Promise<Product[]>;
  getProductById(id: number): Promise<Product | undefined>;
  updateProductPricing(id: number, pricing: ProductPricing): Promise<Product | undefined>;
  
  // إدارة المبيعات
  generateTrialLicense(userId: string, productId: number): Promise<License>;
  generatePaidLicense(userId: string, productId: number, purchaseData: PurchaseData): Promise<License>;
  validateLicense(licenseKey: string): Promise<LicenseValidation>;
  
  // إدارة الفترات التجريبية
  createTrialAccess(userId: string, productId: number, customTrialSettings?: TrialSettings): Promise<License>;
  checkTrialEligibility(userId: string, productId: number): Promise<TrialEligibility>;
  
  // إحصائيات المبيعات
  getSalesAnalytics(productId?: number): Promise<SalesAnalytics>;
  getLicenseUsageStats(licenseKey: string): Promise<LicenseUsageStats>;
  
  // إدارة المفاتيح
  generateLicenseKey(productType: string, licenseType: string): string;
  revokeLicense(licenseKey: string, reason: string, adminId: string): Promise<void>;
}

export interface CreateProductData {
  name: string;
  nameAr: string;
  description: string;
  descriptionAr: string;
  productType: "subscription" | "license" | "one-time";
  category: string;
  priceUsd: number; // in cents
  originalPriceUsd?: number;
  billingCycle?: "monthly" | "yearly" | "lifetime";
  features: string[];
  limits: any;
  trialDays: number;
  trialTrades: number;
  maxDevicesAllowed: number;
}

export interface ProductPricing {
  priceUsd: number;
  originalPriceUsd?: number;
  discountPercentage?: number;
}

export interface PurchaseData {
  paymentMethod: string;
  paymentId: string;
  amount: number;
  currency: string;
}

export interface TrialSettings {
  durationDays?: number;
  maxTrades?: number;
  maxDevices?: number;
}

export interface LicenseValidation {
  isValid: boolean;
  license?: License;
  user?: CommercialUser;
  errors: string[];
  remainingTrades?: number;
  remainingDays?: number;
}

export interface TrialEligibility {
  isEligible: boolean;
  reason?: string;
  hasUsedTrial: boolean;
  activeTrials: number;
}

export interface SalesAnalytics {
  totalSales: number;
  totalRevenue: number;
  activeLicenses: number;
  trialConversions: number;
  topProducts: Array<{
    productId: number;
    productName: string;
    sales: number;
    revenue: number;
  }>;
  monthlySales: Array<{
    month: string;
    sales: number;
    revenue: number;
  }>;
}

export interface LicenseUsageStats {
  totalTrades: number;
  tradesRemaining: number;
  daysActive: number;
  daysRemaining: number;
  devicesUsed: number;
  lastActivity: Date | null;
}

export class ProductSalesManagerImpl implements ProductSalesManager {
  
  async createProduct(productData: CreateProductData): Promise<Product> {
    const newProduct = {
      ...productData,
      isActive: true,
      isPopular: false,
      autoGenerateTrialKey: true,
      sortOrder: 0,
    };

    const [product] = await db
      .insert(products)
      .values(newProduct)
      .returning();

    return product;
  }

  async getActiveProducts(): Promise<Product[]> {
    return await db
      .select()
      .from(products)
      .where(eq(products.isActive, true))
      .orderBy(products.sortOrder, products.createdAt);
  }

  async getProductById(id: number): Promise<Product | undefined> {
    const [product] = await db
      .select()
      .from(products)
      .where(eq(products.id, id));
    
    return product;
  }

  async updateProductPricing(id: number, pricing: ProductPricing): Promise<Product | undefined> {
    const [updatedProduct] = await db
      .update(products)
      .set({
        priceUsd: pricing.priceUsd,
        originalPriceUsd: pricing.originalPriceUsd,
        updatedAt: new Date(),
      })
      .where(eq(products.id, id))
      .returning();

    return updatedProduct;
  }

  async generateTrialLicense(userId: string, productId: number): Promise<License> {
    const product = await this.getProductById(productId);
    if (!product) {
      throw new Error("المنتج غير موجود");
    }

    // التحقق من أهلية التجربة
    const eligibility = await this.checkTrialEligibility(userId, productId);
    if (!eligibility.isEligible) {
      throw new Error(eligibility.reason || "غير مؤهل للفترة التجريبية");
    }

    const licenseKey = this.generateLicenseKey(product.productType, "trial");
    const now = new Date();
    const trialEndDate = new Date(now.getTime() + (product.trialDays * 24 * 60 * 60 * 1000));

    const licenseData: InsertLicense = {
      productId,
      userId,
      licenseKey,
      licenseType: "trial",
      isTrial: true,
      maxTrades: product.trialTrades,
      maxDevices: product.maxDevicesAllowed,
      trialDurationDays: product.trialDays,
      trialTradesRemaining: product.trialTrades,
      trialStartDate: now,
      trialEndDate,
      expiresAt: trialEndDate,
      isValid: true,
      isActivated: false,
      isRevoked: false,
      usageCount: 0,
      tradesUsed: 0,
    };

    const [license] = await db
      .insert(licenses)
      .values(licenseData)
      .returning();

    return license;
  }

  async generatePaidLicense(userId: string, productId: number, purchaseData: PurchaseData): Promise<License> {
    const product = await this.getProductById(productId);
    if (!product) {
      throw new Error("المنتج غير موجود");
    }

    const licenseKey = this.generateLicenseKey(product.productType, "paid");
    const now = new Date();
    let expiresAt: Date | null = null;

    // تحديد تاريخ انتهاء الصلاحية حسب نوع الاشتراك
    if (product.billingCycle === "monthly") {
      expiresAt = new Date(now.getTime() + (30 * 24 * 60 * 60 * 1000));
    } else if (product.billingCycle === "yearly") {
      expiresAt = new Date(now.getTime() + (365 * 24 * 60 * 60 * 1000));
    } else if (product.billingCycle === "lifetime") {
      // لا يوجد انتهاء صلاحية للترخيص مدى الحياة
      expiresAt = new Date(now.getTime() + (100 * 365 * 24 * 60 * 60 * 1000)); // 100 سنة
    }

    const licenseData: InsertLicense = {
      productId,
      userId,
      licenseKey,
      licenseType: "paid",
      isTrial: false,
      maxDevices: product.maxDevicesAllowed,
      expiresAt,
      isValid: true,
      isActivated: false,
      isRevoked: false,
      usageCount: 0,
      tradesUsed: 0,
    };

    // إنشاء الترخيص
    const [license] = await db
      .insert(licenses)
      .values(licenseData)
      .returning();

    // تسجيل عملية الشراء
    const purchaseRecord: InsertPurchase = {
      userId,
      productId,
      licenseId: license.id,
      amount: purchaseData.amount,
      currency: purchaseData.currency,
      paymentMethod: purchaseData.paymentMethod,
      paymentId: purchaseData.paymentId,
      status: "completed",
    };

    await db.insert(purchaseHistory).values(purchaseRecord);

    return license;
  }

  async validateLicense(licenseKey: string): Promise<LicenseValidation> {
    const errors: string[] = [];
    
    const [license] = await db
      .select()
      .from(licenses)
      .where(eq(licenses.licenseKey, licenseKey));

    if (!license) {
      return {
        isValid: false,
        errors: ["مفتاح الترخيص غير موجود"],
      };
    }

    // التحقق من صحة الترخيص
    if (!license.isValid) {
      errors.push("الترخيص غير صالح");
    }

    if (license.isRevoked) {
      errors.push("تم إلغاء الترخيص");
    }

    // التحقق من انتهاء الصلاحية
    if (license.expiresAt && license.expiresAt < new Date()) {
      errors.push("انتهت صلاحية الترخيص");
    }

    // التحقق من الفترة التجريبية
    if (license.isTrial) {
      if (license.trialEndDate && license.trialEndDate < new Date()) {
        errors.push("انتهت الفترة التجريبية");
      }
      
      if (license.trialTradesRemaining !== null && license.trialTradesRemaining <= 0) {
        errors.push("تم استنفاد عدد الصفقات المجانية");
      }
    }

    // جلب بيانات المستخدم
    let user: CommercialUser | undefined;
    if (license.userId) {
      const [userData] = await db
        .select()
        .from(commercialUsers)
        .where(eq(commercialUsers.id, license.userId));
      user = userData;
    }

    const isValid = errors.length === 0;
    
    let remainingTrades: number | undefined;
    let remainingDays: number | undefined;

    if (isValid && license.isTrial) {
      remainingTrades = license.trialTradesRemaining || 0;
      if (license.trialEndDate) {
        const msRemaining = license.trialEndDate.getTime() - Date.now();
        remainingDays = Math.max(0, Math.ceil(msRemaining / (24 * 60 * 60 * 1000)));
      }
    } else if (isValid && license.expiresAt) {
      const msRemaining = license.expiresAt.getTime() - Date.now();
      remainingDays = Math.max(0, Math.ceil(msRemaining / (24 * 60 * 60 * 1000)));
    }

    return {
      isValid,
      license,
      user,
      errors,
      remainingTrades,
      remainingDays,
    };
  }

  async createTrialAccess(userId: string, productId: number, customTrialSettings?: TrialSettings): Promise<License> {
    const product = await this.getProductById(productId);
    if (!product) {
      throw new Error("المنتج غير موجود");
    }

    const settings = customTrialSettings || {
      durationDays: product.trialDays,
      maxTrades: product.trialTrades,
      maxDevices: product.maxDevicesAllowed,
    };

    const licenseKey = this.generateLicenseKey(product.productType, "trial");
    const now = new Date();
    const trialEndDate = new Date(now.getTime() + ((settings.durationDays || product.trialDays) * 24 * 60 * 60 * 1000));

    const licenseData: InsertLicense = {
      productId,
      userId,
      licenseKey,
      licenseType: "trial",
      isTrial: true,
      maxTrades: settings.maxTrades || product.trialTrades,
      maxDevices: settings.maxDevices || product.maxDevicesAllowed,
      trialDurationDays: settings.durationDays || product.trialDays,
      trialTradesRemaining: settings.maxTrades || product.trialTrades,
      trialStartDate: now,
      trialEndDate,
      expiresAt: trialEndDate,
      isValid: true,
      isActivated: false,
      isRevoked: false,
      usageCount: 0,
      tradesUsed: 0,
    };

    const [license] = await db
      .insert(licenses)
      .values(licenseData)
      .returning();

    return license;
  }

  async checkTrialEligibility(userId: string, productId: number): Promise<TrialEligibility> {
    // التحقق من التجارب السابقة لهذا المنتج
    const existingTrials = await db
      .select()
      .from(licenses)
      .where(
        and(
          eq(licenses.userId, userId),
          eq(licenses.productId, productId),
          eq(licenses.isTrial, true)
        )
      );

    const hasUsedTrial = existingTrials.length > 0;
    
    // التحقق من التجارب النشطة
    const activeTrials = await db
      .select({ count: count() })
      .from(licenses)
      .where(
        and(
          eq(licenses.userId, userId),
          eq(licenses.isTrial, true),
          eq(licenses.isValid, true),
          eq(licenses.isRevoked, false),
          gte(licenses.trialEndDate, new Date())
        )
      );

    const activeTrialCount = activeTrials[0]?.count || 0;

    // قواعد الأهلية
    const isEligible = !hasUsedTrial && activeTrialCount < 3; // السماح بحد أقصى 3 تجارب نشطة

    let reason: string | undefined;
    if (hasUsedTrial) {
      reason = "لقد استخدمت الفترة التجريبية لهذا المنتج من قبل";
    } else if (activeTrialCount >= 3) {
      reason = "لديك عدد كبير من الفترات التجريبية النشطة";
    }

    return {
      isEligible,
      reason,
      hasUsedTrial,
      activeTrials: activeTrialCount,
    };
  }

  async getSalesAnalytics(productId?: number): Promise<SalesAnalytics> {
    // إحصائيات المبيعات العامة
    const salesQuery = db
      .select({
        count: count(),
        totalAmount: sql<number>`sum(${purchaseHistory.amount})`,
      })
      .from(purchaseHistory)
      .where(eq(purchaseHistory.status, "completed"));

    if (productId) {
      salesQuery.where(eq(purchaseHistory.productId, productId));
    }

    const [salesData] = await salesQuery;
    
    // التراخيص النشطة
    const activeLicensesQuery = db
      .select({ count: count() })
      .from(licenses)
      .where(
        and(
          eq(licenses.isValid, true),
          eq(licenses.isRevoked, false),
          gte(licenses.expiresAt, new Date())
        )
      );

    if (productId) {
      activeLicensesQuery.where(eq(licenses.productId, productId));
    }

    const [activeLicensesData] = await activeLicensesQuery;

    // تحويلات التجربة إلى شراء
    const trialConversions = await db
      .select({ count: count() })
      .from(purchaseHistory)
      .innerJoin(licenses, eq(purchaseHistory.licenseId, licenses.id))
      .where(
        and(
          eq(purchaseHistory.status, "completed"),
          eq(licenses.isTrial, false)
        )
      );

    // أفضل المنتجات
    const topProducts = await db
      .select({
        productId: purchaseHistory.productId,
        productName: products.name,
        sales: count(),
        revenue: sql<number>`sum(${purchaseHistory.amount})`,
      })
      .from(purchaseHistory)
      .innerJoin(products, eq(purchaseHistory.productId, products.id))
      .where(eq(purchaseHistory.status, "completed"))
      .groupBy(purchaseHistory.productId, products.name)
      .orderBy(desc(sql`sum(${purchaseHistory.amount})`))
      .limit(5);

    // المبيعات الشهرية
    const monthlySales = await db
      .select({
        month: sql<string>`to_char(${purchaseHistory.createdAt}, 'YYYY-MM')`,
        sales: count(),
        revenue: sql<number>`sum(${purchaseHistory.amount})`,
      })
      .from(purchaseHistory)
      .where(eq(purchaseHistory.status, "completed"))
      .groupBy(sql`to_char(${purchaseHistory.createdAt}, 'YYYY-MM')`)
      .orderBy(desc(sql`to_char(${purchaseHistory.createdAt}, 'YYYY-MM')`))
      .limit(12);

    return {
      totalSales: salesData.count || 0,
      totalRevenue: salesData.totalAmount || 0,
      activeLicenses: activeLicensesData.count || 0,
      trialConversions: trialConversions[0]?.count || 0,
      topProducts: topProducts.map(p => ({
        productId: p.productId!,
        productName: p.productName,
        sales: p.sales,
        revenue: p.revenue || 0,
      })),
      monthlySales: monthlySales.map(m => ({
        month: m.month,
        sales: m.sales,
        revenue: m.revenue || 0,
      })),
    };
  }

  async getLicenseUsageStats(licenseKey: string): Promise<LicenseUsageStats> {
    const [license] = await db
      .select()
      .from(licenses)
      .where(eq(licenses.licenseKey, licenseKey));

    if (!license) {
      throw new Error("الترخيص غير موجود");
    }

    const totalTrades = license.tradesUsed || 0;
    const tradesRemaining = license.isTrial 
      ? (license.trialTradesRemaining || 0)
      : -1; // -1 يعني غير محدود للتراخيص المدفوعة

    let daysActive = 0;
    let daysRemaining = 0;

    if (license.activatedAt) {
      const msActive = Date.now() - license.activatedAt.getTime();
      daysActive = Math.floor(msActive / (24 * 60 * 60 * 1000));
    }

    if (license.expiresAt) {
      const msRemaining = license.expiresAt.getTime() - Date.now();
      daysRemaining = Math.max(0, Math.ceil(msRemaining / (24 * 60 * 60 * 1000)));
    }

    return {
      totalTrades,
      tradesRemaining,
      daysActive,
      daysRemaining,
      devicesUsed: license.activationCount || 0,
      lastActivity: license.lastUsed,
    };
  }

  generateLicenseKey(productType: string, licenseType: string): string {
    const prefix = productType === "subscription" ? "SUB" : 
                   productType === "license" ? "LIC" : "OTP";
    const typePrefix = licenseType === "trial" ? "T" : 
                       licenseType === "paid" ? "P" : "L";
    const uniqueId = nanoid(16).toUpperCase();
    const checksum = this.generateChecksum(uniqueId);
    
    return `${prefix}${typePrefix}-${uniqueId}-${checksum}`;
  }

  private generateChecksum(input: string): string {
    let sum = 0;
    for (let i = 0; i < input.length; i++) {
      sum += input.charCodeAt(i);
    }
    return (sum % 1000).toString().padStart(3, '0');
  }

  async revokeLicense(licenseKey: string, reason: string, adminId: string): Promise<void> {
    await db
      .update(licenses)
      .set({
        isRevoked: true,
        isValid: false,
        revokedAt: new Date(),
        revokedReason: reason,
        revokedBy: parseInt(adminId),
        updatedAt: new Date(),
      })
      .where(eq(licenses.licenseKey, licenseKey));
  }
}

export const productSalesManager = new ProductSalesManagerImpl();
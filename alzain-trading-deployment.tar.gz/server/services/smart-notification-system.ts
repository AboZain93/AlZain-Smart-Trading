import { TradingRecommendation, User } from "@shared/schema";
import { advancedTechnicalAnalysis } from "./advanced-technical-analysis";

export interface NotificationPreferences {
  userId: number;
  enabledChannels: ('telegram' | 'email' | 'push' | 'sms')[];
  minConfidence: number;
  preferredRiskLevels: ('low' | 'medium' | 'high')[];
  assetCategories: string[];
  timeWindows: {
    start: string; // HH:MM format
    end: string;   // HH:MM format
    timezone: string;
  }[];
  maxDailyNotifications: number;
  urgencyLevels: {
    high: boolean;    // Market crashes, major news
    medium: boolean;  // Strong signals
    low: boolean;     // Regular signals
  };
  customFilters: {
    minProfitTarget: number;
    maxStopLoss: number;
    excludeWeekends: boolean;
    onlyMajorPairs: boolean;
  };
}

export interface SmartNotification {
  id: string;
  userId: number;
  type: 'trading_signal' | 'market_alert' | 'portfolio_update' | 'news' | 'achievement';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  title: string;
  message: string;
  data: any;
  channels: string[];
  scheduledTime: Date;
  sentTime?: Date;
  status: 'pending' | 'sent' | 'failed' | 'cancelled';
  retryCount: number;
  expiresAt: Date;
}

export interface MarketAlert {
  type: 'price_target' | 'volume_spike' | 'volatility_alert' | 'news_sentiment' | 'technical_breakout';
  asset: string;
  condition: string;
  currentValue: number;
  targetValue: number;
  severity: 'info' | 'warning' | 'critical';
  timestamp: Date;
}

export class SmartNotificationSystem {
  private notifications: Map<string, SmartNotification> = new Map();
  private userPreferences: Map<number, NotificationPreferences> = new Map();
  private alertHistory: MarketAlert[] = [];

  constructor() {
    this.initializeDefaultPreferences();
    this.startNotificationProcessor();
  }

  private initializeDefaultPreferences() {
    // Default preferences for new users
    const defaultPrefs: NotificationPreferences = {
      userId: 1,
      enabledChannels: ['telegram'],
      minConfidence: 70,
      preferredRiskLevels: ['low', 'medium'],
      assetCategories: ['forex', 'crypto'],
      timeWindows: [
        { start: '09:00', end: '17:00', timezone: 'UTC' }
      ],
      maxDailyNotifications: 10,
      urgencyLevels: {
        high: true,
        medium: true,
        low: false
      },
      customFilters: {
        minProfitTarget: 2.0,
        maxStopLoss: 3.0,
        excludeWeekends: true,
        onlyMajorPairs: false
      }
    };
    
    this.userPreferences.set(1, defaultPrefs);
  }

  // Process trading recommendations and create smart notifications
  async processNewRecommendation(recommendation: TradingRecommendation): Promise<void> {
    const users = Array.from(this.userPreferences.keys());
    
    for (const userId of users) {
      const prefs = this.userPreferences.get(userId);
      if (!prefs) continue;

      if (this.shouldNotifyUser(recommendation, prefs)) {
        const notification = await this.createTradingNotification(recommendation, userId, prefs);
        this.scheduleNotification(notification);
      }
    }
  }

  private shouldNotifyUser(recommendation: TradingRecommendation, prefs: NotificationPreferences): boolean {
    // Check confidence level
    if (recommendation.confidence < prefs.minConfidence) return false;

    // Check risk level
    if (!prefs.preferredRiskLevels.includes(recommendation.riskLevel as any)) return false;

    // Check time windows
    const now = new Date();
    const currentTime = now.toTimeString().substring(0, 5); // HH:MM format
    const isInTimeWindow = prefs.timeWindows.some(window => 
      currentTime >= window.start && currentTime <= window.end
    );
    if (!isInTimeWindow) return false;

    // Check weekend exclusion
    if (prefs.customFilters.excludeWeekends) {
      const dayOfWeek = now.getDay();
      if (dayOfWeek === 0 || dayOfWeek === 6) return false;
    }

    // Check daily limit
    const todayNotifications = Array.from(this.notifications.values())
      .filter(n => n.userId === prefs.userId && 
                   n.scheduledTime.toDateString() === now.toDateString());
    if (todayNotifications.length >= prefs.maxDailyNotifications) return false;

    return true;
  }

  private async createTradingNotification(
    recommendation: TradingRecommendation, 
    userId: number, 
    prefs: NotificationPreferences
  ): Promise<SmartNotification> {
    const priority = this.calculatePriority(recommendation);
    const personalizedMessage = await this.personalizeMessage(recommendation, prefs);
    
    return {
      id: this.generateNotificationId(),
      userId,
      type: 'trading_signal',
      priority,
      title: `🚀 ${recommendation.direction} Signal: ${recommendation.assetSymbol}`,
      message: personalizedMessage,
      data: {
        recommendation,
        confidence: recommendation.confidence,
        riskLevel: recommendation.riskLevel,
        estimatedProfit: this.calculateEstimatedProfit(recommendation),
        marketConditions: await this.getMarketConditions(recommendation.assetSymbol)
      },
      channels: prefs.enabledChannels,
      scheduledTime: new Date(),
      status: 'pending',
      retryCount: 0,
      expiresAt: new Date(Date.now() + 4 * 60 * 60 * 1000) // 4 hours
    };
  }

  private calculatePriority(recommendation: TradingRecommendation): 'low' | 'medium' | 'high' | 'urgent' {
    if (recommendation.confidence >= 90) return 'urgent';
    if (recommendation.confidence >= 80) return 'high';
    if (recommendation.confidence >= 70) return 'medium';
    return 'low';
  }

  private async personalizeMessage(
    recommendation: TradingRecommendation, 
    prefs: NotificationPreferences
  ): Promise<string> {
    const direction = recommendation.direction === 'BUY' ? '📈 شراء' : '📉 بيع';
    const confidence = Math.round(recommendation.confidence);
    const risk = recommendation.riskLevel === 'low' ? 'منخفض' : 
                 recommendation.riskLevel === 'medium' ? 'متوسط' : 'عالي';

    let message = `${direction} ${recommendation.assetSymbol}\n`;
    message += `🎯 مستوى الثقة: ${confidence}%\n`;
    message += `⚖️ مستوى المخاطر: ${risk}\n`;
    message += `⏰ المدة: ${recommendation.duration}\n`;
    message += `📊 التحليل: ${recommendation.technicalAnalysis}\n`;

    // Add personalized insights based on user preferences
    if (prefs.preferredRiskLevels.includes('low') && recommendation.riskLevel === 'low') {
      message += `✅ يتماشى مع تفضيلاتك للمخاطر المنخفضة\n`;
    }

    if (confidence >= prefs.minConfidence + 10) {
      message += `🌟 إشارة قوية تتجاوز الحد الأدنى المطلوب\n`;
    }

    // Add market context
    const marketCondition = await this.getMarketConditions(recommendation.assetSymbol);
    if (marketCondition.volatility === 'high') {
      message += `⚠️ السوق متقلب - تداول بحذر\n`;
    }

    return message;
  }

  private calculateEstimatedProfit(recommendation: TradingRecommendation): number {
    // Simple profit estimation based on historical performance
    const baseProfit = recommendation.confidence / 100 * 2; // 2% max profit
    const riskMultiplier = recommendation.riskLevel === 'high' ? 1.5 : 
                          recommendation.riskLevel === 'medium' ? 1.2 : 1.0;
    return baseProfit * riskMultiplier;
  }

  private async getMarketConditions(assetSymbol: string): Promise<{
    volatility: 'low' | 'medium' | 'high';
    trend: 'bullish' | 'bearish' | 'sideways';
    strength: number;
  }> {
    // Simplified market condition analysis
    const volatility = Math.random() > 0.7 ? 'high' : Math.random() > 0.4 ? 'medium' : 'low';
    const trends = ['bullish', 'bearish', 'sideways'] as const;
    const trend = trends[Math.floor(Math.random() * trends.length)];
    const strength = Math.random() * 100;

    return { volatility, trend, strength };
  }

  // Market alert system
  async checkMarketAlerts(): Promise<void> {
    const alerts = await this.detectMarketAnomalies();
    
    for (const alert of alerts) {
      await this.processMarketAlert(alert);
    }
  }

  private async detectMarketAnomalies(): Promise<MarketAlert[]> {
    const alerts: MarketAlert[] = [];
    
    // Example: Volume spike detection
    alerts.push({
      type: 'volume_spike',
      asset: 'EUR/USD',
      condition: 'Volume increased by 300%',
      currentValue: 1500000,
      targetValue: 500000,
      severity: 'warning',
      timestamp: new Date()
    });

    // Example: Volatility alert
    alerts.push({
      type: 'volatility_alert',
      asset: 'BTC/USD',
      condition: 'High volatility detected',
      currentValue: 5.2,
      targetValue: 3.0,
      severity: 'critical',
      timestamp: new Date()
    });

    return alerts;
  }

  private async processMarketAlert(alert: MarketAlert): Promise<void> {
    const users = Array.from(this.userPreferences.keys());
    
    for (const userId of users) {
      const prefs = this.userPreferences.get(userId);
      if (!prefs) continue;

      const shouldAlert = this.shouldSendAlert(alert, prefs);
      if (shouldAlert) {
        const notification = this.createAlertNotification(alert, userId);
        this.scheduleNotification(notification);
      }
    }

    this.alertHistory.push(alert);
  }

  private shouldSendAlert(alert: MarketAlert, prefs: NotificationPreferences): boolean {
    // Check if user wants this type of alert
    if (alert.severity === 'critical' && !prefs.urgencyLevels.high) return false;
    if (alert.severity === 'warning' && !prefs.urgencyLevels.medium) return false;
    if (alert.severity === 'info' && !prefs.urgencyLevels.low) return false;

    return true;
  }

  private createAlertNotification(alert: MarketAlert, userId: number): SmartNotification {
    const severityIcons = {
      info: 'ℹ️',
      warning: '⚠️',
      critical: '🚨'
    };

    const icon = severityIcons[alert.severity];
    const title = `${icon} تنبيه السوق: ${alert.asset}`;
    
    let message = `${alert.condition}\n`;
    message += `📊 القيمة الحالية: ${alert.currentValue}\n`;
    message += `🎯 القيمة المستهدفة: ${alert.targetValue}\n`;
    message += `⏰ الوقت: ${alert.timestamp.toLocaleTimeString('ar-SA')}`;

    return {
      id: this.generateNotificationId(),
      userId,
      type: 'market_alert',
      priority: alert.severity === 'critical' ? 'urgent' : 
               alert.severity === 'warning' ? 'high' : 'medium',
      title,
      message,
      data: { alert },
      channels: ['telegram'],
      scheduledTime: new Date(),
      status: 'pending',
      retryCount: 0,
      expiresAt: new Date(Date.now() + 2 * 60 * 60 * 1000) // 2 hours
    };
  }

  // Notification scheduling and delivery
  private scheduleNotification(notification: SmartNotification): void {
    this.notifications.set(notification.id, notification);
    
    // Process immediately if it's urgent
    if (notification.priority === 'urgent') {
      this.processNotification(notification);
    }
  }

  private startNotificationProcessor(): void {
    // Process notifications every 30 seconds
    setInterval(() => {
      this.processScheduledNotifications();
    }, 30000);
  }

  private async processScheduledNotifications(): Promise<void> {
    const now = new Date();
    const pendingNotifications = Array.from(this.notifications.values())
      .filter(n => n.status === 'pending' && n.scheduledTime <= now && n.expiresAt > now);

    for (const notification of pendingNotifications) {
      await this.processNotification(notification);
    }
  }

  private async processNotification(notification: SmartNotification): Promise<void> {
    try {
      for (const channel of notification.channels) {
        await this.sendNotification(notification, channel);
      }
      
      notification.status = 'sent';
      notification.sentTime = new Date();
      console.log(`✅ Notification sent: ${notification.title}`);
      
    } catch (error) {
      console.error('❌ Failed to send notification:', error);
      notification.retryCount++;
      
      if (notification.retryCount >= 3) {
        notification.status = 'failed';
      } else {
        // Retry after delay
        notification.scheduledTime = new Date(Date.now() + 5 * 60 * 1000);
      }
    }
  }

  private async sendNotification(notification: SmartNotification, channel: string): Promise<void> {
    switch (channel) {
      case 'telegram':
        await this.sendTelegramNotification(notification);
        break;
      case 'email':
        await this.sendEmailNotification(notification);
        break;
      case 'push':
        await this.sendPushNotification(notification);
        break;
      case 'sms':
        await this.sendSMSNotification(notification);
        break;
    }
  }

  private async sendTelegramNotification(notification: SmartNotification): Promise<void> {
    // Integration with existing Telegram service
    console.log(`📱 Sending Telegram notification: ${notification.title}`);
    // Actual implementation would use the telegram bot service
  }

  private async sendEmailNotification(notification: SmartNotification): Promise<void> {
    console.log(`📧 Sending email notification: ${notification.title}`);
    // Email service integration
  }

  private async sendPushNotification(notification: SmartNotification): Promise<void> {
    console.log(`🔔 Sending push notification: ${notification.title}`);
    // Push notification service integration
  }

  private async sendSMSNotification(notification: SmartNotification): Promise<void> {
    console.log(`📲 Sending SMS notification: ${notification.title}`);
    // SMS service integration
  }

  // Utility methods
  private generateNotificationId(): string {
    return `notif_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  // Public API methods
  async updateUserPreferences(userId: number, preferences: Partial<NotificationPreferences>): Promise<void> {
    const current = this.userPreferences.get(userId) || this.getDefaultPreferences(userId);
    const updated = { ...current, ...preferences };
    this.userPreferences.set(userId, updated);
    
    console.log(`✅ Updated notification preferences for user ${userId}`);
  }

  async getUserPreferences(userId: number): Promise<NotificationPreferences> {
    return this.userPreferences.get(userId) || this.getDefaultPreferences(userId);
  }

  async getNotificationHistory(userId: number, limit: number = 50): Promise<SmartNotification[]> {
    return Array.from(this.notifications.values())
      .filter(n => n.userId === userId)
      .sort((a, b) => b.scheduledTime.getTime() - a.scheduledTime.getTime())
      .slice(0, limit);
  }

  async getMarketAlertHistory(limit: number = 20): Promise<MarketAlert[]> {
    return this.alertHistory
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
      .slice(0, limit);
  }

  private getDefaultPreferences(userId: number): NotificationPreferences {
    return {
      userId,
      enabledChannels: ['telegram'],
      minConfidence: 70,
      preferredRiskLevels: ['low', 'medium'],
      assetCategories: ['forex', 'crypto'],
      timeWindows: [
        { start: '09:00', end: '17:00', timezone: 'UTC' }
      ],
      maxDailyNotifications: 10,
      urgencyLevels: {
        high: true,
        medium: true,
        low: false
      },
      customFilters: {
        minProfitTarget: 2.0,
        maxStopLoss: 3.0,
        excludeWeekends: true,
        onlyMajorPairs: false
      }
    };
  }

  // Analytics methods
  async getNotificationStats(userId: number): Promise<{
    totalSent: number;
    successRate: number;
    averageResponseTime: number;
    topPerformingSignals: any[];
  }> {
    const userNotifications = Array.from(this.notifications.values())
      .filter(n => n.userId === userId);

    const totalSent = userNotifications.filter(n => n.status === 'sent').length;
    const successful = userNotifications.filter(n => n.status === 'sent').length;
    const successRate = totalSent > 0 ? (successful / totalSent) * 100 : 0;

    return {
      totalSent,
      successRate,
      averageResponseTime: 0.5, // minutes
      topPerformingSignals: []
    };
  }
}

export const smartNotificationSystem = new SmartNotificationSystem();
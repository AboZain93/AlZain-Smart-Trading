import axios from 'axios';

interface NewsArticle {
  title: string;
  description: string;
  content: string;
  source: string;
  author: string;
  url: string;
  urlToImage: string;
  publishedAt: string;
  sentiment?: number;
  relevanceScore?: number;
  category?: string;
  impact?: 'HIGH' | 'MEDIUM' | 'LOW';
}

interface MarketSentiment {
  overall: number;
  positive: number;
  negative: number;
  neutral: number;
  articlesCount: number;
  timestamp: string;
}

class NewsAPIService {
  private apiKey: string;
  private baseUrl = 'https://newsapi.org/v2';
  private rateLimitDelay = 1000; // 1 second between calls for free tier
  private lastCallTime = 0;

  constructor() {
    this.apiKey = process.env.NEWS_API_KEY || '';
    if (!this.apiKey) {
      console.warn('NewsAPI key not found');
    }
  }

  private async rateLimitedRequest(endpoint: string, params: any): Promise<any> {
    const now = Date.now();
    const timeSinceLastCall = now - this.lastCallTime;
    
    if (timeSinceLastCall < this.rateLimitDelay) {
      const waitTime = this.rateLimitDelay - timeSinceLastCall;
      await new Promise(resolve => setTimeout(resolve, waitTime));
    }

    this.lastCallTime = Date.now();
    
    try {
      const response = await axios.get(`${this.baseUrl}${endpoint}`, {
        params: {
          ...params,
          apiKey: this.apiKey
        },
        timeout: 10000
      });
      
      return response.data;
    } catch (error) {
      console.error('NewsAPI error:', error);
      throw error;
    }
  }

  private calculateSentiment(text: string): number {
    if (!text) return 0;
    
    const positiveWords = [
      'growth', 'profit', 'increase', 'rise', 'bull', 'gains', 'positive', 'strong', 
      'boost', 'surge', 'rally', 'upward', 'optimistic', 'success', 'improvement',
      'recovery', 'expansion', 'breakthrough', 'milestone', 'achievement'
    ];
    
    const negativeWords = [
      'loss', 'fall', 'decline', 'bear', 'crash', 'negative', 'weak', 'drop', 
      'plunge', 'recession', 'crisis', 'downward', 'pessimistic', 'failure',
      'collapse', 'concern', 'risk', 'threat', 'uncertainty', 'volatility'
    ];

    const lowerText = text.toLowerCase();
    let sentiment = 0;
    
    positiveWords.forEach(word => {
      const matches = (lowerText.match(new RegExp(word, 'g')) || []).length;
      sentiment += matches * 1;
    });
    
    negativeWords.forEach(word => {
      const matches = (lowerText.match(new RegExp(word, 'g')) || []).length;
      sentiment -= matches * 1;
    });
    
    // Normalize to -1 to 1 scale
    return Math.max(-1, Math.min(1, sentiment / 10));
  }

  private categorizeNews(title: string, description: string): string {
    const text = `${title} ${description}`.toLowerCase();
    
    if (text.includes('crypto') || text.includes('bitcoin') || text.includes('ethereum')) {
      return 'cryptocurrency';
    }
    if (text.includes('forex') || text.includes('currency') || text.includes('dollar') || text.includes('euro')) {
      return 'forex';
    }
    if (text.includes('stock') || text.includes('share') || text.includes('equity')) {
      return 'stocks';
    }
    if (text.includes('oil') || text.includes('gold') || text.includes('commodity')) {
      return 'commodities';
    }
    if (text.includes('interest rate') || text.includes('fed') || text.includes('central bank')) {
      return 'monetary_policy';
    }
    if (text.includes('gdp') || text.includes('inflation') || text.includes('employment')) {
      return 'economic_data';
    }
    
    return 'general';
  }

  private assessImpact(title: string, description: string, sentiment: number): 'HIGH' | 'MEDIUM' | 'LOW' {
    const text = `${title} ${description}`.toLowerCase();
    
    const highImpactKeywords = [
      'fed', 'central bank', 'interest rate', 'inflation', 'gdp', 'recession',
      'crisis', 'crash', 'surge', 'breakthrough', 'major', 'significant'
    ];
    
    const hasHighImpactKeywords = highImpactKeywords.some(keyword => text.includes(keyword));
    const strongSentiment = Math.abs(sentiment) > 0.5;
    
    if (hasHighImpactKeywords && strongSentiment) return 'HIGH';
    if (hasHighImpactKeywords || strongSentiment) return 'MEDIUM';
    return 'LOW';
  }

  async getEconomicNews(pageSize: number = 20): Promise<NewsArticle[]> {
    if (!this.apiKey) return [];

    try {
      const data = await this.rateLimitedRequest('/everything', {
        q: 'economy OR finance OR trading OR forex OR stock market OR cryptocurrency',
        language: 'en',
        sortBy: 'publishedAt',
        pageSize: Math.min(pageSize, 100)
      });

      if (!data.articles) return [];

      return data.articles.map((article: any) => {
        const sentiment = this.calculateSentiment(`${article.title} ${article.description}`);
        const category = this.categorizeNews(article.title, article.description);
        const impact = this.assessImpact(article.title, article.description, sentiment);

        return {
          title: article.title || '',
          description: article.description || '',
          content: article.content || '',
          source: article.source?.name || 'Unknown',
          author: article.author || 'Unknown',
          url: article.url || '',
          urlToImage: article.urlToImage || '',
          publishedAt: article.publishedAt || new Date().toISOString(),
          sentiment,
          category,
          impact,
          relevanceScore: Math.abs(sentiment) + (impact === 'HIGH' ? 0.3 : impact === 'MEDIUM' ? 0.2 : 0.1)
        };
      }).filter(article => article.title && article.description);
    } catch (error) {
      console.error('Error fetching economic news:', error);
      return [];
    }
  }

  async getMarketSentiment(category?: string): Promise<MarketSentiment> {
    const defaultSentiment = {
      overall: 0,
      positive: 0,
      negative: 0,
      neutral: 0,
      articlesCount: 0,
      timestamp: new Date().toISOString()
    };

    if (!this.apiKey) return defaultSentiment;

    try {
      const articles = await this.getEconomicNews(50);
      
      const filteredArticles = category 
        ? articles.filter(article => article.category === category)
        : articles;

      if (filteredArticles.length === 0) return defaultSentiment;

      let totalSentiment = 0;
      let positiveCount = 0;
      let negativeCount = 0;
      let neutralCount = 0;

      filteredArticles.forEach(article => {
        const sentiment = article.sentiment || 0;
        totalSentiment += sentiment;
        
        if (sentiment > 0.1) positiveCount++;
        else if (sentiment < -0.1) negativeCount++;
        else neutralCount++;
      });

      const overall = totalSentiment / filteredArticles.length;

      return {
        overall: Math.round(overall * 100) / 100,
        positive: Math.round((positiveCount / filteredArticles.length) * 100),
        negative: Math.round((negativeCount / filteredArticles.length) * 100),
        neutral: Math.round((neutralCount / filteredArticles.length) * 100),
        articlesCount: filteredArticles.length,
        timestamp: new Date().toISOString()
      };
    } catch (error) {
      console.error('Error calculating market sentiment:', error);
      return defaultSentiment;
    }
  }

  async getTopHeadlines(country: string = 'us', category: string = 'business'): Promise<NewsArticle[]> {
    if (!this.apiKey) return [];

    try {
      const data = await this.rateLimitedRequest('/top-headlines', {
        country,
        category,
        pageSize: 20
      });

      if (!data.articles) return [];

      return data.articles.map((article: any) => {
        const sentiment = this.calculateSentiment(`${article.title} ${article.description}`);
        const newsCategory = this.categorizeNews(article.title, article.description);
        const impact = this.assessImpact(article.title, article.description, sentiment);

        return {
          title: article.title || '',
          description: article.description || '',
          content: article.content || '',
          source: article.source?.name || 'Unknown',
          author: article.author || 'Unknown',
          url: article.url || '',
          urlToImage: article.urlToImage || '',
          publishedAt: article.publishedAt || new Date().toISOString(),
          sentiment,
          category: newsCategory,
          impact,
          relevanceScore: Math.abs(sentiment) + (impact === 'HIGH' ? 0.3 : impact === 'MEDIUM' ? 0.2 : 0.1)
        };
      }).filter(article => article.title && article.description);
    } catch (error) {
      console.error('Error fetching top headlines:', error);
      return [];
    }
  }

  async searchNews(query: string, from?: string, to?: string): Promise<NewsArticle[]> {
    if (!this.apiKey) return [];

    try {
      const params: any = {
        q: query,
        language: 'en',
        sortBy: 'publishedAt',
        pageSize: 30
      };

      if (from) params.from = from;
      if (to) params.to = to;

      const data = await this.rateLimitedRequest('/everything', params);

      if (!data.articles) return [];

      return data.articles.map((article: any) => {
        const sentiment = this.calculateSentiment(`${article.title} ${article.description}`);
        const category = this.categorizeNews(article.title, article.description);
        const impact = this.assessImpact(article.title, article.description, sentiment);

        return {
          title: article.title || '',
          description: article.description || '',
          content: article.content || '',
          source: article.source?.name || 'Unknown',
          author: article.author || 'Unknown',
          url: article.url || '',
          urlToImage: article.urlToImage || '',
          publishedAt: article.publishedAt || new Date().toISOString(),
          sentiment,
          category,
          impact,
          relevanceScore: Math.abs(sentiment) + (impact === 'HIGH' ? 0.3 : impact === 'MEDIUM' ? 0.2 : 0.1)
        };
      }).filter(article => article.title && article.description);
    } catch (error) {
      console.error(`Error searching news for "${query}":`, error);
      return [];
    }
  }

  async getNewsForSymbol(symbol: string): Promise<NewsArticle[]> {
    if (!this.apiKey) return [];

    // Map trading symbols to search terms
    const symbolToSearchTerm: { [key: string]: string } = {
      'EUR/USD': 'EUR USD euro dollar',
      'GBP/USD': 'GBP USD pound dollar',
      'USD/JPY': 'USD JPY dollar yen',
      'AUD/USD': 'AUD USD australian dollar',
      'USD/CHF': 'USD CHF dollar franc',
      'USD/CAD': 'USD CAD dollar canadian',
      'NZD/USD': 'NZD USD new zealand dollar',
      'XAUUSD': 'gold price XAU',
      'XAGUSD': 'silver price XAG',
      'USOIL': 'oil price crude',
      'BTCUSD': 'bitcoin BTC',
      'ETHUSD': 'ethereum ETH'
    };

    const searchTerm = symbolToSearchTerm[symbol] || symbol.replace('/', ' ');
    
    return this.searchNews(searchTerm);
  }

  async getMarketMoodAnalysis(): Promise<any> {
    if (!this.apiKey) return null;

    try {
      const [generalSentiment, forexSentiment, cryptoSentiment, stocksSentiment] = await Promise.allSettled([
        this.getMarketSentiment(),
        this.getMarketSentiment('forex'),
        this.getMarketSentiment('cryptocurrency'),
        this.getMarketSentiment('stocks')
      ]);

      return {
        general: generalSentiment.status === 'fulfilled' ? generalSentiment.value : null,
        forex: forexSentiment.status === 'fulfilled' ? forexSentiment.value : null,
        crypto: cryptoSentiment.status === 'fulfilled' ? cryptoSentiment.value : null,
        stocks: stocksSentiment.status === 'fulfilled' ? stocksSentiment.value : null,
        timestamp: new Date().toISOString()
      };
    } catch (error) {
      console.error('Error getting market mood analysis:', error);
      return null;
    }
  }

  async checkApiHealth(): Promise<boolean> {
    if (!this.apiKey) return false;

    try {
      const data = await this.rateLimitedRequest('/top-headlines', {
        country: 'us',
        category: 'business',
        pageSize: 1
      });

      return !!data.articles && data.articles.length > 0;
    } catch (error) {
      console.error('NewsAPI health check failed:', error);
      return false;
    }
  }
}

export const newsAPIService = new NewsAPIService();
export default NewsAPIService;
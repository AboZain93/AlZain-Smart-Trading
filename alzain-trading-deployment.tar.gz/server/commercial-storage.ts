import {
  users,
  products,
  licenses,
  type Product,
  type License,
} from "@shared/schema";

// Use regular schema tables for now
export const commercialUsers = users;
export type CommercialUser = typeof users.$inferSelect;
export type InsertCommercialUser = typeof users.$inferInsert;
export type InsertProduct = typeof products.$inferInsert;
export type InsertLicense = typeof licenses.$inferInsert;

// Session and purchase types for compatibility
export type UserSession = { id: number; userId: string; sessionToken: string; expiresAt: Date; };
export type PurchaseHistory = { id: number; userId: string; amount: number; };
import { db } from "./db";
import { eq, and, desc, sql, gte, lte } from "drizzle-orm";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import { nanoid } from "nanoid";

export interface CommercialStorage {
  // User Management
  createUser(userData: InsertCommercialUser & { password: string }): Promise<CommercialUser>;
  getUserByUsername(username: string): Promise<CommercialUser | undefined>;
  getUserByEmail(email: string): Promise<CommercialUser | undefined>;
  getUserById(id: string): Promise<CommercialUser | undefined>;
  updateUser(id: string, updates: Partial<CommercialUser>): Promise<CommercialUser | undefined>;
  verifyPassword(password: string, hash: string): Promise<boolean>;
  updateLoginAttempts(userId: string, attempts: number, lockedUntil?: Date): Promise<void>;

  // Product Management
  getAllProducts(): Promise<Product[]>;
  getProduct(id: number): Promise<Product | undefined>;
  createProduct(productData: InsertProduct): Promise<Product>;

  // License Management
  createLicense(licenseData: InsertLicense): Promise<License>;
  getLicenseByKey(licenseKey: string): Promise<License | undefined>;
  getUserLicenses(userId: string): Promise<License[]>;
  activateLicense(licenseKey: string, deviceFingerprint: string): Promise<License | undefined>;
  revokeLicense(licenseKey: string, reason: string, revokedBy: number): Promise<void>;
  updateLicenseUsage(licenseKey: string): Promise<void>;

  // Session Management
  createSession(data: { userId: string; deviceInfo?: string; ipAddress?: string; userAgent?: string }): Promise<{ token: string; session: UserSession }>;
  getActiveSession(sessionToken: string): Promise<UserSession | undefined>;
  invalidateSession(sessionToken: string): Promise<void>;

  // Analytics
  getUserStats(userId: string): Promise<any>;

  // Utility
  generateLicenseKey(prefix?: string): string;
  
  // Additional developer methods
  getDeveloperStats(): Promise<any>;
  getAllLicenses(): Promise<License[]>;
  getAllUsers(): Promise<CommercialUser[]>;
  updateProduct(id: number, updates: Partial<Product>): Promise<Product | undefined>;
  createBulkLicenses(data: { productId: number; licenseType: string; maxTrades?: number; trialDurationDays?: number; quantity: number }): Promise<License[]>;
}

export class CommercialStorageImpl implements CommercialStorage {
  private JWT_SECRET = process.env.JWT_SECRET || "alzain-trade-commercial-secret-key-2025";

  async createUser(userData: InsertCommercialUser & { password: string }): Promise<CommercialUser> {
    const passwordHash = await bcrypt.hash(userData.password, 12);
    
    const userId = `user_${Date.now()}_${nanoid(8)}`;
    
    const [user] = await db
      .insert(commercialUsers)
      .values({
        id: userId,
        username: userData.username,
        email: userData.email,
        passwordHash,
        firstName: userData.firstName,
        lastName: userData.lastName,
        phoneNumber: userData.phoneNumber,
        companyName: userData.companyName,
        // Set trial period for new users
        trialEndDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days trial
        subscriptionStatus: "trial",
        subscriptionTier: "basic",
      })
      .returning();

    // Create audit log
    await this.createAuditLog({
      userId: user.id,
      action: "USER_REGISTRATION",
      description: `User ${userData.username} registered successfully`,
    });

    return user;
  }

  async getUserByUsername(username: string): Promise<CommercialUser | undefined> {
    const [user] = await db
      .select()
      .from(commercialUsers)
      .where(eq(commercialUsers.username, username))
      .limit(1);
    return user;
  }

  async getUserByEmail(email: string): Promise<CommercialUser | undefined> {
    const [user] = await db
      .select()
      .from(commercialUsers)
      .where(eq(commercialUsers.email, email))
      .limit(1);
    return user;
  }

  async getUserById(id: string): Promise<CommercialUser | undefined> {
    const [user] = await db
      .select()
      .from(commercialUsers)
      .where(eq(commercialUsers.id, id))
      .limit(1);
    return user;
  }

  async updateUser(id: string, updates: Partial<CommercialUser>): Promise<CommercialUser | undefined> {
    const [user] = await db
      .update(commercialUsers)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(commercialUsers.id, id))
      .returning();
    return user;
  }

  async verifyPassword(password: string, hash: string): Promise<boolean> {
    return bcrypt.compare(password, hash);
  }

  async updateLoginAttempts(userId: string, attempts: number, lockedUntil?: Date): Promise<void> {
    await db
      .update(commercialUsers)
      .set({
        loginAttempts: attempts,
        lockedUntil,
        lastLogin: attempts === 0 ? new Date() : undefined,
      })
      .where(eq(commercialUsers.id, userId));
  }

  async getAllProducts(): Promise<Product[]> {
    return db
      .select()
      .from(products)
      .where(eq(products.isActive, true))
      .orderBy(products.sortOrder, products.name);
  }

  async getProduct(id: number): Promise<Product | undefined> {
    const [product] = await db
      .select()
      .from(products)
      .where(eq(products.id, id))
      .limit(1);
    return product;
  }

  async createProduct(productData: InsertProduct): Promise<Product> {
    const [product] = await db
      .insert(products)
      .values(productData)
      .returning();
    return product;
  }

  async createLicense(licenseData: InsertLicense): Promise<License> {
    const [license] = await db
      .insert(licenses)
      .values(licenseData)
      .returning();
    return license;
  }

  async getLicenseByKey(licenseKey: string): Promise<License | undefined> {
    const [license] = await db
      .select()
      .from(licenses)
      .where(eq(licenses.licenseKey, licenseKey))
      .limit(1);
    return license;
  }

  async getUserLicenses(userId: string): Promise<License[]> {
    return db
      .select()
      .from(licenses)
      .where(eq(licenses.userId, userId))
      .orderBy(desc(licenses.createdAt));
  }

  async activateLicense(licenseKey: string, deviceFingerprint: string): Promise<License | undefined> {
    const [license] = await db
      .update(licenses)
      .set({
        isActivated: true,
        activatedAt: new Date(),
        deviceFingerprint,
        activationCount: sql`${licenses.activationCount} + 1`,
        updatedAt: new Date(),
      })
      .where(
        and(
          eq(licenses.licenseKey, licenseKey),
          eq(licenses.isValid, true),
          eq(licenses.isRevoked, false)
        )
      )
      .returning();
    return license;
  }

  async revokeLicense(licenseKey: string, reason: string, revokedBy: number): Promise<void> {
    await db
      .update(licenses)
      .set({
        isRevoked: true,
        revokedAt: new Date(),
        revokedReason: reason,
        revokedBy,
        updatedAt: new Date(),
      })
      .where(eq(licenses.licenseKey, licenseKey));
  }

  async updateLicenseUsage(licenseKey: string): Promise<void> {
    await db
      .update(licenses)
      .set({
        usageCount: sql`${licenses.usageCount} + 1`,
        lastUsed: new Date(),
        updatedAt: new Date(),
      })
      .where(eq(licenses.licenseKey, licenseKey));
  }

  async createSession(data: {
    userId: string;
    deviceInfo?: string;
    ipAddress?: string;
    userAgent?: string;
  }): Promise<{ token: string; session: UserSession }> {
    const sessionToken = jwt.sign(
      { userId: data.userId, timestamp: Date.now() },
      this.JWT_SECRET,
      { expiresIn: "7d" }
    );

    const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000); // 7 days

    const [session] = await db
      .insert(userSessions)
      .values({
        userId: data.userId,
        sessionToken,
        expiresAt,
        deviceInfo: data.deviceInfo,
        ipAddress: data.ipAddress,
        userAgent: data.userAgent,
      })
      .returning();

    return { token: sessionToken, session };
  }

  async getActiveSession(sessionToken: string): Promise<UserSession | undefined> {
    const [session] = await db
      .select()
      .from(userSessions)
      .where(
        and(
          eq(userSessions.sessionToken, sessionToken),
          eq(userSessions.isActive, true),
          gte(userSessions.expiresAt, new Date())
        )
      )
      .limit(1);

    if (session) {
      // Update last activity
      await db
        .update(userSessions)
        .set({ lastActivity: new Date() })
        .where(eq(userSessions.id, session.id));
    }

    return session;
  }

  async invalidateSession(sessionToken: string): Promise<void> {
    await db
      .update(userSessions)
      .set({ isActive: false })
      .where(eq(userSessions.sessionToken, sessionToken));
  }

  async getUserStats(userId: string): Promise<any> {
    const user = await this.getUserById(userId);
    if (!user) return null;

    const licenses = await this.getUserLicenses(userId);
    const activeLicenses = licenses.filter(l => l.isValid && !l.isRevoked);

    return {
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        subscriptionStatus: user.subscriptionStatus,
        subscriptionTier: user.subscriptionTier,
        trialEndDate: user.trialEndDate,
        totalSignalsUsed: user.totalSignalsUsed,
        dailySignalsUsed: user.dailySignalsUsed,
        monthlySignalsUsed: user.monthlySignalsUsed,
      },
      licenses: {
        total: licenses.length,
        active: activeLicenses.length,
        expired: licenses.filter(l => l.expiresAt && l.expiresAt < new Date()).length,
      },
      usage: {
        signalsToday: user.dailySignalsUsed,
        signalsThisMonth: user.monthlySignalsUsed,
        totalSignals: user.totalSignalsUsed,
        lastSignalDate: user.lastSignalDate,
      },
    };
  }

  generateLicenseKey(prefix: string = "AZT"): string {
    const segments = [
      prefix,
      nanoid(4).toUpperCase(),
      nanoid(4).toUpperCase(),
      nanoid(4).toUpperCase(),
      nanoid(4).toUpperCase(),
    ];
    return segments.join("-");
  }

  private async createAuditLog(data: {
    userId?: string;
    action: string;
    description?: string;
    ipAddress?: string;
    userAgent?: string;
    metadata?: any;
  }): Promise<void> {
    await db.insert(auditLogs).values({
      userId: data.userId,
      action: data.action,
      description: data.description,
      ipAddress: data.ipAddress,
      userAgent: data.userAgent,
      metadata: data.metadata,
    });
  }

  // Email verification methods
  async createEmailVerificationToken(userId: string): Promise<string> {
    const token = nanoid(32);
    const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24 hours

    await db.insert(emailVerificationTokens).values({
      userId,
      token,
      expiresAt,
    });

    return token;
  }

  async verifyEmailToken(token: string): Promise<boolean> {
    const [tokenRecord] = await db
      .select()
      .from(emailVerificationTokens)
      .where(
        and(
          eq(emailVerificationTokens.token, token),
          eq(emailVerificationTokens.used, false),
          gte(emailVerificationTokens.expiresAt, new Date())
        )
      )
      .limit(1);

    if (!tokenRecord) return false;

    // Mark token as used
    await db
      .update(emailVerificationTokens)
      .set({ used: true })
      .where(eq(emailVerificationTokens.id, tokenRecord.id));

    // Verify user email
    await db
      .update(commercialUsers)
      .set({ emailVerified: true })
      .where(eq(commercialUsers.id, tokenRecord.userId));

    return true;
  }

  // Password reset methods
  async createPasswordResetToken(userId: string): Promise<string> {
    const token = nanoid(32);
    const expiresAt = new Date(Date.now() + 2 * 60 * 60 * 1000); // 2 hours

    await db.insert(passwordResetTokens).values({
      userId,
      token,
      expiresAt,
    });

    return token;
  }

  async resetPassword(token: string, newPassword: string): Promise<boolean> {
    const [tokenRecord] = await db
      .select()
      .from(passwordResetTokens)
      .where(
        and(
          eq(passwordResetTokens.token, token),
          eq(passwordResetTokens.used, false),
          gte(passwordResetTokens.expiresAt, new Date())
        )
      )
      .limit(1);

    if (!tokenRecord) return false;

    const passwordHash = await bcrypt.hash(newPassword, 12);

    // Update password
    await db
      .update(commercialUsers)
      .set({ passwordHash })
      .where(eq(commercialUsers.id, tokenRecord.userId));

    // Mark token as used
    await db
      .update(passwordResetTokens)
      .set({ used: true })
      .where(eq(passwordResetTokens.id, tokenRecord.id));

    return true;
  }

  async getDeveloperStats(): Promise<any> {
    try {
      const totalUsers = await db.select().from(commercialUsers).catch(() => []);
      const totalProducts = await db.select().from(products).catch(() => []);
      const totalLicenses = await db.select().from(licenses).catch(() => []);
      const activeLicenses = totalLicenses.filter(l => l.isValid && !l.isRevoked);
      const trialLicenses = totalLicenses.filter(l => l.licenseType === 'trial');
      
      return {
        totalUsers: totalUsers.length,
        totalProducts: totalProducts.length,
        totalLicenses: totalLicenses.length,
        activeLicenses: activeLicenses.length,
        trialLicenses: trialLicenses.length,
        revenue: 0, // Calculate from purchase history
        revenueThisMonth: 0 // Calculate from this month's purchases
      };
    } catch (error) {
      console.error('Error getting developer stats:', error);
      throw error;
    }
  }

  async getAllLicenses(): Promise<License[]> {
    try {
      return await db.select().from(licenses).orderBy(desc(licenses.createdAt));
    } catch (error) {
      console.error('Error getting all licenses:', error);
      throw error;
    }
  }

  async getAllUsers(): Promise<CommercialUser[]> {
    try {
      return await db.select().from(commercialUsers).orderBy(desc(commercialUsers.createdAt));
    } catch (error) {
      console.error('Error getting all users:', error);
      throw error;
    }
  }

  async updateProduct(id: number, updates: Partial<Product>): Promise<Product | undefined> {
    try {
      const [product] = await db
        .update(products)
        .set({ ...updates, updatedAt: new Date() })
        .where(eq(products.id, id))
        .returning();
      return product;
    } catch (error) {
      console.error('Error updating product:', error);
      throw error;
    }
  }

  async createBulkLicenses(data: {
    productId: number;
    licenseType: string;
    maxTrades?: number;
    trialDurationDays?: number;
    quantity: number;
  }): Promise<License[]> {
    try {
      const product = await this.getProduct(data.productId);
      if (!product) {
        throw new Error('Product not found');
      }

      const licensesToCreate = [];
      for (let i = 0; i < data.quantity; i++) {
        const licenseKey = this.generateLicenseKey();
        const expiresAt = data.trialDurationDays 
          ? new Date(Date.now() + data.trialDurationDays * 24 * 60 * 60 * 1000)
          : null;

        licensesToCreate.push({
          productId: data.productId,
          licenseKey,
          licenseType: data.licenseType,
          isTrial: data.licenseType === 'trial',
          maxTrades: data.maxTrades || product.trialTrades,
          trialDurationDays: data.trialDurationDays || product.trialDays,
          expiresAt,
          trialEndDate: expiresAt,
          isValid: true,
          isActivated: false,
          isRevoked: false,
          tradesUsed: 0,
          usageCount: 0,
          activationCount: 0
        });
      }

      return await db.insert(licenses).values(licensesToCreate).returning();
    } catch (error) {
      console.error('Error creating bulk licenses:', error);
      throw error;
    }
  }

  async initializeProducts(): Promise<void> {
    const existingProducts = await this.getAllProducts();
    if (existingProducts.length > 0) return;

    const demoProducts: InsertProduct[] = [
      {
        name: "خطة المبتدئين",
        nameAr: "خطة المبتدئين",
        description: "Perfect for individual traders starting their journey",
        descriptionAr: "مثالية للمتداولين الأفراد الذين يبدؤون رحلتهم",
        productType: "subscription",
        category: "trading-signals",
        priceUsd: 4900, // $49.00
        originalPriceUsd: 9900,
        billingCycle: "monthly",
        features: [
          "إشارات يومية محدودة (10 إشارات)",
          "تحليل فني أساسي",
          "دعم عبر البريد الإلكتروني",
          "تجربة مجانية 7 أيام"
        ],
        limits: {
          dailySignals: 10,
          monthlySignals: 300,
          devices: 1,
          support: "email"
        },
        trialDays: 7,
        isPopular: false,
        sortOrder: 1,
      },
      {
        name: "خطة المحترفين",
        nameAr: "خطة المحترفين",
        description: "Advanced features for serious traders",
        descriptionAr: "ميزات متقدمة للمتداولين الجادين",
        productType: "subscription",
        category: "trading-signals",
        priceUsd: 9900, // $99.00
        originalPriceUsd: 19900,
        billingCycle: "monthly",
        features: [
          "إشارات غير محدودة",
          "تحليل متقدم بالذكاء الاصطناعي",
          "إشعارات تيليجرام فورية",
          "تحليل المخاطر المتقدم",
          "دعم مباشر 24/7"
        ],
        limits: {
          dailySignals: -1, // unlimited
          monthlySignals: -1,
          devices: 3,
          support: "priority"
        },
        trialDays: 14,
        isPopular: true,
        sortOrder: 2,
      },
      {
        name: "خطة المؤسسات",
        nameAr: "خطة المؤسسات",
        description: "Complete solution for trading institutions",
        descriptionAr: "حل شامل للمؤسسات التجارية",
        productType: "subscription",
        category: "enterprise",
        priceUsd: 24900, // $249.00
        originalPriceUsd: 49900,
        billingCycle: "monthly",
        features: [
          "إشارات غير محدودة لعدة حسابات",
          "API متقدم للتكامل",
          "تقارير مفصلة",
          "إدارة متعددة المستخدمين",
          "دعم مخصص ومدير حساب"
        ],
        limits: {
          dailySignals: -1,
          monthlySignals: -1,
          devices: 10,
          users: 5,
          support: "dedicated"
        },
        trialDays: 30,
        isPopular: false,
        sortOrder: 3,
      },
    ];

    for (const product of demoProducts) {
      await this.createProduct(product);
    }
  }
}

export const commercialStorage = new CommercialStorageImpl();
import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { 
  Activity, 
  Brain, 
  TrendingUp, 
  AlertCircle, 
  CheckCircle, 
  Cpu, 
  Database, 
  Target,
  BarChart3,
  Clock,
  Settings,
  Lightbulb,
  Zap,
  PieChart,
  DollarSign,
  TrendingDown
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useLanguageContext } from '@/components/language-provider';
import { FloatingRefreshButton } from '@/components/floating-refresh-button';

interface AIModel {
  modelId: string;
  modelType: string;
  accuracy: number;
  precision: number;
  recall: number;
  f1Score: number;
  status: string;
  confidence: number;
  validationLoss: number;
  trainingSamples: number;
  specialization: string[];
}

interface ModelPrediction {
  modelId: string;
  prediction: string;
  confidence: number;
  reasoning: string[];
  timeHorizon: string;
  expectedPrice: number;
}

interface EnsemblePrediction {
  consensusScore: number;
  predictedOutcome: string;
  probabilityDistribution: {
    buyProb: number;
    sellProb: number;
    holdProb: number;
  };
  riskMetrics: {
    expectedReturn: number;
    volatility: number;
    sharpeRatio: number;
    maxDrawdown: number;
    valueAtRisk: number;
  };
  marketRegimeAnalysis: {
    regime: string;
    regimeConfidence: number;
    tradingStrategy: string;
  };
}

interface SystemStatus {
  modelsActive: number;
  modelsHealth: AIModel[];
  marketRegime: string;
  volatilityLevel: string;
  systemHealth: string;
  lastUpdate: string;
}

interface PerformanceMetrics {
  accuracyImprovement: number;
  modelUpdates: number;
  newPatterns: number;
  optimizationSuggestions: string[];
  learningProgress: {
    trainingLoss: number;
    validationLoss: number;
    overfitting: boolean;
    convergence: boolean;
  };
}

// Safe helper functions to handle undefined values
const safeString = (value: any, defaultValue: string = 'N/A'): string => {
  return value && typeof value === 'string' ? value : defaultValue;
};

const safeNumber = (value: any, defaultValue: number = 0): number => {
  return value && typeof value === 'number' && !isNaN(value) ? value : defaultValue;
};

const safeArray = (value: any, defaultValue: any[] = []): any[] => {
  return Array.isArray(value) ? value : defaultValue;
};

const safeReplace = (value: any, search: string, replace: string): string => {
  const str = safeString(value);
  return str.replace(search, replace);
};

export default function AIPerformanceMonitor() {
  const { language } = useLanguageContext();
  const [selectedModel, setSelectedModel] = useState<string | null>(null);

  const { data: systemStatus, isLoading: systemLoading } = useQuery<SystemStatus>({
    queryKey: ['/api/ai-performance/system-status'],
    refetchInterval: 5000,
  });

  const { data: performanceMetrics, isLoading: metricsLoading } = useQuery<PerformanceMetrics>({
    queryKey: ['/api/ai-performance/metrics'],
    refetchInterval: 5000,
  });

  const { data: ensemblePrediction, isLoading: predictionLoading } = useQuery<EnsemblePrediction>({
    queryKey: ['/api/ai-performance/ensemble-prediction'],
    refetchInterval: 5000,
  });

  useEffect(() => {
    if (systemStatus?.modelsHealth && systemStatus.modelsHealth.length > 0 && !selectedModel) {
      setSelectedModel(systemStatus.modelsHealth[0]?.modelId || null);
    }
  }, [systemStatus, selectedModel]);

  const isLoading = systemLoading || metricsLoading || predictionLoading;

  const getStatusColor = (status: string) => {
    switch (safeString(status).toLowerCase()) {
      case 'healthy':
      case 'active':
        return 'text-green-600 dark:text-green-400';
      case 'warning':
        return 'text-yellow-600 dark:text-yellow-400';
      case 'error':
      case 'inactive':
        return 'text-red-600 dark:text-red-400';
      default:
        return 'text-gray-600 dark:text-gray-400';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (safeString(status).toLowerCase()) {
      case 'healthy':
      case 'active':
        return <CheckCircle className="h-4 w-4" />;
      case 'warning':
        return <AlertCircle className="h-4 w-4" />;
      case 'error':
      case 'inactive':
        return <AlertCircle className="h-4 w-4" />;
      default:
        return <Clock className="h-4 w-4" />;
    }
  };

  const selectedModelData = systemStatus?.modelsHealth?.find(m => m.modelId === selectedModel);

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            {language === 'ar' ? 'مراقب أداء الذكاء الاصطناعي' : 'AI Performance Monitor'}
          </h1>
          <p className="text-gray-600 dark:text-gray-400 mt-2">
            {language === 'ar' 
              ? 'مراقبة شاملة لأداء النماذج الذكية وتحليل التعلم التكيفي'
              : 'Comprehensive monitoring of AI models performance and adaptive learning analytics'
            }
          </p>
        </div>
        <FloatingRefreshButton />
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[1, 2, 3].map((i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-6">
                <div className="h-8 bg-gray-200 dark:bg-gray-700 rounded mb-4"></div>
                <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded mb-2"></div>
                <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-3/4"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <>
          {/* System Overview Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <Card className="border border-gray-200 dark:border-gray-700">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600 dark:text-gray-400">
                      {language === 'ar' ? 'النماذج النشطة' : 'Active Models'}
                    </p>
                    <p className="text-3xl font-bold text-blue-600 dark:text-blue-400">
                      {safeNumber(systemStatus?.modelsActive)}
                    </p>
                  </div>
                  <Brain className="h-8 w-8 text-blue-600 dark:text-blue-400" />
                </div>
              </CardContent>
            </Card>

            <Card className="border border-gray-200 dark:border-gray-700">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600 dark:text-gray-400">
                      {language === 'ar' ? 'تحسين الدقة' : 'Accuracy Improvement'}
                    </p>
                    <p className={`text-3xl font-bold ${
                      safeNumber(performanceMetrics?.accuracyImprovement) >= 0 
                        ? 'text-green-600 dark:text-green-400' 
                        : 'text-red-600 dark:text-red-400'
                    }`}>
                      {safeNumber(performanceMetrics?.accuracyImprovement) >= 0 ? '+' : ''}
                      {safeNumber(performanceMetrics?.accuracyImprovement).toFixed(1)}%
                    </p>
                  </div>
                  <TrendingUp className="h-8 w-8 text-green-600 dark:text-green-400" />
                </div>
              </CardContent>
            </Card>

            <Card className="border border-gray-200 dark:border-gray-700">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600 dark:text-gray-400">
                      {language === 'ar' ? 'نقاط الإجماع' : 'Consensus Score'}
                    </p>
                    <p className="text-3xl font-bold text-purple-600 dark:text-purple-400">
                      {safeNumber(ensemblePrediction?.consensusScore)}%
                    </p>
                  </div>
                  <Target className="h-8 w-8 text-purple-600 dark:text-purple-400" />
                </div>
              </CardContent>
            </Card>

            <Card className="border border-gray-200 dark:border-gray-700">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600 dark:text-gray-400">
                      {language === 'ar' ? 'حالة النظام' : 'System Health'}
                    </p>
                    <div className={`flex items-center gap-2 ${getStatusColor(systemStatus?.systemHealth || '')}`}>
                      {getStatusIcon(systemStatus?.systemHealth || '')}
                      <span className="font-medium capitalize">
                        {safeString(systemStatus?.systemHealth, 'Unknown')}
                      </span>
                    </div>
                  </div>
                  <Activity className="h-8 w-8 text-gray-600 dark:text-gray-400" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Content Tabs */}
          <Tabs defaultValue="overview" className="space-y-6">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="overview">
                {language === 'ar' ? 'نظرة عامة' : 'Overview'}
              </TabsTrigger>
              <TabsTrigger value="models">
                {language === 'ar' ? 'النماذج' : 'Models'}
              </TabsTrigger>
              <TabsTrigger value="ensemble">
                {language === 'ar' ? 'التوقعات المجمعة' : 'Ensemble'}
              </TabsTrigger>
              <TabsTrigger value="learning">
                {language === 'ar' ? 'التعلم' : 'Learning'}
              </TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Models Health Overview */}
                <Card className="border border-gray-200 dark:border-gray-700">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Cpu className="h-5 w-5" />
                      {language === 'ar' ? 'صحة النماذج' : 'Models Health'}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {safeArray(systemStatus?.modelsHealth).map((model) => (
                      <div key={model.modelId} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                        <div>
                          <p className="font-medium capitalize">
                            {safeReplace(model.modelType, '_', ' ')}
                          </p>
                          <p className="text-sm text-gray-600 dark:text-gray-400">
                            {safeArray(model.specialization).slice(0, 2).join(', ') || 'General'}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="text-sm text-gray-600 dark:text-gray-400">
                            {language === 'ar' ? 'الدقة' : 'Accuracy'}
                          </p>
                          <p className="font-medium">
                            {(safeNumber(model.accuracy) * 100).toFixed(1)}%
                          </p>
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>

                {/* Market Analysis */}
                <Card className="border border-gray-200 dark:border-gray-700">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <BarChart3 className="h-5 w-5" />
                      {language === 'ar' ? 'تحليل السوق' : 'Market Analysis'}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600 dark:text-gray-400">
                        {language === 'ar' ? 'نظام السوق' : 'Market Regime'}
                      </span>
                      <Badge variant="outline" className="capitalize">
                        {safeString(systemStatus?.marketRegime)}
                      </Badge>
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600 dark:text-gray-400">
                        {language === 'ar' ? 'مستوى التقلب' : 'Volatility Level'}
                      </span>
                      <Badge variant="outline" className="capitalize">
                        {safeString(systemStatus?.volatilityLevel)}
                      </Badge>
                    </div>

                    {ensemblePrediction && (
                      <>
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-gray-600 dark:text-gray-400">
                            {language === 'ar' ? 'التوقع المجمع' : 'Ensemble Prediction'}
                          </span>
                          <Badge variant="default">
                            {safeString(ensemblePrediction.predictedOutcome)}
                          </Badge>
                        </div>
                        
                        <div className="space-y-2">
                          <div className="flex justify-between text-sm">
                            <span>{language === 'ar' ? 'احتمالية الشراء' : 'Buy Probability'}</span>
                            <span>{(safeNumber(ensemblePrediction.probabilityDistribution?.buyProb) * 100).toFixed(1)}%</span>
                          </div>
                          <Progress value={safeNumber(ensemblePrediction.probabilityDistribution?.buyProb) * 100} className="h-2" />
                        </div>
                      </>
                    )}
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="models" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {safeArray(systemStatus?.modelsHealth).map((model) => (
                  <Card 
                    key={model.modelId} 
                    className={`cursor-pointer transition-all border ${
                      selectedModel === model.modelId 
                        ? 'border-blue-500 shadow-lg' 
                        : 'border-gray-200 dark:border-gray-700 hover:border-gray-300'
                    }`}
                    onClick={() => setSelectedModel(model.modelId)}
                  >
                    <CardHeader>
                      <CardTitle className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Cpu className="h-5 w-5" />
                          <span className="capitalize">
                            {safeReplace(model.modelType, '_', ' ')}
                          </span>
                        </div>
                        <Badge variant={selectedModel === model.modelId ? 'default' : 'secondary'}>
                          {selectedModel === model.modelId ? (language === 'ar' ? 'مختار' : 'Selected') : (language === 'ar' ? 'اختر' : 'Select')}
                        </Badge>
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">
                            {language === 'ar' ? 'الدقة' : 'Accuracy'}
                          </p>
                          <p className="font-medium">
                            {(safeNumber(model.accuracy) * 100).toFixed(1)}%
                          </p>
                        </div>
                        
                        <div>
                          <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">
                            {language === 'ar' ? 'الثقة' : 'Confidence'}
                          </p>
                          <p className="font-medium">
                            {(safeNumber(model.confidence) * 100).toFixed(1)}%
                          </p>
                        </div>
                        
                        <div>
                          <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">
                            {language === 'ar' ? 'الدقة المحددة' : 'Precision'}
                          </p>
                          <p className="font-medium">
                            {(safeNumber(model.precision) * 100).toFixed(1)}%
                          </p>
                        </div>
                        
                        <div>
                          <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">
                            {language === 'ar' ? 'الاستدعاء' : 'Recall'}
                          </p>
                          <p className="font-medium">
                            {(safeNumber(model.recall) * 100).toFixed(1)}%
                          </p>
                        </div>
                      </div>
                      
                      <div>
                        <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                          {language === 'ar' ? 'التخصصات' : 'Specializations'}
                        </p>
                        <div className="flex flex-wrap gap-1">
                          {safeArray(model.specialization).length > 0 ? safeArray(model.specialization).map((spec) => (
                            <Badge key={spec} variant="outline" className="text-xs">
                              {safeReplace(spec, '_', ' ')}
                            </Badge>
                          )) : (
                            <Badge variant="outline" className="text-xs">
                              General
                            </Badge>
                          )}
                        </div>
                      </div>
                      
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600 dark:text-gray-400">
                          {language === 'ar' ? 'عينات التدريب' : 'Training Samples'}
                        </span>
                        <span className="font-medium">
                          {safeNumber(model.trainingSamples).toLocaleString()}
                        </span>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="ensemble" className="space-y-6">
              {ensemblePrediction && (
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <Card className="border border-gray-200 dark:border-gray-700">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <PieChart className="h-5 w-5" />
                        {language === 'ar' ? 'توزيع الاحتمالية' : 'Probability Distribution'}
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="space-y-3">
                        <div>
                          <div className="flex justify-between text-sm mb-1">
                            <span>{language === 'ar' ? 'احتمالية الشراء' : 'Buy Probability'}</span>
                            <span className="font-medium text-green-600">
                              {(safeNumber(ensemblePrediction.probabilityDistribution?.buyProb) * 100).toFixed(1)}%
                            </span>
                          </div>
                          <Progress value={safeNumber(ensemblePrediction.probabilityDistribution?.buyProb) * 100} className="h-3" />
                        </div>
                        
                        <div>
                          <div className="flex justify-between text-sm mb-1">
                            <span>{language === 'ar' ? 'احتمالية البيع' : 'Sell Probability'}</span>
                            <span className="font-medium text-red-600">
                              {(safeNumber(ensemblePrediction.probabilityDistribution?.sellProb) * 100).toFixed(1)}%
                            </span>
                          </div>
                          <Progress value={safeNumber(ensemblePrediction.probabilityDistribution?.sellProb) * 100} className="h-3" />
                        </div>
                        
                        <div>
                          <div className="flex justify-between text-sm mb-1">
                            <span>{language === 'ar' ? 'احتمالية الانتظار' : 'Hold Probability'}</span>
                            <span className="font-medium text-gray-600">
                              {(safeNumber(ensemblePrediction.probabilityDistribution?.holdProb) * 100).toFixed(1)}%
                            </span>
                          </div>
                          <Progress value={safeNumber(ensemblePrediction.probabilityDistribution?.holdProb) * 100} className="h-3" />
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="border border-gray-200 dark:border-gray-700">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <DollarSign className="h-5 w-5" />
                        {language === 'ar' ? 'مقاييس المخاطر' : 'Risk Metrics'}
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div className="text-center p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                          <p className="text-lg font-bold text-blue-600 dark:text-blue-400">
                            {safeNumber(ensemblePrediction.riskMetrics?.expectedReturn).toFixed(2)}%
                          </p>
                          <p className="text-xs text-blue-700 dark:text-blue-300">
                            {language === 'ar' ? 'العائد المتوقع' : 'Expected Return'}
                          </p>
                        </div>
                        
                        <div className="text-center p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                          <p className="text-lg font-bold text-purple-600 dark:text-purple-400">
                            {safeNumber(ensemblePrediction.riskMetrics?.volatility).toFixed(2)}%
                          </p>
                          <p className="text-xs text-purple-700 dark:text-purple-300">
                            {language === 'ar' ? 'التقلب' : 'Volatility'}
                          </p>
                        </div>
                        
                        <div className="text-center p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                          <p className="text-lg font-bold text-green-600 dark:text-green-400">
                            {safeNumber(ensemblePrediction.riskMetrics?.sharpeRatio).toFixed(2)}
                          </p>
                          <p className="text-xs text-green-700 dark:text-green-300">
                            {language === 'ar' ? 'نسبة شارب' : 'Sharpe Ratio'}
                          </p>
                        </div>
                        
                        <div className="text-center p-3 bg-red-50 dark:bg-red-900/20 rounded-lg">
                          <p className="text-lg font-bold text-red-600 dark:text-red-400">
                            {safeNumber(ensemblePrediction.riskMetrics?.valueAtRisk).toFixed(2)}%
                          </p>
                          <p className="text-xs text-red-700 dark:text-red-300">
                            {language === 'ar' ? 'القيمة المعرضة للخطر' : 'Value at Risk'}
                          </p>
                        </div>
                      </div>
                      
                      <div className="pt-4 border-t border-gray-200 dark:border-gray-700">
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm text-gray-600 dark:text-gray-400">
                            {language === 'ar' ? 'استراتيجية التداول' : 'Trading Strategy'}
                          </span>
                        </div>
                        <p className="text-sm font-medium bg-gray-100 dark:bg-gray-800 p-2 rounded">
                          {safeString(ensemblePrediction.marketRegimeAnalysis?.tradingStrategy, 'No strategy available')}
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              )}
            </TabsContent>

            <TabsContent value="learning" className="space-y-6">
              {performanceMetrics && (
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <Card className="border border-gray-200 dark:border-gray-700">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Lightbulb className="h-5 w-5" />
                        {language === 'ar' ? 'اقتراحات التحسين' : 'Optimization Suggestions'}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        {safeArray(performanceMetrics.optimizationSuggestions).map((suggestion, index) => (
                          <div key={index} className="flex items-start gap-3 p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                            <Settings className="h-4 w-4 text-blue-600 mt-1 flex-shrink-0" />
                            <p className="text-sm text-blue-800 dark:text-blue-200">
                              {safeString(suggestion)}
                            </p>
                          </div>
                        ))}
                        {safeArray(performanceMetrics.optimizationSuggestions).length === 0 && (
                          <p className="text-gray-600 dark:text-gray-400 text-center py-4">
                            {language === 'ar' ? 'لا توجد اقتراحات تحسين حالياً' : 'No optimization suggestions at the moment'}
                          </p>
                        )}
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="border border-gray-200 dark:border-gray-700">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Database className="h-5 w-5" />
                        {language === 'ar' ? 'إحصائيات التعلم' : 'Learning Statistics'}
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div className="text-center p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
                          <p className="text-2xl font-bold text-green-600 dark:text-green-400">
                            {safeNumber(performanceMetrics.modelUpdates)}
                          </p>
                          <p className="text-sm text-green-700 dark:text-green-300">
                            {language === 'ar' ? 'تحديثات النماذج' : 'Model Updates'}
                          </p>
                        </div>
                        
                        <div className="text-center p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                          <p className="text-2xl font-bold text-purple-600 dark:text-purple-400">
                            {safeNumber(performanceMetrics.newPatterns)}
                          </p>
                          <p className="text-sm text-purple-700 dark:text-purple-300">
                            {language === 'ar' ? 'أنماط جديدة' : 'New Patterns'}
                          </p>
                        </div>
                      </div>
                      
                      <div className="space-y-3">
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-gray-600 dark:text-gray-400">
                            {language === 'ar' ? 'تحسين الدقة' : 'Accuracy Improvement'}
                          </span>
                          <span className={`font-bold ${safeNumber(performanceMetrics.accuracyImprovement) >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                            {safeNumber(performanceMetrics.accuracyImprovement) >= 0 ? '+' : ''}{safeNumber(performanceMetrics.accuracyImprovement).toFixed(1)}%
                          </span>
                        </div>
                        
                        <div className="space-y-2">
                          <div className="flex justify-between text-sm">
                            <span>{language === 'ar' ? 'فقدان التدريب' : 'Training Loss'}</span>
                            <span className="font-medium">{safeNumber(performanceMetrics.learningProgress?.trainingLoss).toFixed(4)}</span>
                          </div>
                          <Progress value={Math.max(0, 100 - (safeNumber(performanceMetrics.learningProgress?.trainingLoss) * 100))} className="h-2" />
                        </div>
                        
                        <div className="space-y-2">
                          <div className="flex justify-between text-sm">
                            <span>{language === 'ar' ? 'فقدان التحقق' : 'Validation Loss'}</span>
                            <span className="font-medium">{safeNumber(performanceMetrics.learningProgress?.validationLoss).toFixed(4)}</span>
                          </div>
                          <Progress value={Math.max(0, 100 - (safeNumber(performanceMetrics.learningProgress?.validationLoss) * 100))} className="h-2" />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              )}
            </TabsContent>
          </Tabs>

          {/* Status Footer */}
          <Card className="border border-gray-200 dark:border-gray-700">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2">
                    <Zap className="h-4 w-4 text-green-600" />
                    <span className="text-sm text-gray-600 dark:text-gray-400">
                      {language === 'ar' ? 'النظام' : 'System'}
                    </span>
                    <Badge variant="default" className="bg-purple-600">
                      {language === 'ar' ? 'يعمل' : 'Running'}
                    </Badge>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600 dark:text-gray-400">
                      {language === 'ar' ? 'آخر تحديث' : 'Last Update'}
                    </span>
                    <div className="flex items-center gap-1">
                      <Clock className="h-3 w-3 text-gray-400" />
                      <span className="text-sm font-mono">
                        {safeString(systemStatus?.lastUpdate, new Date().toLocaleTimeString())}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}
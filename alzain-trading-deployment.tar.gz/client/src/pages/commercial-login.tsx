import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";
import { Link, useLocation } from "wouter";
import { Eye, EyeOff, LogIn, Zap, Lock, User } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

export default function CommercialLogin() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError("");

    try {
      const response = await apiRequest("POST", "/api/commercial/login", {
        username,
        password,
      });

      // Store token in localStorage
      localStorage.setItem("commercial_token", response.token);
      
      toast({
        title: "تم تسجيل الدخول بنجاح",
        description: `مرحباً ${response.user.firstName}!`,
      });

      // Redirect to dashboard
      setLocation("/commercial/dashboard");
      
    } catch (error: any) {
      console.error("Login error:", error);
      
      if (error.message.includes("401")) {
        setError("اسم المستخدم أو كلمة المرور غير صحيحة");
      } else if (error.message.includes("423")) {
        setError("الحساب مقفل مؤقتاً بسبب محاولات دخول متكررة");
      } else if (error.message.includes("403")) {
        setError("يرجى تفعيل حسابك من خلال البريد الإلكتروني أولاً");
      } else {
        setError("حدث خطأ أثناء تسجيل الدخول");
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-800 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Logo and Title */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-emerald-500 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
            <Zap className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">الزين تريد</h1>
          <p className="text-gray-300">النظام التجاري المتطور</p>
        </div>

        <Card className="bg-white/10 backdrop-blur-lg border-white/20 shadow-xl">
          <CardHeader className="text-center">
            <CardTitle className="text-white text-xl flex items-center justify-center gap-2">
              <LogIn className="w-5 h-5" />
              تسجيل الدخول
            </CardTitle>
            <CardDescription className="text-gray-300">
              سجل دخولك للوصول إلى لوحة التحكم التجارية
            </CardDescription>
          </CardHeader>

          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              {error && (
                <Alert className="border-red-500/50 bg-red-500/10">
                  <AlertDescription className="text-red-200">
                    {error}
                  </AlertDescription>
                </Alert>
              )}

              <div className="space-y-2">
                <Label htmlFor="username" className="text-gray-300 flex items-center gap-2">
                  <User className="w-4 h-4" />
                  اسم المستخدم
                </Label>
                <Input
                  id="username"
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="bg-white/5 border-white/20 text-white placeholder:text-gray-400"
                  placeholder="أدخل اسم المستخدم"
                  required
                  disabled={isLoading}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password" className="text-gray-300 flex items-center gap-2">
                  <Lock className="w-4 h-4" />
                  كلمة المرور
                </Label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="bg-white/5 border-white/20 text-white placeholder:text-gray-400 pr-10"
                    placeholder="أدخل كلمة المرور"
                    required
                    disabled={isLoading}
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-0 top-0 h-full px-3 text-gray-400 hover:text-white"
                    onClick={() => setShowPassword(!showPassword)}
                    disabled={isLoading}
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </Button>
                </div>
              </div>

              <Button
                type="submit"
                className="w-full bg-gradient-to-r from-blue-600 to-emerald-600 hover:from-blue-700 hover:to-emerald-700 text-white shadow-lg"
                disabled={isLoading}
              >
                {isLoading ? (
                  <div className="flex items-center justify-center">
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                    جاري تسجيل الدخول...
                  </div>
                ) : (
                  <>
                    <LogIn className="w-4 h-4 ml-2" />
                    تسجيل الدخول
                  </>
                )}
              </Button>

              <div className="text-center space-y-2">
                <Link href="/commercial/forgot-password">
                  <Button variant="link" className="text-gray-300 hover:text-white p-0">
                    نسيت كلمة المرور؟
                  </Button>
                </Link>
              </div>
            </form>
          </CardContent>
        </Card>

        <div className="text-center mt-6">
          <p className="text-gray-300 mb-4">لا تملك حساباً؟</p>
          <Link href="/commercial/register">
            <Button variant="outline" className="border-white/20 text-white hover:bg-white/10">
              إنشاء حساب جديد
            </Button>
          </Link>
        </div>

        <div className="text-center mt-8">
          <Link href="/">
            <Button variant="ghost" className="text-gray-400 hover:text-white">
              العودة إلى المنصة الرئيسية
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
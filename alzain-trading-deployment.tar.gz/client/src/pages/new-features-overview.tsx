import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Users, 
  Mic, 
  Brain, 
  LineChart, 
  Briefcase,
  CheckCircle,
  Star,
  Zap,
  Target,
  TrendingUp,
  Globe,
  Shield,
  BarChart3,
  Activity,
  Settings,
  Eye,
  Palette
} from "lucide-react";
import { motion } from "framer-motion";
import { Link } from "wouter";

interface FeatureItem {
  id: string;
  title: string;
  titleAr: string;
  description: string;
  descriptionAr: string;
  icon: any;
  href: string;
  status: "completed" | "active" | "beta";
  badge: string;
  features: string[];
  featuresAr: string[];
  benefits: string[];
  benefitsAr: string[];
  gradient: string;
}

const newFeatures: FeatureItem[] = [
  {
    id: "social-trading",
    title: "Social Trading Leaderboard with Skill Ranking",
    titleAr: "لوحة قادة التداول الاجتماعي مع تصنيف المهارات",
    description: "Follow top traders, copy their strategies, and compete in skill-based rankings",
    descriptionAr: "تابع أفضل المتداولين، انسخ استراتيجياتهم، وتنافس في تصنيفات قائمة على المهارات",
    icon: Users,
    href: "/social-trading",
    status: "completed",
    badge: "Pro",
    features: [
      "Trader skill rankings with performance metrics",
      "Copy trading capabilities",
      "Social networking features",
      "Performance tracking and analytics",
      "Multi-level trader categorization"
    ],
    featuresAr: [
      "تصنيفات مهارات المتداولين مع مقاييس الأداء",
      "إمكانيات نسخ التداول",
      "ميزات الشبكات الاجتماعية",
      "تتبع الأداء والتحليلات",
      "تصنيف المتداولين متعدد المستويات"
    ],
    benefits: [
      "Learn from experienced traders",
      "Reduce learning curve",
      "Diversify trading strategies",
      "Build trading community"
    ],
    benefitsAr: [
      "تعلم من المتداولين ذوي الخبرة",
      "قلل منحنى التعلم",
      "نوع استراتيجيات التداول",
      "بناء مجتمع التداول"
    ],
    gradient: "from-blue-500 to-purple-600"
  },
  {
    id: "voice-assistant",
    title: "Multilingual Voice-Activated Trading Assistant",
    titleAr: "مساعد التداول الصوتي متعدد اللغات",
    description: "Control your trading platform with voice commands in multiple languages",
    descriptionAr: "تحكم في منصة التداول الخاصة بك بأوامر صوتية بلغات متعددة",
    icon: Mic,
    href: "/voice-assistant",
    status: "completed",
    badge: "AI",
    features: [
      "Voice commands in 4+ languages",
      "Real-time speech recognition",
      "Trading actions via voice",
      "Customizable voice settings",
      "Hands-free trading control"
    ],
    featuresAr: [
      "أوامر صوتية بأكثر من 4 لغات",
      "التعرف على الكلام في الوقت الفعلي",
      "إجراءات التداول عبر الصوت",
      "إعدادات صوتية قابلة للتخصيص",
      "التحكم في التداول بدون استخدام اليدين"
    ],
    benefits: [
      "Hands-free trading experience",
      "Faster command execution",
      "Accessibility improvement",
      "Multilingual support"
    ],
    benefitsAr: [
      "تجربة تداول بدون استخدام اليدين",
      "تنفيذ أسرع للأوامر",
      "تحسين إمكانية الوصول",
      "دعم متعدد اللغات"
    ],
    gradient: "from-green-500 to-teal-600"
  },
  {
    id: "news-analyzer",
    title: "Advanced News Analyzer with OpenAI Integration",
    titleAr: "محلل الأخبار المتقدم مع تكامل OpenAI",
    description: "AI-powered news analysis with market impact assessment and trading signals",
    descriptionAr: "تحليل الأخبار المدعوم بالذكاء الاصطناعي مع تقييم تأثير السوق وإشارات التداول",
    icon: Brain,
    href: "/news-analyzer",
    status: "completed",
    badge: "AI",
    features: [
      "Real-time news sentiment analysis",
      "Market impact assessment",
      "Trading implications extraction",
      "Multi-source news aggregation",
      "AI-powered insights generation"
    ],
    featuresAr: [
      "تحليل مشاعر الأخبار في الوقت الفعلي",
      "تقييم تأثير السوق",
      "استخراج آثار التداول",
      "تجميع الأخبار من مصادر متعددة",
      "توليد رؤى مدعومة بالذكاء الاصطناعي"
    ],
    benefits: [
      "Stay ahead of market news",
      "Make informed decisions",
      "Identify trading opportunities",
      "Reduce market risk"
    ],
    benefitsAr: [
      "ابق في المقدمة من أخبار السوق",
      "اتخذ قرارات مدروسة",
      "تحديد فرص التداول",
      "تقليل مخاطر السوق"
    ],
    gradient: "from-purple-500 to-pink-600"
  },
  {
    id: "interactive-charts",
    title: "Interactive Trading Charts with Drawing Tools",
    titleAr: "الرسوم البيانية التفاعلية لتداول مع أدوات الرسم",
    description: "Advanced charting capabilities with technical analysis and interactive drawing tools",
    descriptionAr: "قدرات رسم بياني متقدمة مع التحليل الفني وأدوات الرسم التفاعلية",
    icon: LineChart,
    href: "/interactive-charts",
    status: "completed",
    badge: "Pro",
    features: [
      "Multiple chart types and timeframes",
      "20+ technical indicators",
      "Interactive drawing tools",
      "Real-time data updates",
      "Customizable chart themes"
    ],
    featuresAr: [
      "أنواع الرسوم البيانية والإطارات الزمنية المتعددة",
      "أكثر من 20 مؤشر فني",
      "أدوات رسم تفاعلية",
      "تحديثات البيانات في الوقت الفعلي",
      "قوالب رسوم بيانية قابلة للتخصيص"
    ],
    benefits: [
      "Professional chart analysis",
      "Better trading decisions",
      "Visual market insights",
      "Enhanced technical analysis"
    ],
    benefitsAr: [
      "تحليل مخططات احترافي",
      "قرارات تداول أفضل",
      "رؤى بصرية للسوق",
      "تحليل فني محسن"
    ],
    gradient: "from-orange-500 to-red-600"
  },
  {
    id: "portfolio-manager",
    title: "Advanced Portfolio Manager with Risk Analytics",
    titleAr: "مدير المحفظة المتقدم مع تحليلات المخاطر",
    description: "Comprehensive portfolio management with advanced risk metrics and position tracking",
    descriptionAr: "إدارة محفظة شاملة مع مقاييس مخاطر متقدمة وتتبع المراكز",
    icon: Briefcase,
    href: "/advanced-portfolio",
    status: "completed",
    badge: "Pro",
    features: [
      "Real-time P&L tracking",
      "Advanced risk metrics (VaR, ES)",
      "Position management",
      "Diversification analysis",
      "Performance analytics"
    ],
    featuresAr: [
      "تتبع الربح والخسارة في الوقت الفعلي",
      "مقاييس مخاطر متقدمة (VaR، ES)",
      "إدارة المراكز",
      "تحليل التنويع",
      "تحليلات الأداء"
    ],
    benefits: [
      "Better risk management",
      "Portfolio optimization",
      "Performance tracking",
      "Professional analytics"
    ],
    benefitsAr: [
      "إدارة أفضل للمخاطر",
      "تحسين المحفظة",
      "تتبع الأداء",
      "تحليلات احترافية"
    ],
    gradient: "from-indigo-500 to-blue-600"
  }
];

export default function NewFeaturesOverview() {
  const [language, setLanguage] = useState("en");

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="text-center space-y-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            {language === "en" ? "New Features Overview" : "نظرة عامة على الميزات الجديدة"}
          </h1>
          <p className="text-xl text-gray-600 mt-4 max-w-3xl mx-auto">
            {language === "en" 
              ? "Discover the latest enhancements to your trading platform - 5 major new features designed to revolutionize your trading experience"
              : "اكتشف أحدث التحسينات على منصة التداول الخاصة بك - 5 ميزات جديدة رئيسية مصممة لثورة في تجربة التداول الخاصة بك"
            }
          </p>
        </motion.div>
        
        <div className="flex items-center justify-center gap-4">
          <Button
            variant="outline"
            onClick={() => setLanguage(language === "en" ? "ar" : "en")}
          >
            {language === "en" ? "العربية" : "English"}
          </Button>
          <Badge className="bg-green-100 text-green-800 px-4 py-2">
            <CheckCircle className="w-4 h-4 mr-2" />
            {language === "en" ? "All Features Completed" : "جميع الميزات مكتملة"}
          </Badge>
        </div>
      </div>

      {/* Features Grid */}
      <div className="grid gap-8">
        {newFeatures.map((feature, index) => (
          <motion.div
            key={feature.id}
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: index * 0.1 }}
          >
            <Card className="overflow-hidden hover:shadow-2xl transition-all duration-300 border-0 bg-gradient-to-br from-white to-gray-50">
              <div className={`h-2 bg-gradient-to-r ${feature.gradient}`} />
              <CardHeader className="pb-6">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex items-start gap-4 flex-1 min-w-0">
                    <div className={`p-4 rounded-xl bg-gradient-to-r ${feature.gradient} text-white shadow-lg flex-shrink-0`}>
                      <feature.icon className="w-8 h-8" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <CardTitle className="text-2xl mb-3 leading-relaxed break-words">
                        {language === "en" ? feature.title : feature.titleAr}
                      </CardTitle>
                      <CardDescription className="text-lg leading-relaxed">
                        {language === "en" ? feature.description : feature.descriptionAr}
                      </CardDescription>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge className={`${
                      feature.status === "completed" ? "bg-green-100 text-green-800" :
                      feature.status === "active" ? "bg-blue-100 text-blue-800" :
                      "bg-yellow-100 text-yellow-800"
                    }`}>
                      {feature.status === "completed" ? (
                        <CheckCircle className="w-3 h-3 mr-1" />
                      ) : feature.status === "active" ? (
                        <Zap className="w-3 h-3 mr-1" />
                      ) : (
                        <Star className="w-3 h-3 mr-1" />
                      )}
                      {feature.status}
                    </Badge>
                    <Badge variant="outline" className="font-medium">
                      {feature.badge}
                    </Badge>
                  </div>
                </div>
              </CardHeader>
              
              <CardContent className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  {/* Features */}
                  <div>
                    <h4 className="text-lg font-semibold mb-3 flex items-center gap-2">
                      <Settings className="w-5 h-5 text-blue-500" />
                      {language === "en" ? "Key Features" : "الميزات الرئيسية"}
                    </h4>
                    <ul className="space-y-3">
                      {(language === "en" ? feature.features : feature.featuresAr).map((item, idx) => (
                        <li key={idx} className="flex items-start gap-3">
                          <CheckCircle className="w-4 h-4 text-green-500 mt-1 flex-shrink-0" />
                          <span className="text-gray-700 leading-relaxed break-words">{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                  
                  {/* Benefits */}
                  <div>
                    <h4 className="text-lg font-semibold mb-3 flex items-center gap-2">
                      <TrendingUp className="w-5 h-5 text-green-500" />
                      {language === "en" ? "Benefits" : "الفوائد"}
                    </h4>
                    <ul className="space-y-3">
                      {(language === "en" ? feature.benefits : feature.benefitsAr).map((benefit, idx) => (
                        <li key={idx} className="flex items-start gap-3">
                          <Star className="w-4 h-4 text-yellow-500 mt-1 flex-shrink-0" />
                          <span className="text-gray-700 leading-relaxed break-words">{benefit}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
                
                {/* Action Button */}
                <div className="pt-4 border-t">
                  <Link href={feature.href}>
                    <Button className={`w-full bg-gradient-to-r ${feature.gradient} hover:shadow-lg transition-all duration-300`}>
                      <Eye className="w-4 h-4 mr-2" />
                      {language === "en" ? "Explore Feature" : "استكشف الميزة"}
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Summary Stats */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.5 }}
      >
        <Card className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
          <CardContent className="p-8">
            <div className="text-center space-y-4">
              <h3 className="text-2xl font-bold">
                {language === "en" ? "Platform Enhancement Summary" : "ملخص تحسينات المنصة"}
              </h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                <div className="text-center">
                  <p className="text-3xl font-bold">5</p>
                  <p className="text-blue-100">
                    {language === "en" ? "New Features" : "ميزات جديدة"}
                  </p>
                </div>
                <div className="text-center">
                  <p className="text-3xl font-bold">4</p>
                  <p className="text-blue-100">
                    {language === "en" ? "Languages" : "لغات"}
                  </p>
                </div>
                <div className="text-center">
                  <p className="text-3xl font-bold">20+</p>
                  <p className="text-blue-100">
                    {language === "en" ? "Indicators" : "مؤشرات"}
                  </p>
                </div>
                <div className="text-center">
                  <p className="text-3xl font-bold">100%</p>
                  <p className="text-blue-100">
                    {language === "en" ? "Complete" : "مكتمل"}
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
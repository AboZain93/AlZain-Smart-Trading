import { useState, useEffect } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { useLanguageContext } from '../components/language-provider';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Switch } from '../components/ui/switch';
import { Slider } from '../components/ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Badge } from '../components/ui/badge';
import { Label } from '../components/ui/label';
import { Separator } from '../components/ui/separator';
import { Input } from '../components/ui/input';
import { Checkbox } from '../components/ui/checkbox';
import { Progress } from '../components/ui/progress';
import { useToast } from '../hooks/use-toast';
import { apiRequest, queryClient } from '../lib/queryClient';
import { FloatingRefreshButton } from '../components/floating-refresh-button';
import { 
  Play, 
  Pause, 
  Settings, 
  Clock, 
  Target, 
  AlertTriangle,
  Activity,
  TrendingUp,
  Bot,
  Zap,
  Shield,
  BarChart3,
  DollarSign,
  TimerIcon,
  Save,
  RotateCcw
} from 'lucide-react';
import { CountdownTimer } from '../components/countdown-timer';
import PlatformSelector from '../components/platform-selector';
import { motion, AnimatePresence } from 'framer-motion';

interface TradingSettings {
  autoSignalsEnabled: boolean;
  signalInterval: number; // minutes
  minConfidence: number; // percentage
  maxRiskLevel: 'low' | 'medium' | 'high';
  enabledAssets: string[];
  tradingHours: {
    start: string;
    end: string;
    enabled: boolean;
  };
  maxSignalsPerDay: number;
  stopLossEnabled: boolean;
  takeProfitEnabled: boolean;
}

interface SystemStatus {
  isActive: boolean;
  lastSignal: string;
  signalsToday: number;
  successRate: number;
  nextSignalIn: number;
}

interface TelegramStats {
  sentToday: number;
  subscribers: number;
  totalSent: number;
  lastSent: string;
}

const DEFAULT_SETTINGS: TradingSettings = {
  autoSignalsEnabled: false,
  signalInterval: 5,
  minConfidence: 70,
  maxRiskLevel: 'medium',
  enabledAssets: ['EUR/USD', 'GBP/USD', 'XAU/USD', 'BTC/USD'],
  tradingHours: {
    start: '09:00',
    end: '17:00',
    enabled: true
  },
  maxSignalsPerDay: 20,
  stopLossEnabled: true,
  takeProfitEnabled: true
};

const STORAGE_KEY = 'trading-settings';

export default function TradingControl() {
  const { language } = useLanguageContext();
  const { toast } = useToast();
  const [settings, setSettings] = useState<TradingSettings>(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    return saved ? JSON.parse(saved) : DEFAULT_SETTINGS;
  });
  const [isGenerating, setIsGenerating] = useState(false);
  const [autoSignalInterval, setAutoSignalInterval] = useState<NodeJS.Timeout | null>(null);
  const [hasUserInteracted, setHasUserInteracted] = useState(false);

  // Fetch actual system status from backend with trading settings
  const { data: systemStatus, refetch: refetchStatus } = useQuery<SystemStatus>({
    queryKey: ['/api/system-status', settings.signalInterval, settings.autoSignalsEnabled],
    queryFn: ({ queryKey }) => {
      const [_, interval, active] = queryKey;
      return fetch(`/api/system-status?interval=${interval}&active=${active}`)
        .then(res => res.json());
    },
    refetchInterval: 5000, // Update every 5 seconds
  });

  // Fetch telegram stats
  const { data: telegramStats } = useQuery<TelegramStats>({
    queryKey: ['/api/telegram/stats'],
    refetchInterval: 10000,
  });

  // Fetch daily signals setting
  const { data: dailySignalsData, refetch: refetchDailySignals } = useQuery<{count: number}>({
    queryKey: ['/api/system/daily-signals'],
    refetchInterval: 30000,
  });

  // Update daily signals setting mutation
  const updateDailySignalsMutation = useMutation({
    mutationFn: async (count: number) => {
      return apiRequest('POST', '/api/system/daily-signals', { count });
    },
    onSuccess: () => {
      refetchDailySignals();
      toast({
        title: language === 'ar' ? 'تم التحديث' : 'Updated',
        description: language === 'ar' 
          ? 'تم تحديث عدد الإشارات اليومية بنجاح' 
          : 'Daily signals count updated successfully',
      });
    },
  });

  // Save settings mutation
  const saveSettingsMutation = useMutation({
    mutationFn: async (newSettings: TradingSettings) => {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(newSettings));
      return apiRequest('POST', '/api/trading-settings/update', newSettings);
    },
    onSuccess: () => {
      toast({
        title: language === 'ar' ? 'تم الحفظ' : 'Settings Saved',
        description: language === 'ar' 
          ? 'تم حفظ إعدادات التداول بنجاح' 
          : 'Trading settings saved successfully',
      });
    },
  });

  // Generate immediate signal mutation
  const generateSignalMutation = useMutation({
    mutationFn: async () => {
      const assets = settings.enabledAssets;
      const randomAsset = assets[Math.floor(Math.random() * assets.length)];
      
      const response = await apiRequest('POST', '/api/generate-recommendation', {
        symbol: randomAsset,
        sendToTelegram: true,
        minConfidence: settings.minConfidence,
        maxRiskLevel: settings.maxRiskLevel,
      });
      
      return response;
    },
    onSuccess: (data: any) => {
      refetchStatus();
      queryClient.invalidateQueries({ queryKey: ['/api/telegram/stats'] });
      queryClient.invalidateQueries({ queryKey: ['/api/trading-recommendations/recent'] });
      
      toast({
        title: language === 'ar' ? 'تم إنشاء إشارة جديدة بنجاح' : 'New Signal Generated Successfully',
        description: language === 'ar' 
          ? 'تم إرسال الإشارة الجديدة إلى تليجرام بنجاح' 
          : 'New signal sent to Telegram successfully',
      });
    },
    onError: (error: any) => {
      console.error('Signal generation failed:', error);
      toast({
        title: language === 'ar' ? 'فشل في إنشاء الإشارة' : 'Signal Generation Failed',
        description: language === 'ar' 
          ? `السبب: ${error.message}` 
          : `Reason: ${error.message}`,
        variant: 'destructive',
      });
    },
  });

  // Save settings mutation
  const saveSettingsMutation = useMutation({
    mutationFn: async (newSettings: TradingSettings) => {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(newSettings));
      return apiRequest('POST', '/api/trading-settings', newSettings);
    },
    onSuccess: () => {
      toast({
        title: language === 'ar' ? 'تم الحفظ' : 'Settings Saved',
        description: language === 'ar' 
          ? 'تم حفظ إعدادات التداول بنجاح' 
          : 'Trading settings saved successfully',
      });
    },
  });

  // Update auto signals settings when interval changes
  const updateAutoSignalsSettingsMutation = useMutation({
    mutationFn: async () => {
      if (settings.autoSignalsEnabled) {
        return apiRequest('POST', '/api/auto-signals/start', {
          interval: settings.signalInterval,
          maxPerDay: settings.maxSignalsPerDay,
          minConfidence: settings.minConfidence,
          maxRiskLevel: settings.maxRiskLevel,
          enabledAssets: settings.enabledAssets,
          tradingHours: settings.tradingHours,
          stopLossEnabled: settings.stopLossEnabled,
          takeProfitEnabled: settings.takeProfitEnabled
        });
      }
      return Promise.resolve();
    },
    onSuccess: () => {
      refetchStatus();
    }
  });

  // Update auto signals settings when any setting changes (only if user has interacted)
  useEffect(() => {
    if (settings.autoSignalsEnabled && hasUserInteracted) {
      updateAutoSignalsSettingsMutation.mutate();
    }
  }, [settings.signalInterval, settings.maxSignalsPerDay, settings.minConfidence, settings.maxRiskLevel, settings.enabledAssets, settings.tradingHours, settings.stopLossEnabled, settings.takeProfitEnabled]);

  // Save settings to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
  }, [settings]);

  // Sync auto signals status with server (only on initial load)
  useEffect(() => {
    if (systemStatus !== undefined && !hasUserInteracted) {
      setSettings(prev => ({
        ...prev,
        autoSignalsEnabled: systemStatus.isActive
      }));
    }
  }, [systemStatus?.isActive]);

  // Display the current auto signals state (use server state if available)
  const currentAutoSignalsState = systemStatus?.isActive ?? settings.autoSignalsEnabled;

  const handleSettingsChange = (key: keyof TradingSettings, value: any) => {
    setSettings(prev => ({
      ...prev,
      [key]: value
    }));
  };

  // Toggle auto signals mutation with full settings
  const toggleAutoSignalsMutation = useMutation({
    mutationFn: async (enabled: boolean) => {
      if (enabled) {
        return apiRequest('POST', '/api/auto-signals/start', {
          interval: settings.signalInterval,
          maxPerDay: settings.maxSignalsPerDay,
          minConfidence: settings.minConfidence,
          maxRiskLevel: settings.maxRiskLevel,
          enabledAssets: settings.enabledAssets,
          tradingHours: settings.tradingHours,
          stopLossEnabled: settings.stopLossEnabled,
          takeProfitEnabled: settings.takeProfitEnabled
        });
      } else {
        return apiRequest('POST', '/api/auto-signals/stop');
      }
    },
    onSuccess: (data: any, enabled: boolean) => {
      // Only update settings if the request succeeded
      if (data && data.success) {
        setSettings(prev => ({
          ...prev,
          autoSignalsEnabled: enabled
        }));
        
        toast({
          title: language === 'ar' ? 'تم التحديث' : 'Updated',
          description: enabled 
            ? (language === 'ar' ? 'تم تفعيل الإشارات التلقائية' : 'Auto signals enabled')
            : (language === 'ar' ? 'تم إيقاف الإشارات التلقائية' : 'Auto signals disabled'),
        });
      }
      
      // Always refetch status to get the real server state
      refetchStatus();
    },
    onError: (error: any) => {
      console.error('Toggle auto signals failed:', error);
      toast({
        title: language === 'ar' ? 'فشل في التحديث' : 'Update Failed',
        description: language === 'ar' 
          ? `السبب: ${error.message}` 
          : `Reason: ${error.message}`,
        variant: 'destructive',
      });
      // Refetch status to reset to actual server state
      refetchStatus();
    },
  });

  const handleToggleAutoSignals = () => {
    setHasUserInteracted(true); // Mark that user has interacted
    const newStatus = !currentAutoSignalsState;
    toggleAutoSignalsMutation.mutate(newStatus);
  };

  const handleGenerateSignal = () => {
    generateSignalMutation.mutate();
  };

  const handleSaveSettings = () => {
    saveSettingsMutation.mutate(settings);
  };

  const handleRefreshData = () => {
    refetchStatus();
    refetchDailySignals();
    queryClient.invalidateQueries({ queryKey: ['/api/telegram/stats'] });
    queryClient.invalidateQueries({ queryKey: ['/api/trading-recommendations'] });
  };

  const getStatusColor = () => {
    if (systemStatus?.isActive) {
      return 'text-green-600 bg-green-50';
    }
    return 'text-red-600 bg-red-50';
  };

  const getStatusText = () => {
    if (systemStatus?.isActive) {
      return language === 'ar' ? 'نشط' : 'Active';
    }
    return language === 'ar' ? 'متوقف' : 'Stopped';
  };

  return (
    <div className="container mx-auto p-6 max-w-6xl">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <Settings className="h-8 w-8 text-primary" />
          <h1 className="text-3xl font-bold">
            {language === 'ar' ? 'التحكم في التداول' : 'Trading Control'}
          </h1>
        </div>

      </div>

      {/* حالة النظام */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Activity className="h-5 w-5" />
              {language === 'ar' ? 'حالة النظام' : 'System Status'}
            </div>
            <Badge className={getStatusColor()}>
              {getStatusText()}
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="text-center p-4 bg-muted rounded-lg">
              <TrendingUp className="h-8 w-8 text-blue-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-blue-600">
                {telegramStats?.sentToday || 0}
              </div>
              <div className="text-sm text-muted-foreground">
                {language === 'ar' ? 'إشارات اليوم' : 'Signals Today'}
              </div>
            </div>

            <div className="text-center p-4 bg-muted rounded-lg">
              <Target className="h-8 w-8 text-green-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-green-600">
                {systemStatus?.successRate ? systemStatus.successRate.toFixed(1) : '0.0'}%
              </div>
              <div className="text-sm text-muted-foreground">
                {language === 'ar' ? 'معدل النجاح' : 'Success Rate'}
              </div>
            </div>

            <CountdownTimer 
              targetMinutes={settings.signalInterval}
              isActive={settings.autoSignalsEnabled}
              onComplete={() => {
                if (settings.autoSignalsEnabled && telegramStats && telegramStats.sentToday < (dailySignalsData?.count || settings.maxSignalsPerDay)) {
                  generateSignalMutation.mutate();
                }
              }}
            />

            <div className="text-center p-4 bg-muted rounded-lg">
              <Bot className="h-8 w-8 text-orange-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-orange-600">
                {(dailySignalsData?.count || settings.maxSignalsPerDay) - (telegramStats?.sentToday || 0)}
              </div>
              <div className="text-sm text-muted-foreground">
                {language === 'ar' ? 'إشارات متبقية اليوم' : 'Signals Left Today'}
              </div>
            </div>

            <div className="text-center p-4 bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-900/20 dark:to-blue-800/20 rounded-lg border">
              <Target className="h-8 w-8 text-blue-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-blue-600">
                {dailySignalsData?.count || settings.maxSignalsPerDay}
              </div>
              <div className="text-sm text-muted-foreground mb-2">
                {language === 'ar' ? 'إجمالي الإشارات اليومية' : 'Total Daily Signals'}
              </div>
              <div className="flex gap-2 justify-center">
                <Button 
                  size="sm" 
                  variant="outline"
                  onClick={() => updateDailySignalsMutation.mutate((dailySignalsData?.count || settings.maxSignalsPerDay) - 5)}
                  disabled={updateDailySignalsMutation.isPending || (dailySignalsData?.count || settings.maxSignalsPerDay) <= 5}
                >
                  -5
                </Button>
                <Button 
                  size="sm" 
                  variant="outline"
                  onClick={() => updateDailySignalsMutation.mutate((dailySignalsData?.count || settings.maxSignalsPerDay) + 5)}
                  disabled={updateDailySignalsMutation.isPending || (dailySignalsData?.count || settings.maxSignalsPerDay) >= 100}
                >
                  +5
                </Button>
              </div>
            </div>
          </div>

          {/* Auto Signals Status & Control */}
          <div className="mt-6 p-4 bg-gradient-to-r from-gray-50 to-gray-100 dark:from-gray-800 dark:to-gray-900 rounded-lg border">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className={`w-3 h-3 rounded-full ${currentAutoSignalsState ? 'bg-green-500 animate-pulse' : 'bg-red-500'}`} />
                <div>
                  <h4 className="font-semibold text-lg">
                    {language === 'ar' ? 'الإشارات التلقائية' : 'Auto Signals'}
                  </h4>
                  <p className="text-sm text-muted-foreground">
                    {currentAutoSignalsState 
                      ? (language === 'ar' ? `نشط - كل ${settings.signalInterval} دقيقة` : `Active - Every ${settings.signalInterval} minutes`)
                      : (language === 'ar' ? 'متوقف' : 'Stopped')
                    }
                  </p>
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                {currentAutoSignalsState && (
                  <Badge variant="secondary" className="animate-pulse">
                    <Zap className="h-3 w-3 mr-1" />
                    {language === 'ar' ? 'يعمل' : 'Running'}
                  </Badge>
                )}
                <Button 
                  onClick={handleToggleAutoSignals}
                  disabled={toggleAutoSignalsMutation.isPending}
                  size="lg"
                  className={`min-w-[180px] ${currentAutoSignalsState ? 'bg-red-600 hover:bg-red-700 text-white' : 'bg-green-600 hover:bg-green-700 text-white'}`}
                >
                  {toggleAutoSignalsMutation.isPending ? (
                    <>
                      <Activity className="h-4 w-4 mr-2 animate-spin" />
                      {language === 'ar' ? 'جاري التحديث...' : 'Updating...'}
                    </>
                  ) : currentAutoSignalsState ? (
                    <>
                      <Pause className="h-4 w-4 mr-2" />
                      {language === 'ar' ? 'إيقاف الإشارات' : 'Stop Signals'}
                    </>
                  ) : (
                    <>
                      <Play className="h-4 w-4 mr-2" />
                      {language === 'ar' ? 'تشغيل الإشارات' : 'Start Signals'}
                    </>
                  )}
                </Button>
              </div>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 mt-4">

            <Button 
              onClick={handleGenerateSignal}
              disabled={generateSignalMutation.isPending}
              variant="outline"
              className="flex-1"
            >
              {generateSignalMutation.isPending ? (
                <>
                  <Activity className="h-4 w-4 mr-2 animate-spin" />
                  {language === 'ar' ? 'جاري الإنشاء...' : 'Generating...'}
                </>
              ) : (
                <>
                  <Zap className="h-4 w-4 mr-2" />
                  {language === 'ar' ? 'إنشاء إشارة فورية' : 'Generate Signal Now'}
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* اختيار منصة التداول */}
      <div className="mb-6">
        <PlatformSelector />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* إعدادات التوقيت */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5" />
              {language === 'ar' ? 'إعدادات التوقيت' : 'Timing Settings'}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <div className="flex items-center justify-between mb-3">
                <Label className="text-base">
                  {language === 'ar' ? 'فترة الإشارات (دقائق)' : 'Signal Interval (minutes)'}
                </Label>
                <Badge variant="outline" className="text-xs">
                  {language === 'ar' ? 'حالياً' : 'Current'}: {settings.signalInterval}m
                </Badge>
              </div>
              <Select 
                value={settings.signalInterval.toString()} 
                onValueChange={(value) => {
                  setHasUserInteracted(true);
                  handleSettingsChange('signalInterval', parseInt(value));
                }}
                disabled={toggleAutoSignalsMutation.isPending}
              >
                <SelectTrigger className="bg-background">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">
                    <div className="flex items-center justify-between w-full">
                      <span>{language === 'ar' ? 'كل دقيقة' : 'Every 1 minute'}</span>
                      <Badge variant="secondary" className="ml-2 text-xs">
                        {language === 'ar' ? 'سريع جداً' : 'Very Fast'}
                      </Badge>
                    </div>
                  </SelectItem>
                  <SelectItem value="2">
                    <div className="flex items-center justify-between w-full">
                      <span>{language === 'ar' ? 'كل دقيقتين' : 'Every 2 minutes'}</span>
                      <Badge variant="secondary" className="ml-2 text-xs">
                        {language === 'ar' ? 'سريع' : 'Fast'}
                      </Badge>
                    </div>
                  </SelectItem>
                  <SelectItem value="5">
                    <div className="flex items-center justify-between w-full">
                      <span>{language === 'ar' ? 'كل 5 دقائق' : 'Every 5 minutes'}</span>
                      <Badge variant="secondary" className="ml-2 text-xs">
                        {language === 'ar' ? 'متوسط' : 'Normal'}
                      </Badge>
                    </div>
                  </SelectItem>
                  <SelectItem value="10">
                    <div className="flex items-center justify-between w-full">
                      <span>{language === 'ar' ? 'كل 10 دقائق' : 'Every 10 minutes'}</span>
                      <Badge variant="secondary" className="ml-2 text-xs">
                        {language === 'ar' ? 'محافظ' : 'Conservative'}
                      </Badge>
                    </div>
                  </SelectItem>
                  <SelectItem value="15">{language === 'ar' ? 'كل 15 دقيقة' : 'Every 15 minutes'}</SelectItem>
                  <SelectItem value="30">{language === 'ar' ? 'كل 30 دقيقة' : 'Every 30 minutes'}</SelectItem>
                  <SelectItem value="60">{language === 'ar' ? 'كل ساعة' : 'Every hour'}</SelectItem>
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground mt-2">
                {language === 'ar' 
                  ? 'يتم تطبيق التغييرات تلقائياً عند تفعيل الإشارات التلقائية' 
                  : 'Changes apply automatically when auto signals are enabled'
                }
              </p>
            </div>

            <Separator />

            <div>
              <Label className="text-base mb-3 block">
                {language === 'ar' ? 'الحد الأقصى للإشارات يومياً' : 'Max Signals Per Day'}
              </Label>
              <div className="px-3">
                <Slider
                  value={[settings.maxSignalsPerDay]}
                  onValueChange={(value) => handleSettingsChange('maxSignalsPerDay', value[0])}
                  max={50}
                  min={5}
                  step={5}
                  className="w-full"
                />
                <div className="flex justify-between text-sm text-muted-foreground mt-1">
                  <span>5</span>
                  <span className="font-medium">{settings.maxSignalsPerDay}</span>
                  <span>50</span>
                </div>
              </div>
            </div>

            <Separator />

            <div className="flex items-center justify-between">
              <div>
                <Label className="text-base">
                  {language === 'ar' ? 'ساعات التداول' : 'Trading Hours'}
                </Label>
                <p className="text-sm text-muted-foreground">
                  {language === 'ar' ? 'تفعيل التداول في أوقات محددة' : 'Enable trading during specific hours'}
                </p>
              </div>
              <Switch 
                checked={settings.tradingHours.enabled}
                onCheckedChange={(checked) => 
                  handleSettingsChange('tradingHours', { ...settings.tradingHours, enabled: checked })
                }
              />
            </div>
          </CardContent>
        </Card>

        {/* إعدادات المخاطر */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5" />
              {language === 'ar' ? 'إدارة المخاطر' : 'Risk Management'}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <Label className="text-base mb-3 block">
                {language === 'ar' ? 'الحد الأدنى للثقة (%)' : 'Minimum Confidence (%)'}
              </Label>
              <div className="px-3">
                <Slider
                  value={[settings.minConfidence]}
                  onValueChange={(value) => handleSettingsChange('minConfidence', value[0])}
                  max={95}
                  min={50}
                  step={5}
                  className="w-full"
                />
                <div className="flex justify-between text-sm text-muted-foreground mt-1">
                  <span>50%</span>
                  <span className="font-medium">{settings.minConfidence}%</span>
                  <span>95%</span>
                </div>
              </div>
            </div>

            <Separator />

            <div>
              <Label className="text-base mb-3 block">
                {language === 'ar' ? 'الحد الأقصى للمخاطر' : 'Maximum Risk Level'}
              </Label>
              <Select 
                value={settings.maxRiskLevel} 
                onValueChange={(value: 'low' | 'medium' | 'high') => handleSettingsChange('maxRiskLevel', value)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">
                    {language === 'ar' ? 'منخفض' : 'Low Risk'}
                  </SelectItem>
                  <SelectItem value="medium">
                    {language === 'ar' ? 'متوسط' : 'Medium Risk'}
                  </SelectItem>
                  <SelectItem value="high">
                    {language === 'ar' ? 'مرتفع' : 'High Risk'}
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            <Separator />

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-base">
                    {language === 'ar' ? 'وقف الخسارة' : 'Stop Loss'}
                  </Label>
                  <p className="text-sm text-muted-foreground">
                    {language === 'ar' ? 'حماية من الخسائر الكبيرة' : 'Protection from large losses'}
                  </p>
                </div>
                <Switch 
                  checked={settings.stopLossEnabled}
                  onCheckedChange={(checked) => handleSettingsChange('stopLossEnabled', checked)}
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-base">
                    {language === 'ar' ? 'جني الأرباح' : 'Take Profit'}
                  </Label>
                  <p className="text-sm text-muted-foreground">
                    {language === 'ar' ? 'تأمين الأرباح تلقائياً' : 'Secure profits automatically'}
                  </p>
                </div>
                <Switch 
                  checked={settings.takeProfitEnabled}
                  onCheckedChange={(checked) => handleSettingsChange('takeProfitEnabled', checked)}
                />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* حفظ الإعدادات */}
      <div className="flex justify-end mt-6">
        <Button onClick={handleSaveSettings} className="min-w-[150px]">
          {language === 'ar' ? 'حفظ الإعدادات' : 'Save Settings'}
        </Button>
      </div>
      
      {/* Floating Refresh Button */}
      <FloatingRefreshButton onRefresh={handleRefreshData} />
    </div>
  );
}
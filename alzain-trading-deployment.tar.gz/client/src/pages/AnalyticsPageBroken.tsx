import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { MLInsights } from '@/components/MLInsights';
import { FeedbackAnalytics } from '@/components/FeedbackAnalytics';
import { ErrorBoundary } from '@/components/ErrorBoundary';
import { Brain, MessageCircle, TrendingUp, BarChart3 } from 'lucide-react';

export function AnalyticsPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50/30 to-purple-50/30 dark:from-slate-900 dark:via-slate-800 dark:to-indigo-900/30">
      <div className="container mx-auto p-6 space-y-8">
        <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-purple-600 via-blue-600 to-cyan-600 p-8 text-white shadow-2xl">
          {/* Background decoration */}
          <div className="absolute inset-0 opacity-20">
            <div className="absolute top-0 right-0 w-32 h-32 bg-white rounded-full blur-3xl"></div>
            <div className="absolute bottom-0 left-0 w-24 h-24 bg-white rounded-full blur-2xl"></div>
            <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-40 h-40 bg-white/10 rounded-full blur-3xl"></div>
          </div>
          
          <div className="relative flex items-center justify-between">
            <div className="space-y-3">
              <div className="flex items-center gap-3">
                <div className="p-3 rounded-xl bg-white/20 backdrop-blur-sm">
                  <Brain className="h-8 w-8 text-white" />
                </div>
                <h1 className="text-4xl font-bold tracking-tight">تحليلات التعلم الآلي</h1>
              </div>
              <p className="text-purple-100 text-lg max-w-2xl">
                تحليل أداء التوصيات وتفاعلات المستخدمين لتحسين دقة الذكاء الاصطناعي المتقدم
              </p>
              <div className="flex items-center gap-4 pt-2">
                <div className="flex items-center gap-2 text-purple-200">
                  <BarChart3 className="h-4 w-4" />
                  <span className="text-sm font-medium">تحليل متقدم</span>
                </div>
                <div className="flex items-center gap-2 text-purple-200">
                  <TrendingUp className="h-4 w-4" />
                  <span className="text-sm font-medium">تحسين مستمر</span>
                </div>
              </div>
            </div>
            
            <div className="hidden md:block">
              <div className="relative">
                <div className="w-24 h-24 rounded-full bg-white/10 backdrop-blur-sm flex items-center justify-center">
                  <Brain className="h-12 w-12 text-white animate-pulse" />
                </div>
                <div className="absolute inset-0 rounded-full bg-gradient-to-r from-purple-400 to-cyan-400 opacity-20 animate-ping"></div>
              </div>
            </div>
          </div>
        </div>

      <Tabs defaultValue="insights" className="space-y-8">
        <TabsList className="grid w-full max-w-md mx-auto grid-cols-2 h-12 p-1 bg-white/70 dark:bg-slate-800/70 backdrop-blur-sm border-0 shadow-lg rounded-xl">
          <TabsTrigger 
            value="insights" 
            className="flex items-center gap-2 rounded-lg font-medium data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-500 data-[state=active]:to-blue-600 data-[state=active]:text-white data-[state=active]:shadow-md transition-all duration-200"
          >
            <BarChart3 className="h-4 w-4" />
            تحليل الأداء
          </TabsTrigger>
          <TabsTrigger 
            value="feedback" 
            className="flex items-center gap-2 rounded-lg font-medium data-[state=active]:bg-gradient-to-r data-[state=active]:from-green-500 data-[state=active]:to-cyan-600 data-[state=active]:text-white data-[state=active]:shadow-md transition-all duration-200"
          >
            <MessageCircle className="h-4 w-4" />
            تفاعلات المستخدمين
          </TabsTrigger>
        </TabsList>

        <TabsContent value="insights" className="space-y-6">
          <Card className="border-0 shadow-lg bg-gradient-to-br from-purple-50/50 to-blue-50/50 dark:from-purple-900/20 dark:to-blue-900/20">
            <CardHeader className="pb-4">
              <CardTitle className="flex items-center gap-3 text-xl">
                <div className="p-2 rounded-lg bg-gradient-to-br from-purple-500 to-blue-600 text-white shadow-md">
                  <Brain className="h-5 w-5" />
                </div>
                رؤى التعلم الآلي
              </CardTitle>
              <CardDescription className="text-base">
                تحليل شامل لأداء التوصيات وتوجيهات التحسين المدعومة بالذكاء الاصطناعي
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ErrorBoundary>
                <MLInsights />
              </ErrorBoundary>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="feedback" className="space-y-6">
          <Card className="border-0 shadow-lg bg-gradient-to-br from-green-50/50 to-cyan-50/50 dark:from-green-900/20 dark:to-cyan-900/20">
            <CardHeader className="pb-4">
              <CardTitle className="flex items-center gap-3 text-xl">
                <div className="p-2 rounded-lg bg-gradient-to-br from-green-500 to-cyan-600 text-white shadow-md">
                  <MessageCircle className="h-5 w-5" />
                </div>
                تحليل التفاعلات
              </CardTitle>
              <CardDescription className="text-base">
                تتبع وتحليل ردود أفعال المستخدمين على التوصيات عبر تليجرام
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ErrorBoundary>
                <FeedbackAnalytics />
              </ErrorBoundary>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      </div>
    </div>
  );
}
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useLanguageContext } from '@/components/language-provider';
import { EnhancedSignalStats } from '@/components/enhanced-signal-stats';
import { SmartNotifications } from '@/components/smart-notifications';
import { 
  Brain, 
  Bell, 
  TrendingUp, 
  Target, 
  Zap, 
  BarChart3,
  Settings,
  Sparkles,
  Rocket,
  Shield,
  CheckCircle,
  Star,
  Activity,
  Users,
  Database,
  Cpu
} from 'lucide-react';

export default function EnhancementsPage() {
  const { language } = useLanguageContext();

  const enhancements = [
    {
      id: 'ai-analysis',
      icon: Brain,
      title: language === 'ar' ? 'نظام الذكاء الاصطناعي المتقدم' : 'Advanced AI Analysis System',
      description: language === 'ar' 
        ? 'تحليل متعدد الإطارات الزمنية مع خوارزميات متقدمة لتحسين دقة الإشارات'
        : 'Multi-timeframe analysis with advanced algorithms for improved signal accuracy',
      status: 'active',
      improvements: [
        language === 'ar' ? 'تحليل 5 إطارات زمنية مختلفة' : '5 different timeframe analysis',
        language === 'ar' ? 'فلترة الإشارات ضعيفة الجودة' : 'Low-quality signal filtering',
        language === 'ar' ? 'تحسين الثقة بالتوصيات' : 'Enhanced recommendation confidence',
        language === 'ar' ? 'تقييم السياق السوقي' : 'Market context evaluation'
      ]
    },
    {
      id: 'smart-notifications',
      icon: Bell,
      title: language === 'ar' ? 'نظام الإشعارات الذكية' : 'Smart Notification System',
      description: language === 'ar' 
        ? 'إشعارات مخصصة وذكية تصل في الوقت المناسب حسب تفضيلاتك'
        : 'Personalized smart notifications delivered at the right time based on your preferences',
      status: 'active',
      improvements: [
        language === 'ar' ? 'فلاتر متقدمة للإشعارات' : 'Advanced notification filters',
        language === 'ar' ? 'إعدادات أولوية ذكية' : 'Smart priority settings',
        language === 'ar' ? 'تحكم في التوقيت والتكرار' : 'Time and frequency control',
        language === 'ar' ? 'إشعارات فورية وصوتية' : 'Push and sound notifications'
      ]
    },
    {
      id: 'performance-tracking',
      icon: TrendingUp,
      title: language === 'ar' ? 'تتبع الأداء المتقدم' : 'Advanced Performance Tracking',
      description: language === 'ar' 
        ? 'مقاييس شاملة لتتبع أداء الإشارات والتحسين المستمر'
        : 'Comprehensive metrics for signal performance tracking and continuous improvement',
      status: 'active',
      improvements: [
        language === 'ar' ? 'إحصائيات مفصلة للدقة' : 'Detailed accuracy statistics',
        language === 'ar' ? 'تحليل الأداء حسب الأصل' : 'Asset-specific performance analysis',
        language === 'ar' ? 'تتبع معدل النجاح' : 'Success rate tracking',
        language === 'ar' ? 'رؤى التحسين' : 'Improvement insights'
      ]
    },
    {
      id: 'ml-learning',
      icon: Cpu,
      title: language === 'ar' ? 'التعلم الآلي المستمر' : 'Continuous Machine Learning',
      description: language === 'ar' 
        ? 'النظام يتعلم من تفاعلاتك ويحسن دقته تلقائياً'
        : 'System learns from your interactions and automatically improves accuracy',
      status: 'active',
      improvements: [
        language === 'ar' ? 'تعلم من تعليقات المستخدمين' : 'Learning from user feedback',
        language === 'ar' ? 'تحسين التوصيات تلقائياً' : 'Automatic recommendation optimization',
        language === 'ar' ? 'تخصيص حسب أسلوب التداول' : 'Trading style customization',
        language === 'ar' ? 'تحليل البيانات التاريخية' : 'Historical data analysis'
      ]
    },
    {
      id: 'risk-management',
      icon: Shield,
      title: language === 'ar' ? 'إدارة المخاطر الذكية' : 'Smart Risk Management',
      description: language === 'ar' 
        ? 'أدوات متقدمة لإدارة المخاطر وحماية رأس المال'
        : 'Advanced tools for risk management and capital protection',
      status: 'active',
      improvements: [
        language === 'ar' ? 'حاسبة حجم الصفقة' : 'Position size calculator',
        language === 'ar' ? 'إيقاف الخسارة الذكي' : 'Smart stop-loss',
        language === 'ar' ? 'تحليل المخاطر المحفظة' : 'Portfolio risk analysis',
        language === 'ar' ? 'تنبيهات المخاطر' : 'Risk alerts'
      ]
    },
    {
      id: 'social-trading',
      icon: Users,
      title: language === 'ar' ? 'التداول الاجتماعي' : 'Social Trading',
      description: language === 'ar' 
        ? 'تفاعل مع متداولين آخرين وشارك الاستراتيجيات'
        : 'Interact with other traders and share strategies',
      status: 'active',
      improvements: [
        language === 'ar' ? 'متابعة المتداولين الناجحين' : 'Follow successful traders',
        language === 'ar' ? 'نسخ الصفقات' : 'Copy trading',
        language === 'ar' ? 'غرف الدردشة' : 'Chat rooms',
        language === 'ar' ? 'تصنيف المستخدمين' : 'User rankings'
      ]
    }
  ];

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active':
        return (
          <Badge variant="secondary" className="text-green-600">
            <CheckCircle className="h-3 w-3 mr-1" />
            {language === 'ar' ? 'نشط' : 'Active'}
          </Badge>
        );
      case 'planned':
        return (
          <Badge variant="secondary" className="text-blue-600">
            <Star className="h-3 w-3 mr-1" />
            {language === 'ar' ? 'مخطط' : 'Planned'}
          </Badge>
        );
      default:
        return null;
    }
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="text-center space-y-4 mb-8">
        <div className="flex items-center justify-center gap-2 mb-4">
          <Sparkles className="h-8 w-8 text-primary" />
          <h1 className="text-3xl font-bold">
            {language === 'ar' ? 'التحسينات والميزات المتطورة' : 'Advanced Features & Enhancements'}
          </h1>
        </div>
        <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
          {language === 'ar' 
            ? 'اكتشف الميزات الجديدة والتحسينات المتطورة التي تجعل تداولك أكثر ذكاءً ودقة. نظام شامل مدعوم بالذكاء الاصطناعي لتجربة تداول متميزة.'
            : 'Discover new features and advanced enhancements that make your trading smarter and more accurate. A comprehensive AI-powered system for an exceptional trading experience.'
          }
        </p>
      </div>

      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview" className="flex items-center gap-2">
            <Rocket className="h-4 w-4" />
            {language === 'ar' ? 'نظرة عامة' : 'Overview'}
          </TabsTrigger>
          <TabsTrigger value="ai-stats" className="flex items-center gap-2">
            <Brain className="h-4 w-4" />
            {language === 'ar' ? 'إحصائيات الذكاء الاصطناعي' : 'AI Statistics'}
          </TabsTrigger>
          <TabsTrigger value="notifications" className="flex items-center gap-2">
            <Bell className="h-4 w-4" />
            {language === 'ar' ? 'الإشعارات' : 'Notifications'}
          </TabsTrigger>
          <TabsTrigger value="settings" className="flex items-center gap-2">
            <Settings className="h-4 w-4" />
            {language === 'ar' ? 'الإعدادات' : 'Settings'}
          </TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {enhancements.map((enhancement) => {
              const IconComponent = enhancement.icon;
              return (
                <Card key={enhancement.id} className="relative overflow-hidden">
                  <CardHeader className="pb-4">
                    <div className="flex items-start justify-between gap-3 mb-3">
                      <div className="flex items-start gap-3 flex-1 min-w-0">
                        <IconComponent className="h-6 w-6 text-primary flex-shrink-0 mt-1" />
                        <CardTitle className="text-lg leading-relaxed font-semibold break-words">
                          {enhancement.title}
                        </CardTitle>
                      </div>
                      <div className="flex-shrink-0">
                        {getStatusBadge(enhancement.status)}
                      </div>
                    </div>
                    <CardDescription className="text-sm leading-relaxed mt-2">
                      {enhancement.description}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <div className="space-y-4">
                      <h4 className="font-medium text-sm text-muted-foreground">
                        {language === 'ar' ? 'التحسينات الرئيسية:' : 'Key Improvements:'}
                      </h4>
                      <ul className="space-y-3">
                        {enhancement.improvements.map((improvement, index) => (
                          <li key={index} className="flex items-start gap-3 text-sm leading-relaxed">
                            <CheckCircle className="h-4 w-4 text-green-600 flex-shrink-0 mt-0.5" />
                            <span className="break-words">{improvement}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* Performance Metrics */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="h-5 w-5" />
                {language === 'ar' ? 'مقاييس الأداء العامة' : 'Overall Performance Metrics'}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <div className="text-center p-6 bg-green-50 dark:bg-green-950/20 rounded-lg">
                  <div className="text-3xl font-bold text-green-600 mb-2">95.2%</div>
                  <div className="text-sm text-muted-foreground leading-relaxed">
                    {language === 'ar' ? 'دقة النظام' : 'System Accuracy'}
                  </div>
                </div>
                <div className="text-center p-6 bg-blue-50 dark:bg-blue-950/20 rounded-lg">
                  <div className="text-3xl font-bold text-blue-600 mb-2">2.3s</div>
                  <div className="text-sm text-muted-foreground leading-relaxed">
                    {language === 'ar' ? 'زمن التحليل' : 'Analysis Time'}
                  </div>
                </div>
                <div className="text-center p-6 bg-purple-50 dark:bg-purple-950/20 rounded-lg">
                  <div className="text-3xl font-bold text-purple-600 mb-2">15+</div>
                  <div className="text-sm text-muted-foreground leading-relaxed">
                    {language === 'ar' ? 'مؤشرات تقنية' : 'Technical Indicators'}
                  </div>
                </div>
                <div className="text-center p-6 bg-orange-50 dark:bg-orange-950/20 rounded-lg">
                  <div className="text-3xl font-bold text-orange-600 mb-2">24/7</div>
                  <div className="text-sm text-muted-foreground leading-relaxed">
                    {language === 'ar' ? 'مراقبة مستمرة' : 'Continuous Monitoring'}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* AI Statistics Tab */}
        <TabsContent value="ai-stats" className="space-y-6">
          <EnhancedSignalStats />
        </TabsContent>

        {/* Notifications Tab */}
        <TabsContent value="notifications" className="space-y-6">
          <SmartNotifications />
        </TabsContent>

        {/* Settings Tab */}
        <TabsContent value="settings" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="h-5 w-5" />
                {language === 'ar' ? 'إعدادات التحسينات' : 'Enhancement Settings'}
              </CardTitle>
              <CardDescription>
                {language === 'ar' 
                  ? 'تخصيص سلوك الميزات المتطورة حسب احتياجاتك'
                  : 'Customize advanced feature behavior according to your needs'
                }
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="p-4 bg-muted/50 rounded-lg">
                  <h4 className="font-medium mb-2">
                    {language === 'ar' ? 'قريباً' : 'Coming Soon'}
                  </h4>
                  <p className="text-sm text-muted-foreground">
                    {language === 'ar' 
                      ? 'إعدادات متقدمة للتحكم في سلوك النظام والتخصيص الشامل'
                      : 'Advanced settings for system behavior control and comprehensive customization'
                    }
                  </p>
                  <Button className="mt-4" disabled>
                    <Star className="h-4 w-4 mr-2" />
                    {language === 'ar' ? 'قيد التطوير' : 'In Development'}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
import { useQuery } from '@tanstack/react-query';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Brain, MessageCircle, TrendingUp, BarChart3, Activity, Users, Star, CheckCircle, XCircle, Clock, Target, Zap, TrendingDown, AlertTriangle } from 'lucide-react';
import { useLanguageContext } from '@/components/language-provider';
import { useDateTimeFormat } from '@/components/date-settings';
import { FloatingRefreshButton } from '@/components/floating-refresh-button';

interface TelegramFeedback {
  id: number;
  recommendationId: number;
  feedbackType: 'success' | 'partial' | 'failure';
  assetSymbol: string;
  direction: string;
  confidence: number;
  createdAt: string;
  actualResult?: string;
  responseTime?: number;
}

interface AssetPerformance {
  id: number;
  assetSymbol: string;
  totalRecommendations: number;
  successfulTrades: number;
  partialSuccessTrades: number;
  failedTrades: number;
  successRate: number;
  averageConfidence: number;
  createdAt: string;
  updatedAt: string;
}

interface MLTrainingData {
  id: number;
  assetSymbol: string;
  direction: string;
  originalConfidence: number;
  actualResult: string;
  successScore: number;
  createdAt: string;
}

export function AnalyticsPage() {
  const { language } = useLanguageContext();
  const { formatDateTime } = useDateTimeFormat();

  // Fetch ML training data and analytics
  const { data: mlData, isLoading: mlLoading, refetch: refetchMlData } = useQuery<MLTrainingData[]>({
    queryKey: ['/api/ml-training-data'],
    refetchInterval: 30000,
  });

  // Fetch telegram feedback data  
  const { data: feedbackData, isLoading: feedbackLoading, refetch: refetchFeedback } = useQuery<TelegramFeedback[]>({
    queryKey: ['/api/telegram-feedback'],
    refetchInterval: 15000,
  });

  // Fetch asset performance data
  const { data: performanceData, isLoading: performanceLoading, refetch: refetchPerformance } = useQuery<AssetPerformance[]>({
    queryKey: ['/api/asset-performance'],
    refetchInterval: 30000,
  });

  const isLoading = mlLoading || feedbackLoading || performanceLoading;

  // Calculate overall statistics
  const totalFeedback = feedbackData?.length || 0;
  const successfulFeedback = feedbackData?.filter(f => f.feedbackType === 'success').length || 0;
  const partialFeedback = feedbackData?.filter(f => f.feedbackType === 'partial').length || 0;
  const failedFeedback = feedbackData?.filter(f => f.feedbackType === 'failure').length || 0;
  
  const overallSuccessRate = totalFeedback > 0 ? (successfulFeedback / totalFeedback) * 100 : 0;
  const partialSuccessRate = totalFeedback > 0 ? (partialFeedback / totalFeedback) * 100 : 0;
  
  // ML Learning insights
  const avgMLConfidence = mlData && mlData.length > 0 ? mlData.reduce((sum, item) => sum + item.originalConfidence, 0) / mlData.length : 0;
  const avgSuccessScore = mlData && mlData.length > 0 ? mlData.reduce((sum, item) => sum + item.successScore, 0) / mlData.length : 0;

  // Top performing assets
  const topAssets = performanceData?.sort((a, b) => b.successRate - a.successRate).slice(0, 5) || [];
  
  const refreshAllData = async () => {
    await Promise.all([
      refetchMlData(),
      refetchFeedback(),
      refetchPerformance()
    ]);
  };

  // Use the new date formatting system instead of local formatDate
  const formatDateLocal = (dateStr: string) => {
    return formatDateTime(dateStr);
  };

  return (
    <div className="container mx-auto p-6 space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            {language === 'ar' ? 'تحليلات الذكاء الاصطناعي' : 'AI Analytics Dashboard'}
          </h1>
          <p className="text-muted-foreground mt-2">
            {language === 'ar' ? 
              'تتبع أداء النظام والتعلم من تفاعلات تليجرام' : 
              'Track system performance and learn from Telegram interactions'
            }
          </p>
        </div>

      </div>

      {/* Overview Cards */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card className="bg-gradient-to-br from-green-50 to-green-100 dark:from-green-900/20 dark:to-green-800/20 border-green-200 dark:border-green-800">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-green-800 dark:text-green-200">
              {language === 'ar' ? 'معدل النجاح العام' : 'Overall Success Rate'}
            </CardTitle>
            <CheckCircle className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-700 dark:text-green-300">
              {overallSuccessRate.toFixed(1)}%
            </div>
            <p className="text-xs text-green-600 dark:text-green-400">
              {successfulFeedback} {language === 'ar' ? 'من' : 'of'} {totalFeedback} {language === 'ar' ? 'تفاعل' : 'interactions'}
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-orange-50 to-orange-100 dark:from-orange-900/20 dark:to-orange-800/20 border-orange-200 dark:border-orange-800">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-orange-800 dark:text-orange-200">
              {language === 'ar' ? 'النجاح الجزئي' : 'Partial Success'}
            </CardTitle>
            <AlertTriangle className="h-4 w-4 text-orange-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-700 dark:text-orange-300">
              {partialSuccessRate.toFixed(1)}%
            </div>
            <p className="text-xs text-orange-600 dark:text-orange-400">
              {partialFeedback} {language === 'ar' ? 'تفاعل جزئي' : 'partial interactions'}
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-900/20 dark:to-blue-800/20 border-blue-200 dark:border-blue-800">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-blue-800 dark:text-blue-200">
              {language === 'ar' ? 'متوسط الثقة' : 'Avg Confidence'}
            </CardTitle>
            <Target className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-700 dark:text-blue-300">
              {avgMLConfidence.toFixed(1)}%
            </div>
            <p className="text-xs text-blue-600 dark:text-blue-400">
              {language === 'ar' ? 'الثقة في التوصيات' : 'recommendation confidence'}
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-50 to-purple-100 dark:from-purple-900/20 dark:to-purple-800/20 border-purple-200 dark:border-purple-800">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-purple-800 dark:text-purple-200">
              {language === 'ar' ? 'نقاط التعلم' : 'ML Score'}
            </CardTitle>
            <Brain className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-700 dark:text-purple-300">
              {avgSuccessScore.toFixed(1)}
            </div>
            <p className="text-xs text-purple-600 dark:text-purple-400">
              {language === 'ar' ? 'متوسط نقاط النجاح' : 'average success score'}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Main Analytics Tabs */}
      <Tabs defaultValue="feedback" className="space-y-6">
        <TabsList className="grid w-full grid-cols-1 md:grid-cols-3">
          <TabsTrigger value="feedback" className="flex items-center gap-2">
            <MessageCircle className="h-4 w-4" />
            {language === 'ar' ? 'تفاعلات تليجرام' : 'Telegram Feedback'}
          </TabsTrigger>
          <TabsTrigger value="performance" className="flex items-center gap-2">
            <BarChart3 className="h-4 w-4" />
            {language === 'ar' ? 'أداء الأصول' : 'Asset Performance'}
          </TabsTrigger>
          <TabsTrigger value="ml-insights" className="flex items-center gap-2">
            <Brain className="h-4 w-4" />
            {language === 'ar' ? 'رؤى الذكاء الاصطناعي' : 'ML Insights'}
          </TabsTrigger>
        </TabsList>

        {/* Telegram Feedback Tab */}
        <TabsContent value="feedback" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageCircle className="h-5 w-5 text-blue-600" />
                {language === 'ar' ? 'آخر التفاعلات من تليجرام' : 'Recent Telegram Interactions'}
              </CardTitle>
              <CardDescription>
                {language === 'ar' ? 
                  'تفاعلات المستخدمين مع أزرار التوصيات في تليجرام' :
                  'User interactions with recommendation buttons in Telegram'
                }
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="space-y-4">
                  {[...Array(5)].map((_, i) => (
                    <div key={i} className="flex items-center space-x-4 p-4 border rounded-lg animate-pulse">
                      <div className="w-10 h-10 bg-muted rounded-full"></div>
                      <div className="flex-1 space-y-2">
                        <div className="w-32 h-4 bg-muted rounded"></div>
                        <div className="w-48 h-3 bg-muted rounded"></div>
                      </div>
                      <div className="w-16 h-6 bg-muted rounded"></div>
                    </div>
                  ))}
                </div>
              ) : feedbackData && feedbackData.length > 0 ? (
                <div className="space-y-4 max-h-96 overflow-y-auto">
                  {feedbackData.slice(0, 20).map((feedback) => (
                    <div key={feedback.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-accent/50 transition-colors">
                      <div className="flex items-center space-x-4">
                        <div className={`p-2 rounded-full ${
                          feedback.feedbackType === 'success' ? 'bg-green-100 dark:bg-green-900/30' :
                          feedback.feedbackType === 'partial' ? 'bg-orange-100 dark:bg-orange-900/30' :
                          'bg-red-100 dark:bg-red-900/30'
                        }`}>
                          {feedback.feedbackType === 'success' ? (
                            <CheckCircle className="h-4 w-4 text-green-600" />
                          ) : feedback.feedbackType === 'partial' ? (
                            <AlertTriangle className="h-4 w-4 text-orange-600" />
                          ) : (
                            <XCircle className="h-4 w-4 text-red-600" />
                          )}
                        </div>
                        <div>
                          <div className="font-medium">
                            {feedback.assetSymbol} - {feedback.direction}
                          </div>
                          <div className="text-sm text-muted-foreground">
                            {language === 'ar' ? 'الثقة:' : 'Confidence:'} {feedback.confidence}% • {formatDateLocal(feedback.createdAt)}
                          </div>
                        </div>
                      </div>
                      <Badge variant={
                        feedback.feedbackType === 'success' ? 'default' :
                        feedback.feedbackType === 'partial' ? 'secondary' : 'destructive'
                      }>
                        {feedback.feedbackType === 'success' ? (language === 'ar' ? 'نجح' : 'Success') :
                         feedback.feedbackType === 'partial' ? (language === 'ar' ? 'جزئي' : 'Partial') :
                         (language === 'ar' ? 'فشل' : 'Failed')}
                      </Badge>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <MessageCircle className="h-12 w-12 mx-auto mb-2 opacity-50" />
                  <p>{language === 'ar' ? 'لا توجد تفاعلات حتى الآن' : 'No interactions yet'}</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Asset Performance Tab */}
        <TabsContent value="performance" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5 text-green-600" />
                {language === 'ar' ? 'أداء الأصول' : 'Asset Performance Analytics'}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="space-y-4">
                  {[...Array(5)].map((_, i) => (
                    <div key={i} className="p-4 border rounded-lg animate-pulse">
                      <div className="flex justify-between items-center mb-2">
                        <div className="w-20 h-4 bg-muted rounded"></div>
                        <div className="w-12 h-4 bg-muted rounded"></div>
                      </div>
                      <div className="w-full h-2 bg-muted rounded"></div>
                    </div>
                  ))}
                </div>
              ) : topAssets.length > 0 ? (
                <div className="space-y-4">
                  {topAssets.map((asset) => (
                    <Card key={asset.id} className="p-4">
                      <div className="flex justify-between items-center mb-2">
                        <div className="font-medium">{asset.assetSymbol}</div>
                        <Badge variant={asset.successRate >= 70 ? 'default' : asset.successRate >= 50 ? 'secondary' : 'destructive'}>
                          {asset.successRate.toFixed(1)}%
                        </Badge>
                      </div>
                      <Progress value={asset.successRate} className="mb-2" />
                      <div className="flex justify-between text-sm text-muted-foreground">
                        <span>
                          {language === 'ar' ? 'إجمالي التوصيات:' : 'Total recommendations:'} {asset.totalRecommendations}
                        </span>
                        <span>
                          {language === 'ar' ? 'نجح:' : 'Successful:'} {asset.successfulTrades}
                        </span>
                      </div>
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <BarChart3 className="h-12 w-12 mx-auto mb-2 opacity-50" />
                  <p>{language === 'ar' ? 'لا توجد بيانات أداء متاحة' : 'No performance data available'}</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* ML Insights Tab */}
        <TabsContent value="ml-insights" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Brain className="h-5 w-5 text-purple-600" />
                {language === 'ar' ? 'رؤى التعلم الآلي' : 'Machine Learning Insights'}
              </CardTitle>
              <CardDescription>
                {language === 'ar' ? 
                  'كيف يتعلم النظام من التفاعلات ويحسن أداءه' :
                  'How the system learns from interactions and improves performance'
                }
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="space-y-4">
                  {[...Array(4)].map((_, i) => (
                    <div key={i} className="p-4 border rounded-lg animate-pulse">
                      <div className="flex justify-between items-center mb-2">
                        <div className="w-24 h-4 bg-muted rounded"></div>
                        <div className="w-16 h-4 bg-muted rounded"></div>
                      </div>
                      <div className="w-full h-3 bg-muted rounded mb-1"></div>
                      <div className="w-3/4 h-3 bg-muted rounded"></div>
                    </div>
                  ))}
                </div>
              ) : mlData && mlData.length > 0 ? (
                <div className="space-y-4">
                  <div className="grid gap-4 md:grid-cols-2">
                    <Card className="p-4 bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20">
                      <div className="flex items-center gap-2 mb-2">
                        <Brain className="h-4 w-4 text-blue-600" />
                        <span className="font-medium">{language === 'ar' ? 'نماذج التدريب' : 'Training Models'}</span>
                      </div>
                      <div className="text-2xl font-bold text-blue-700 dark:text-blue-300">
                        {mlData.length}
                      </div>
                      <p className="text-sm text-blue-600 dark:text-blue-400">
                        {language === 'ar' ? 'عينات تدريب متاحة' : 'training samples available'}
                      </p>
                    </Card>

                    <Card className="p-4 bg-gradient-to-br from-purple-50 to-pink-50 dark:from-purple-900/20 dark:to-pink-900/20">
                      <div className="flex items-center gap-2 mb-2">
                        <Target className="h-4 w-4 text-purple-600" />
                        <span className="font-medium">{language === 'ar' ? 'دقة التعلم' : 'Learning Accuracy'}</span>
                      </div>
                      <div className="text-2xl font-bold text-purple-700 dark:text-purple-300">
                        {avgSuccessScore.toFixed(1)}
                      </div>
                      <p className="text-sm text-purple-600 dark:text-purple-400">
                        {language === 'ar' ? 'متوسط نقاط النجاح' : 'average success score'}
                      </p>
                    </Card>
                  </div>

                  <div className="space-y-3 max-h-64 overflow-y-auto">
                    <h4 className="font-medium text-sm text-muted-foreground">
                      {language === 'ar' ? 'آخر البيانات المتعلمة' : 'Recent Learning Data'}
                    </h4>
                    {mlData.slice(0, 10).map((item) => (
                      <div key={item.id} className="flex items-center justify-between p-3 border rounded-lg">
                        <div className="flex items-center gap-3">
                          <div className={`w-2 h-2 rounded-full ${
                            item.successScore >= 0.8 ? 'bg-green-500' :
                            item.successScore >= 0.5 ? 'bg-orange-500' : 'bg-red-500'
                          }`}></div>
                          <div>
                            <div className="font-medium text-sm">
                              {item.assetSymbol} - {item.direction}
                            </div>
                            <div className="text-xs text-muted-foreground">
                              {language === 'ar' ? 'الثقة الأصلية:' : 'Original confidence:'} {item.originalConfidence}%
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-sm font-medium">
                            {item.successScore.toFixed(2)}
                          </div>
                          <div className="text-xs text-muted-foreground">
                            {formatDateLocal(item.createdAt)}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <Brain className="h-12 w-12 mx-auto mb-2 opacity-50" />
                  <p>{language === 'ar' ? 'لا توجد بيانات تعلم آلي متاحة' : 'No ML training data available'}</p>
                  <p className="text-sm mt-1">
                    {language === 'ar' ? 
                      'ستظهر البيانات عندما يتفاعل المستخدمون مع التوصيات' :
                      'Data will appear as users interact with recommendations'
                    }
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      {/* Floating Refresh Button */}
      <FloatingRefreshButton onRefresh={refreshAllData} />
    </div>
  );
}
import { useQuery } from '@tanstack/react-query';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { FloatingRefreshButton } from '@/components/floating-refresh-button';
import { useLanguageContext } from '@/components/language-provider';
import { useQueryClient } from '@tanstack/react-query';
import { 
  Brain, 
  MessageCircle, 
  TrendingUp, 
  BarChart3, 
  Activity, 
  Users, 
  Star, 
  CheckCircle, 
  XCircle, 
  Clock, 
  Target, 
  Zap, 
  TrendingDown, 
  AlertTriangle,
  PieChart,
  LineChart,
  Database,
  Lightbulb
} from 'lucide-react';

interface TelegramFeedback {
  id: number;
  recommendationId: number;
  feedbackType: 'success' | 'partial' | 'failure';
  assetSymbol: string;
  direction: string;
  confidence: number;
  createdAt: string;
  actualResult?: string;
  responseTime?: number;
}

interface AssetPerformance {
  id: number;
  assetSymbol: string;
  totalRecommendations: number;
  successfulTrades: number;
  partialSuccessTrades: number;
  failedTrades: number;
  successRate: number;
  averageConfidence: number;
  lastUpdated: string;
}

interface MLTrainingData {
  id: number;
  assetSymbol: string;
  direction: string;
  originalConfidence: number;
  actualResult: string;
  successScore: number;
  createdAt: string;
}

export default function AIAnalytics() {
  const { language } = useLanguageContext();
  const queryClient = useQueryClient();

  // Fetch ML training data and analytics
  const { data: mlData, isLoading: mlLoading, refetch: refetchMlData } = useQuery<MLTrainingData[]>({
    queryKey: ['/api/ml-training-data'],
    refetchInterval: 30000,
  });

  // Fetch telegram feedback data with faster refresh
  const { data: feedbackData, isLoading: feedbackLoading, refetch: refetchFeedback } = useQuery<TelegramFeedback[]>({
    queryKey: ['/api/telegram-feedback'],
    refetchInterval: 5000, // Refresh every 5 seconds for real-time updates
    refetchOnWindowFocus: true,
    refetchOnMount: true,
  });

  // Fetch asset performance data with improved refresh
  const { data: performanceData, isLoading: performanceLoading, refetch: refetchPerformance } = useQuery<AssetPerformance[]>({
    queryKey: ['/api/asset-performance'],
    refetchInterval: 10000, // Refresh every 10 seconds
    refetchOnWindowFocus: true,
    refetchOnMount: true,
  });

  const isLoading = mlLoading || feedbackLoading || performanceLoading;

  // Calculate overall statistics
  const totalFeedback = feedbackData?.length || 0;
  const successfulFeedback = feedbackData?.filter(f => f.feedbackType === 'success').length || 0;
  const partialFeedback = feedbackData?.filter(f => f.feedbackType === 'partial').length || 0;
  const failedFeedback = feedbackData?.filter(f => f.feedbackType === 'failure').length || 0;
  
  const overallSuccessRate = totalFeedback > 0 ? (successfulFeedback / totalFeedback) * 100 : 0;
  const partialSuccessRate = totalFeedback > 0 ? (partialFeedback / totalFeedback) * 100 : 0;
  
  // ML Learning insights
  const avgMLConfidence = mlData && mlData.length > 0 ? mlData.reduce((sum, item) => sum + item.originalConfidence, 0) / mlData.length : 0;
  const avgSuccessScore = mlData && mlData.length > 0 ? mlData.reduce((sum, item) => sum + item.successScore, 0) / mlData.length : 0;

  // Top performing assets
  const topAssets = performanceData?.sort((a, b) => b.successRate - a.successRate).slice(0, 5) || [];
  const poorAssets = performanceData?.sort((a, b) => a.successRate - b.successRate).slice(0, 3) || [];
  
  const refreshAllData = async () => {
    await Promise.all([
      refetchMlData(),
      refetchFeedback(),
      refetchPerformance()
    ]);
  };

  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString(language === 'ar' ? 'ar-SA' : 'en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getPerformanceColor = (rate: number) => {
    if (rate >= 70) return 'text-green-600';
    if (rate >= 50) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getPerformanceBadge = (rate: number) => {
    if (rate >= 70) return 'bg-green-100 text-green-800 border-green-200';
    if (rate >= 50) return 'bg-yellow-100 text-yellow-800 border-yellow-200';
    return 'bg-red-100 text-red-800 border-red-200';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50/30 to-purple-50/30 dark:from-slate-900 dark:via-slate-800 dark:to-indigo-900/30">
      <div className="container mx-auto p-6 space-y-8">
        {/* Modern Header */}
        <div className="relative overflow-hidden bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900 rounded-3xl shadow-2xl">
          {/* Background Pattern */}
          <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZGVmcz48cGF0dGVybiBpZD0iYSIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSIgd2lkdGg9IjQwIiBoZWlnaHQ9IjQwIiBwYXR0ZXJuVHJhbnNmb3JtPSJyb3RhdGUoNDUpIj48cmVjdCB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIGZpbGw9Im5vbmUiLz48Y2lyY2xlIGN4PSIyMCIgY3k9IjIwIiByPSIzIiBmaWxsPSIjZmZmIiBmaWxsLW9wYWNpdHk9IjAuMSIvPjwvcGF0dGVybj48L2RlZnM+PHJlY3Qgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIgZmlsbD0idXJsKCNhKSIvPjwvc3ZnPg==')] opacity-30"></div>
          
          {/* Floating Elements */}
          <div className="absolute top-8 right-8 w-20 h-20 bg-gradient-to-r from-pink-400 to-purple-400 rounded-full opacity-20 animate-pulse"></div>
          <div className="absolute bottom-8 left-8 w-16 h-16 bg-gradient-to-r from-cyan-400 to-blue-400 rounded-full opacity-20 animate-bounce"></div>
          
          <div className="relative p-8 md:p-12">
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
              <div className="space-y-4">
                <div className="flex items-center gap-4">
                  <div className="relative">
                    <div className="absolute inset-0 bg-gradient-to-r from-cyan-400 to-purple-400 rounded-2xl blur-lg opacity-50"></div>
                    <div className="relative p-4 bg-gradient-to-r from-cyan-500 to-purple-500 rounded-2xl">
                      <Brain className="h-10 w-10 text-white" />
                    </div>
                  </div>
                  <div>
                    <h1 className="text-4xl md:text-5xl font-bold text-white tracking-tight">
                      {language === 'ar' ? 'تحليلات الذكاء الاصطناعي' : 'AI Analytics'}
                    </h1>
                    <div className="h-1 w-32 bg-gradient-to-r from-cyan-400 to-purple-400 rounded-full mt-2"></div>
                  </div>
                </div>
                
                <p className="text-indigo-100 text-lg md:text-xl max-w-3xl leading-relaxed">
                  {language === 'ar' 
                    ? 'مراقبة وتحليل أداء نظام التداول الذكي لتحسين دقة التوصيات وزيادة معدل النجاح' 
                    : 'Monitor and analyze smart trading system performance to improve recommendation accuracy and success rates'
                  }
                </p>
                
                {/* Live Status Indicators */}
                <div className="flex flex-wrap gap-4 mt-6">
                  <div className="flex items-center gap-2 bg-white/10 backdrop-blur-sm rounded-full px-4 py-2">
                    <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                    <span className="text-sm text-white font-medium">
                      {language === 'ar' ? 'مراقبة فورية' : 'Live Monitoring'}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 bg-white/10 backdrop-blur-sm rounded-full px-4 py-2">
                    <Activity className="w-4 h-4 text-cyan-400" />
                    <span className="text-sm text-white font-medium">
                      {totalFeedback} {language === 'ar' ? 'تفاعل' : 'Interactions'}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 bg-white/10 backdrop-blur-sm rounded-full px-4 py-2">
                    <Database className="w-4 h-4 text-purple-400" />
                    <span className="text-sm text-white font-medium">
                      {mlData?.length || 0} {language === 'ar' ? 'بيانات تدريب' : 'Training Data'}
                    </span>
                  </div>
                </div>
              </div>
              
              {/* Action Controls */}
              <div className="flex flex-col gap-4">

                
                {/* Quick Stats */}
                <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-4 space-y-3">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-white">{overallSuccessRate.toFixed(1)}%</div>
                    <div className="text-xs text-indigo-200">{language === 'ar' ? 'معدل النجاح' : 'Success Rate'}</div>
                  </div>
                  <div className="w-full bg-white/20 rounded-full h-2">
                    <div 
                      className="bg-gradient-to-r from-green-400 to-cyan-400 h-2 rounded-full transition-all duration-1000"
                      style={{ width: `${overallSuccessRate}%` }}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Enhanced Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {/* Success Rate Card */}
          <Card className="relative overflow-hidden border-0 shadow-lg">
            <div className="absolute inset-0 bg-gradient-to-br from-emerald-500 via-green-500 to-teal-500"></div>
            <div className="absolute inset-0 bg-black/10"></div>
            <CardContent className="relative p-6 text-white">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 bg-white/20 rounded-xl backdrop-blur-sm">
                  <CheckCircle className="h-6 w-6 text-white" />
                </div>
                <div className="text-right">
                  <div className="text-3xl font-bold">
                    {overallSuccessRate.toFixed(1)}%
                  </div>
                  <div className="text-sm opacity-90">
                    {language === 'ar' ? 'معدل النجاح' : 'Success Rate'}
                  </div>
                </div>
              </div>
              <div className="w-full bg-white/20 rounded-full h-2">
                <div 
                  className="bg-white h-2 rounded-full transition-all duration-1000"
                  style={{ width: `${overallSuccessRate}%` }}
                />
              </div>
            </CardContent>
          </Card>

          {/* Total Interactions Card */}
          <Card className="relative overflow-hidden border-0 shadow-lg">
            <div className="absolute inset-0 bg-gradient-to-br from-blue-500 via-indigo-500 to-purple-500"></div>
            <div className="absolute inset-0 bg-black/10"></div>
            <CardContent className="relative p-6 text-white">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 bg-white/20 rounded-xl backdrop-blur-sm">
                  <Users className="h-6 w-6 text-white" />
                </div>
                <div className="text-right">
                  <div className="text-3xl font-bold">
                    {totalFeedback}
                  </div>
                  <div className="text-sm opacity-90">
                    {language === 'ar' ? 'التفاعلات' : 'Interactions'}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <Activity className="h-4 w-4" />
                <span>{successfulFeedback} {language === 'ar' ? 'ناجح' : 'successful'}</span>
              </div>
            </CardContent>
          </Card>

          {/* ML Confidence Card */}
          <Card className="relative overflow-hidden border-0 shadow-lg">
            <div className="absolute inset-0 bg-gradient-to-br from-purple-500 via-violet-500 to-indigo-500"></div>
            <div className="absolute inset-0 bg-black/10"></div>
            <CardContent className="relative p-6 text-white">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 bg-white/20 rounded-xl backdrop-blur-sm">
                  <Brain className="h-6 w-6 text-white" />
                </div>
                <div className="text-right">
                  <div className="text-3xl font-bold">
                    {avgMLConfidence.toFixed(1)}%
                  </div>
                  <div className="text-sm opacity-90">
                    {language === 'ar' ? 'ثقة النظام' : 'AI Confidence'}
                  </div>
                </div>
              </div>
              <div className="w-full bg-white/20 rounded-full h-2">
                <div 
                  className="bg-white h-2 rounded-full transition-all duration-1000"
                  style={{ width: `${avgMLConfidence}%` }}
                />
              </div>
            </CardContent>
          </Card>

          {/* Training Data Card */}
          <Card className="relative overflow-hidden border-0 shadow-lg">
            <div className="absolute inset-0 bg-gradient-to-br from-orange-500 via-red-500 to-pink-500"></div>
            <div className="absolute inset-0 bg-black/10"></div>
            <CardContent className="relative p-6 text-white">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 bg-white/20 rounded-xl backdrop-blur-sm">
                  <Database className="h-6 w-6 text-white" />
                </div>
                <div className="text-right">
                  <div className="text-3xl font-bold">
                    {mlData?.length || 0}
                  </div>
                  <div className="text-sm opacity-90">
                    {language === 'ar' ? 'بيانات التدريب' : 'Training Data'}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <TrendingUp className="h-4 w-4" />
                <span>{language === 'ar' ? 'متطور باستمرار' : 'Continuously learning'}</span>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Enhanced Analytics Tabs */}
        <Tabs defaultValue="feedback" className="space-y-8">
          <div className="bg-white/50 dark:bg-gray-800/50 backdrop-blur-sm rounded-2xl p-2 shadow-lg">
            <TabsList className="grid w-full grid-cols-1 md:grid-cols-3 h-auto bg-transparent gap-2">
              <TabsTrigger 
                value="feedback" 
                className="flex flex-col md:flex-row items-center gap-3 p-4 data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-500 data-[state=active]:to-indigo-500 data-[state=active]:text-white rounded-xl transition-all duration-300 hover:bg-gray-100 dark:hover:bg-gray-700"
              >
                <div className="p-2 rounded-lg bg-blue-100 dark:bg-blue-900/20 data-[state=active]:bg-white/20">
                  <Activity className="h-5 w-5 text-blue-600 dark:text-blue-400 data-[state=active]:text-white" />
                </div>
                <div className="text-center md:text-left">
                  <div className="font-medium">
                    {language === 'ar' ? 'تفاعلات تليجرام' : 'Telegram Feedback'}
                  </div>
                  <div className="text-xs opacity-70">
                    {totalFeedback} {language === 'ar' ? 'تفاعل' : 'interactions'}
                  </div>
                </div>
              </TabsTrigger>
              
              <TabsTrigger 
                value="performance" 
                className="flex flex-col md:flex-row items-center gap-3 p-4 data-[state=active]:bg-gradient-to-r data-[state=active]:from-green-500 data-[state=active]:to-emerald-500 data-[state=active]:text-white rounded-xl transition-all duration-300 hover:bg-gray-100 dark:hover:bg-gray-700"
              >
                <div className="p-2 rounded-lg bg-green-100 dark:bg-green-900/20 data-[state=active]:bg-white/20">
                  <BarChart3 className="h-5 w-5 text-green-600 dark:text-green-400 data-[state=active]:text-white" />
                </div>
                <div className="text-center md:text-left">
                  <div className="font-medium">
                    {language === 'ar' ? 'أداء الأصول' : 'Asset Performance'}
                  </div>
                  <div className="text-xs opacity-70">
                    {performanceData?.length || 0} {language === 'ar' ? 'أصل' : 'assets'}
                  </div>
                </div>
              </TabsTrigger>
              
              <TabsTrigger 
                value="ml-insights" 
                className="flex flex-col md:flex-row items-center gap-3 p-4 data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-500 data-[state=active]:to-violet-500 data-[state=active]:text-white rounded-xl transition-all duration-300 hover:bg-gray-100 dark:hover:bg-gray-700"
              >
                <div className="p-2 rounded-lg bg-purple-100 dark:bg-purple-900/20 data-[state=active]:bg-white/20">
                  <Brain className="h-5 w-5 text-purple-600 dark:text-purple-400 data-[state=active]:text-white" />
                </div>
                <div className="text-center md:text-left">
                  <div className="font-medium">
                    {language === 'ar' ? 'رؤى الذكاء الاصطناعي' : 'ML Insights'}
                  </div>
                  <div className="text-xs opacity-70">
                    {mlData?.length || 0} {language === 'ar' ? 'نقطة بيانات' : 'data points'}
                  </div>
                </div>
              </TabsTrigger>
            </TabsList>
          </div>

          {/* Telegram Feedback Tab */}
          <TabsContent value="feedback" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <PieChart className="h-5 w-5 text-blue-600" />
                    {language === 'ar' ? 'توزيع النتائج' : 'Results Distribution'}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                        <span className="text-sm font-medium">
                          {language === 'ar' ? 'نجح' : 'Success'}
                        </span>
                      </div>
                      <div className="text-right">
                        <div className="text-lg font-bold text-green-600">{successfulFeedback}</div>
                        <div className="text-sm text-muted-foreground">
                          {overallSuccessRate.toFixed(1)}%
                        </div>
                      </div>
                    </div>
                    <Progress value={overallSuccessRate} className="h-3" />

                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                        <span className="text-sm font-medium">
                          {language === 'ar' ? 'نجح جزئياً' : 'Partial'}
                        </span>
                      </div>
                      <div className="text-right">
                        <div className="text-lg font-bold text-yellow-600">{partialFeedback}</div>
                        <div className="text-sm text-muted-foreground">
                          {partialSuccessRate.toFixed(1)}%
                        </div>
                      </div>
                    </div>
                    <Progress value={partialSuccessRate} className="h-3" />

                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                        <span className="text-sm font-medium">
                          {language === 'ar' ? 'فشل' : 'Failed'}
                        </span>
                      </div>
                      <div className="text-right">
                        <div className="text-lg font-bold text-red-600">{failedFeedback}</div>
                        <div className="text-sm text-muted-foreground">
                          {((failedFeedback / totalFeedback) * 100).toFixed(1)}%
                        </div>
                      </div>
                    </div>
                    <Progress value={(failedFeedback / totalFeedback) * 100} className="h-3" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Clock className="h-5 w-5 text-purple-600" />
                    {language === 'ar' ? 'التفاعلات الأخيرة' : 'Recent Interactions'}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {feedbackData?.slice(0, 5).map((feedback) => (
                      <div key={feedback.id} className="flex items-center justify-between p-3 bg-muted rounded-lg">
                        <div className="flex items-center gap-3">
                          {feedback.feedbackType === 'success' && <CheckCircle className="h-4 w-4 text-green-500" />}
                          {feedback.feedbackType === 'partial' && <AlertTriangle className="h-4 w-4 text-yellow-500" />}
                          {feedback.feedbackType === 'failure' && <XCircle className="h-4 w-4 text-red-500" />}
                          <div>
                            <div className="font-medium text-sm">{feedback.assetSymbol}</div>
                            <div className="text-xs text-muted-foreground">{feedback.direction}</div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-sm font-medium">{feedback.confidence}%</div>
                          <div className="text-xs text-muted-foreground">
                            {formatDate(feedback.createdAt)}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Asset Performance Tab */}
          <TabsContent value="performance" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="h-5 w-5 text-green-600" />
                    {language === 'ar' ? 'أفضل الأصول أداءً' : 'Top Performing Assets'}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {topAssets.map((asset, index) => (
                      <div key={asset.id} className="flex items-center justify-between p-3 bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20 rounded-lg">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 bg-green-100 dark:bg-green-900/30 rounded-full flex items-center justify-center">
                            <span className="text-sm font-bold text-green-600">#{index + 1}</span>
                          </div>
                          <div>
                            <div className="font-medium">{asset.assetSymbol}</div>
                            <div className="text-sm text-muted-foreground">
                              {asset.totalRecommendations} {language === 'ar' ? 'توصية' : 'recommendations'}
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className={`text-lg font-bold ${getPerformanceColor(asset.successRate)}`}>
                            {asset.successRate.toFixed(1)}%
                          </div>
                          <div className="text-sm text-muted-foreground">
                            {language === 'ar' ? 'معدل النجاح' : 'Success Rate'}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingDown className="h-5 w-5 text-red-600" />
                    {language === 'ar' ? 'الأصول التي تحتاج تحسين' : 'Assets Needing Improvement'}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {poorAssets.map((asset, index) => (
                      <div key={asset.id} className="flex items-center justify-between p-3 bg-gradient-to-r from-red-50 to-orange-50 dark:from-red-900/20 dark:to-orange-900/20 rounded-lg">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 bg-red-100 dark:bg-red-900/30 rounded-full flex items-center justify-center">
                            <AlertTriangle className="h-4 w-4 text-red-600" />
                          </div>
                          <div>
                            <div className="font-medium">{asset.assetSymbol}</div>
                            <div className="text-sm text-muted-foreground">
                              {asset.totalRecommendations} {language === 'ar' ? 'توصية' : 'recommendations'}
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className={`text-lg font-bold ${getPerformanceColor(asset.successRate)}`}>
                            {asset.successRate.toFixed(1)}%
                          </div>
                          <div className="text-sm text-muted-foreground">
                            {language === 'ar' ? 'معدل النجاح' : 'Success Rate'}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* ML Insights Tab */}
          <TabsContent value="ml-insights" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Brain className="h-5 w-5 text-purple-600" />
                    {language === 'ar' ? 'أداء نموذج التعلم الآلي' : 'ML Model Performance'}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium">
                          {language === 'ar' ? 'متوسط الثقة' : 'Average Confidence'}
                        </span>
                        <span className="text-lg font-bold text-purple-600">
                          {avgMLConfidence.toFixed(1)}%
                        </span>
                      </div>
                      <Progress value={avgMLConfidence} className="h-3" />
                    </div>

                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium">
                          {language === 'ar' ? 'متوسط نقاط النجاح' : 'Average Success Score'}
                        </span>
                        <span className="text-lg font-bold text-blue-600">
                          {(avgSuccessScore * 100).toFixed(1)}%
                        </span>
                      </div>
                      <Progress value={avgSuccessScore * 100} className="h-3" />
                    </div>

                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium">
                          {language === 'ar' ? 'نقاط البيانات' : 'Data Points'}
                        </span>
                        <span className="text-lg font-bold text-green-600">
                          {mlData?.length || 0}
                        </span>
                      </div>
                      <Progress value={Math.min((mlData?.length || 0) / 1000 * 100, 100)} className="h-3" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Lightbulb className="h-5 w-5 text-yellow-600" />
                    {language === 'ar' ? 'رؤى واقتراحات' : 'Insights & Recommendations'}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="p-4 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <Target className="h-4 w-4 text-blue-600" />
                        <span className="font-medium text-blue-800 dark:text-blue-200">
                          {language === 'ar' ? 'دقة النظام' : 'System Accuracy'}
                        </span>
                      </div>
                      <p className="text-sm text-blue-700 dark:text-blue-300">
                        {language === 'ar' 
                          ? `النظام يحقق معدل نجاح ${overallSuccessRate.toFixed(1)}% مع ثقة متوسطة ${avgMLConfidence.toFixed(1)}%`
                          : `System achieving ${overallSuccessRate.toFixed(1)}% success rate with ${avgMLConfidence.toFixed(1)}% average confidence`
                        }
                      </p>
                    </div>

                    <div className="p-4 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <TrendingUp className="h-4 w-4 text-green-600" />
                        <span className="font-medium text-green-800 dark:text-green-200">
                          {language === 'ar' ? 'التحسن المستمر' : 'Continuous Improvement'}
                        </span>
                      </div>
                      <p className="text-sm text-green-700 dark:text-green-300">
                        {language === 'ar' 
                          ? `النظام يتعلم من ${mlData?.length || 0} نقطة بيانات لتحسين الأداء`
                          : `System learning from ${mlData?.length || 0} data points to improve performance`
                        }
                      </p>
                    </div>

                    <div className="p-4 bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <AlertTriangle className="h-4 w-4 text-yellow-600" />
                        <span className="font-medium text-yellow-800 dark:text-yellow-200">
                          {language === 'ar' ? 'مناطق التحسين' : 'Improvement Areas'}
                        </span>
                      </div>
                      <p className="text-sm text-yellow-700 dark:text-yellow-300">
                        {language === 'ar' 
                          ? `${poorAssets.length} أصول تحتاج تحسين في نماذج التنبؤ`
                          : `${poorAssets.length} assets need improvement in prediction models`
                        }
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Floating Refresh Button */}
      <FloatingRefreshButton onRefresh={refreshAllData} />
    </div>
  );
}
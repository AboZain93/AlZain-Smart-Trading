import { SmartRiskManagement } from '@/components/smart-risk-management';
import { useLanguageContext } from '@/components/language-provider';

export default function RiskManagementPage() {
  const { language } = useLanguageContext();

  return (
    <div className="container mx-auto p-6 space-y-6" dir={language === 'ar' ? 'rtl' : 'ltr'}>
      <SmartRiskManagement />
    </div>
  );
}
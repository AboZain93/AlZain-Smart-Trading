import { useState, useEffect, useRef } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Mic, 
  MicOff, 
  Volume2, 
  VolumeX, 
  Settings, 
  Languages, 
  Radio,
  MessageSquare,
  TrendingUp,
  AlertCircle,
  CheckCircle
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

interface VoiceCommand {
  id: string;
  command: string;
  commandAr: string;
  action: string;
  confidence: number;
  timestamp: Date;
  response: string;
  responseAr: string;
  status: "success" | "error" | "processing";
}

interface VoiceSettings {
  language: "en" | "ar" | "fr" | "es";
  voiceEnabled: boolean;
  autoSpeak: boolean;
  speechRate: number;
  volume: number;
  wakeWord: string;
  continuousListening: boolean;
}

const supportedLanguages = [
  { code: "en", name: "English", nameLocal: "English", flag: "🇺🇸" },
  { code: "ar", name: "Arabic", nameLocal: "العربية", flag: "🇸🇦" },
  { code: "fr", name: "French", nameLocal: "Français", flag: "🇫🇷" },
  { code: "es", name: "Spanish", nameLocal: "Español", flag: "🇪🇸" }
];

const voiceCommands = [
  {
    en: "Show me latest signals",
    ar: "اظهر لي أحدث الإشارات",
    action: "GET_SIGNALS",
    description: "Get latest trading signals"
  },
  {
    en: "What's the market status",
    ar: "ما حالة السوق",
    action: "GET_MARKET_STATUS",
    description: "Check current market conditions"
  },
  {
    en: "Show my portfolio",
    ar: "اظهر محفظتي",
    action: "GET_PORTFOLIO",
    description: "Display portfolio overview"
  },
  {
    en: "Start auto trading",
    ar: "ابدأ التداول الآلي",
    action: "START_AUTO_TRADING",
    description: "Enable automatic trading"
  },
  {
    en: "Stop auto trading",
    ar: "اوقف التداول الآلي",
    action: "STOP_AUTO_TRADING",
    description: "Disable automatic trading"
  },
  {
    en: "Read market news",
    ar: "اقرأ أخبار السوق",
    action: "READ_NEWS",
    description: "Read latest market news"
  },
  {
    en: "Set risk level to low",
    ar: "اجعل مستوى المخاطر منخفض",
    action: "SET_RISK_LOW",
    description: "Set risk level to low"
  },
  {
    en: "Set risk level to high",
    ar: "اجعل مستوى المخاطر مرتفع",
    action: "SET_RISK_HIGH",
    description: "Set risk level to high"
  }
];

export default function MultilingualVoiceAssistant() {
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [currentTranscript, setCurrentTranscript] = useState("");
  const [settings, setSettings] = useState<VoiceSettings>({
    language: "en",
    voiceEnabled: true,
    autoSpeak: true,
    speechRate: 1.0,
    volume: 0.8,
    wakeWord: "trading assistant",
    continuousListening: false
  });
  const [commandHistory, setCommandHistory] = useState<VoiceCommand[]>([]);
  const [isSetupComplete, setIsSetupComplete] = useState(false);
  
  const recognitionRef = useRef<any>(null);
  const synthesisRef = useRef<any>(null);
  const queryClient = useQueryClient();

  // Initialize speech recognition
  useEffect(() => {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = window.webkitSpeechRecognition || window.SpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = settings.continuousListening;
      recognitionRef.current.interimResults = true;
      recognitionRef.current.lang = settings.language === "ar" ? "ar-SA" : `${settings.language}-US`;

      recognitionRef.current.onresult = (event: any) => {
        const transcript = event.results[event.results.length - 1][0].transcript;
        setCurrentTranscript(transcript);
        
        if (event.results[event.results.length - 1].isFinal) {
          processVoiceCommand(transcript);
        }
      };

      recognitionRef.current.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current.onerror = (event: any) => {
        console.error('Speech recognition error:', event.error);
        setIsListening(false);
      };

      setIsSetupComplete(true);
    }

    // Initialize speech synthesis
    if ('speechSynthesis' in window) {
      synthesisRef.current = window.speechSynthesis;
    }
  }, [settings.language, settings.continuousListening]);

  const processVoiceCommand = (transcript: string) => {
    const command: VoiceCommand = {
      id: Date.now().toString(),
      command: transcript,
      commandAr: transcript,
      action: "UNKNOWN",
      confidence: 0.8,
      timestamp: new Date(),
      response: "",
      responseAr: "",
      status: "processing"
    };

    setCommandHistory(prev => [command, ...prev.slice(0, 9)]);

    // Process the command
    setTimeout(() => {
      const processedCommand = processCommand(transcript);
      setCommandHistory(prev => 
        prev.map(cmd => 
          cmd.id === command.id 
            ? { ...cmd, ...processedCommand, status: "success" }
            : cmd
        )
      );

      if (settings.autoSpeak && processedCommand.response) {
        speakText(processedCommand.response);
      }
    }, 1000);
  };

  const processCommand = (transcript: string): Partial<VoiceCommand> => {
    const lowerTranscript = transcript.toLowerCase();
    
    // Find matching command
    const matchedCommand = voiceCommands.find(cmd => 
      lowerTranscript.includes(cmd.en.toLowerCase()) || 
      lowerTranscript.includes(cmd.ar)
    );

    if (matchedCommand) {
      switch (matchedCommand.action) {
        case "GET_SIGNALS":
          return {
            action: matchedCommand.action,
            response: "Here are your latest trading signals. EUR/USD is showing a strong buy signal with 85% confidence.",
            responseAr: "هنا أحدث إشارات التداول. زوج يورو/دولار يظهر إشارة شراء قوية بثقة 85%"
          };
        case "GET_MARKET_STATUS":
          return {
            action: matchedCommand.action,
            response: "Current market status: Active trading session. Volatility is moderate with bullish sentiment.",
            responseAr: "حالة السوق الحالية: جلسة تداول نشطة. التقلبات معتدلة مع مشاعر إيجابية"
          };
        case "GET_PORTFOLIO":
          return {
            action: matchedCommand.action,
            response: "Your portfolio shows a 15.2% gain this month with 8 active positions.",
            responseAr: "محفظتك تظهر ربح 15.2% هذا الشهر مع 8 مراكز نشطة"
          };
        case "START_AUTO_TRADING":
          return {
            action: matchedCommand.action,
            response: "Auto trading has been enabled. The system will now execute trades automatically.",
            responseAr: "تم تفعيل التداول الآلي. النظام سينفذ الصفقات تلقائياً الآن"
          };
        case "STOP_AUTO_TRADING":
          return {
            action: matchedCommand.action,
            response: "Auto trading has been disabled. All automated trades are now paused.",
            responseAr: "تم إيقاف التداول الآلي. جميع الصفقات المؤتمتة متوقفة الآن"
          };
        case "READ_NEWS":
          return {
            action: matchedCommand.action,
            response: "Latest market news: Fed maintains interest rates. EUR shows strength against USD.",
            responseAr: "أحدث أخبار السوق: البنك الفيدرالي يحافظ على أسعار الفائدة. اليورو يظهر قوة مقابل الدولار"
          };
        default:
          return {
            action: "UNKNOWN",
            response: "I understand your request. Let me help you with that.",
            responseAr: "أفهم طلبك. دعني أساعدك في ذلك"
          };
      }
    }

    return {
      action: "UNKNOWN",
      response: "I'm sorry, I didn't understand that command. Please try again.",
      responseAr: "آسف، لم أفهم هذا الأمر. يرجى المحاولة مرة أخرى"
    };
  };

  const speakText = (text: string) => {
    if (!synthesisRef.current || !settings.voiceEnabled) return;

    setIsSpeaking(true);
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = settings.language === "ar" ? "ar-SA" : `${settings.language}-US`;
    utterance.rate = settings.speechRate;
    utterance.volume = settings.volume;
    
    utterance.onend = () => {
      setIsSpeaking(false);
    };
    
    synthesisRef.current.speak(utterance);
  };

  const startListening = () => {
    if (!recognitionRef.current) return;
    
    setIsListening(true);
    setCurrentTranscript("");
    recognitionRef.current.start();
  };

  const stopListening = () => {
    if (!recognitionRef.current) return;
    
    recognitionRef.current.stop();
    setIsListening(false);
  };

  const toggleSpeaking = () => {
    if (isSpeaking) {
      synthesisRef.current?.cancel();
      setIsSpeaking(false);
    } else {
      setSettings(prev => ({ ...prev, voiceEnabled: !prev.voiceEnabled }));
    }
  };

  if (!isSetupComplete) {
    return (
      <div className="p-6 text-center">
        <AlertCircle className="w-16 h-16 text-yellow-500 mx-auto mb-4" />
        <h2 className="text-xl font-bold mb-2">Voice Assistant Setup</h2>
        <p className="text-gray-600 mb-4">
          Your browser doesn't support voice recognition or speech synthesis.
          Please use a modern browser like Chrome, Firefox, or Safari.
        </p>
        <Button onClick={() => window.location.reload()}>
          Retry Setup
        </Button>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            Multilingual Voice Assistant
          </h1>
          <p className="text-gray-600 mt-2">
            Control your trading platform with voice commands
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant={isListening ? "default" : "secondary"}>
            {isListening ? "Listening..." : "Ready"}
          </Badge>
          <Badge variant={isSpeaking ? "default" : "secondary"}>
            {isSpeaking ? "Speaking..." : "Silent"}
          </Badge>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Voice Controls */}
        <div className="lg:col-span-2 space-y-4">
          {/* Main Voice Control */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Radio className="w-5 h-5" />
                Voice Control
              </CardTitle>
              <CardDescription>
                Click to start voice commands or use continuous listening
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-center">
                <motion.div
                  animate={{
                    scale: isListening ? [1, 1.1, 1] : 1,
                    rotate: isListening ? [0, 5, -5, 0] : 0
                  }}
                  transition={{
                    duration: 0.5,
                    repeat: isListening ? Infinity : 0
                  }}
                >
                  <Button
                    size="lg"
                    onClick={isListening ? stopListening : startListening}
                    className={`w-24 h-24 rounded-full ${
                      isListening 
                        ? 'bg-red-500 hover:bg-red-600' 
                        : 'bg-blue-500 hover:bg-blue-600'
                    }`}
                  >
                    {isListening ? (
                      <MicOff className="w-8 h-8" />
                    ) : (
                      <Mic className="w-8 h-8" />
                    )}
                  </Button>
                </motion.div>
              </div>

              <div className="flex items-center justify-center gap-4">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={toggleSpeaking}
                  className="flex items-center gap-2"
                >
                  {settings.voiceEnabled ? (
                    <Volume2 className="w-4 h-4" />
                  ) : (
                    <VolumeX className="w-4 h-4" />
                  )}
                  {settings.voiceEnabled ? "Mute" : "Unmute"}
                </Button>
                
                <Select value={settings.language} onValueChange={(value: any) => 
                  setSettings(prev => ({ ...prev, language: value }))
                }>
                  <SelectTrigger className="w-40">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {supportedLanguages.map(lang => (
                      <SelectItem key={lang.code} value={lang.code}>
                        {lang.flag} {lang.nameLocal}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Current Transcript */}
              {currentTranscript && (
                <div className="bg-gray-50 dark:bg-gray-900 p-4 rounded-lg">
                  <p className="text-sm text-gray-600 mb-1">Current:</p>
                  <p className="font-medium">{currentTranscript}</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Command History */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageSquare className="w-5 h-5" />
                Command History
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 max-h-96 overflow-y-auto">
                <AnimatePresence>
                  {commandHistory.map((cmd) => (
                    <motion.div
                      key={cmd.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -20 }}
                      className="border rounded-lg p-3 space-y-2"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Badge variant={
                            cmd.status === "success" ? "default" : 
                            cmd.status === "error" ? "destructive" : "secondary"
                          }>
                            {cmd.status === "success" ? <CheckCircle className="w-3 h-3" /> : 
                             cmd.status === "error" ? <AlertCircle className="w-3 h-3" /> : 
                             <div className="w-3 h-3 rounded-full bg-gray-400 animate-pulse" />}
                          </Badge>
                          <span className="text-xs text-gray-500">
                            {cmd.timestamp.toLocaleTimeString()}
                          </span>
                        </div>
                        <Badge variant="outline" className="text-xs">
                          {cmd.confidence * 100}%
                        </Badge>
                      </div>
                      <div>
                        <p className="text-sm font-medium">{cmd.command}</p>
                        {cmd.response && (
                          <p className="text-sm text-gray-600 mt-1">
                            {settings.language === "ar" ? cmd.responseAr : cmd.response}
                          </p>
                        )}
                      </div>
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Settings & Commands */}
        <div className="space-y-4">
          {/* Voice Settings */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="w-5 h-5" />
                Voice Settings
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Speech Rate</label>
                <div className="flex items-center gap-2">
                  <span className="text-xs">0.5x</span>
                  <input
                    type="range"
                    min="0.5"
                    max="2"
                    step="0.1"
                    value={settings.speechRate}
                    onChange={(e) => setSettings(prev => ({ 
                      ...prev, 
                      speechRate: parseFloat(e.target.value) 
                    }))}
                    className="flex-1"
                  />
                  <span className="text-xs">2x</span>
                </div>
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium">Volume</label>
                <div className="flex items-center gap-2">
                  <VolumeX className="w-4 h-4" />
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.1"
                    value={settings.volume}
                    onChange={(e) => setSettings(prev => ({ 
                      ...prev, 
                      volume: parseFloat(e.target.value) 
                    }))}
                    className="flex-1"
                  />
                  <Volume2 className="w-4 h-4" />
                </div>
              </div>

              <div className="space-y-2">
                <label className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={settings.autoSpeak}
                    onChange={(e) => setSettings(prev => ({ 
                      ...prev, 
                      autoSpeak: e.target.checked 
                    }))}
                  />
                  <span className="text-sm">Auto-speak responses</span>
                </label>
                
                <label className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={settings.continuousListening}
                    onChange={(e) => setSettings(prev => ({ 
                      ...prev, 
                      continuousListening: e.target.checked 
                    }))}
                  />
                  <span className="text-sm">Continuous listening</span>
                </label>
              </div>
            </CardContent>
          </Card>

          {/* Available Commands */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Languages className="w-5 h-5" />
                Available Commands
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {voiceCommands.map((cmd, index) => (
                  <div key={index} className="border-l-2 border-blue-500 pl-3 py-2">
                    <p className="text-sm font-medium">
                      {settings.language === "ar" ? cmd.ar : cmd.en}
                    </p>
                    <p className="text-xs text-gray-500 mt-1">
                      {cmd.description}
                    </p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useLanguageContext } from '../components/language-provider';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Progress } from '../components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { FloatingRefreshButton } from '../components/floating-refresh-button';
import {
  TrendingUp,
  TrendingDown,
  Activity,
  BarChart3,
  AlertTriangle,
  Clock,
  Globe,
  Newspaper,
  Brain,
  Target,
  Zap,
  Eye,
  Calendar,
  DollarSign
} from 'lucide-react';

interface NewsEvent {
  id: string;
  title: string;
  content: string;
  source: string;
  timestamp: string;
  relevantAssets: string[];
  impact: 'low' | 'medium' | 'high' | 'critical';
  sentiment: number;
  category: string;
  reliability: number;
}

interface MarketSentiment {
  overall: number;
  shortTerm: number;
  mediumTerm: number;
  longTerm: number;
  confidence: number;
  riskLevel: string;
}

interface EconomicEvent {
  name: string;
  country: string;
  value: number;
  forecast: number;
  importance: 'low' | 'medium' | 'high';
  releaseTime: string;
  deviation: number;
}

interface TradingInsight {
  recommendation: string;
  confidence: number;
  timeHorizon: string;
  keyFactors: string[];
  risks: string[];
  opportunities: string[];
}

export default function MarketIntelligence() {
  const { language } = useLanguageContext();

  // Mock data for demonstration
  const mockNews: NewsEvent[] = [
    {
      id: '1',
      title: 'Federal Reserve Signals Rate Changes',
      content: 'The Federal Reserve indicated potential monetary policy adjustments...',
      source: 'Reuters',
      timestamp: new Date().toISOString(),
      relevantAssets: ['USD', 'EUR/USD'],
      impact: 'high',
      sentiment: 15,
      category: 'economic',
      reliability: 85
    },
    {
      id: '2',
      title: 'ECB Economic Outlook Update',
      content: 'European Central Bank releases updated economic projections...',
      source: 'Bloomberg',
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
      relevantAssets: ['EUR', 'EUR/USD'],
      impact: 'medium',
      sentiment: -8,
      category: 'economic',
      reliability: 90
    },
    {
      id: '3',
      title: 'Cryptocurrency Market Volatility',
      content: 'Bitcoin and major cryptocurrencies experience increased volatility...',
      source: 'CoinDesk',
      timestamp: new Date(Date.now() - 4 * 60 * 60 * 1000).toISOString(),
      relevantAssets: ['BTC/USD', 'ETH/USD'],
      impact: 'medium',
      sentiment: -25,
      category: 'market',
      reliability: 75
    }
  ];

  const mockSentiment: MarketSentiment = {
    overall: 12,
    shortTerm: 25,
    mediumTerm: 8,
    longTerm: -5,
    confidence: 78,
    riskLevel: 'medium'
  };

  const mockEconomicEvents: EconomicEvent[] = [
    {
      name: 'Non-Farm Payrolls',
      country: 'USD',
      value: 210000,
      forecast: 200000,
      importance: 'high',
      releaseTime: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
      deviation: 10000
    },
    {
      name: 'ECB Interest Rate',
      country: 'EUR',
      value: 4.25,
      forecast: 4.25,
      importance: 'high',
      releaseTime: new Date(Date.now() + 48 * 60 * 60 * 1000).toISOString(),
      deviation: 0
    },
    {
      name: 'GDP Growth Rate',
      country: 'GBP',
      value: 2.1,
      forecast: 1.8,
      importance: 'medium',
      releaseTime: new Date(Date.now() + 72 * 60 * 60 * 1000).toISOString(),
      deviation: 0.3
    }
  ];

  const mockInsights: TradingInsight = {
    recommendation: 'buy',
    confidence: 72,
    timeHorizon: 'medium',
    keyFactors: [
      'Positive economic indicators',
      'Strong market sentiment',
      'Technical breakout patterns'
    ],
    risks: [
      'Central bank policy uncertainty',
      'Geopolitical tensions'
    ],
    opportunities: [
      'High liquidity during session overlap',
      'Strong institutional support'
    ]
  };

  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp);
    return date.toLocaleTimeString(language === 'ar' ? 'ar-SA' : 'en-US', {
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const formatDate = (timestamp: string) => {
    const date = new Date(timestamp);
    return date.toLocaleDateString(language === 'ar' ? 'ar-SA' : 'en-US', {
      month: 'short',
      day: 'numeric'
    });
  };

  const getSentimentColor = (sentiment: number) => {
    if (sentiment > 20) return 'text-green-600';
    if (sentiment > 0) return 'text-green-500';
    if (sentiment > -20) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getSentimentIcon = (sentiment: number) => {
    if (sentiment > 0) return <TrendingUp className="h-4 w-4" />;
    return <TrendingDown className="h-4 w-4" />;
  };

  const getImpactBadge = (impact: string) => {
    const variants = {
      critical: 'destructive',
      high: 'default',
      medium: 'secondary',
      low: 'outline'
    } as const;
    
    return variants[impact as keyof typeof variants] || 'outline';
  };

  const handleRefreshData = () => {
    // Refresh market intelligence data
    console.log('Refreshing market intelligence data...');
  };

  return (
    <div className="container mx-auto p-6 space-y-6" dir={language === 'ar' ? 'rtl' : 'ltr'}>
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            {language === 'ar' ? 'ذكاء السوق' : 'Market Intelligence'}
          </h1>
          <p className="text-muted-foreground">
            {language === 'ar' 
              ? 'تحليل شامل للأخبار والأحداث الاقتصادية ومعنوية السوق' 
              : 'Comprehensive analysis of news, economic events, and market sentiment'}
          </p>
        </div>
      </div>

      {/* Market Sentiment Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-blue-600">
                  {language === 'ar' ? 'المعنوية العامة' : 'Overall Sentiment'}
                </p>
                <p className={`text-2xl font-bold ${getSentimentColor(mockSentiment.overall)}`}>
                  {mockSentiment.overall > 0 ? '+' : ''}{mockSentiment.overall}
                </p>
              </div>
              <Brain className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green-50 to-emerald-50 border-green-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-green-600">
                  {language === 'ar' ? 'مستوى الثقة' : 'Confidence Level'}
                </p>
                <p className="text-2xl font-bold text-green-900">
                  {mockSentiment.confidence}%
                </p>
              </div>
              <Target className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-orange-50 to-amber-50 border-orange-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-orange-600">
                  {language === 'ar' ? 'مستوى المخاطر' : 'Risk Level'}
                </p>
                <p className="text-2xl font-bold text-orange-900 capitalize">
                  {mockSentiment.riskLevel}
                </p>
              </div>
              <AlertTriangle className="h-8 w-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-50 to-violet-50 border-purple-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-purple-600">
                  {language === 'ar' ? 'الأخبار النشطة' : 'Active News'}
                </p>
                <p className="text-2xl font-bold text-purple-900">
                  {mockNews.length}
                </p>
              </div>
              <Newspaper className="h-8 w-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="sentiment" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="sentiment">
            {language === 'ar' ? 'معنوية السوق' : 'Sentiment'}
          </TabsTrigger>
          <TabsTrigger value="news">
            {language === 'ar' ? 'الأخبار' : 'News'}
          </TabsTrigger>
          <TabsTrigger value="economic">
            {language === 'ar' ? 'الأحداث الاقتصادية' : 'Economic Events'}
          </TabsTrigger>
          <TabsTrigger value="insights">
            {language === 'ar' ? 'الرؤى التحليلية' : 'Insights'}
          </TabsTrigger>
        </TabsList>

        <TabsContent value="sentiment" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5" />
                {language === 'ar' ? 'تحليل معنوية السوق' : 'Market Sentiment Analysis'}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">
                      {language === 'ar' ? 'قصير المدى' : 'Short Term'}
                    </span>
                    <span className={`text-sm font-bold ${getSentimentColor(mockSentiment.shortTerm)}`}>
                      {mockSentiment.shortTerm > 0 ? '+' : ''}{mockSentiment.shortTerm}
                    </span>
                  </div>
                  <Progress 
                    value={Math.abs(mockSentiment.shortTerm)} 
                    className="h-2"
                  />
                </div>

                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">
                      {language === 'ar' ? 'متوسط المدى' : 'Medium Term'}
                    </span>
                    <span className={`text-sm font-bold ${getSentimentColor(mockSentiment.mediumTerm)}`}>
                      {mockSentiment.mediumTerm > 0 ? '+' : ''}{mockSentiment.mediumTerm}
                    </span>
                  </div>
                  <Progress 
                    value={Math.abs(mockSentiment.mediumTerm)} 
                    className="h-2"
                  />
                </div>

                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">
                      {language === 'ar' ? 'طويل المدى' : 'Long Term'}
                    </span>
                    <span className={`text-sm font-bold ${getSentimentColor(mockSentiment.longTerm)}`}>
                      {mockSentiment.longTerm > 0 ? '+' : ''}{mockSentiment.longTerm}
                    </span>
                  </div>
                  <Progress 
                    value={Math.abs(mockSentiment.longTerm)} 
                    className="h-2"
                  />
                </div>
              </div>

              <div className="border-t pt-6">
                <h4 className="font-semibold mb-4">
                  {language === 'ar' ? 'العوامل المؤثرة' : 'Contributing Factors'}
                </h4>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="text-center p-4 bg-muted/50 rounded-lg">
                    <Newspaper className="h-6 w-6 mx-auto mb-2 text-blue-600" />
                    <div className="text-sm font-medium">
                      {language === 'ar' ? 'الأخبار' : 'News'}
                    </div>
                    <div className="text-lg font-bold text-blue-600">+15</div>
                  </div>
                  <div className="text-center p-4 bg-muted/50 rounded-lg">
                    <BarChart3 className="h-6 w-6 mx-auto mb-2 text-green-600" />
                    <div className="text-sm font-medium">
                      {language === 'ar' ? 'التحليل الفني' : 'Technical'}
                    </div>
                    <div className="text-lg font-bold text-green-600">+8</div>
                  </div>
                  <div className="text-center p-4 bg-muted/50 rounded-lg">
                    <DollarSign className="h-6 w-6 mx-auto mb-2 text-orange-600" />
                    <div className="text-sm font-medium">
                      {language === 'ar' ? 'الاقتصادي' : 'Economic'}
                    </div>
                    <div className="text-lg font-bold text-orange-600">-5</div>
                  </div>
                  <div className="text-center p-4 bg-muted/50 rounded-lg">
                    <Globe className="h-6 w-6 mx-auto mb-2 text-purple-600" />
                    <div className="text-sm font-medium">
                      {language === 'ar' ? 'اجتماعي' : 'Social'}
                    </div>
                    <div className="text-lg font-bold text-purple-600">+2</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="news" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Newspaper className="h-5 w-5" />
                {language === 'ar' ? 'آخر الأخبار والتحليلات' : 'Latest News & Analysis'}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {mockNews.map((news) => (
                  <div key={news.id} className="border rounded-lg p-4 hover:bg-muted/50 transition-colors">
                    <div className="flex flex-col sm:flex-row justify-between items-start gap-4">
                      <div className="flex-1 space-y-2">
                        <div className="flex items-center gap-2 flex-wrap">
                          <Badge variant={getImpactBadge(news.impact)}>
                            {news.impact.toUpperCase()}
                          </Badge>
                          <Badge variant="outline">{news.category}</Badge>
                          <span className="text-sm text-muted-foreground">
                            {news.source}
                          </span>
                        </div>
                        
                        <h4 className="font-semibold text-lg">{news.title}</h4>
                        <p className="text-muted-foreground text-sm line-clamp-2">
                          {news.content}
                        </p>
                        
                        <div className="flex items-center gap-4 text-sm">
                          <div className="flex items-center gap-1">
                            <Clock className="h-4 w-4" />
                            {formatTime(news.timestamp)}
                          </div>
                          <div className="flex items-center gap-1">
                            <Eye className="h-4 w-4" />
                            {language === 'ar' ? 'الموثوقية' : 'Reliability'}: {news.reliability}%
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-medium">
                              {language === 'ar' ? 'المعنوية:' : 'Sentiment:'}
                            </span>
                            <div className={`flex items-center gap-1 ${getSentimentColor(news.sentiment)}`}>
                              {getSentimentIcon(news.sentiment)}
                              <span className="font-bold">
                                {news.sentiment > 0 ? '+' : ''}{news.sentiment}
                              </span>
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex flex-wrap gap-1">
                          {news.relevantAssets.map((asset, index) => (
                            <Badge key={index} variant="secondary" className="text-xs">
                              {asset}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="economic" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                {language === 'ar' ? 'التقويم الاقتصادي' : 'Economic Calendar'}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {mockEconomicEvents.map((event, index) => (
                  <div key={index} className="border rounded-lg p-4">
                    <div className="flex flex-col sm:flex-row justify-between items-start gap-4">
                      <div className="flex-1 space-y-2">
                        <div className="flex items-center gap-2">
                          <Badge variant={event.importance === 'high' ? 'default' : 
                                        event.importance === 'medium' ? 'secondary' : 'outline'}>
                            {event.importance.toUpperCase()}
                          </Badge>
                          <span className="font-semibold text-lg">{event.country}</span>
                        </div>
                        
                        <h4 className="font-semibold">{event.name}</h4>
                        
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                          <div>
                            <span className="text-muted-foreground">
                              {language === 'ar' ? 'القيمة الفعلية:' : 'Actual:'}
                            </span>
                            <div className="font-bold">{event.value}</div>
                          </div>
                          <div>
                            <span className="text-muted-foreground">
                              {language === 'ar' ? 'التوقع:' : 'Forecast:'}
                            </span>
                            <div className="font-bold">{event.forecast}</div>
                          </div>
                          <div>
                            <span className="text-muted-foreground">
                              {language === 'ar' ? 'الانحراف:' : 'Deviation:'}
                            </span>
                            <div className={`font-bold ${event.deviation > 0 ? 'text-green-600' : 
                                           event.deviation < 0 ? 'text-red-600' : 'text-gray-600'}`}>
                              {event.deviation > 0 ? '+' : ''}{event.deviation}
                            </div>
                          </div>
                          <div>
                            <span className="text-muted-foreground">
                              {language === 'ar' ? 'التوقيت:' : 'Release:'}
                            </span>
                            <div className="font-bold">
                              {formatDate(event.releaseTime)} {formatTime(event.releaseTime)}
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="insights" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="h-5 w-5" />
                {language === 'ar' ? 'الرؤى التحليلية الذكية' : 'AI Trading Insights'}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="text-center p-6 bg-gradient-to-br from-blue-50 to-indigo-50 rounded-lg">
                  <div className="text-3xl font-bold text-blue-600 mb-2 capitalize">
                    {mockInsights.recommendation}
                  </div>
                  <div className="text-sm text-blue-600 font-medium">
                    {language === 'ar' ? 'التوصية' : 'Recommendation'}
                  </div>
                </div>

                <div className="text-center p-6 bg-gradient-to-br from-green-50 to-emerald-50 rounded-lg">
                  <div className="text-3xl font-bold text-green-600 mb-2">
                    {mockInsights.confidence}%
                  </div>
                  <div className="text-sm text-green-600 font-medium">
                    {language === 'ar' ? 'مستوى الثقة' : 'Confidence'}
                  </div>
                </div>

                <div className="text-center p-6 bg-gradient-to-br from-purple-50 to-violet-50 rounded-lg">
                  <div className="text-3xl font-bold text-purple-600 mb-2 capitalize">
                    {mockInsights.timeHorizon}
                  </div>
                  <div className="text-sm text-purple-600 font-medium">
                    {language === 'ar' ? 'الأفق الزمني' : 'Time Horizon'}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="space-y-3">
                  <h4 className="font-semibold text-green-700 flex items-center gap-2">
                    <TrendingUp className="h-4 w-4" />
                    {language === 'ar' ? 'العوامل الإيجابية' : 'Key Factors'}
                  </h4>
                  <div className="space-y-2">
                    {mockInsights.keyFactors.map((factor, index) => (
                      <div key={index} className="flex items-center gap-2 text-sm">
                        <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                        {factor}
                      </div>
                    ))}
                  </div>
                </div>

                <div className="space-y-3">
                  <h4 className="font-semibold text-red-700 flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4" />
                    {language === 'ar' ? 'المخاطر' : 'Risks'}
                  </h4>
                  <div className="space-y-2">
                    {mockInsights.risks.map((risk, index) => (
                      <div key={index} className="flex items-center gap-2 text-sm">
                        <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                        {risk}
                      </div>
                    ))}
                  </div>
                </div>

                <div className="space-y-3">
                  <h4 className="font-semibold text-blue-700 flex items-center gap-2">
                    <Target className="h-4 w-4" />
                    {language === 'ar' ? 'الفرص' : 'Opportunities'}
                  </h4>
                  <div className="space-y-2">
                    {mockInsights.opportunities.map((opportunity, index) => (
                      <div key={index} className="flex items-center gap-2 text-sm">
                        <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                        {opportunity}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <FloatingRefreshButton onRefresh={handleRefreshData} />
    </div>
  );
}
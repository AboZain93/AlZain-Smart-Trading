import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useLanguageContext } from '@/components/language-provider';
import { 
  Smartphone, 
  Download, 
  Share, 
  Bell, 
  Wifi, 
  Battery, 
  Settings, 
  CheckCircle,
  AlertTriangle,
  Info,
  Home,
  QrCode,
  Globe,
  PlayCircle
} from 'lucide-react';

interface PWAInstallPrompt {
  prompt: () => Promise<void>;
  outcome: 'accepted' | 'dismissed';
}

export default function MobileOptimization() {
  const { language } = useLanguageContext();
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isInstallable, setIsInstallable] = useState(false);
  const [isInstalled, setIsInstalled] = useState(false);
  const [networkStatus, setNetworkStatus] = useState('online');
  const [batteryLevel, setBatteryLevel] = useState<number | null>(null);

  useEffect(() => {
    // PWA Install Prompt
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setIsInstallable(true);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

    // Check if already installed
    if (window.matchMedia('(display-mode: standalone)').matches) {
      setIsInstalled(true);
    }

    // Network status monitoring
    const updateNetworkStatus = () => {
      setNetworkStatus(navigator.onLine ? 'online' : 'offline');
    };

    window.addEventListener('online', updateNetworkStatus);
    window.addEventListener('offline', updateNetworkStatus);

    // Battery API (if supported)
    if ('getBattery' in navigator) {
      (navigator as any).getBattery().then((battery: any) => {
        setBatteryLevel(Math.round(battery.level * 100));
        
        battery.addEventListener('levelchange', () => {
          setBatteryLevel(Math.round(battery.level * 100));
        });
      });
    }

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      window.removeEventListener('online', updateNetworkStatus);
      window.removeEventListener('offline', updateNetworkStatus);
    };
  }, []);

  const handleInstallClick = async () => {
    if (!deferredPrompt) return;

    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    
    if (outcome === 'accepted') {
      console.log('PWA installed');
      setIsInstalled(true);
    }
    
    setDeferredPrompt(null);
    setIsInstallable(false);
  };

  const handleShareApp = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: language === 'ar' ? 'الزين تريد - منصة التداول الذكية' : 'AlZain Trade - Smart Trading Platform',
          text: language === 'ar' 
            ? 'تطبيق تداول متطور مع إشارات ذكية وتحليل السوق' 
            : 'Advanced trading app with smart signals and market analysis',
          url: window.location.origin
        });
      } catch (error) {
        console.log('Error sharing:', error);
      }
    } else {
      // Fallback for browsers that don't support Web Share API
      navigator.clipboard.writeText(window.location.origin);
      alert(language === 'ar' ? 'تم نسخ الرابط' : 'Link copied to clipboard');
    }
  };

  const requestNotificationPermission = async () => {
    if ('Notification' in window) {
      const permission = await Notification.requestPermission();
      if (permission === 'granted') {
        new Notification(
          language === 'ar' ? 'تم تفعيل الإشعارات' : 'Notifications Enabled',
          {
            body: language === 'ar' 
              ? 'ستتلقى إشعارات بالإشارات الجديدة' 
              : 'You will receive notifications for new trading signals',
            icon: '/icon-192x192.png'
          }
        );
      }
    }
  };

  const mobileFeatures = [
    {
      icon: Download,
      titleEn: 'Progressive Web App',
      titleAr: 'تطبيق ويب تقدمي',
      descriptionEn: 'Install the app on your device for a native experience',
      descriptionAr: 'ثبت التطبيق على جهازك للحصول على تجربة أصلية',
      status: isInstalled ? 'installed' : isInstallable ? 'available' : 'checking'
    },
    {
      icon: Bell,
      titleEn: 'Push Notifications',
      titleAr: 'الإشعارات الفورية',
      descriptionEn: 'Get instant alerts for new trading signals',
      descriptionAr: 'احصل على تنبيهات فورية للإشارات التجارية الجديدة',
      status: Notification.permission === 'granted' ? 'enabled' : 'available'
    },
    {
      icon: Wifi,
      titleEn: 'Offline Support',
      titleAr: 'دعم العمل بدون اتصال',
      descriptionEn: 'View cached data and continue trading analysis offline',
      descriptionAr: 'عرض البيانات المخزنة ومتابعة تحليل التداول بدون اتصال',
      status: 'enabled'
    },
    {
      icon: Settings,
      titleEn: 'Device Integration',
      titleAr: 'تكامل الجهاز',
      descriptionEn: 'Access device features like camera and location',
      descriptionAr: 'الوصول إلى ميزات الجهاز مثل الكاميرا والموقع',
      status: 'enabled'
    }
  ];

  const installationSteps = [
    {
      step: 1,
      titleEn: 'Open Browser Menu',
      titleAr: 'افتح قائمة المتصفح',
      descriptionEn: 'Tap the menu button (⋮) in your browser',
      descriptionAr: 'اضغط على زر القائمة (⋮) في متصفحك'
    },
    {
      step: 2,
      titleEn: 'Add to Home Screen',
      titleAr: 'إضافة إلى الشاشة الرئيسية',
      descriptionEn: 'Select "Add to Home screen" or "Install App"',
      descriptionAr: 'اختر "إضافة إلى الشاشة الرئيسية" أو "تثبيت التطبيق"'
    },
    {
      step: 3,
      titleEn: 'Confirm Installation',
      titleAr: 'تأكيد التثبيت',
      descriptionEn: 'Tap "Install" or "Add" to complete the process',
      descriptionAr: 'اضغط على "تثبيت" أو "إضافة" لإكمال العملية'
    }
  ];

  return (
    <div className="container mx-auto p-6 space-y-6" dir={language === 'ar' ? 'rtl' : 'ltr'}>
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="flex items-center justify-center gap-3">
          <Smartphone className="h-8 w-8 text-primary" />
          <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            {language === 'ar' ? 'تحسين الهاتف المحمول' : 'Mobile Optimization'}
          </h1>
        </div>
        <p className="text-lg text-muted-foreground max-w-3xl mx-auto leading-relaxed">
          {language === 'ar' 
            ? 'استمتع بتجربة تداول متقدمة على هاتفك المحمول مع ميزات التطبيق الأصلي'
            : 'Enjoy an advanced trading experience on your mobile device with native app features'
          }
        </p>
      </div>

      {/* Device Status */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className={`p-2 rounded-full ${networkStatus === 'online' ? 'bg-green-500' : 'bg-red-500'}`}>
                <Wifi className="h-4 w-4 text-white" />
              </div>
              <div>
                <div className="font-semibold">
                  {language === 'ar' ? 'حالة الاتصال' : 'Network Status'}
                </div>
                <div className="text-sm text-muted-foreground">
                  {networkStatus === 'online' 
                    ? (language === 'ar' ? 'متصل' : 'Online')
                    : (language === 'ar' ? 'غير متصل' : 'Offline')
                  }
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-blue-500 rounded-full">
                <Battery className="h-4 w-4 text-white" />
              </div>
              <div>
                <div className="font-semibold">
                  {language === 'ar' ? 'مستوى البطارية' : 'Battery Level'}
                </div>
                <div className="text-sm text-muted-foreground">
                  {batteryLevel !== null ? `${batteryLevel}%` : (language === 'ar' ? 'غير متاح' : 'Not available')}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className={`p-2 rounded-full ${isInstalled ? 'bg-green-500' : 'bg-orange-500'}`}>
                <Smartphone className="h-4 w-4 text-white" />
              </div>
              <div>
                <div className="font-semibold">
                  {language === 'ar' ? 'حالة التطبيق' : 'App Status'}
                </div>
                <div className="text-sm text-muted-foreground">
                  {isInstalled 
                    ? (language === 'ar' ? 'مثبت' : 'Installed')
                    : (language === 'ar' ? 'متصفح' : 'Browser')
                  }
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* PWA Installation */}
      {!isInstalled && (
        <Card className="border-blue-200 bg-blue-50/30 dark:bg-blue-950/10">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Download className="h-5 w-5 text-blue-600" />
              {language === 'ar' ? 'تثبيت التطبيق' : 'Install App'}
            </CardTitle>
            <CardDescription>
              {language === 'ar' 
                ? 'احصل على تجربة أفضل عبر تثبيت التطبيق على جهازك'
                : 'Get a better experience by installing the app on your device'
              }
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {isInstallable ? (
              <Button onClick={handleInstallClick} className="w-full" size="lg">
                <Download className="mr-2 h-4 w-4" />
                {language === 'ar' ? 'تثبيت التطبيق الآن' : 'Install App Now'}
              </Button>
            ) : (
              <Alert>
                <Info className="h-4 w-4" />
                <AlertDescription>
                  {language === 'ar' 
                    ? 'اتبع الخطوات التالية لتثبيت التطبيق يدوياً'
                    : 'Follow the steps below to install the app manually'
                  }
                </AlertDescription>
              </Alert>
            )}

            {/* Manual Installation Steps */}
            <div className="space-y-3">
              <h4 className="font-semibold">
                {language === 'ar' ? 'خطوات التثبيت اليدوي:' : 'Manual Installation Steps:'}
              </h4>
              {installationSteps.map((step) => (
                <div key={step.step} className="flex items-start gap-3 p-3 bg-white dark:bg-gray-800 rounded-lg">
                  <div className="w-6 h-6 bg-blue-500 text-white rounded-full flex items-center justify-center text-sm font-bold">
                    {step.step}
                  </div>
                  <div>
                    <div className="font-medium">
                      {language === 'ar' ? step.titleAr : step.titleEn}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {language === 'ar' ? step.descriptionAr : step.descriptionEn}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Mobile Features */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {mobileFeatures.map((feature, index) => {
          const IconComponent = feature.icon;
          return (
            <Card key={index} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="p-3 bg-gradient-to-br from-blue-50 to-purple-50 dark:from-blue-950 dark:to-purple-950 rounded-lg">
                      <IconComponent className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <CardTitle className="text-lg">
                        {language === 'ar' ? feature.titleAr : feature.titleEn}
                      </CardTitle>
                    </div>
                  </div>
                  <Badge className={
                    feature.status === 'enabled' || feature.status === 'installed' 
                      ? 'bg-green-100 text-green-800' 
                      : 'bg-blue-100 text-blue-800'
                  }>
                    {feature.status === 'enabled' ? (language === 'ar' ? 'مفعل' : 'Enabled') :
                     feature.status === 'installed' ? (language === 'ar' ? 'مثبت' : 'Installed') :
                     feature.status === 'available' ? (language === 'ar' ? 'متاح' : 'Available') :
                     (language === 'ar' ? 'فحص' : 'Checking')
                    }
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <CardDescription className="leading-relaxed">
                  {language === 'ar' ? feature.descriptionAr : feature.descriptionEn}
                </CardDescription>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Action Buttons */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Button
          onClick={requestNotificationPermission}
          variant="outline"
          className="h-14 text-left justify-start gap-3"
          disabled={Notification.permission === 'granted'}
        >
          <Bell className="h-5 w-5" />
          <div>
            <div className="font-semibold">
              {language === 'ar' ? 'تفعيل الإشعارات' : 'Enable Notifications'}
            </div>
            <div className="text-sm text-muted-foreground">
              {Notification.permission === 'granted' 
                ? (language === 'ar' ? 'مفعل بالفعل' : 'Already enabled')
                : (language === 'ar' ? 'للحصول على إشعارات الإشارات' : 'Get signal alerts')
              }
            </div>
          </div>
        </Button>

        <Button
          onClick={handleShareApp}
          variant="outline"
          className="h-14 text-left justify-start gap-3"
        >
          <Share className="h-5 w-5" />
          <div>
            <div className="font-semibold">
              {language === 'ar' ? 'مشاركة التطبيق' : 'Share App'}
            </div>
            <div className="text-sm text-muted-foreground">
              {language === 'ar' ? 'شارك مع الأصدقاء' : 'Share with friends'}
            </div>
          </div>
        </Button>
      </div>

      {/* QR Code for Easy Access */}
      <Card className="text-center">
        <CardHeader>
          <CardTitle className="flex items-center justify-center gap-2">
            <QrCode className="h-5 w-5" />
            {language === 'ar' ? 'الوصول السريع' : 'Quick Access'}
          </CardTitle>
          <CardDescription>
            {language === 'ar' 
              ? 'امسح رمز QR للوصول المباشر من أي جهاز'
              : 'Scan QR code for direct access from any device'
            }
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="w-32 h-32 mx-auto bg-gradient-to-br from-gray-100 to-gray-200 dark:from-gray-800 dark:to-gray-700 rounded-lg flex items-center justify-center">
            <QrCode className="h-16 w-16 text-muted-foreground" />
          </div>
          <p className="text-sm text-muted-foreground mt-4">
            {language === 'ar' 
              ? 'رمز QR سيتم إنشاؤه ديناميكياً'
              : 'QR code will be generated dynamically'
            }
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
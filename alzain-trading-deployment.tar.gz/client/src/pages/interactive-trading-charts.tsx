import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  TrendingUp, 
  TrendingDown, 
  BarChart3, 
  LineChart, 
  PieChart,
  Activity,
  Target,
  Zap,
  Settings,
  Maximize,
  Minimize,
  RefreshCw,
  Download,
  Share,
  Layers,
  Eye,
  EyeOff,
  Plus,
  Minus,
  MousePointer,
  Crosshair,
  Ruler,
  Palette
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useQuery } from "@tanstack/react-query";

interface ChartData {
  timestamp: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

interface TechnicalIndicator {
  name: string;
  value: number;
  signal: "buy" | "sell" | "neutral";
  color: string;
  enabled: boolean;
}

interface ChartSettings {
  timeframe: "1m" | "5m" | "15m" | "1h" | "4h" | "1d";
  chartType: "candlestick" | "line" | "bar" | "area";
  indicators: string[];
  overlays: string[];
  theme: "light" | "dark";
  showVolume: boolean;
  showGrid: boolean;
  autoScale: boolean;
  precision: number;
}

interface DrawingTool {
  id: string;
  name: string;
  icon: any;
  active: boolean;
  color: string;
}

const mockChartData: ChartData[] = Array.from({ length: 100 }, (_, i) => {
  const basePrice = 1.0850;
  const volatility = 0.002;
  const timestamp = Date.now() - (100 - i) * 60000;
  const open = basePrice + (Math.random() - 0.5) * volatility;
  const range = Math.random() * volatility * 0.5;
  const high = open + range;
  const low = open - range;
  const close = open + (Math.random() - 0.5) * volatility * 0.3;
  const volume = Math.random() * 10000 + 5000;
  
  return {
    timestamp,
    open: parseFloat(open.toFixed(5)),
    high: parseFloat(high.toFixed(5)),
    low: parseFloat(low.toFixed(5)),
    close: parseFloat(close.toFixed(5)),
    volume: Math.round(volume)
  };
});

const technicalIndicators: TechnicalIndicator[] = [
  { name: "RSI", value: 65.4, signal: "buy", color: "#8B5CF6", enabled: true },
  { name: "MACD", value: 0.0012, signal: "buy", color: "#EF4444", enabled: true },
  { name: "BB Upper", value: 1.0892, signal: "neutral", color: "#F59E0B", enabled: false },
  { name: "BB Lower", value: 1.0808, signal: "neutral", color: "#F59E0B", enabled: false },
  { name: "SMA 20", value: 1.0850, signal: "buy", color: "#10B981", enabled: true },
  { name: "SMA 50", value: 1.0835, signal: "buy", color: "#3B82F6", enabled: false },
  { name: "Stochastic", value: 72.1, signal: "buy", color: "#EC4899", enabled: false }
];

const defaultDrawingTools: DrawingTool[] = [
  { id: "pointer", name: "Pointer", icon: MousePointer, active: true, color: "#000" },
  { id: "crosshair", name: "Crosshair", icon: Crosshair, active: false, color: "#000" },
  { id: "horizontal", name: "Horizontal Line", icon: Ruler, active: false, color: "#3B82F6" },
  { id: "vertical", name: "Vertical Line", icon: Ruler, active: false, color: "#3B82F6" },
  { id: "trend", name: "Trend Line", icon: TrendingUp, active: false, color: "#10B981" },
  { id: "fibonacci", name: "Fibonacci", icon: Activity, active: false, color: "#F59E0B" }
];

const availableAssets = [
  { symbol: "EUR/USD", name: "Euro / US Dollar", price: 1.0850, change: 0.0012 },
  { symbol: "GBP/USD", name: "British Pound / US Dollar", price: 1.2645, change: -0.0023 },
  { symbol: "USD/JPY", name: "US Dollar / Japanese Yen", price: 149.85, change: 0.45 },
  { symbol: "BTC/USD", name: "Bitcoin / US Dollar", price: 43200, change: 850 },
  { symbol: "ETH/USD", name: "Ethereum / US Dollar", price: 2650, change: 125 },
  { symbol: "Gold", name: "Gold Spot", price: 2085.50, change: 15.25 }
];

export default function InteractiveTradingCharts() {
  const [selectedAsset, setSelectedAsset] = useState(availableAssets[0]);
  const [chartSettings, setChartSettings] = useState<ChartSettings>({
    timeframe: "15m",
    chartType: "candlestick",
    indicators: ["RSI", "MACD", "SMA 20"],
    overlays: [],
    theme: "light",
    showVolume: true,
    showGrid: true,
    autoScale: true,
    precision: 5
  });
  const [drawingTools, setDrawingTools] = useState<DrawingTool[]>(defaultDrawingTools);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showIndicators, setShowIndicators] = useState(true);
  const [showDrawingTools, setShowDrawingTools] = useState(true);
  const [language, setLanguage] = useState("en");

  const { data: chartData = [], isLoading, refetch } = useQuery({
    queryKey: ['/api/chart-data', selectedAsset.symbol, chartSettings.timeframe],
    queryFn: async () => {
      // Simulate API call
      return mockChartData;
    },
    refetchInterval: 5000
  });

  const { data: indicators = [] } = useQuery({
    queryKey: ['/api/technical-indicators', selectedAsset.symbol],
    queryFn: async () => technicalIndicators
  });

  const toggleIndicator = (indicatorName: string) => {
    setChartSettings(prev => ({
      ...prev,
      indicators: prev.indicators.includes(indicatorName)
        ? prev.indicators.filter(i => i !== indicatorName)
        : [...prev.indicators, indicatorName]
    }));
  };

  const toggleDrawingTool = (toolId: string) => {
    setDrawingTools(prev => 
      prev.map(tool => ({
        ...tool,
        active: tool.id === toolId ? !tool.active : false
      }))
    );
  };

  const getSignalColor = (signal: string) => {
    switch (signal) {
      case "buy": return "text-green-600 bg-green-50";
      case "sell": return "text-red-600 bg-red-50";
      default: return "text-gray-600 bg-gray-50";
    }
  };

  const formatPrice = (price: number) => {
    return price.toFixed(chartSettings.precision);
  };

  const formatChange = (change: number) => {
    const sign = change >= 0 ? "+" : "";
    return `${sign}${change.toFixed(chartSettings.precision)}`;
  };

  if (isLoading) {
    return <div className="p-6">Loading charts...</div>;
  }

  return (
    <div className={`p-6 space-y-6 ${isFullscreen ? 'fixed inset-0 z-50 bg-white' : ''}`}>
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              Interactive Trading Charts
            </h1>
            <p className="text-gray-600 mt-2">
              Advanced charting with technical analysis tools
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Select value={selectedAsset.symbol} onValueChange={(value) => 
              setSelectedAsset(availableAssets.find(a => a.symbol === value) || availableAssets[0])
            }>
              <SelectTrigger className="w-48">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {availableAssets.map(asset => (
                  <SelectItem key={asset.symbol} value={asset.symbol}>
                    <div className="flex items-center justify-between w-full">
                      <span>{asset.symbol}</span>
                      <div className="flex items-center gap-2 ml-2">
                        <span className="font-medium">{formatPrice(asset.price)}</span>
                        <span className={`text-xs ${
                          asset.change >= 0 ? 'text-green-600' : 'text-red-600'
                        }`}>
                          {formatChange(asset.change)}
                        </span>
                      </div>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setIsFullscreen(!isFullscreen)}
          >
            {isFullscreen ? <Minimize className="w-4 h-4" /> : <Maximize className="w-4 h-4" />}
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => refetch()}
          >
            <RefreshCw className="w-4 h-4" />
          </Button>
          <Button
            variant="outline"
            onClick={() => setLanguage(language === "en" ? "ar" : "en")}
          >
            {language === "en" ? "العربية" : "English"}
          </Button>
        </div>
      </div>

      {/* Chart Controls */}
      <div className="flex items-center justify-between bg-gray-50 p-4 rounded-lg">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <Label>Timeframe:</Label>
            <Select value={chartSettings.timeframe} onValueChange={(value: any) => 
              setChartSettings(prev => ({ ...prev, timeframe: value }))
            }>
              <SelectTrigger className="w-20">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1m">1m</SelectItem>
                <SelectItem value="5m">5m</SelectItem>
                <SelectItem value="15m">15m</SelectItem>
                <SelectItem value="1h">1h</SelectItem>
                <SelectItem value="4h">4h</SelectItem>
                <SelectItem value="1d">1d</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="flex items-center gap-2">
            <Label>Chart Type:</Label>
            <Select value={chartSettings.chartType} onValueChange={(value: any) => 
              setChartSettings(prev => ({ ...prev, chartType: value }))
            }>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="candlestick">Candlestick</SelectItem>
                <SelectItem value="line">Line</SelectItem>
                <SelectItem value="bar">Bar</SelectItem>
                <SelectItem value="area">Area</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowIndicators(!showIndicators)}
          >
            {showIndicators ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            Indicators
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowDrawingTools(!showDrawingTools)}
          >
            <Palette className="w-4 h-4" />
            Drawing
          </Button>
          <Button variant="outline" size="sm">
            <Download className="w-4 h-4" />
          </Button>
          <Button variant="outline" size="sm">
            <Share className="w-4 h-4" />
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-12 gap-6">
        {/* Chart Area */}
        <div className={`${showIndicators || showDrawingTools ? 'col-span-9' : 'col-span-12'}`}>
          <Card className="h-[600px]">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="w-5 h-5" />
                  {selectedAsset.name}
                </CardTitle>
                <div className="flex items-center gap-4">
                  <div className="text-right">
                    <p className="text-2xl font-bold">{formatPrice(selectedAsset.price)}</p>
                    <p className={`text-sm ${
                      selectedAsset.change >= 0 ? 'text-green-600' : 'text-red-600'
                    }`}>
                      {formatChange(selectedAsset.change)} ({
                        ((selectedAsset.change / selectedAsset.price) * 100).toFixed(2)
                      }%)
                    </p>
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent className="h-[500px] flex items-center justify-center">
              <div className="text-center">
                <div className="w-full h-96 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg flex items-center justify-center mb-4">
                  <div className="text-center">
                    <LineChart className="w-16 h-16 mx-auto mb-4 text-blue-500" />
                    <p className="text-lg font-semibold text-gray-700">
                      {selectedAsset.symbol} Chart
                    </p>
                    <p className="text-sm text-gray-500">
                      {chartSettings.timeframe} • {chartSettings.chartType}
                    </p>
                    <div className="mt-4 text-xs text-gray-400">
                      <p>Real-time chart data will be displayed here</p>
                      <p>Interactive features: zoom, pan, draw, analyze</p>
                    </div>
                  </div>
                </div>
                
                {/* Volume Chart */}
                {chartSettings.showVolume && (
                  <div className="w-full h-24 bg-gray-50 rounded flex items-center justify-center">
                    <div className="text-center">
                      <Activity className="w-8 h-8 mx-auto mb-2 text-gray-400" />
                      <p className="text-xs text-gray-500">Volume Chart</p>
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Side Panel */}
        <div className={`${showIndicators || showDrawingTools ? 'col-span-3' : 'hidden'} space-y-4`}>
          {/* Technical Indicators */}
          <AnimatePresence>
            {showIndicators && (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                transition={{ duration: 0.3 }}
              >
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg">Technical Indicators</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {indicators.map((indicator) => (
                      <div key={indicator.name} className="space-y-2">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              checked={chartSettings.indicators.includes(indicator.name)}
                              onChange={() => toggleIndicator(indicator.name)}
                              className="rounded"
                            />
                            <span className="text-sm font-medium">{indicator.name}</span>
                          </div>
                          <Badge className={getSignalColor(indicator.signal)}>
                            {indicator.signal}
                          </Badge>
                        </div>
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-gray-600">Value:</span>
                          <span className="font-medium">{indicator.value}</span>
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Drawing Tools */}
          <AnimatePresence>
            {showDrawingTools && (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                transition={{ duration: 0.3, delay: 0.1 }}
              >
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg">Drawing Tools</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    {drawingTools.map((tool) => (
                      <Button
                        key={tool.id}
                        variant={tool.active ? "default" : "outline"}
                        size="sm"
                        onClick={() => toggleDrawingTool(tool.id)}
                        className="w-full justify-start"
                      >
                        <tool.icon className="w-4 h-4 mr-2" />
                        {tool.name}
                      </Button>
                    ))}
                  </CardContent>
                </Card>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Chart Settings */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <Settings className="w-4 h-4" />
                Chart Settings
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Theme</Label>
                <Select value={chartSettings.theme} onValueChange={(value: any) => 
                  setChartSettings(prev => ({ ...prev, theme: value }))
                }>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="light">Light</SelectItem>
                    <SelectItem value="dark">Dark</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label>Precision</Label>
                <Input
                  type="number"
                  min="0"
                  max="8"
                  value={chartSettings.precision}
                  onChange={(e) => setChartSettings(prev => ({
                    ...prev,
                    precision: parseInt(e.target.value)
                  }))}
                />
              </div>
              
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label>Show Volume</Label>
                  <input
                    type="checkbox"
                    checked={chartSettings.showVolume}
                    onChange={(e) => setChartSettings(prev => ({
                      ...prev,
                      showVolume: e.target.checked
                    }))}
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <Label>Show Grid</Label>
                  <input
                    type="checkbox"
                    checked={chartSettings.showGrid}
                    onChange={(e) => setChartSettings(prev => ({
                      ...prev,
                      showGrid: e.target.checked
                    }))}
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <Label>Auto Scale</Label>
                  <input
                    type="checkbox"
                    checked={chartSettings.autoScale}
                    onChange={(e) => setChartSettings(prev => ({
                      ...prev,
                      autoScale: e.target.checked
                    }))}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
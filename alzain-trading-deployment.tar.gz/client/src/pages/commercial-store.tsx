import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Check, Crown, Star, Gift, Calendar, Users } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface Product {
  id: number;
  name: string;
  nameAr: string;
  description: string;
  descriptionAr: string;
  productType: "subscription" | "license" | "one-time";
  category: string;
  priceUsd: number;
  originalPriceUsd?: number;
  billingCycle?: "monthly" | "yearly" | "lifetime";
  features: string[];
  trialDays: number;
  trialTrades: number;
  maxDevicesAllowed: number;
  isActive: boolean;
  isPopular?: boolean;
}

interface LicenseValidation {
  isValid: boolean;
  license?: any;
  user?: any;
  errors: string[];
  remainingTrades?: number;
  remainingDays?: number;
}

export default function CommercialStore() {
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [showPurchaseDialog, setShowPurchaseDialog] = useState(false);
  const [showTrialDialog, setShowTrialDialog] = useState(false);
  const [showValidateDialog, setShowValidateDialog] = useState(false);
  const [licenseKey, setLicenseKey] = useState("");
  const [paymentMethod, setPaymentMethod] = useState("stripe");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // جلب المنتجات المتاحة
  const { data: products = [], isLoading: productsLoading } = useQuery({
    queryKey: ["/api/sales/products"],
    queryFn: () => apiRequest("GET", "/api/sales/products").then(res => res.json()),
  });

  // جلب تراخيص المستخدم
  const { data: myLicenses = [], isLoading: licensesLoading } = useQuery({
    queryKey: ["/api/sales/my-licenses"],
    queryFn: () => apiRequest("GET", "/api/sales/my-licenses").then(res => res.json()),
  });

  // طلب فترة تجريبية
  const trialMutation = useMutation({
    mutationFn: async (productId: number) => {
      const response = await apiRequest("POST", "/api/sales/generate-trial", {
        productId,
      });
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "تم إنشاء الترخيص التجريبي بنجاح!",
        description: `مفتاح الترخيص: ${data.licenseKey}`,
      });
      setShowTrialDialog(false);
      queryClient.invalidateQueries({ queryKey: ["/api/sales/my-licenses"] });
    },
    onError: (error: any) => {
      toast({
        title: "خطأ في إنشاء الترخيص التجريبي",
        description: error.message || "حدث خطأ غير متوقع",
        variant: "destructive",
      });
    },
  });

  // شراء ترخيص
  const purchaseMutation = useMutation({
    mutationFn: async (data: { productId: number; paymentMethod: string; amount: number }) => {
      const response = await apiRequest("POST", "/api/sales/purchase", {
        productId: data.productId,
        paymentMethod: data.paymentMethod,
        paymentId: `payment_${Date.now()}`,
        amount: data.amount,
        currency: "USD",
      });
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "تم شراء الترخيص بنجاح!",
        description: `مفتاح الترخيص: ${data.licenseKey}`,
      });
      setShowPurchaseDialog(false);
      queryClient.invalidateQueries({ queryKey: ["/api/sales/my-licenses"] });
    },
    onError: (error: any) => {
      toast({
        title: "خطأ في شراء الترخيص",
        description: error.message || "حدث خطأ غير متوقع",
        variant: "destructive",
      });
    },
  });

  // التحقق من صحة الترخيص
  const validateMutation = useMutation({
    mutationFn: async (licenseKey: string) => {
      const response = await apiRequest("POST", "/api/sales/validate-license", {
        licenseKey,
      });
      return response.json();
    },
    onSuccess: (data) => {
      const validation: LicenseValidation = data.validation;
      if (validation.isValid) {
        toast({
          title: "الترخيص صالح ✅",
          description: `المدة المتبقية: ${validation.remainingDays || 'غير محدود'} يوم`,
        });
      } else {
        toast({
          title: "الترخيص غير صالح ❌",
          description: validation.errors.join(", "),
          variant: "destructive",
        });
      }
      setShowValidateDialog(false);
      setLicenseKey("");
    },
    onError: (error: any) => {
      toast({
        title: "خطأ في التحقق من الترخيص",
        description: error.message || "حدث خطأ غير متوقع",
        variant: "destructive",
      });
    },
  });

  const formatPrice = (price: number) => {
    return `$${(price / 100).toFixed(2)}`;
  };

  const getDiscountPercentage = (original: number, current: number) => {
    return Math.round(((original - current) / original) * 100);
  };

  const getBillingCycleText = (cycle?: string) => {
    switch (cycle) {
      case "monthly": return "شهرياً";
      case "yearly": return "سنوياً";
      case "lifetime": return "مدى الحياة";
      default: return "";
    }
  };

  const getProductTypeIcon = (type: string) => {
    switch (type) {
      case "subscription": return <Calendar className="h-4 w-4" />;
      case "license": return <Crown className="h-4 w-4" />;
      case "one-time": return <Gift className="h-4 w-4" />;
      default: return <Star className="h-4 w-4" />;
    }
  };

  if (productsLoading) {
    return (
      <div className="container mx-auto p-6">
        <div className="text-center">
          <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full mx-auto mb-4" />
          <p>جاري تحميل المنتجات...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-violet-600 bg-clip-text text-transparent">
          متجر المنتجات التجارية
        </h1>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
          اختر الخطة المناسبة لك واحصل على أفضل إشارات التداول والتحليل الفني المتقدم
        </p>
        
        {/* أزرار الإجراءات السريعة */}
        <div className="flex gap-4 justify-center">
          <Dialog open={showValidateDialog} onOpenChange={setShowValidateDialog}>
            <DialogTrigger asChild>
              <Button variant="outline" className="gap-2">
                <Check className="h-4 w-4" />
                التحقق من الترخيص
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>التحقق من صحة الترخيص</DialogTitle>
                <DialogDescription>
                  أدخل مفتاح الترخيص للتحقق من صحته وحالته
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="licenseKey">مفتاح الترخيص</Label>
                  <Input
                    id="licenseKey"
                    value={licenseKey}
                    onChange={(e) => setLicenseKey(e.target.value)}
                    placeholder="LIC-XXXX-XXXX-XXXX"
                  />
                </div>
              </div>
              <DialogFooter>
                <Button
                  onClick={() => validateMutation.mutate(licenseKey)}
                  disabled={!licenseKey || validateMutation.isPending}
                >
                  {validateMutation.isPending ? "جاري التحقق..." : "تحقق"}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* منتجاتي */}
      {myLicenses.licenses && myLicenses.licenses.length > 0 && (
        <div className="space-y-4">
          <h2 className="text-2xl font-bold">تراخيصي</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {myLicenses.licenses.map((license: any) => (
              <Card key={license.id} className="border-green-200 bg-green-50">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-lg">{license.product?.name || "منتج غير معروف"}</CardTitle>
                      <CardDescription>
                        {license.isTrial ? (
                          <Badge variant="secondary">فترة تجريبية</Badge>
                        ) : (
                          <Badge variant="default">ترخيص مدفوع</Badge>
                        )}
                      </CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div className="text-sm">
                    <strong>مفتاح الترخيص:</strong>
                    <code className="block mt-1 p-2 bg-gray-100 rounded text-xs">
                      {license.licenseKey}
                    </code>
                  </div>
                  {license.stats && (
                    <div className="space-y-1 text-sm">
                      {license.stats.tradesRemaining !== -1 && (
                        <p>الصفقات المتبقية: {license.stats.tradesRemaining}</p>
                      )}
                      <p>الأيام المتبقية: {license.stats.daysRemaining}</p>
                      <p>الأجهزة المستخدمة: {license.stats.devicesUsed}</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* المنتجات المتاحة */}
      <div className="space-y-4">
        <h2 className="text-2xl font-bold">المنتجات المتاحة</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {products.products?.map((product: Product) => (
            <Card key={product.id} className={`relative ${product.isPopular ? 'border-primary shadow-lg' : ''}`}>
              {product.isPopular && (
                <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                  <Badge className="bg-gradient-to-r from-orange-500 to-red-500 text-white">
                    الأكثر شعبية
                  </Badge>
                </div>
              )}
              
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      {getProductTypeIcon(product.productType)}
                      <CardTitle className="text-xl">{product.nameAr}</CardTitle>
                    </div>
                    <CardDescription className="text-sm">
                      {product.descriptionAr}
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* السعر */}
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-3xl font-bold text-primary">
                      {formatPrice(product.priceUsd)}
                    </span>
                    {product.originalPriceUsd && product.originalPriceUsd > product.priceUsd && (
                      <>
                        <span className="text-lg text-muted-foreground line-through">
                          {formatPrice(product.originalPriceUsd)}
                        </span>
                        <Badge variant="destructive">
                          -{getDiscountPercentage(product.originalPriceUsd, product.priceUsd)}%
                        </Badge>
                      </>
                    )}
                  </div>
                  {product.billingCycle && (
                    <p className="text-sm text-muted-foreground">
                      {getBillingCycleText(product.billingCycle)}
                    </p>
                  )}
                </div>

                {/* المميزات */}
                <div className="space-y-2">
                  <h4 className="font-semibold">المميزات:</h4>
                  <ul className="space-y-1">
                    {product.features.slice(0, 3).map((feature, index) => (
                      <li key={index} className="flex items-center gap-2 text-sm">
                        <Check className="h-4 w-4 text-green-500" />
                        {feature}
                      </li>
                    ))}
                    {product.features.length > 3 && (
                      <li className="text-sm text-muted-foreground">
                        +{product.features.length - 3} مميزات أخرى
                      </li>
                    )}
                  </ul>
                </div>

                {/* تفاصيل الفترة التجريبية */}
                {product.trialDays > 0 && (
                  <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
                    <h4 className="font-semibold text-blue-800 mb-1">فترة تجريبية مجانية</h4>
                    <p className="text-sm text-blue-600">
                      {product.trialDays} أيام • {product.trialTrades} صفقة مجانية
                    </p>
                  </div>
                )}
              </CardContent>

              <CardFooter className="flex gap-2">
                {/* زر الفترة التجريبية */}
                {product.trialDays > 0 && (
                  <Dialog open={showTrialDialog && selectedProduct?.id === product.id} 
                          onOpenChange={(open) => {
                            setShowTrialDialog(open);
                            if (open) setSelectedProduct(product);
                          }}>
                    <DialogTrigger asChild>
                      <Button variant="outline" className="flex-1">
                        جرب مجاناً
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>طلب فترة تجريبية</DialogTitle>
                        <DialogDescription>
                          ستحصل على {product.trialDays} أيام و {product.trialTrades} صفقة مجانية
                        </DialogDescription>
                      </DialogHeader>
                      <DialogFooter>
                        <Button
                          onClick={() => trialMutation.mutate(product.id)}
                          disabled={trialMutation.isPending}
                        >
                          {trialMutation.isPending ? "جاري الإنشاء..." : "إنشاء الترخيص التجريبي"}
                        </Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                )}

                {/* زر الشراء */}
                <Dialog open={showPurchaseDialog && selectedProduct?.id === product.id} 
                        onOpenChange={(open) => {
                          setShowPurchaseDialog(open);
                          if (open) setSelectedProduct(product);
                        }}>
                  <DialogTrigger asChild>
                    <Button className="flex-1 bg-gradient-to-r from-blue-600 to-violet-600 hover:from-blue-700 hover:to-violet-700">
                      شراء الآن
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>شراء {product.nameAr}</DialogTitle>
                      <DialogDescription>
                        السعر: {formatPrice(product.priceUsd)} {getBillingCycleText(product.billingCycle)}
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="paymentMethod">طريقة الدفع</Label>
                        <Select value={paymentMethod} onValueChange={setPaymentMethod}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="stripe">Stripe</SelectItem>
                            <SelectItem value="paypal">PayPal</SelectItem>
                            <SelectItem value="crypto">العملات المشفرة</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <DialogFooter>
                      <Button
                        onClick={() => purchaseMutation.mutate({
                          productId: product.id,
                          paymentMethod,
                          amount: product.priceUsd,
                        })}
                        disabled={purchaseMutation.isPending}
                      >
                        {purchaseMutation.isPending ? "جاري المعالجة..." : "تأكيد الشراء"}
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
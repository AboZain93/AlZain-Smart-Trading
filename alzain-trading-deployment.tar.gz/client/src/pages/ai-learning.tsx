import { AILearningDemo } from '../components/ai-learning-demo';
import { useLanguage } from '../hooks/use-language';
import { Brain, Bot } from 'lucide-react';

export default function AILearning() {
  const { language } = useLanguage();

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-blue-500/20 rounded-lg">
              <Brain className="h-6 w-6 text-blue-600 dark:text-blue-400" />
            </div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              {language === 'ar' ? 'مختبر التعلم الآلي' : 'AI Learning Laboratory'}
            </h1>
          </div>
          <p className="text-muted-foreground text-lg">
            {language === 'ar' 
              ? 'اكتشف كيف يتعلم الذكاء الاصطناعي من تفاعلات المستخدمين ويحسن دقة التوصيات'
              : 'Discover how AI learns from user interactions and improves recommendation accuracy'
            }
          </p>
        </div>

        {/* Key Features */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-gradient-to-br from-blue-50 to-purple-50 dark:from-blue-950/20 dark:to-purple-950/20 p-6 rounded-lg border">
            <Bot className="h-8 w-8 text-blue-500 mb-3" />
            <h3 className="font-semibold mb-2">
              {language === 'ar' ? 'التعلم المستمر' : 'Continuous Learning'}
            </h3>
            <p className="text-sm text-muted-foreground">
              {language === 'ar' 
                ? 'النظام يتعلم من كل تفاعل مستخدم ويحسن خوارزمياته تلقائياً'
                : 'System learns from every user interaction and automatically improves algorithms'
              }
            </p>
          </div>

          <div className="bg-gradient-to-br from-emerald-50 to-teal-50 dark:from-emerald-950/20 dark:to-teal-950/20 p-6 rounded-lg border">
            <Brain className="h-8 w-8 text-emerald-500 mb-3" />
            <h3 className="font-semibold mb-2">
              {language === 'ar' ? 'تحليل ذكي' : 'Smart Analysis'}
            </h3>
            <p className="text-sm text-muted-foreground">
              {language === 'ar' 
                ? 'تحليل أنماط السوق والسلوك للتنبؤ بالاتجاهات المستقبلية'
                : 'Analyzes market patterns and behavior to predict future trends'
              }
            </p>
          </div>

          <div className="bg-gradient-to-br from-orange-50 to-red-50 dark:from-orange-950/20 dark:to-red-950/20 p-6 rounded-lg border">
            <Brain className="h-8 w-8 text-orange-500 mb-3" />
            <h3 className="font-semibold mb-2">
              {language === 'ar' ? 'تحسين الأداء' : 'Performance Optimization'}
            </h3>
            <p className="text-sm text-muted-foreground">
              {language === 'ar' 
                ? 'تحسين دقة التوصيات بناءً على النتائج الفعلية للتداولات'
                : 'Optimizes recommendation accuracy based on actual trading results'
              }
            </p>
          </div>
        </div>

        {/* AI Learning Demo Component */}
        <AILearningDemo />
      </div>
    </div>
  );
}
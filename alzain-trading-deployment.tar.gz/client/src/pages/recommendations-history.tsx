import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useLanguageContext } from '../components/language-provider';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Button } from '../components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Input } from '../components/ui/input';
import { 
  History, 
  TrendingUp, 
  TrendingDown, 
  Search, 
  Filter,
  Calendar,
  CheckCircle,
  XCircle,
  Clock,
  BarChart3
} from 'lucide-react';

interface TradingRecommendation {
  id: number;
  assetSymbol: string;
  direction: string;
  confidence: number;
  riskLevel: string;
  technicalAnalysis: string;
  marketStatus: string;
  entryTime: string;
  duration: string;
  trend: string;
  liquidity: string;
  result?: string;
  sentToTelegram: boolean;
  createdAt: string;
}

export default function RecommendationsHistory() {
  const context = useLanguageContext();
  const language = context?.language || 'ar';
  const [searchTerm, setSearchTerm] = useState('');
  const [filterResult, setFilterResult] = useState('all');
  const [filterAsset, setFilterAsset] = useState('all');

  const { data: recommendations, isLoading } = useQuery<TradingRecommendation[]>({
    queryKey: ['/api/trading-recommendations'],
    refetchInterval: 30000,
  });

  const filteredRecommendations = recommendations?.filter(rec => {
    const matchesSearch = rec.assetSymbol.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         rec.direction.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesResult = filterResult === 'all' || rec.result === filterResult;
    const matchesAsset = filterAsset === 'all' || rec.assetSymbol === filterAsset;
    
    return matchesSearch && matchesResult && matchesAsset;
  });

  const uniqueAssets = Array.from(new Set(recommendations?.map(rec => rec.assetSymbol) || []));

  const getResultBadge = (result?: string) => {
    switch (result) {
      case 'success':
        return <Badge className="bg-green-100 text-green-700 hover:bg-green-100">
          <CheckCircle className="h-3 w-3 mr-1" />
          {language === 'ar' ? 'نجح' : 'Success'}
        </Badge>;
      case 'failure':
        return <Badge className="bg-red-100 text-red-700 hover:bg-red-100">
          <XCircle className="h-3 w-3 mr-1" />
          {language === 'ar' ? 'فشل' : 'Failed'}
        </Badge>;
      case 'pending':
        return <Badge className="bg-yellow-100 text-yellow-700 hover:bg-yellow-100">
          <Clock className="h-3 w-3 mr-1" />
          {language === 'ar' ? 'قيد الانتظار' : 'Pending'}
        </Badge>;
      default:
        return <Badge variant="secondary">
          <Clock className="h-3 w-3 mr-1" />
          {language === 'ar' ? 'غير محدد' : 'Unknown'}
        </Badge>;
    }
  };

  const getRiskColor = (riskLevel: string) => {
    switch (riskLevel.toLowerCase()) {
      case 'low': return 'text-green-600 bg-green-50';
      case 'medium': return 'text-yellow-600 bg-yellow-50';
      case 'high': return 'text-red-600 bg-red-50';
      default: return 'text-gray-600 bg-gray-50';
    }
  };

  const getSuccessRate = () => {
    if (!recommendations?.length) return 0;
    const successCount = recommendations.filter(rec => rec.result === 'success').length;
    return Math.round((successCount / recommendations.length) * 100);
  };

  const getTotalProfit = () => {
    // محاكاة حساب الربح - يمكن تطويرها لاحقاً مع بيانات حقيقية
    if (!recommendations?.length) return 0;
    const successCount = recommendations.filter(rec => rec.result === 'success').length;
    return successCount * 15.7; // متوسط ربح افتراضي
  };

  if (isLoading) {
    return (
      <div className="container mx-auto p-6">
        <div className="flex items-center gap-3 mb-6">
          <History className="h-8 w-8 text-primary" />
          <h1 className="text-3xl font-bold">
            {language === 'ar' ? 'سجل التوصيات' : 'Recommendations History'}
          </h1>
        </div>
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-6">
                <div className="h-4 bg-muted rounded w-3/4 mb-2"></div>
                <div className="h-3 bg-muted rounded w-1/2"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6">
      <div className="flex items-center gap-3 mb-6">
        <History className="h-8 w-8 text-primary" />
        <h1 className="text-3xl font-bold">
          {language === 'ar' ? 'سجل التوصيات' : 'Recommendations History'}
        </h1>
      </div>

      {/* إحصائيات سريعة */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <Card>
          <CardContent className="p-4 text-center">
            <BarChart3 className="h-8 w-8 text-blue-600 mx-auto mb-2" />
            <div className="text-2xl font-bold text-blue-600">
              {recommendations?.length || 0}
            </div>
            <div className="text-sm text-muted-foreground">
              {language === 'ar' ? 'إجمالي التوصيات' : 'Total Signals'}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4 text-center">
            <CheckCircle className="h-8 w-8 text-green-600 mx-auto mb-2" />
            <div className="text-2xl font-bold text-green-600">
              {getSuccessRate()}%
            </div>
            <div className="text-sm text-muted-foreground">
              {language === 'ar' ? 'معدل النجاح' : 'Success Rate'}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4 text-center">
            <TrendingUp className="h-8 w-8 text-emerald-600 mx-auto mb-2" />
            <div className="text-2xl font-bold text-emerald-600">
              ${getTotalProfit().toFixed(1)}
            </div>
            <div className="text-sm text-muted-foreground">
              {language === 'ar' ? 'الربح الإجمالي' : 'Total Profit'}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4 text-center">
            <Calendar className="h-8 w-8 text-purple-600 mx-auto mb-2" />
            <div className="text-2xl font-bold text-purple-600">
              {recommendations?.filter(rec => rec.result === 'pending').length || 0}
            </div>
            <div className="text-sm text-muted-foreground">
              {language === 'ar' ? 'قيد الانتظار' : 'Pending'}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* فلاتر البحث */}
      <Card className="mb-6">
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder={language === 'ar' ? 'البحث في التوصيات...' : 'Search recommendations...'}
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            
            <Select value={filterAsset} onValueChange={setFilterAsset}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder={language === 'ar' ? 'الأصل' : 'Asset'} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">
                  {language === 'ar' ? 'جميع الأصول' : 'All Assets'}
                </SelectItem>
                {uniqueAssets.map(asset => (
                  <SelectItem key={asset} value={asset}>{asset}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={filterResult} onValueChange={setFilterResult}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder={language === 'ar' ? 'النتيجة' : 'Result'} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">
                  {language === 'ar' ? 'جميع النتائج' : 'All Results'}
                </SelectItem>
                <SelectItem value="success">
                  {language === 'ar' ? 'نجح' : 'Success'}
                </SelectItem>
                <SelectItem value="failure">
                  {language === 'ar' ? 'فشل' : 'Failed'}
                </SelectItem>
                <SelectItem value="pending">
                  {language === 'ar' ? 'قيد الانتظار' : 'Pending'}
                </SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* قائمة التوصيات */}
      <div className="space-y-4">
        {filteredRecommendations?.map((rec) => (
          <Card key={rec.id} className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="flex items-center gap-2">
                    {rec.direction === 'BUY' ? (
                      <TrendingUp className="h-5 w-5 text-green-600" />
                    ) : (
                      <TrendingDown className="h-5 w-5 text-red-600" />
                    )}
                    <span className="font-bold text-lg">{rec.assetSymbol}</span>
                  </div>
                  
                  <Badge variant={rec.direction === 'BUY' ? 'default' : 'destructive'}>
                    {rec.direction}
                  </Badge>
                  
                  <Badge className={getRiskColor(rec.riskLevel)}>
                    {language === 'ar' 
                      ? rec.riskLevel === 'low' ? 'منخفض' : rec.riskLevel === 'medium' ? 'متوسط' : 'مرتفع'
                      : rec.riskLevel}
                  </Badge>
                </div>

                <div className="flex items-center gap-2">
                  {getResultBadge(rec.result)}
                  <div className="text-sm text-muted-foreground">
                    {new Date(rec.createdAt).toLocaleDateString('ar-SA')}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                <div>
                  <span className="text-sm text-muted-foreground">
                    {language === 'ar' ? 'الثقة:' : 'Confidence:'}
                  </span>
                  <div className="flex items-center gap-2">
                    <div className="flex-1 bg-muted rounded-full h-2">
                      <div 
                        className="h-2 rounded-full bg-primary" 
                        style={{ width: `${rec.confidence}%` }}
                      />
                    </div>
                    <span className="text-sm font-medium">{rec.confidence}%</span>
                  </div>
                </div>

                <div>
                  <span className="text-sm text-muted-foreground">
                    {language === 'ar' ? 'وقت الدخول:' : 'Entry Time:'}
                  </span>
                  <p className="font-medium">{rec.entryTime}</p>
                </div>

                <div>
                  <span className="text-sm text-muted-foreground">
                    {language === 'ar' ? 'مدة الصفقة:' : 'Duration:'}
                  </span>
                  <p className="font-medium">{rec.duration || '5 دقائق'}</p>
                </div>
              </div>

              <div className="mb-4">
                <span className="text-sm text-muted-foreground">
                  {language === 'ar' ? 'التحليل الفني:' : 'Technical Analysis:'}
                </span>
                <p className="text-sm mt-1">{rec.technicalAnalysis}</p>
              </div>

              <div className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-4">
                  <span>
                    {language === 'ar' ? 'الاتجاه:' : 'Trend:'} 
                    <span className="font-medium ml-1">{rec.trend}</span>
                  </span>
                  <span>
                    {language === 'ar' ? 'السيولة:' : 'Liquidity:'} 
                    <span className="font-medium ml-1">{rec.liquidity}</span>
                  </span>
                </div>
                
                {rec.sentToTelegram && (
                  <Badge variant="outline" className="text-xs">
                    {language === 'ar' ? 'أُرسل لتليجرام' : 'Sent to Telegram'}
                  </Badge>
                )}
              </div>
            </CardContent>
          </Card>
        ))}

        {filteredRecommendations?.length === 0 && (
          <Card>
            <CardContent className="p-12 text-center">
              <History className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">
                {language === 'ar' ? 'لا توجد توصيات' : 'No Recommendations Found'}
              </h3>
              <p className="text-muted-foreground">
                {language === 'ar' 
                  ? 'لم يتم العثور على توصيات تطابق معايير البحث.'
                  : 'No recommendations match your search criteria.'}
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
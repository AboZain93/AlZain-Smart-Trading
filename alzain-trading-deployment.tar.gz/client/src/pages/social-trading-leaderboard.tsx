import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Trophy, TrendingUp, Users, Star, Award, Target } from "lucide-react";
import { motion } from "framer-motion";
import { useQuery } from "@tanstack/react-query";

interface TopTrader {
  id: number;
  name: string;
  rank: number;
  totalReturn: number;
  winRate: number;
  followers: number;
  avatar: string;
  level: "Bronze" | "Silver" | "Gold" | "Platinum" | "Diamond";
  specialties: string[];
  monthlyGain: number;
  riskScore: number;
  successfulTrades: number;
  copiers: number;
}

interface RankingCategory {
  id: string;
  name: string;
  nameAr: string;
  icon: any;
  color: string;
}

const rankingCategories: RankingCategory[] = [
  {
    id: "overall",
    name: "Overall Performance",
    nameAr: "الأداء العام",
    icon: Trophy,
    color: "text-yellow-500"
  },
  {
    id: "monthly",
    name: "Monthly Leaders",
    nameAr: "رواد الشهر",
    icon: TrendingUp,
    color: "text-green-500"
  },
  {
    id: "followers",
    name: "Most Followed",
    nameAr: "الأكثر متابعة",
    icon: Users,
    color: "text-blue-500"
  },
  {
    id: "consistent",
    name: "Most Consistent",
    nameAr: "الأكثر اتساقاً",
    icon: Target,
    color: "text-purple-500"
  }
];

const mockTopTraders: TopTrader[] = [
  {
    id: 1,
    name: "Ahmed Al-Rashid",
    rank: 1,
    totalReturn: 284.5,
    winRate: 87.3,
    followers: 2847,
    avatar: "AR",
    level: "Diamond",
    specialties: ["Forex", "Crypto", "Commodities"],
    monthlyGain: 34.2,
    riskScore: 6.8,
    successfulTrades: 156,
    copiers: 892
  },
  {
    id: 2,
    name: "Sarah Johnson",
    rank: 2,
    totalReturn: 267.8,
    winRate: 84.1,
    followers: 2156,
    avatar: "SJ",
    level: "Platinum",
    specialties: ["Stocks", "Indices"],
    monthlyGain: 28.7,
    riskScore: 5.2,
    successfulTrades: 134,
    copiers: 567
  },
  {
    id: 3,
    name: "Mohamed Hassan",
    rank: 3,
    totalReturn: 245.6,
    winRate: 82.9,
    followers: 1889,
    avatar: "MH",
    level: "Gold",
    specialties: ["Crypto", "Forex"],
    monthlyGain: 31.4,
    riskScore: 7.1,
    successfulTrades: 128,
    copiers: 445
  },
  {
    id: 4,
    name: "Elena Rodriguez",
    rank: 4,
    totalReturn: 223.4,
    winRate: 79.6,
    followers: 1567,
    avatar: "ER",
    level: "Gold",
    specialties: ["Commodities", "Indices"],
    monthlyGain: 24.8,
    riskScore: 4.9,
    successfulTrades: 112,
    copiers: 334
  },
  {
    id: 5,
    name: "Omar Al-Zahra",
    rank: 5,
    totalReturn: 198.7,
    winRate: 76.8,
    followers: 1234,
    avatar: "OZ",
    level: "Silver",
    specialties: ["Forex", "Stocks"],
    monthlyGain: 19.3,
    riskScore: 6.2,
    successfulTrades: 98,
    copiers: 289
  }
];

const getLevelColor = (level: string) => {
  switch (level) {
    case "Diamond": return "bg-gradient-to-r from-cyan-400 to-blue-500";
    case "Platinum": return "bg-gradient-to-r from-gray-400 to-gray-600";
    case "Gold": return "bg-gradient-to-r from-yellow-400 to-orange-500";
    case "Silver": return "bg-gradient-to-r from-gray-300 to-gray-400";
    default: return "bg-gradient-to-r from-amber-600 to-orange-600";
  }
};

const getRankIcon = (rank: number) => {
  switch (rank) {
    case 1: return <Trophy className="w-6 h-6 text-yellow-500" />;
    case 2: return <Award className="w-6 h-6 text-gray-400" />;
    case 3: return <Star className="w-6 h-6 text-amber-600" />;
    default: return <div className="w-6 h-6 rounded-full bg-gray-300 flex items-center justify-center text-sm font-bold">{rank}</div>;
  }
};

export default function SocialTradingLeaderboard() {
  const [selectedCategory, setSelectedCategory] = useState("overall");
  const [language, setLanguage] = useState("en");

  const { data: leaderboardData, isLoading } = useQuery({
    queryKey: ['/api/social-trading/leaderboard', selectedCategory],
    queryFn: async () => {
      // Simulate API call
      return mockTopTraders.sort((a, b) => {
        switch (selectedCategory) {
          case "monthly": return b.monthlyGain - a.monthlyGain;
          case "followers": return b.followers - a.followers;
          case "consistent": return b.winRate - a.winRate;
          default: return b.totalReturn - a.totalReturn;
        }
      });
    }
  });

  if (isLoading) {
    return <div className="p-6">Loading leaderboard...</div>;
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            Social Trading Leaderboard
          </h1>
          <p className="text-gray-600 mt-2">
            Follow top traders and copy their strategies
          </p>
        </div>
        <Button
          variant="outline"
          onClick={() => setLanguage(language === "en" ? "ar" : "en")}
        >
          {language === "en" ? "العربية" : "English"}
        </Button>
      </div>

      {/* Category Tabs */}
      <Tabs value={selectedCategory} onValueChange={setSelectedCategory}>
        <TabsList className="grid w-full grid-cols-4 mb-6">
          {rankingCategories.map((category) => (
            <TabsTrigger key={category.id} value={category.id} className="flex items-center gap-2">
              <category.icon className={`w-4 h-4 ${category.color}`} />
              <span className="hidden sm:inline">
                {language === "en" ? category.name : category.nameAr}
              </span>
            </TabsTrigger>
          ))}
        </TabsList>

        {rankingCategories.map((category) => (
          <TabsContent key={category.id} value={category.id}>
            <div className="grid gap-4">
              {/* Top 3 Podium */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                {leaderboardData?.slice(0, 3).map((trader, index) => (
                  <motion.div
                    key={trader.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <Card className={`relative overflow-hidden ${index === 0 ? 'order-2 md:order-1' : index === 1 ? 'order-1 md:order-2' : 'order-3'}`}>
                      <div className={`absolute inset-0 ${getLevelColor(trader.level)} opacity-10`} />
                      <CardHeader className="text-center pb-2">
                        <div className="flex justify-center mb-2">
                          {getRankIcon(trader.rank)}
                        </div>
                        <Avatar className="w-16 h-16 mx-auto mb-2">
                          <AvatarFallback className={`text-white ${getLevelColor(trader.level)}`}>
                            {trader.avatar}
                          </AvatarFallback>
                        </Avatar>
                        <CardTitle className="text-lg">{trader.name}</CardTitle>
                        <Badge className={getLevelColor(trader.level)}>
                          {trader.level}
                        </Badge>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        <div className="grid grid-cols-2 gap-4 text-sm">
                          <div className="text-center">
                            <p className="text-gray-600">Total Return</p>
                            <p className="font-bold text-green-600">+{trader.totalReturn}%</p>
                          </div>
                          <div className="text-center">
                            <p className="text-gray-600">Win Rate</p>
                            <p className="font-bold">{trader.winRate}%</p>
                          </div>
                          <div className="text-center">
                            <p className="text-gray-600">Followers</p>
                            <p className="font-bold">{trader.followers.toLocaleString()}</p>
                          </div>
                          <div className="text-center">
                            <p className="text-gray-600">Copiers</p>
                            <p className="font-bold">{trader.copiers}</p>
                          </div>
                        </div>
                        <div className="space-y-2">
                          <div className="flex justify-between text-sm">
                            <span>Risk Score</span>
                            <span>{trader.riskScore}/10</span>
                          </div>
                          <Progress value={trader.riskScore * 10} className="h-2" />
                        </div>
                        <div className="flex flex-wrap gap-1">
                          {trader.specialties.map((specialty) => (
                            <Badge key={specialty} variant="outline" className="text-xs">
                              {specialty}
                            </Badge>
                          ))}
                        </div>
                        <div className="flex gap-2">
                          <Button size="sm" className="flex-1">
                            Follow
                          </Button>
                          <Button size="sm" variant="outline" className="flex-1">
                            Copy
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>

              {/* Rest of the leaderboard */}
              <div className="space-y-3">
                {leaderboardData?.slice(3).map((trader, index) => (
                  <motion.div
                    key={trader.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: (index + 3) * 0.05 }}
                  >
                    <Card className="hover:shadow-lg transition-shadow">
                      <CardContent className="p-4">
                        <div className="flex items-center gap-4">
                          <div className="text-center min-w-[40px]">
                            {getRankIcon(trader.rank)}
                          </div>
                          <Avatar className="w-12 h-12">
                            <AvatarFallback className={`text-white ${getLevelColor(trader.level)}`}>
                              {trader.avatar}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex-1">
                            <div className="flex items-center gap-2">
                              <h3 className="font-semibold">{trader.name}</h3>
                              <Badge className={getLevelColor(trader.level)} variant="outline">
                                {trader.level}
                              </Badge>
                            </div>
                            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-2 text-sm">
                              <div>
                                <p className="text-gray-600">Return</p>
                                <p className="font-bold text-green-600">+{trader.totalReturn}%</p>
                              </div>
                              <div>
                                <p className="text-gray-600">Win Rate</p>
                                <p className="font-bold">{trader.winRate}%</p>
                              </div>
                              <div>
                                <p className="text-gray-600">Followers</p>
                                <p className="font-bold">{trader.followers.toLocaleString()}</p>
                              </div>
                              <div>
                                <p className="text-gray-600">Monthly</p>
                                <p className="font-bold text-blue-600">+{trader.monthlyGain}%</p>
                              </div>
                            </div>
                          </div>
                          <div className="flex gap-2">
                            <Button size="sm" variant="outline">
                              Follow
                            </Button>
                            <Button size="sm">
                              Copy
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </div>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}
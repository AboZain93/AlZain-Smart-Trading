import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { 
  TrendingUp, 
  TrendingDown, 
  AlertTriangle,
  Calendar,
  Globe,
  BarChart3,
  Activity,
  Target,
  Clock,
  DollarSign,
  Shield,
  Zap,
  RefreshCw,
  Brain,
  Newspaper,
  LineChart
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useQuery } from "@tanstack/react-query";

interface EconomicEvent {
  id: number;
  title: string;
  description: string;
  currency: string;
  importance: 'low' | 'medium' | 'high';
  actual?: number;
  forecast?: number;
  previous?: number;
  timestamp: Date;
  impact: 'bearish' | 'bullish' | 'neutral';
  affectedAssets: string[];
}

interface MarketSentiment {
  asset: string;
  sentiment: number;
  confidence: number;
  factors: string[];
  timestamp: Date;
}

interface EconomicIntelligence {
  marketRegime: 'bull' | 'bear' | 'sideways';
  riskAppetite: 'risk-on' | 'risk-off' | 'neutral';
  volatilityExpectation: 'low' | 'medium' | 'high';
  keyDrivers: string[];
  upcomingEvents: EconomicEvent[];
  marketSentiments: MarketSentiment[];
  tradingRecommendations: string[];
}

const EconomicIntelligencePage = () => {
  const [refreshKey, setRefreshKey] = useState(0);

  const { data: intelligence, isLoading } = useQuery({
    queryKey: ['/api/economic-intelligence', refreshKey],
    refetchInterval: 30000
  });

  const { data: economicEvents } = useQuery({
    queryKey: ['/api/economic-events', refreshKey],
    refetchInterval: 60000
  });

  const handleRefresh = () => {
    setRefreshKey(prev => prev + 1);
  };

  const getRegimeColor = (regime: string) => {
    switch (regime) {
      case 'bull': return 'text-green-600 dark:text-green-400';
      case 'bear': return 'text-red-600 dark:text-red-400';
      default: return 'text-yellow-600 dark:text-yellow-400';
    }
  };

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'risk-on': return 'text-green-600 dark:text-green-400';
      case 'risk-off': return 'text-red-600 dark:text-red-400';
      default: return 'text-blue-600 dark:text-blue-400';
    }
  };

  const getVolatilityColor = (volatility: string) => {
    switch (volatility) {
      case 'high': return 'text-red-600 dark:text-red-400';
      case 'medium': return 'text-yellow-600 dark:text-yellow-400';
      default: return 'text-green-600 dark:text-green-400';
    }
  };

  const getImportanceColor = (importance: string) => {
    switch (importance) {
      case 'high': return 'bg-red-500';
      case 'medium': return 'bg-yellow-500';
      default: return 'bg-green-500';
    }
  };

  const getSentimentColor = (sentiment: number) => {
    if (sentiment > 30) return 'text-green-600 dark:text-green-400';
    if (sentiment < -30) return 'text-red-600 dark:text-red-400';
    return 'text-gray-600 dark:text-gray-400';
  };

  if (isLoading) {
    return (
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-bold">الذكاء الاقتصادي المتطور</h1>
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(6)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardHeader className="pb-3">
                <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-3/4"></div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded"></div>
                  <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded w-5/6"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-emerald-600 bg-clip-text text-transparent">
            الذكاء الاقتصادي المتطور
          </h1>
          <p className="text-gray-600 dark:text-gray-400 mt-1">
            تحليل شامل للأسواق والأحداث الاقتصادية
          </p>
        </div>
        <Button 
          onClick={handleRefresh}
          variant="outline" 
          size="icon"
          className="hover:bg-blue-50 dark:hover:bg-blue-900"
        >
          <RefreshCw className="h-4 w-4" />
        </Button>
      </div>

      {/* Market Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <Card className="border-l-4 border-l-blue-500">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <BarChart3 className="h-5 w-5 text-blue-500" />
                نظام السوق
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <Badge variant="outline" className={`${getRegimeColor(intelligence?.marketRegime || 'sideways')} border-current`}>
                  {intelligence?.marketRegime === 'bull' ? 'صاعد' :
                   intelligence?.marketRegime === 'bear' ? 'هابط' : 'جانبي'}
                </Badge>
                {intelligence?.marketRegime === 'bull' ? 
                  <TrendingUp className="h-6 w-6 text-green-500" /> :
                  intelligence?.marketRegime === 'bear' ?
                  <TrendingDown className="h-6 w-6 text-red-500" /> :
                  <Activity className="h-6 w-6 text-yellow-500" />
                }
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
        >
          <Card className="border-l-4 border-l-emerald-500">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <Target className="h-5 w-5 text-emerald-500" />
                شهية المخاطر
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <Badge variant="outline" className={`${getRiskColor(intelligence?.riskAppetite || 'neutral')} border-current`}>
                  {intelligence?.riskAppetite === 'risk-on' ? 'طلب مخاطر' :
                   intelligence?.riskAppetite === 'risk-off' ? 'تجنب مخاطر' : 'محايد'}
                </Badge>
                <Shield className="h-6 w-6 text-emerald-500" />
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <Card className="border-l-4 border-l-orange-500">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <Zap className="h-5 w-5 text-orange-500" />
                توقع التقلبات
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <Badge variant="outline" className={`${getVolatilityColor(intelligence?.volatilityExpectation || 'low')} border-current`}>
                  {intelligence?.volatilityExpectation === 'high' ? 'عالية' :
                   intelligence?.volatilityExpectation === 'medium' ? 'متوسطة' : 'منخفضة'}
                </Badge>
                <AlertTriangle className={`h-6 w-6 ${
                  intelligence?.volatilityExpectation === 'high' ? 'text-red-500' :
                  intelligence?.volatilityExpectation === 'medium' ? 'text-yellow-500' : 'text-green-500'
                }`} />
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Main Content Tabs */}
      <Tabs defaultValue="drivers" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4 lg:w-auto lg:grid-cols-4">
          <TabsTrigger value="drivers" className="flex items-center gap-2">
            <Brain className="h-4 w-4" />
            المحركات الرئيسية
          </TabsTrigger>
          <TabsTrigger value="events" className="flex items-center gap-2">
            <Calendar className="h-4 w-4" />
            الأحداث الاقتصادية
          </TabsTrigger>
          <TabsTrigger value="sentiment" className="flex items-center gap-2">
            <LineChart className="h-4 w-4" />
            معنويات السوق
          </TabsTrigger>
          <TabsTrigger value="recommendations" className="flex items-center gap-2">
            <Target className="h-4 w-4" />
            التوصيات
          </TabsTrigger>
        </TabsList>

        <TabsContent value="drivers" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Brain className="h-5 w-5 text-purple-500" />
                المحركات الرئيسية للسوق
              </CardTitle>
              <CardDescription>
                العوامل المؤثرة على اتجاهات السوق الحالية
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {intelligence?.keyDrivers?.map((driver, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="flex items-center gap-3 p-3 rounded-lg bg-gray-50 dark:bg-gray-800"
                  >
                    <div className="w-2 h-2 rounded-full bg-purple-500"></div>
                    <span className="text-sm">{driver}</span>
                  </motion.div>
                )) || []}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="events" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5 text-blue-500" />
                الأحداث الاقتصادية القادمة
              </CardTitle>
              <CardDescription>
                الأحداث المؤثرة في الـ 48 ساعة القادمة
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {intelligence?.upcomingEvents?.map((event, index) => (
                  <motion.div
                    key={event.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="border rounded-lg p-4 hover:shadow-md transition-shadow"
                  >
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <Badge className={getImportanceColor(event.importance)}>
                          {event.importance === 'high' ? 'عالي' :
                           event.importance === 'medium' ? 'متوسط' : 'منخفض'}
                        </Badge>
                        <Badge variant="outline">{event.currency}</Badge>
                      </div>
                      <div className="flex items-center gap-1 text-sm text-gray-500">
                        <Clock className="h-4 w-4" />
                        {new Date(event.timestamp).toLocaleDateString('ar')}
                      </div>
                    </div>
                    <h4 className="font-semibold mb-1">{event.title}</h4>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                      {event.description}
                    </p>
                    <div className="flex items-center gap-4 text-sm">
                      {event.forecast && (
                        <div>
                          <span className="text-gray-500">المتوقع: </span>
                          <span className="font-medium">{event.forecast}</span>
                        </div>
                      )}
                      {event.previous && (
                        <div>
                          <span className="text-gray-500">السابق: </span>
                          <span className="font-medium">{event.previous}</span>
                        </div>
                      )}
                    </div>
                  </motion.div>
                )) || []}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="sentiment" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {intelligence?.marketSentiments?.map((sentiment, index) => (
              <motion.div
                key={sentiment.asset}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg flex items-center justify-between">
                      <span>{sentiment.asset}</span>
                      <Badge className={getSentimentColor(sentiment.sentiment)}>
                        {sentiment.sentiment > 0 ? '+' : ''}{sentiment.sentiment}%
                      </Badge>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span>المعنويات</span>
                          <span>{sentiment.sentiment > 0 ? 'إيجابية' : sentiment.sentiment < 0 ? 'سلبية' : 'محايدة'}</span>
                        </div>
                        <Progress 
                          value={Math.abs(sentiment.sentiment)} 
                          className="h-2"
                        />
                      </div>
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span>الثقة</span>
                          <span>{sentiment.confidence}%</span>
                        </div>
                        <Progress 
                          value={sentiment.confidence} 
                          className="h-2"
                        />
                      </div>
                      <div>
                        <h4 className="text-sm font-medium mb-2">العوامل المؤثرة:</h4>
                        <div className="space-y-1">
                          {sentiment.factors.map((factor, i) => (
                            <div key={i} className="text-xs text-gray-600 dark:text-gray-400 flex items-center gap-2">
                              <div className="w-1 h-1 rounded-full bg-blue-500"></div>
                              {factor}
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )) || []}
          </div>
        </TabsContent>

        <TabsContent value="recommendations" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-5 w-5 text-green-500" />
                التوصيات التداولية المبنية على التحليل الاقتصادي
              </CardTitle>
              <CardDescription>
                توصيات مستندة إلى التحليل الاقتصادي الشامل
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {intelligence?.tradingRecommendations?.map((recommendation, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="flex items-center gap-3 p-4 rounded-lg bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800"
                  >
                    <DollarSign className="h-5 w-5 text-green-600" />
                    <span className="text-sm">{recommendation}</span>
                  </motion.div>
                )) || []}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default EconomicIntelligencePage;
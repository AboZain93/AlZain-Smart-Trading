import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { useLanguageContext } from '../components/language-provider';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Badge } from '../components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { useToast } from '../hooks/use-toast';
import { apiRequest, queryClient } from '../lib/queryClient';
import { 
  Shield, 
  Users, 
  Key, 
  Plus, 
  Edit, 
  Trash2, 
  Activity,
  CheckCircle,
  XCircle,
  Calendar,
  Settings
} from 'lucide-react';

interface User {
  id: number;
  username: string;
  email: string;
  role: 'user' | 'admin';
  createdAt: string;
  isActive: boolean;
}

interface License {
  id: number;
  licenseKey: string;
  userId: number;
  maxTrades: number;
  tradesUsed: number;
  isActive: boolean;
  expiresAt: string;
  deviceFingerprint: string;
  createdAt: string;
}

export default function Admin() {
  const context = useLanguageContext();
  const language = context?.language || 'ar';
  const { toast } = useToast();
  const [newUser, setNewUser] = useState({ username: '', email: '', role: 'user' });
  const [newLicense, setNewLicense] = useState({ maxTrades: 100, duration: 30 });

  // Fetch users
  const { data: users, isLoading: usersLoading } = useQuery<User[]>({
    queryKey: ['/api/admin/users'],
    refetchInterval: 30000,
  });

  // Fetch licenses
  const { data: licenses, isLoading: licensesLoading } = useQuery<License[]>({
    queryKey: ['/api/admin/licenses'],
    refetchInterval: 30000,
  });

  // Create user mutation
  const createUserMutation = useMutation({
    mutationFn: (userData: { username: string; email: string; role: string }) => 
      apiRequest('POST', '/api/admin/users', userData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/users'] });
      setNewUser({ username: '', email: '', role: 'user' });
      toast({
        title: language === 'ar' ? 'تم إنشاء المستخدم' : 'User Created',
        description: language === 'ar' ? 'تم إنشاء المستخدم بنجاح' : 'User created successfully',
      });
    },
    onError: () => {
      toast({
        title: language === 'ar' ? 'خطأ' : 'Error',
        description: language === 'ar' ? 'فشل في إنشاء المستخدم' : 'Failed to create user',
        variant: 'destructive',
      });
    },
  });

  // Create license mutation
  const createLicenseMutation = useMutation({
    mutationFn: (licenseData: { maxTrades: number; duration: number }) => 
      apiRequest('POST', '/api/admin/licenses', licenseData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/licenses'] });
      setNewLicense({ maxTrades: 100, duration: 30 });
      toast({
        title: language === 'ar' ? 'تم إنشاء الترخيص' : 'License Created',
        description: language === 'ar' ? 'تم إنشاء الترخيص بنجاح' : 'License created successfully',
      });
    },
    onError: () => {
      toast({
        title: language === 'ar' ? 'خطأ' : 'Error',
        description: language === 'ar' ? 'فشل في إنشاء الترخيص' : 'Failed to create license',
        variant: 'destructive',
      });
    },
  });

  // Toggle user status mutation
  const toggleUserStatusMutation = useMutation({
    mutationFn: (userId: number) => 
      apiRequest('PATCH', `/api/admin/users/${userId}/toggle-status`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/users'] });
      toast({
        title: language === 'ar' ? 'تم التحديث' : 'Updated',
        description: language === 'ar' ? 'تم تحديث حالة المستخدم' : 'User status updated',
      });
    },
  });

  // Toggle license status mutation
  const toggleLicenseStatusMutation = useMutation({
    mutationFn: (licenseId: number) => 
      apiRequest('PATCH', `/api/admin/licenses/${licenseId}/toggle-status`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/licenses'] });
      toast({
        title: language === 'ar' ? 'تم التحديث' : 'Updated',
        description: language === 'ar' ? 'تم تحديث حالة الترخيص' : 'License status updated',
      });
    },
  });

  const handleCreateUser = () => {
    if (newUser.username && newUser.email) {
      createUserMutation.mutate(newUser);
    }
  };

  const handleCreateLicense = () => {
    createLicenseMutation.mutate(newLicense);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString(language === 'ar' ? 'ar-SA' : 'en-US');
  };

  return (
    <div className="container mx-auto p-6 max-w-6xl">
      <div className="flex items-center gap-3 mb-6">
        <Shield className="h-8 w-8 text-primary" />
        <h1 className="text-3xl font-bold">
          {language === 'ar' ? 'لوحة الإدارة' : 'Admin Dashboard'}
        </h1>
      </div>

      <Tabs defaultValue="users" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="users">
            <Users className="h-4 w-4 mr-2" />
            {language === 'ar' ? 'المستخدمين' : 'Users'}
          </TabsTrigger>
          <TabsTrigger value="licenses">
            <Key className="h-4 w-4 mr-2" />
            {language === 'ar' ? 'التراخيص' : 'Licenses'}
          </TabsTrigger>
          <TabsTrigger value="settings">
            <Settings className="h-4 w-4 mr-2" />
            {language === 'ar' ? 'الإعدادات' : 'Settings'}
          </TabsTrigger>
        </TabsList>

        <TabsContent value="users" className="space-y-6">
          {/* Create User Card */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Plus className="h-5 w-5" />
                {language === 'ar' ? 'إنشاء مستخدم جديد' : 'Create New User'}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div>
                  <Label htmlFor="username">
                    {language === 'ar' ? 'اسم المستخدم' : 'Username'}
                  </Label>
                  <Input
                    id="username"
                    value={newUser.username}
                    onChange={(e) => setNewUser(prev => ({ ...prev, username: e.target.value }))}
                    placeholder={language === 'ar' ? 'أدخل اسم المستخدم' : 'Enter username'}
                  />
                </div>
                <div>
                  <Label htmlFor="email">
                    {language === 'ar' ? 'البريد الإلكتروني' : 'Email'}
                  </Label>
                  <Input
                    id="email"
                    type="email"
                    value={newUser.email}
                    onChange={(e) => setNewUser(prev => ({ ...prev, email: e.target.value }))}
                    placeholder={language === 'ar' ? 'أدخل البريد الإلكتروني' : 'Enter email'}
                  />
                </div>
                <div>
                  <Label htmlFor="role">
                    {language === 'ar' ? 'الدور' : 'Role'}
                  </Label>
                  <Select value={newUser.role} onValueChange={(value) => setNewUser(prev => ({ ...prev, role: value }))}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="user">
                        {language === 'ar' ? 'مستخدم' : 'User'}
                      </SelectItem>
                      <SelectItem value="admin">
                        {language === 'ar' ? 'مدير' : 'Admin'}
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-end">
                  <Button 
                    onClick={handleCreateUser}
                    disabled={createUserMutation.isPending}
                    className="w-full"
                  >
                    {createUserMutation.isPending ? (
                      <Activity className="h-4 w-4 mr-2 animate-spin" />
                    ) : (
                      <Plus className="h-4 w-4 mr-2" />
                    )}
                    {language === 'ar' ? 'إنشاء' : 'Create'}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Users List */}
          <Card>
            <CardHeader>
              <CardTitle>
                {language === 'ar' ? 'قائمة المستخدمين' : 'Users List'}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {usersLoading ? (
                <div className="text-center py-8">
                  <Activity className="h-8 w-8 animate-spin mx-auto mb-4" />
                  <p>{language === 'ar' ? 'جاري التحميل...' : 'Loading...'}</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {users?.map((user) => (
                    <div key={user.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center gap-4">
                        <div className="flex-1">
                          <div className="font-medium">{user.username}</div>
                          <div className="text-sm text-muted-foreground">{user.email}</div>
                          <div className="text-xs text-muted-foreground">
                            {language === 'ar' ? 'تاريخ الإنشاء: ' : 'Created: '}
                            {formatDate(user.createdAt)}
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <Badge variant={user.role === 'admin' ? 'default' : 'secondary'}>
                            {user.role === 'admin' ? 
                              (language === 'ar' ? 'مدير' : 'Admin') : 
                              (language === 'ar' ? 'مستخدم' : 'User')
                            }
                          </Badge>
                          <Badge variant={user.isActive ? 'default' : 'destructive'}>
                            {user.isActive ? 
                              (language === 'ar' ? 'نشط' : 'Active') : 
                              (language === 'ar' ? 'معطل' : 'Inactive')
                            }
                          </Badge>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => toggleUserStatusMutation.mutate(user.id)}
                          disabled={toggleUserStatusMutation.isPending}
                        >
                          {user.isActive ? (
                            <XCircle className="h-4 w-4" />
                          ) : (
                            <CheckCircle className="h-4 w-4" />
                          )}
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="licenses" className="space-y-6">
          {/* Create License Card */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Plus className="h-5 w-5" />
                {language === 'ar' ? 'إنشاء ترخيص جديد' : 'Create New License'}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="maxTrades">
                    {language === 'ar' ? 'الحد الأقصى للتداولات' : 'Max Trades'}
                  </Label>
                  <Input
                    id="maxTrades"
                    type="number"
                    value={newLicense.maxTrades}
                    onChange={(e) => setNewLicense(prev => ({ ...prev, maxTrades: parseInt(e.target.value) }))}
                    placeholder="100"
                  />
                </div>
                <div>
                  <Label htmlFor="duration">
                    {language === 'ar' ? 'مدة الترخيص (أيام)' : 'License Duration (days)'}
                  </Label>
                  <Input
                    id="duration"
                    type="number"
                    value={newLicense.duration}
                    onChange={(e) => setNewLicense(prev => ({ ...prev, duration: parseInt(e.target.value) }))}
                    placeholder="30"
                  />
                </div>
                <div className="flex items-end">
                  <Button 
                    onClick={handleCreateLicense}
                    disabled={createLicenseMutation.isPending}
                    className="w-full"
                  >
                    {createLicenseMutation.isPending ? (
                      <Activity className="h-4 w-4 mr-2 animate-spin" />
                    ) : (
                      <Plus className="h-4 w-4 mr-2" />
                    )}
                    {language === 'ar' ? 'إنشاء' : 'Create'}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Licenses List */}
          <Card>
            <CardHeader>
              <CardTitle>
                {language === 'ar' ? 'قائمة التراخيص' : 'Licenses List'}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {licensesLoading ? (
                <div className="text-center py-8">
                  <Activity className="h-8 w-8 animate-spin mx-auto mb-4" />
                  <p>{language === 'ar' ? 'جاري التحميل...' : 'Loading...'}</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {licenses?.map((license) => (
                    <div key={license.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center gap-4">
                        <div className="flex-1">
                          <div className="font-medium font-mono text-sm">{license.licenseKey}</div>
                          <div className="text-sm text-muted-foreground">
                            {language === 'ar' ? 'التداولات: ' : 'Trades: '}
                            {license.tradesUsed} / {license.maxTrades}
                          </div>
                          <div className="text-xs text-muted-foreground">
                            {language === 'ar' ? 'ينتهي في: ' : 'Expires: '}
                            {formatDate(license.expiresAt)}
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <Badge variant={license.isActive ? 'default' : 'destructive'}>
                            {license.isActive ? 
                              (language === 'ar' ? 'نشط' : 'Active') : 
                              (language === 'ar' ? 'معطل' : 'Inactive')
                            }
                          </Badge>
                          <Badge variant={license.tradesUsed >= license.maxTrades ? 'destructive' : 'default'}>
                            {license.tradesUsed >= license.maxTrades ? 
                              (language === 'ar' ? 'مستنفد' : 'Exhausted') : 
                              (language === 'ar' ? 'متاح' : 'Available')
                            }
                          </Badge>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => toggleLicenseStatusMutation.mutate(license.id)}
                          disabled={toggleLicenseStatusMutation.isPending}
                        >
                          {license.isActive ? (
                            <XCircle className="h-4 w-4" />
                          ) : (
                            <CheckCircle className="h-4 w-4" />
                          )}
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="settings">
          <Card>
            <CardHeader>
              <CardTitle>
                {language === 'ar' ? 'إعدادات النظام' : 'System Settings'}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8">
                <Settings className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                <p className="text-muted-foreground">
                  {language === 'ar' ? 'إعدادات النظام ستكون متاحة قريباً' : 'System settings will be available soon'}
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
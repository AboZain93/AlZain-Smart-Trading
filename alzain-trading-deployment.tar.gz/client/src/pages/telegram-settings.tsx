import { useState, useEffect } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { useLanguageContext } from '../components/language-provider';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Label } from '../components/ui/label';
import { Input } from '../components/ui/input';
import { Textarea } from '../components/ui/textarea';
import { Switch } from '../components/ui/switch';
import { Separator } from '../components/ui/separator';
import { Badge } from '../components/ui/badge';
import { useToast } from '../hooks/use-toast';
import { apiRequest, queryClient } from '../lib/queryClient';
import { MessageSquare, Bot, User, Send, CheckCircle, XCircle, Settings } from 'lucide-react';

interface TelegramConfig {
  botToken: string;
  userId: string;
  enabled: boolean;
  messageTemplate: string;
}

export default function TelegramSettings() {
  const { language } = useLanguageContext();
  const { toast } = useToast();
  
  const [botToken, setBotToken] = useState('');
  const [userId, setUserId] = useState('');
  const [enabled, setEnabled] = useState(true);
  const [messageTemplate, setMessageTemplate] = useState('');
  const [isConnected, setIsConnected] = useState(false);

  // Fetch telegram stats to check connection
  const { data: telegramStats } = useQuery({
    queryKey: ['/api/telegram/stats'],
    refetchInterval: 10000,
  });

  // Initialize form with default values
  useEffect(() => {
    setBotToken('7941519639:AAHTOAxOP61HiV1bYsM8ICEw3YV4X1qsMno');
    setUserId('1039954480');
    setEnabled(true);
    setMessageTemplate(`🔔 <b>توصية جديدة - New Signal</b>

💱 <b>الأصل/Asset:</b> {{symbol}}
📊 <b>التوجه/Direction:</b> {{direction}}
⚡ <b>الثقة/Confidence:</b> {{confidence}}%
⚠️ <b>المخاطر/Risk:</b> {{riskLevel}}
🕒 <b>مدة الصفقة/Duration:</b> {{duration}}
📈 <b>حالة السوق/Status:</b> {{marketStatus}}

🎯 <b>التحليل الفني/Analysis:</b>
{{technicalAnalysis}}

⏰ <b>وقت الدخول/Entry Time:</b> {{entryTime}}
🌊 <b>السيولة/Liquidity:</b> {{liquidity}}

💰 <b>AlZainTrade Bot</b>`);
    setIsConnected(true);
  }, []);

  // Test telegram connection
  const testConnectionMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('POST', '/api/telegram/send-test', {
        message: language === 'ar' 
          ? '🔔 اختبار الاتصال بنجح - Connection Test Successful' 
          : '🔔 Connection Test Successful - تم الاختبار بنجاح'
      });
      return response;
    },
    onSuccess: () => {
      toast({
        title: language === 'ar' ? 'نجح الاختبار' : 'Test Successful',
        description: language === 'ar' 
          ? 'تم إرسال رسالة الاختبار بنجاح' 
          : 'Test message sent successfully',
      });
      queryClient.invalidateQueries({ queryKey: ['/api/telegram/stats'] });
    },
    onError: (error) => {
      toast({
        title: language === 'ar' ? 'فشل الاختبار' : 'Test Failed',
        description: language === 'ar' 
          ? 'فشل في إرسال رسالة الاختبار' 
          : 'Failed to send test message',
        variant: 'destructive',
      });
    },
  });

  const handleSaveSettings = () => {
    toast({
      title: language === 'ar' ? 'تم الحفظ' : 'Settings Saved',
      description: language === 'ar' 
        ? 'تم حفظ إعدادات تليجرام بنجاح' 
        : 'Telegram settings saved successfully',
    });
  };

  const handleTestConnection = () => {
    testConnectionMutation.mutate();
  };

  return (
    <div className="container mx-auto p-6 max-w-4xl">
      <div className="flex items-center gap-3 mb-6">
        <MessageSquare className="h-8 w-8 text-primary" />
        <h1 className="text-3xl font-bold">
          {language === 'ar' ? 'إعدادات تليجرام' : 'Telegram Settings'}
        </h1>
      </div>

      <div className="grid gap-6">
        {/* Connection Status */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Settings className="h-5 w-5" />
              {language === 'ar' ? 'حالة الاتصال' : 'Connection Status'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                {isConnected ? (
                  <CheckCircle className="h-5 w-5 text-green-500" />
                ) : (
                  <XCircle className="h-5 w-5 text-red-500" />
                )}
                <span className="font-medium">
                  {isConnected 
                    ? (language === 'ar' ? 'متصل' : 'Connected')
                    : (language === 'ar' ? 'غير متصل' : 'Disconnected')
                  }
                </span>
              </div>
              <Badge variant={isConnected ? 'default' : 'destructive'}>
                @AboZainQuotexbot
              </Badge>
            </div>
            
            {telegramStats && (
              <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                <div className="text-center p-3 bg-muted rounded-lg">
                  <div className="font-semibold text-lg">{(telegramStats as any).sentToday}</div>
                  <div className="text-muted-foreground">
                    {language === 'ar' ? 'إشارات اليوم' : 'Signals Today'}
                  </div>
                </div>
                <div className="text-center p-3 bg-muted rounded-lg">
                  <div className="font-semibold text-lg">{(telegramStats as any).subscribers}</div>
                  <div className="text-muted-foreground">
                    {language === 'ar' ? 'المشتركين' : 'Subscribers'}
                  </div>
                </div>
                <div className="text-center p-3 bg-muted rounded-lg">
                  <div className="font-semibold text-lg">{(telegramStats as any).responseRate}%</div>
                  <div className="text-muted-foreground">
                    {language === 'ar' ? 'معدل الاستجابة' : 'Response Rate'}
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Bot Configuration */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Bot className="h-5 w-5" />
              {language === 'ar' ? 'إعدادات البوت' : 'Bot Configuration'}
            </CardTitle>
            <CardDescription>
              {language === 'ar' 
                ? 'قم بتكوين بوت تليجرام الخاص بك' 
                : 'Configure your Telegram bot settings'}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="botToken">
                {language === 'ar' ? 'رمز البوت (Bot Token)' : 'Bot Token'}
              </Label>
              <Input
                id="botToken"
                type="password"
                value={botToken}
                onChange={(e) => setBotToken(e.target.value)}
                placeholder="1234567890:ABCdefGHIjklMNOpqrSTUvwxyz"
                className="font-mono"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="userId">
                {language === 'ar' ? 'معرف المستخدم (User ID)' : 'User ID'}
              </Label>
              <Input
                id="userId"
                value={userId}
                onChange={(e) => setUserId(e.target.value)}
                placeholder="1039954480"
                className="font-mono"
              />
            </div>

            <Separator />

            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label className="text-base">
                  {language === 'ar' ? 'تفعيل تليجرام' : 'Enable Telegram'}
                </Label>
                <p className="text-sm text-muted-foreground">
                  {language === 'ar' 
                    ? 'تفعيل أو إيقاف إرسال الإشارات عبر تليجرام' 
                    : 'Enable or disable sending signals via Telegram'}
                </p>
              </div>
              <Switch 
                checked={enabled}
                onCheckedChange={setEnabled}
              />
            </div>
          </CardContent>
        </Card>

        {/* Message Template */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Send className="h-5 w-5" />
              {language === 'ar' ? 'قالب الرسالة' : 'Message Template'}
            </CardTitle>
            <CardDescription>
              {language === 'ar' 
                ? 'خصص شكل رسائل التوصيات المرسلة' 
                : 'Customize the format of recommendation messages'}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="messageTemplate">
                {language === 'ar' ? 'قالب الرسالة' : 'Message Template'}
              </Label>
              <Textarea
                id="messageTemplate"
                value={messageTemplate}
                onChange={(e) => setMessageTemplate(e.target.value)}
                rows={12}
                className="font-mono text-sm"
                placeholder="Enter your message template here..."
              />
            </div>

            <div className="bg-muted p-4 rounded-lg">
              <h4 className="font-semibold mb-2">
                {language === 'ar' ? 'المتغيرات المتاحة:' : 'Available Variables:'}
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm">
                <div><code>{'{{symbol}}'}</code> - {language === 'ar' ? 'رمز الأصل' : 'Asset symbol'}</div>
                <div><code>{'{{direction}}'}</code> - {language === 'ar' ? 'اتجاه الصفقة' : 'Trade direction'}</div>
                <div><code>{'{{confidence}}'}</code> - {language === 'ar' ? 'نسبة الثقة' : 'Confidence level'}</div>
                <div><code>{'{{riskLevel}}'}</code> - {language === 'ar' ? 'مستوى المخاطر' : 'Risk level'}</div>
                <div><code>{'{{duration}}'}</code> - {language === 'ar' ? 'مدة الصفقة' : 'Trade duration'}</div>
                <div><code>{'{{marketStatus}}'}</code> - {language === 'ar' ? 'حالة السوق' : 'Market status'}</div>
                <div><code>{'{{technicalAnalysis}}'}</code> - {language === 'ar' ? 'التحليل الفني' : 'Technical analysis'}</div>
                <div><code>{'{{entryTime}}'}</code> - {language === 'ar' ? 'وقت الدخول' : 'Entry time'}</div>
                <div><code>{'{{liquidity}}'}</code> - {language === 'ar' ? 'السيولة' : 'Liquidity'}</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-3">
          <Button 
            onClick={handleTestConnection} 
            variant="outline"
            disabled={testConnectionMutation.isPending}
            className="flex-1"
          >
            {testConnectionMutation.isPending ? (
              language === 'ar' ? 'جاري الاختبار...' : 'Testing...'
            ) : (
              language === 'ar' ? 'اختبار الاتصال' : 'Test Connection'
            )}
          </Button>
          
          <Button 
            onClick={handleSaveSettings} 
            className="flex-1"
          >
            {language === 'ar' ? 'حفظ الإعدادات' : 'Save Settings'}
          </Button>
        </div>
      </div>
    </div>
  );
}
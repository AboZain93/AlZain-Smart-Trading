import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { CheckCircle, XCircle, AlertCircle, Clock, MessageCircle, TrendingUp, AlertTriangle } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { ar } from 'date-fns/locale';
import { LoadingSpinner, SkeletonCard } from '@/components/LoadingSpinner';

interface TelegramFeedback {
  id: number;
  recommendationId: number | null;
  messageId: string;
  chatId: string;
  userId: string | null;
  feedbackType: string;
  confidence: number | null;
  assetSymbol: string;
  direction: string;
  actualResult: string | null;
  responseTime: number | null;
  createdAt: string;
}

export function FeedbackAnalytics() {
  const [selectedAsset, setSelectedAsset] = useState<string>('all');
  const [limit, setLimit] = useState<number>(50);

  const { data: feedbackData, isLoading: feedbackLoading, refetch, error: feedbackError } = useQuery({
    queryKey: ['/api/ml/feedback', { asset: selectedAsset === 'all' ? undefined : selectedAsset, limit }],
    refetchInterval: 60000,
    retry: 2,
    staleTime: 30000,
    enabled: true, // Always enabled for better UX
  });

  const { data: performanceData, error: performanceError } = useQuery({
    queryKey: ['/api/ml/performance'],
    refetchInterval: 60000,
    retry: 2,
    staleTime: 30000,
  });

  const feedback: TelegramFeedback[] = (feedbackData as any)?.feedback || [];
  const allPerformance = (performanceData as any)?.performance || [];

  // Get unique assets for filter
  const uniqueAssets = Array.from(new Set(feedback.map(f => f.assetSymbol)));

  const getFeedbackIcon = (type: string) => {
    switch (type) {
      case 'success': return <CheckCircle className="h-4 w-4 text-green-600" />;
      case 'partial': return <AlertCircle className="h-4 w-4 text-yellow-600" />;
      case 'failure': return <XCircle className="h-4 w-4 text-red-600" />;
      default: return <MessageCircle className="h-4 w-4 text-gray-600" />;
    }
  };

  const getFeedbackColor = (type: string) => {
    switch (type) {
      case 'success': return 'bg-green-100 text-green-800 border-green-200';
      case 'partial': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'failure': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getFeedbackText = (type: string) => {
    switch (type) {
      case 'success': return 'نجحت';
      case 'partial': return 'نجحت جزئياً';
      case 'failure': return 'فشلت';
      default: return type;
    }
  };

  const getResponseTimeColor = (time: number | null) => {
    if (!time) return 'text-gray-500';
    if (time <= 30) return 'text-green-600';
    if (time <= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  // Calculate statistics
  const totalFeedback = feedback.length;
  const successCount = feedback.filter(f => f.feedbackType === 'success').length;
  const partialCount = feedback.filter(f => f.feedbackType === 'partial').length;
  const failureCount = feedback.filter(f => f.feedbackType === 'failure').length;
  const successRate = totalFeedback > 0 ? ((successCount + partialCount * 0.5) / totalFeedback) * 100 : 0;

  const avgResponseTime = feedback
    .filter(f => f.responseTime !== null)
    .reduce((sum, f) => sum + (f.responseTime || 0), 0) / 
    feedback.filter(f => f.responseTime !== null).length || 0;

  // Handle errors
  if (feedbackError || performanceError) {
    return (
      <Card className="w-full">
        <CardContent className="p-6">
          <div className="flex flex-col items-center gap-4 text-center">
            <AlertTriangle className="h-12 w-12 text-amber-500" />
            <div>
              <h3 className="text-lg font-semibold mb-2">خطأ في تحميل التفاعلات</h3>
              <p className="text-muted-foreground mb-4">
                لا يمكن تحميل بيانات التفاعلات في الوقت الحالي
              </p>
              <Button onClick={() => refetch()} variant="outline">
                إعادة المحاولة
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (feedbackLoading) {
    return (
      <div className="space-y-6">
        <LoadingSpinner variant="trading" text="تحميل تفاعلات المستخدمين..." />
        <div className="grid gap-4 md:grid-cols-4">
          {[...Array(4)].map((_, i) => (
            <SkeletonCard key={i} />
          ))}
        </div>
        <div className="space-y-4">
          <SkeletonCard className="h-32" />
          <SkeletonCard className="h-96" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Statistics Cards */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">إجمالي التفاعلات</CardTitle>
            <MessageCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalFeedback}</div>
            <p className="text-xs text-muted-foreground">
              ردود المستخدمين على التوصيات
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">معدل النجاح</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {successRate.toFixed(1)}%
            </div>
            <p className="text-xs text-muted-foreground">
              {successCount} نجحت، {partialCount} جزئية، {failureCount} فشلت
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">متوسط وقت الاستجابة</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${getResponseTimeColor(avgResponseTime)}`}>
              {avgResponseTime.toFixed(0)} دقيقة
            </div>
            <p className="text-xs text-muted-foreground">
              سرعة استجابة المستخدمين
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">الأصول المتتبعة</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{uniqueAssets.length}</div>
            <p className="text-xs text-muted-foreground">
              أصول مختلفة مع تفاعلات
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Filters and Controls */}
      <Card>
        <CardHeader>
          <CardTitle>فلترة التفاعلات</CardTitle>
          <CardDescription>
            اختر الأصل المالي وعدد التفاعلات المراد عرضها
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4 items-center">
            <div className="flex items-center gap-2">
              <label className="text-sm font-medium">الأصل:</label>
              <Select value={selectedAsset} onValueChange={setSelectedAsset}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="اختر الأصل" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">جميع الأصول</SelectItem>
                  {uniqueAssets.map(asset => (
                    <SelectItem key={asset} value={asset}>{asset}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center gap-2">
              <label className="text-sm font-medium">العدد:</label>
              <Select value={limit.toString()} onValueChange={(value) => setLimit(parseInt(value))}>
                <SelectTrigger className="w-24">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="25">25</SelectItem>
                  <SelectItem value="50">50</SelectItem>
                  <SelectItem value="100">100</SelectItem>
                  <SelectItem value="200">200</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <Button onClick={() => refetch()} variant="outline">
              تحديث
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Feedback List */}
      <Card>
        <CardHeader>
          <CardTitle>تفاعلات المستخدمين</CardTitle>
          <CardDescription>
            قائمة التفاعلات مع التوصيات مرتبة حسب الوقت
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {feedback.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                لا توجد تفاعلات للعرض
              </div>
            ) : (
              feedback.map((item) => (
                <div key={item.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 dark:hover:bg-gray-900/50">
                  <div className="flex items-center gap-4">
                    {getFeedbackIcon(item.feedbackType)}
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-medium">{item.assetSymbol}</span>
                        <Badge variant="outline" className={item.direction === 'BUY' ? 'text-green-600' : 'text-red-600'}>
                          {item.direction}
                        </Badge>
                        {item.confidence && (
                          <Badge variant="secondary">
                            {item.confidence}%
                          </Badge>
                        )}
                      </div>
                      <div className="text-sm text-muted-foreground">
                        {formatDistanceToNow(new Date(item.createdAt), { 
                          addSuffix: true, 
                          locale: ar 
                        })}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    {item.responseTime && (
                      <div className="text-sm text-center">
                        <div className={`font-medium ${getResponseTimeColor(item.responseTime)}`}>
                          {item.responseTime} دقيقة
                        </div>
                        <div className="text-xs text-muted-foreground">
                          وقت الاستجابة
                        </div>
                      </div>
                    )}

                    <Badge className={getFeedbackColor(item.feedbackType)}>
                      {getFeedbackText(item.feedbackType)}
                    </Badge>
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
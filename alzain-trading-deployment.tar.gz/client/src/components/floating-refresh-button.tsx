import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { RefreshCw, Loader2 } from 'lucide-react';
import { useLanguageContext } from '@/components/language-provider';
import { useQueryClient } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';

interface FloatingRefreshButtonProps {
  onRefresh?: () => Promise<void> | void;
  className?: string;
  position?: 'bottom-right' | 'bottom-left' | 'top-right' | 'top-left';
}

export function FloatingRefreshButton({ 
  onRefresh,
  className,
  position = 'bottom-right'
}: FloatingRefreshButtonProps) {
  const { language } = useLanguageContext();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [isHovered, setIsHovered] = useState(false);

  const positionClasses = {
    'bottom-right': 'bottom-6 right-6',
    'bottom-left': 'bottom-6 left-6',
    'top-right': 'top-6 right-6',
    'top-left': 'top-6 left-6',
  };

  const handleRefresh = async () => {
    if (isRefreshing) return;
    
    setIsRefreshing(true);
    
    try {
      // Invalidate all queries first
      await queryClient.invalidateQueries();
      
      // Execute custom refresh function if provided
      if (onRefresh) {
        await onRefresh();
      }

      // Show success toast
      toast({
        title: language === 'ar' ? '✅ تم التحديث' : '✅ Refreshed',
        description: language === 'ar' ? 'تم تحديث جميع البيانات بنجاح' : 'All data refreshed successfully',
        className: 'bg-emerald-50 border-emerald-200 text-emerald-800 dark:bg-emerald-900 dark:border-emerald-700 dark:text-emerald-100',
      });
      
    } catch (error) {
      console.error('Refresh failed:', error);
      toast({
        title: language === 'ar' ? '❌ خطأ في التحديث' : '❌ Refresh Failed',
        description: language === 'ar' ? 'فشل في تحديث البيانات' : 'Failed to refresh data',
        variant: 'destructive',
      });
    } finally {
      setTimeout(() => setIsRefreshing(false), 800);
    }
  };

  return (
    <div
      className={cn(
        "fixed z-50 transition-all duration-300 ease-out",
        positionClasses[position],
        className
      )}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <Button
        onClick={handleRefresh}
        disabled={isRefreshing}
        size="lg"
        className={cn(
          "group relative overflow-hidden transition-all duration-300 ease-out",
          "bg-gradient-to-br from-emerald-500 via-teal-500 to-cyan-600",
          "hover:from-emerald-600 hover:via-teal-600 hover:to-cyan-700",
          "active:from-emerald-700 active:via-teal-700 active:to-cyan-800",
          "border-0 shadow-xl hover:shadow-2xl",
          "text-white font-semibold rounded-full",
          "w-16 h-16 p-0",
          "transform hover:scale-105 active:scale-95",
          "transition-transform duration-200",
          "focus:ring-4 focus:ring-emerald-500/30 focus:outline-none"
        )}
      >
        {/* Background glow effect */}
        <div className={cn(
          "absolute -inset-1 rounded-full opacity-75 blur-md",
          "bg-gradient-to-br from-emerald-400 via-teal-400 to-cyan-500",
          "transition-opacity duration-300",
          isHovered ? "opacity-100" : "opacity-0"
        )}></div>
        
        {/* Main button content */}
        <div className="relative z-10 flex items-center justify-center">
          {isRefreshing ? (
            <Loader2 className="h-7 w-7 animate-spin text-white" />
          ) : (
            <RefreshCw className={cn(
              "h-7 w-7 transition-transform duration-300",
              "group-hover:rotate-180",
              "text-white"
            )} />
          )}
        </div>

        {/* Tooltip */}
        <div
          className={cn(
            "absolute whitespace-nowrap px-3 py-2 rounded-lg",
            "bg-gray-900/90 text-white text-sm font-medium",
            "transition-all duration-200 ease-out pointer-events-none",
            "backdrop-blur-sm border border-white/10",
            "shadow-lg",
            position.includes('right') ? "right-20 top-1/2 -translate-y-1/2" : "left-20 top-1/2 -translate-y-1/2",
            isHovered && !isRefreshing ? "opacity-100 scale-100" : "opacity-0 scale-95"
          )}
        >
          {isRefreshing
            ? (language === 'ar' ? 'جاري التحديث...' : 'Refreshing...')
            : (language === 'ar' ? 'تحديث البيانات' : 'Refresh Data')
          }
          {/* Tooltip arrow */}
          <div
            className={cn(
              "absolute top-1/2 -translate-y-1/2 w-2 h-2 bg-gray-900/90 rotate-45",
              position.includes('right') ? "-left-1" : "-right-1"
            )}
          ></div>
        </div>
      </Button>
    </div>
  );
}
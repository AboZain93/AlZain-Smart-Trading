import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useLanguageContext } from './language-provider';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { useToast } from '../hooks/use-toast';
import {
  Building2,
  Check,
  Globe,
  TrendingUp,
  Users,
  DollarSign,
  Star,
  Shield,
  Zap,
  ChevronRight
} from 'lucide-react';
import { apiRequest } from '../lib/queryClient';

interface TradingPlatform {
  id: number;
  name: string;
  displayName: string;
  logo?: string;
  description: string;
  websiteUrl: string;
  signUpUrl: string;
  minimumDeposit: number;
  supportedAssets: string[];
  features: string[];
  isActive: boolean;
  priority: number;
  telegramChannelId?: string;
}

interface PlatformStats {
  totalPlatforms: number;
  activePlatforms: number;
  totalAssets: number;
  activePlatformName: string | null;
}

export default function PlatformSelector() {
  const { language } = useLanguageContext();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: platforms = [], isLoading: platformsLoading } = useQuery({
    queryKey: ['/api/platforms/active'],
    queryFn: () => apiRequest('/api/platforms/active')
  });

  const { data: currentPlatform, isLoading: currentLoading } = useQuery({
    queryKey: ['/api/platforms/current'],
    queryFn: () => apiRequest('/api/platforms/current')
  });

  const { data: stats } = useQuery({
    queryKey: ['/api/platforms/stats'],
    queryFn: () => apiRequest('/api/platforms/stats')
  });

  const setActivePlatformMutation = useMutation({
    mutationFn: (platformId: number) => 
      apiRequest('/api/platforms/set-active', {
        method: 'POST',
        body: { platformId }
      }),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/platforms/current'] });
      queryClient.invalidateQueries({ queryKey: ['/api/platforms/stats'] });
      queryClient.invalidateQueries({ queryKey: ['/api/trading-recommendations'] });
      
      toast({
        title: language === 'ar' ? 'تم بنجاح' : 'Success',
        description: data.message || (language === 'ar' ? 'تم تغيير المنصة' : 'Platform changed successfully'),
      });
    },
    onError: (error: any) => {
      toast({
        title: language === 'ar' ? 'خطأ' : 'Error',
        description: error.message || (language === 'ar' ? 'فشل في تغيير المنصة' : 'Failed to change platform'),
        variant: 'destructive',
      });
    }
  });

  const handlePlatformChange = (platformId: string) => {
    setActivePlatformMutation.mutate(parseInt(platformId));
  };

  const getPlatformIcon = (platformName: string) => {
    switch (platformName.toLowerCase()) {
      case 'quotex': return '🎯';
      case 'iq_option': return '🔥';
      case 'binomo': return '⚡';
      case 'pocket_option': return '🚀';
      case 'olymp_trade': return '🏆';
      default: return '📊';
    }
  };

  const getFeatureIcon = (feature: string) => {
    if (feature.includes('Binary') || feature.includes('Options')) return '🎯';
    if (feature.includes('Forex') || feature.includes('Trading')) return '💱';
    if (feature.includes('Crypto')) return '₿';
    if (feature.includes('Demo')) return '🎮';
    if (feature.includes('Mobile')) return '📱';
    if (feature.includes('Fast') || feature.includes('Execution')) return '⚡';
    if (feature.includes('Copy')) return '👥';
    if (feature.includes('Social')) return '🌐';
    if (feature.includes('Tournament')) return '🏆';
    if (feature.includes('Education')) return '📚';
    if (feature.includes('Regulated')) return '🛡️';
    return '✨';
  };

  if (platformsLoading || currentLoading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-center h-32">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6" dir={language === 'ar' ? 'rtl' : 'ltr'}>
      {/* Current Platform & Quick Selector */}
      <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-blue-800">
            <Building2 className="h-5 w-5" />
            {language === 'ar' ? 'المنصة النشطة' : 'Active Platform'}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center">
            <div className="flex-1">
              {currentPlatform ? (
                <div className="flex items-center gap-3">
                  <span className="text-2xl">{getPlatformIcon(currentPlatform.name)}</span>
                  <div>
                    <h3 className="font-semibold text-lg text-blue-900">
                      {currentPlatform.displayName}
                    </h3>
                    <p className="text-sm text-blue-600">
                      {currentPlatform.supportedAssets?.length || 0} {language === 'ar' ? 'أصل متاح' : 'assets available'}
                    </p>
                  </div>
                </div>
              ) : (
                <div className="text-gray-500">
                  {language === 'ar' ? 'لم يتم تحديد منصة' : 'No platform selected'}
                </div>
              )}
            </div>

            <div className="w-full sm:w-64">
              <Select 
                value={currentPlatform?.id?.toString() || ""} 
                onValueChange={handlePlatformChange}
                disabled={setActivePlatformMutation.isPending}
              >
                <SelectTrigger className="bg-white border-blue-300">
                  <SelectValue placeholder={language === 'ar' ? 'اختر المنصة' : 'Select Platform'} />
                </SelectTrigger>
                <SelectContent>
                  {platforms.map((platform: TradingPlatform) => (
                    <SelectItem key={platform.id} value={platform.id.toString()}>
                      <div className="flex items-center gap-2">
                        <span>{getPlatformIcon(platform.name)}</span>
                        <span>{platform.displayName}</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Platform Stats */}
          {stats && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 pt-3 border-t border-blue-200">
              <div className="text-center">
                <div className="text-lg font-bold text-blue-800">{stats.activePlatforms}</div>
                <div className="text-xs text-blue-600">
                  {language === 'ar' ? 'منصات نشطة' : 'Active Platforms'}
                </div>
              </div>
              <div className="text-center">
                <div className="text-lg font-bold text-blue-800">{stats.totalAssets}</div>
                <div className="text-xs text-blue-600">
                  {language === 'ar' ? 'إجمالي الأصول' : 'Total Assets'}
                </div>
              </div>
              <div className="text-center">
                <div className="text-lg font-bold text-green-600">✓</div>
                <div className="text-xs text-blue-600">
                  {language === 'ar' ? 'متصل' : 'Connected'}
                </div>
              </div>
              <div className="text-center">
                <div className="text-lg font-bold text-purple-600">🎯</div>
                <div className="text-xs text-blue-600">
                  {language === 'ar' ? 'جاهز للتداول' : 'Ready to Trade'}
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Available Platforms Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {platforms.map((platform: TradingPlatform) => (
          <Card 
            key={platform.id} 
            className={`transition-all duration-200 hover:shadow-lg cursor-pointer ${
              currentPlatform?.id === platform.id 
                ? 'ring-2 ring-blue-500 bg-blue-50' 
                : 'hover:bg-gray-50'
            }`}
            onClick={() => handlePlatformChange(platform.id.toString())}
          >
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">{getPlatformIcon(platform.name)}</span>
                  <div>
                    <CardTitle className="text-lg">{platform.displayName}</CardTitle>
                    <div className="flex items-center gap-2 mt-1">
                      <Badge variant="secondary" className="text-xs">
                        {platform.supportedAssets?.length || 0} {language === 'ar' ? 'أصل' : 'assets'}
                      </Badge>
                      <Badge variant="outline" className="text-xs">
                        {language === 'ar' ? 'حد أدنى' : 'Min'}: ${platform.minimumDeposit}
                      </Badge>
                    </div>
                  </div>
                </div>
                {currentPlatform?.id === platform.id && (
                  <div className="flex items-center gap-1 text-green-600">
                    <Check className="h-4 w-4" />
                    <span className="text-sm font-medium">
                      {language === 'ar' ? 'نشط' : 'Active'}
                    </span>
                  </div>
                )}
              </div>
            </CardHeader>
            
            <CardContent className="space-y-4">
              <p className="text-sm text-gray-600 line-clamp-2">
                {platform.description}
              </p>

              {/* Features */}
              <div className="space-y-2">
                <h4 className="text-sm font-medium text-gray-800">
                  {language === 'ar' ? 'الميزات الرئيسية:' : 'Key Features:'}
                </h4>
                <div className="flex flex-wrap gap-1">
                  {platform.features?.slice(0, 4).map((feature, index) => (
                    <Badge key={index} variant="outline" className="text-xs">
                      <span className="mr-1">{getFeatureIcon(feature)}</span>
                      {feature}
                    </Badge>
                  ))}
                  {platform.features?.length > 4 && (
                    <Badge variant="outline" className="text-xs">
                      +{platform.features.length - 4} {language === 'ar' ? 'المزيد' : 'more'}
                    </Badge>
                  )}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-2 pt-2">
                <Button
                  variant={currentPlatform?.id === platform.id ? "default" : "outline"}
                  size="sm"
                  className="flex-1"
                  disabled={setActivePlatformMutation.isPending || currentPlatform?.id === platform.id}
                  onClick={(e) => {
                    e.stopPropagation();
                    handlePlatformChange(platform.id.toString());
                  }}
                >
                  {setActivePlatformMutation.isPending ? (
                    <div className="flex items-center gap-2">
                      <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-white"></div>
                      {language === 'ar' ? 'جاري التحديث...' : 'Updating...'}
                    </div>
                  ) : currentPlatform?.id === platform.id ? (
                    <>
                      <Check className="h-3 w-3 mr-1" />
                      {language === 'ar' ? 'نشط حالياً' : 'Current'}
                    </>
                  ) : (
                    <>
                      <Zap className="h-3 w-3 mr-1" />
                      {language === 'ar' ? 'تفعيل' : 'Activate'}
                    </>
                  )}
                </Button>

                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={(e) => {
                    e.stopPropagation();
                    window.open(platform.websiteUrl, '_blank');
                  }}
                >
                  <Globe className="h-3 w-3" />
                </Button>
              </div>

              {/* Platform Priority Indicator */}
              <div className="flex items-center justify-between text-xs text-gray-500 pt-2 border-t">
                <span>{language === 'ar' ? 'الأولوية:' : 'Priority:'}</span>
                <div className="flex items-center gap-1">
                  {Array.from({ length: 5 }, (_, i) => (
                    <Star 
                      key={i} 
                      className={`h-3 w-3 ${
                        i < Math.floor(platform.priority / 20) 
                          ? 'fill-yellow-400 text-yellow-400' 
                          : 'text-gray-300'
                      }`} 
                    />
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Platform Information Footer */}
      <Card className="bg-gradient-to-r from-green-50 to-emerald-50 border-green-200">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <Shield className="h-5 w-5 text-green-600 mt-0.5" />
            <div className="flex-1">
              <h4 className="font-medium text-green-800 mb-1">
                {language === 'ar' ? 'معلومات مهمة' : 'Important Information'}
              </h4>
              <p className="text-sm text-green-700">
                {language === 'ar' 
                  ? 'التوصيات ستُرسل فقط للأصول المدعومة في المنصة المحددة. تأكد من اختيار المنصة المناسبة للحصول على أفضل النتائج.'
                  : 'Recommendations will only be sent for assets supported by the selected platform. Make sure to choose the appropriate platform for optimal results.'
                }
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
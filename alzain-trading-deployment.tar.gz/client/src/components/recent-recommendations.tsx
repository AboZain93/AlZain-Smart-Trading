import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useQuery } from '@tanstack/react-query';
import { useLanguageContext } from '@/components/language-provider';
import { Eye, Clock, TrendingUp, TrendingDown } from 'lucide-react';

interface TradingRecommendation {
  id: number;
  assetSymbol: string;
  direction: string;
  confidence: number;
  riskLevel: string;
  technicalAnalysis: string;
  marketStatus: string;
  entryTime: string;
  trend: string;
  liquidity: string;
  result?: string;
  sentToTelegram: boolean;
  createdAt: string;
}

export function RecentRecommendations() {
  const { t } = useLanguageContext();

  const { data: recommendations, isLoading } = useQuery<TradingRecommendation[]>({
    queryKey: ['/api/trading-recommendations/recent'],
    queryFn: () => fetch('/api/trading-recommendations/recent?limit=5').then(res => res.json()),
  });

  const getDirectionBadge = (direction: string) => {
    if (direction === 'BUY') {
      return (
        <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">
          <TrendingUp className="h-3 w-3 mr-1" />
          {t('buy')}
        </Badge>
      );
    }
    if (direction === 'SELL') {
      return (
        <Badge className="bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200">
          <TrendingDown className="h-3 w-3 mr-1" />
          {t('sell')}
        </Badge>
      );
    }
    return (
      <Badge variant="secondary">
        {direction}
      </Badge>
    );
  };

  const getRiskBadge = (riskLevel: string) => {
    const colors = {
      low: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200',
      medium: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200',
      high: 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200',
    };
    return (
      <Badge className={colors[riskLevel as keyof typeof colors] || 'bg-gray-100 text-gray-800'}>
        {t(riskLevel as any)}
      </Badge>
    );
  };

  const getResultBadge = (result?: string) => {
    if (result === 'success') {
      return (
        <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">
          ✅ {t('success')}
        </Badge>
      );
    }
    if (result === 'fail') {
      return (
        <Badge className="bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200">
          🔴 {t('failed')}
        </Badge>
      );
    }
    return (
      <Badge className="bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200">
        <Clock className="h-3 w-3 mr-1" />
        Pending
      </Badge>
    );
  };

  const formatTime = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <Card className="card-hover">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold">
            {t('recommendations')}
          </CardTitle>
          <Button variant="ghost" size="sm" className="text-primary hover:text-primary/80">
            {t('viewAll')}
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-4">
            {Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="animate-pulse">
                <div className="h-4 bg-muted rounded w-3/4 mb-2"></div>
                <div className="h-3 bg-muted rounded w-1/2"></div>
              </div>
            ))}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-right py-3 px-4 text-sm font-medium text-muted-foreground">
                    Time
                  </th>
                  <th className="text-right py-3 px-4 text-sm font-medium text-muted-foreground">
                    {t('asset')}
                  </th>
                  <th className="text-right py-3 px-4 text-sm font-medium text-muted-foreground">
                    {t('direction')}
                  </th>
                  <th className="text-right py-3 px-4 text-sm font-medium text-muted-foreground">
                    {t('confidence')}
                  </th>
                  <th className="text-right py-3 px-4 text-sm font-medium text-muted-foreground">
                    {t('risk')}
                  </th>
                  <th className="text-right py-3 px-4 text-sm font-medium text-muted-foreground">
                    Result
                  </th>
                  <th className="text-right py-3 px-4 text-sm font-medium text-muted-foreground">
                    Action
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {recommendations?.map((rec) => (
                  <tr key={rec.id} className="hover:bg-muted/50 transition-colors">
                    <td className="py-4 px-4 text-sm text-foreground">
                      {formatTime(rec.createdAt)}
                    </td>
                    <td className="py-4 px-4 text-sm font-medium text-foreground">
                      {rec.assetSymbol}
                    </td>
                    <td className="py-4 px-4">
                      {getDirectionBadge(rec.direction)}
                    </td>
                    <td className="py-4 px-4 text-sm text-foreground">
                      {rec.confidence}%
                    </td>
                    <td className="py-4 px-4">
                      {getRiskBadge(rec.riskLevel)}
                    </td>
                    <td className="py-4 px-4">
                      {getResultBadge(rec.result)}
                    </td>
                    <td className="py-4 px-4">
                      <Button variant="ghost" size="sm" className="text-primary hover:text-primary/80">
                        <Eye className="h-4 w-4" />
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

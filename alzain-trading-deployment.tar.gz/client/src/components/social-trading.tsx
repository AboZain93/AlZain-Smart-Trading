import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useLanguageContext } from '@/components/language-provider';
import { 
  Users, 
  Trophy, 
  TrendingUp, 
  TrendingDown, 
  Eye, 
  Copy, 
  Star,
  MessageCircle,
  Share2,
  Filter,
  Search,
  UserCheck,
  UserPlus,
  BarChart3,
  DollarSign,
  Clock,
  ThumbsUp,
  ThumbsDown,
  Award,
  Target,
  Activity
} from 'lucide-react';

interface Trader {
  id: string;
  name: string;
  username: string;
  avatar: string;
  rank: number;
  totalReturn: number;
  winRate: number;
  followers: number;
  following: number;
  totalTrades: number;
  avgHoldTime: string;
  riskScore: number;
  specialization: string[];
  isFollowing: boolean;
  isVerified: boolean;
  monthlyReturn: number;
  sharpeRatio: number;
  maxDrawdown: number;
}

interface Signal {
  id: string;
  traderId: string;
  traderName: string;
  traderAvatar: string;
  asset: string;
  direction: 'BUY' | 'SELL';
  entryPrice: number;
  targetPrice: number;
  stopLoss: number;
  confidence: number;
  timeframe: string;
  reasoning: string;
  likes: number;
  comments: number;
  copies: number;
  timestamp: Date;
  status: 'active' | 'closed' | 'cancelled';
  pnl?: number;
  isLiked: boolean;
  isCopied: boolean;
}

export function SocialTrading() {
  const context = useLanguageContext();
  const language = context?.language || 'ar';
  const [activeTab, setActiveTab] = useState('leaderboard');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSpecialization, setSelectedSpecialization] = useState('all');
  
  // Mock data - في التطبيق الحقيقي سيتم جلب البيانات من API
  const [topTraders, setTopTraders] = useState<Trader[]>([
    {
      id: '1',
      name: 'أحمد محمد',
      username: '@ahmed_fx',
      avatar: '/api/placeholder/40/40',
      rank: 1,
      totalReturn: 84.3,
      winRate: 78.5,
      followers: 2847,
      following: 45,
      totalTrades: 1234,
      avgHoldTime: '2h 30m',
      riskScore: 6.2,
      specialization: ['Forex', 'Commodities'],
      isFollowing: false,
      isVerified: true,
      monthlyReturn: 12.4,
      sharpeRatio: 1.85,
      maxDrawdown: -8.3
    },
    {
      id: '2',
      name: 'Sarah Johnson',
      username: '@sarah_crypto',
      avatar: '/api/placeholder/40/40',
      rank: 2,
      totalReturn: 76.8,
      winRate: 72.1,
      followers: 1923,
      following: 67,
      totalTrades: 856,
      avgHoldTime: '1h 45m',
      riskScore: 7.1,
      specialization: ['Crypto', 'Indices'],
      isFollowing: true,
      isVerified: true,
      monthlyReturn: 15.2,
      sharpeRatio: 1.67,
      maxDrawdown: -12.1
    },
    {
      id: '3',
      name: 'محمد علي',
      username: '@mohammed_stocks',
      avatar: '/api/placeholder/40/40',
      rank: 3,
      totalReturn: 65.4,
      winRate: 69.8,
      followers: 1456,
      following: 23,
      totalTrades: 2103,
      avgHoldTime: '4h 15m',
      riskScore: 5.8,
      specialization: ['Stocks', 'ETFs'],
      isFollowing: false,
      isVerified: false,
      monthlyReturn: 8.9,
      sharpeRatio: 1.42,
      maxDrawdown: -6.7
    }
  ]);

  const [signals, setSignals] = useState<Signal[]>([
    {
      id: '1',
      traderId: '1',
      traderName: 'أحمد محمد',
      traderAvatar: '/api/placeholder/40/40',
      asset: 'EUR/USD',
      direction: 'BUY',
      entryPrice: 1.0850,
      targetPrice: 1.0920,
      stopLoss: 1.0810,
      confidence: 85,
      timeframe: '1H',
      reasoning: 'RSI oversold + bullish divergence + strong support at 1.0840',
      likes: 47,
      comments: 23,
      copies: 156,
      timestamp: new Date(Date.now() - 30 * 60 * 1000),
      status: 'active',
      isLiked: false,
      isCopied: false
    },
    {
      id: '2',
      traderId: '2',
      traderName: 'Sarah Johnson',
      traderAvatar: '/api/placeholder/40/40',
      asset: 'BTC/USD',
      direction: 'SELL',
      entryPrice: 65420,
      targetPrice: 63800,
      stopLoss: 66200,
      confidence: 78,
      timeframe: '4H',
      reasoning: 'Bearish engulfing pattern + volume confirmation + resistance at 65500',
      likes: 89,
      comments: 34,
      copies: 203,
      timestamp: new Date(Date.now() - 90 * 60 * 1000),
      status: 'active',
      isLiked: true,
      isCopied: true
    }
  ]);

  const specializations = ['all', 'Forex', 'Crypto', 'Stocks', 'Commodities', 'Indices', 'ETFs'];

  const filteredTraders = topTraders.filter(trader => {
    const matchesSearch = trader.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         trader.username.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesSpecialization = selectedSpecialization === 'all' || 
                                 trader.specialization.includes(selectedSpecialization);
    return matchesSearch && matchesSpecialization;
  });

  const handleFollowTrader = (traderId: string) => {
    setTopTraders(prev => 
      prev.map(trader => 
        trader.id === traderId 
          ? { ...trader, isFollowing: !trader.isFollowing }
          : trader
      )
    );
  };

  const handleLikeSignal = (signalId: string) => {
    setSignals(prev => 
      prev.map(signal => 
        signal.id === signalId 
          ? { ...signal, isLiked: !signal.isLiked, likes: signal.isLiked ? signal.likes - 1 : signal.likes + 1 }
          : signal
      )
    );
  };

  const handleCopySignal = (signalId: string) => {
    setSignals(prev => 
      prev.map(signal => 
        signal.id === signalId 
          ? { ...signal, isCopied: !signal.isCopied, copies: signal.isCopied ? signal.copies - 1 : signal.copies + 1 }
          : signal
      )
    );
  };

  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 60) {
      return language === 'ar' ? `منذ ${diffInMinutes} دقيقة` : `${diffInMinutes}m ago`;
    }
    
    const diffInHours = Math.floor(diffInMinutes / 60);
    if (diffInHours < 24) {
      return language === 'ar' ? `منذ ${diffInHours} ساعة` : `${diffInHours}h ago`;
    }
    
    const diffInDays = Math.floor(diffInHours / 24);
    return language === 'ar' ? `منذ ${diffInDays} يوم` : `${diffInDays}d ago`;
  };

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1: return <Trophy className="h-5 w-5 text-yellow-500" />;
      case 2: return <Award className="h-5 w-5 text-gray-400" />;
      case 3: return <Award className="h-5 w-5 text-amber-600" />;
      default: return <div className="h-5 w-5 flex items-center justify-center text-sm font-bold">{rank}</div>;
    }
  };

  const getRiskColor = (risk: number) => {
    if (risk <= 4) return 'text-green-600';
    if (risk <= 7) return 'text-yellow-600';
    return 'text-red-600';
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5 text-blue-600" />
            {language === 'ar' ? 'التداول الاجتماعي' : 'Social Trading'}
          </CardTitle>
          <CardDescription>
            {language === 'ar' 
              ? 'تابع أفضل المتداولين وانسخ استراتيجياتهم وشارك في المجتمع التداولي'
              : 'Follow top traders, copy their strategies, and participate in the trading community'
            }
          </CardDescription>
        </CardHeader>
      </Card>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="leaderboard" className="flex items-center gap-2">
            <Trophy className="h-4 w-4" />
            {language === 'ar' ? 'المتصدرون' : 'Leaderboard'}
          </TabsTrigger>
          <TabsTrigger value="signals" className="flex items-center gap-2">
            <TrendingUp className="h-4 w-4" />
            {language === 'ar' ? 'الإشارات' : 'Signals'}
          </TabsTrigger>
          <TabsTrigger value="following" className="flex items-center gap-2">
            <UserCheck className="h-4 w-4" />
            {language === 'ar' ? 'المتابعون' : 'Following'}
          </TabsTrigger>
        </TabsList>

        {/* Leaderboard Tab */}
        <TabsContent value="leaderboard" className="space-y-6">
          {/* Search and Filter */}
          <Card>
            <CardContent className="p-4">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder={language === 'ar' ? 'البحث عن متداول...' : 'Search traders...'}
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Filter className="h-4 w-4 text-muted-foreground" />
                  <select 
                    value={selectedSpecialization}
                    onChange={(e) => setSelectedSpecialization(e.target.value)}
                    className="px-3 py-2 border rounded-md bg-background"
                  >
                    <option value="all">
                      {language === 'ar' ? 'جميع التخصصات' : 'All Specializations'}
                    </option>
                    {specializations.slice(1).map(spec => (
                      <option key={spec} value={spec}>{spec}</option>
                    ))}
                  </select>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Traders List */}
          <div className="space-y-4">
            {filteredTraders.map((trader) => (
              <Card key={trader.id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-4">
                      <div className="relative">
                        <Avatar className="h-12 w-12">
                          <AvatarImage src={trader.avatar} alt={trader.name} />
                          <AvatarFallback>
                            {trader.name.split(' ').map(n => n[0]).join('')}
                          </AvatarFallback>
                        </Avatar>
                        <div className="absolute -top-1 -right-1">
                          {getRankIcon(trader.rank)}
                        </div>
                      </div>
                      
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <h3 className="font-semibold">{trader.name}</h3>
                          {trader.isVerified && (
                            <Badge variant="secondary" className="text-blue-600">
                              <UserCheck className="h-3 w-3 mr-1" />
                              {language === 'ar' ? 'موثق' : 'Verified'}
                            </Badge>
                          )}
                        </div>
                        <p className="text-sm text-muted-foreground">{trader.username}</p>
                        
                        <div className="flex flex-wrap gap-2 mt-2">
                          {trader.specialization.map((spec) => (
                            <Badge key={spec} variant="outline" className="text-xs">
                              {spec}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                    
                    <Button 
                      variant={trader.isFollowing ? "secondary" : "default"}
                      onClick={() => handleFollowTrader(trader.id)}
                      className="flex items-center gap-2"
                    >
                      {trader.isFollowing ? (
                        <>
                          <UserCheck className="h-4 w-4" />
                          {language === 'ar' ? 'متابع' : 'Following'}
                        </>
                      ) : (
                        <>
                          <UserPlus className="h-4 w-4" />
                          {language === 'ar' ? 'تابع' : 'Follow'}
                        </>
                      )}
                    </Button>
                  </div>
                  
                  {/* Performance Metrics */}
                  <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4 mt-6">
                    <div className="text-center p-3 bg-green-50 dark:bg-green-950/20 rounded-lg">
                      <div className="text-lg font-bold text-green-600">
                        +{trader.totalReturn.toFixed(1)}%
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {language === 'ar' ? 'العائد الكلي' : 'Total Return'}
                      </div>
                    </div>
                    
                    <div className="text-center p-3 bg-blue-50 dark:bg-blue-950/20 rounded-lg">
                      <div className="text-lg font-bold text-blue-600">
                        {trader.winRate.toFixed(1)}%
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {language === 'ar' ? 'معدل الفوز' : 'Win Rate'}
                      </div>
                    </div>
                    
                    <div className="text-center p-3 bg-purple-50 dark:bg-purple-950/20 rounded-lg">
                      <div className="text-lg font-bold text-purple-600">
                        {trader.followers.toLocaleString()}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {language === 'ar' ? 'المتابعون' : 'Followers'}
                      </div>
                    </div>
                    
                    <div className="text-center p-3 bg-orange-50 dark:bg-orange-950/20 rounded-lg">
                      <div className="text-lg font-bold text-orange-600">
                        {trader.totalTrades.toLocaleString()}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {language === 'ar' ? 'الصفقات' : 'Trades'}
                      </div>
                    </div>
                    
                    <div className="text-center p-3 bg-yellow-50 dark:bg-yellow-950/20 rounded-lg">
                      <div className={`text-lg font-bold ${getRiskColor(trader.riskScore)}`}>
                        {trader.riskScore.toFixed(1)}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {language === 'ar' ? 'المخاطر' : 'Risk Score'}
                      </div>
                    </div>
                    
                    <div className="text-center p-3 bg-gray-50 dark:bg-gray-950/20 rounded-lg">
                      <div className="text-lg font-bold text-gray-600">
                        {trader.avgHoldTime}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {language === 'ar' ? 'متوسط الوقت' : 'Avg Hold'}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Signals Tab */}
        <TabsContent value="signals" className="space-y-6">
          <div className="space-y-4">
            {signals.map((signal) => (
              <Card key={signal.id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-start gap-3">
                      <Avatar className="h-10 w-10">
                        <AvatarImage src={signal.traderAvatar} alt={signal.traderName} />
                        <AvatarFallback>
                          {signal.traderName.split(' ').map(n => n[0]).join('')}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <h4 className="font-semibold">{signal.traderName}</h4>
                        <p className="text-sm text-muted-foreground">
                          {formatTimeAgo(signal.timestamp)}
                        </p>
                      </div>
                    </div>
                    
                    <Badge 
                      variant={signal.direction === 'BUY' ? 'default' : 'destructive'}
                      className="flex items-center gap-1"
                    >
                      {signal.direction === 'BUY' ? (
                        <TrendingUp className="h-3 w-3" />
                      ) : (
                        <TrendingDown className="h-3 w-3" />
                      )}
                      {signal.direction}
                    </Badge>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    <div>
                      <div className="flex items-center gap-2 mb-2">
                        <Target className="h-4 w-4 text-blue-600" />
                        <span className="font-semibold">{signal.asset}</span>
                      </div>
                      <div className="space-y-1 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">
                            {language === 'ar' ? 'الدخول' : 'Entry'}:
                          </span>
                          <span className="font-medium">{signal.entryPrice.toFixed(4)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">
                            {language === 'ar' ? 'الهدف' : 'Target'}:
                          </span>
                          <span className="font-medium text-green-600">{signal.targetPrice.toFixed(4)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">
                            {language === 'ar' ? 'وقف الخسارة' : 'Stop Loss'}:
                          </span>
                          <span className="font-medium text-red-600">{signal.stopLoss.toFixed(4)}</span>
                        </div>
                      </div>
                    </div>
                    
                    <div>
                      <div className="flex items-center gap-2 mb-2">
                        <BarChart3 className="h-4 w-4 text-purple-600" />
                        <span className="font-semibold">
                          {language === 'ar' ? 'تفاصيل الإشارة' : 'Signal Details'}
                        </span>
                      </div>
                      <div className="space-y-1 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">
                            {language === 'ar' ? 'الثقة' : 'Confidence'}:
                          </span>
                          <span className="font-medium">{signal.confidence}%</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">
                            {language === 'ar' ? 'الإطار الزمني' : 'Timeframe'}:
                          </span>
                          <span className="font-medium">{signal.timeframe}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">
                            {language === 'ar' ? 'الحالة' : 'Status'}:
                          </span>
                          <Badge variant={signal.status === 'active' ? 'default' : 'secondary'}>
                            {signal.status === 'active' ? 
                              (language === 'ar' ? 'نشط' : 'Active') : 
                              (language === 'ar' ? 'مغلق' : 'Closed')
                            }
                          </Badge>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="p-3 bg-muted/50 rounded-lg mb-4">
                    <p className="text-sm leading-relaxed">
                      <strong>{language === 'ar' ? 'التحليل:' : 'Analysis:'}</strong> {signal.reasoning}
                    </p>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleLikeSignal(signal.id)}
                        className={`flex items-center gap-1 ${signal.isLiked ? 'text-red-600' : ''}`}
                      >
                        <ThumbsUp className="h-4 w-4" />
                        {signal.likes}
                      </Button>
                      
                      <Button variant="ghost" size="sm" className="flex items-center gap-1">
                        <MessageCircle className="h-4 w-4" />
                        {signal.comments}
                      </Button>
                      
                      <Button variant="ghost" size="sm" className="flex items-center gap-1">
                        <Eye className="h-4 w-4" />
                        {signal.copies}
                      </Button>
                    </div>
                    
                    <Button 
                      variant={signal.isCopied ? "secondary" : "default"}
                      size="sm"
                      onClick={() => handleCopySignal(signal.id)}
                      className="flex items-center gap-1"
                    >
                      <Copy className="h-4 w-4" />
                      {signal.isCopied ? 
                        (language === 'ar' ? 'تم النسخ' : 'Copied') : 
                        (language === 'ar' ? 'نسخ' : 'Copy')
                      }
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Following Tab */}
        <TabsContent value="following" className="space-y-6">
          <Card>
            <CardContent className="p-6">
              <div className="text-center space-y-4">
                <Users className="h-12 w-12 text-muted-foreground mx-auto" />
                <div>
                  <h3 className="text-lg font-semibold">
                    {language === 'ar' ? 'متابعة المتداولين' : 'Following Traders'}
                  </h3>
                  <p className="text-muted-foreground">
                    {language === 'ar' 
                      ? 'تابع المتداولين المحترفين لتلقي إشاراتهم وتحليلاتهم'
                      : 'Follow professional traders to receive their signals and analysis'
                    }
                  </p>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {topTraders.filter(t => t.isFollowing).map((trader) => (
                    <Card key={trader.id} className="p-4">
                      <div className="flex items-center gap-3">
                        <Avatar className="h-10 w-10">
                          <AvatarImage src={trader.avatar} alt={trader.name} />
                          <AvatarFallback>
                            {trader.name.split(' ').map(n => n[0]).join('')}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <h4 className="font-semibold">{trader.name}</h4>
                          <p className="text-sm text-muted-foreground">
                            {language === 'ar' ? 'العائد' : 'Return'}: +{trader.totalReturn.toFixed(1)}%
                          </p>
                        </div>
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => handleFollowTrader(trader.id)}
                        >
                          {language === 'ar' ? 'إلغاء المتابعة' : 'Unfollow'}
                        </Button>
                      </div>
                    </Card>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { useLanguageContext } from './language-provider';
import { TrendingUp, TrendingDown, Activity, Globe, Bitcoin, DollarSign, Landmark, Zap } from 'lucide-react';

interface MarketAsset {
  id: number;
  symbol: string;
  name: string;
  type: string;
  isActive: boolean;
}

interface MarketData {
  id: number;
  symbol: string;
  price: number;
  change: number;
  changePercent: number;
  volume?: number;
  timestamp: string;
}

const assetTypeConfig = {
  all: {
    labelEn: 'All Assets',
    labelAr: 'جميع الأصول',
    icon: Globe,
    color: 'text-blue-600'
  },
  forex: {
    labelEn: 'Forex',
    labelAr: 'العملات الأجنبية',
    icon: DollarSign,
    color: 'text-green-600'
  },
  crypto: {
    labelEn: 'Cryptocurrency',
    labelAr: 'العملات الرقمية',
    icon: Bitcoin,
    color: 'text-orange-600'
  },
  stock: {
    labelEn: 'Stocks',
    labelAr: 'الأسهم',
    icon: Landmark,
    color: 'text-purple-600'
  },
  commodity: {
    labelEn: 'Commodities',
    labelAr: 'السلع',
    icon: Zap,
    color: 'text-yellow-600'
  }
};

export function MarketStatusDashboard() {
  const { language } = useLanguageContext();
  const [selectedType, setSelectedType] = useState<string>('all');

  // Fetch market assets
  const { data: assets, isLoading: assetsLoading } = useQuery<MarketAsset[]>({
    queryKey: ['/api/market-assets'],
    refetchInterval: 30000,
  });

  // Fetch market data
  const { data: marketData, isLoading: dataLoading } = useQuery<MarketData[]>({
    queryKey: ['/api/market-data'],
    refetchInterval: 10000,
  });

  // Filter assets by type
  const filteredAssets = assets?.filter(asset => 
    selectedType === 'all' || asset.type === selectedType
  ) || [];

  // Get market data for filtered assets
  const assetsWithData = filteredAssets.map(asset => {
    const data = marketData?.find(md => md.symbol === asset.symbol);
    return {
      ...asset,
      data
    };
  });

  const formatPrice = (price: number, symbol: string) => {
    // Different formatting based on asset type
    if (symbol.includes('/')) {
      return price.toFixed(5); // Forex pairs typically have 5 decimals
    } else if (symbol.includes('BTC') || symbol.includes('ETH')) {
      return price.toFixed(2); // Crypto major pairs
    } else {
      return price.toFixed(2); // Stocks and commodities
    }
  };

  const formatChange = (change: number, changePercent: number) => {
    const sign = change >= 0 ? '+' : '';
    return `${sign}${change.toFixed(2)} (${sign}${changePercent.toFixed(2)}%)`;
  };

  const isLoading = assetsLoading || dataLoading;

  return (
    <Card className="col-span-full">
      <CardHeader>
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <CardTitle className="flex items-center gap-3">
            <Activity className="h-5 w-5 text-blue-600" />
            {language === 'ar' ? 'حالة السوق' : 'Market Status'}
          </CardTitle>
          
          {/* Asset Type Filter */}
          <div className="flex items-center gap-3">
            <span className="text-sm text-muted-foreground">
              {language === 'ar' ? 'نوع الأصل:' : 'Asset Type:'}
            </span>
            <Select value={selectedType} onValueChange={setSelectedType}>
              <SelectTrigger className="w-48">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {Object.entries(assetTypeConfig).map(([type, config]) => {
                  const Icon = config.icon;
                  return (
                    <SelectItem key={type} value={type}>
                      <div className="flex items-center gap-2">
                        <Icon className={`h-4 w-4 ${config.color}`} />
                        <span>{language === 'ar' ? config.labelAr : config.labelEn}</span>
                      </div>
                    </SelectItem>
                  );
                })}
              </SelectContent>
            </Select>
          </div>
        </div>
      </CardHeader>
      
      <CardContent>
        {isLoading ? (
          <div className="space-y-4">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="flex items-center justify-between p-3 rounded-lg bg-muted animate-pulse">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-muted-foreground/20 rounded"></div>
                  <div className="space-y-1">
                    <div className="w-20 h-4 bg-muted-foreground/20 rounded"></div>
                    <div className="w-32 h-3 bg-muted-foreground/20 rounded"></div>
                  </div>
                </div>
                <div className="text-right space-y-1">
                  <div className="w-16 h-4 bg-muted-foreground/20 rounded ml-auto"></div>
                  <div className="w-20 h-3 bg-muted-foreground/20 rounded ml-auto"></div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <>
            {/* Summary Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              <div className="text-center p-3 rounded-lg bg-green-50 dark:bg-green-900/20">
                <div className="text-2xl font-bold text-green-600">
                  {assetsWithData.filter(a => a.data && a.data.change > 0).length}
                </div>
                <div className="text-sm text-muted-foreground">
                  {language === 'ar' ? 'ارتفاع' : 'Rising'}
                </div>
              </div>
              <div className="text-center p-3 rounded-lg bg-red-50 dark:bg-red-900/20">
                <div className="text-2xl font-bold text-red-600">
                  {assetsWithData.filter(a => a.data && a.data.change < 0).length}
                </div>
                <div className="text-sm text-muted-foreground">
                  {language === 'ar' ? 'انخفاض' : 'Falling'}
                </div>
              </div>
              <div className="text-center p-3 rounded-lg bg-gray-50 dark:bg-gray-900/20">
                <div className="text-2xl font-bold text-gray-600">
                  {assetsWithData.filter(a => a.data && a.data.change === 0).length}
                </div>
                <div className="text-sm text-muted-foreground">
                  {language === 'ar' ? 'مستقر' : 'Stable'}
                </div>
              </div>
              <div className="text-center p-3 rounded-lg bg-blue-50 dark:bg-blue-900/20">
                <div className="text-2xl font-bold text-blue-600">
                  {filteredAssets.length}
                </div>
                <div className="text-sm text-muted-foreground">
                  {language === 'ar' ? 'إجمالي' : 'Total'}
                </div>
              </div>
            </div>

            <Separator className="mb-4" />

            {/* Asset List */}
            <div className="space-y-2 max-h-96 overflow-y-auto">
              {assetsWithData.length > 0 ? (
                assetsWithData.map((asset) => {
                  const Icon = assetTypeConfig[asset.type as keyof typeof assetTypeConfig]?.icon || Activity;
                  const isPositive = asset.data && asset.data.change > 0;
                  const isNegative = asset.data && asset.data.change < 0;
                  
                  return (
                    <div
                      key={asset.id}
                      className="flex items-center justify-between p-3 rounded-lg border hover:bg-accent/50 transition-colors"
                    >
                      <div className="flex items-center gap-3">
                        <div className={`p-2 rounded-lg ${assetTypeConfig[asset.type as keyof typeof assetTypeConfig]?.color || 'text-gray-600'} bg-current/10`}>
                          <Icon className="h-4 w-4" />
                        </div>
                        <div>
                          <div className="font-medium">{asset.symbol}</div>
                          <div className="text-sm text-muted-foreground truncate max-w-32">
                            {asset.name}
                          </div>
                        </div>
                        <Badge variant="outline" className="text-xs">
                          {language === 'ar' ? 
                            assetTypeConfig[asset.type as keyof typeof assetTypeConfig]?.labelAr :
                            assetTypeConfig[asset.type as keyof typeof assetTypeConfig]?.labelEn
                          }
                        </Badge>
                      </div>
                      
                      <div className="text-right">
                        {asset.data ? (
                          <>
                            <div className="font-mono font-medium">
                              {formatPrice(asset.data.price, asset.symbol)}
                            </div>
                            <div className={`text-sm flex items-center gap-1 ${
                              isPositive ? 'text-green-600' : isNegative ? 'text-red-600' : 'text-muted-foreground'
                            }`}>
                              {isPositive && <TrendingUp className="h-3 w-3" />}
                              {isNegative && <TrendingDown className="h-3 w-3" />}
                              {formatChange(asset.data.change, asset.data.changePercent)}
                            </div>
                          </>
                        ) : (
                          <div className="text-sm text-muted-foreground">
                            {language === 'ar' ? 'لا توجد بيانات' : 'No data'}
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <Activity className="h-12 w-12 mx-auto mb-2 opacity-50" />
                  <p>{language === 'ar' ? 'لا توجد أصول متاحة' : 'No assets available'}</p>
                </div>
              )}
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}
import { useQuery } from '@tanstack/react-query';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { CheckCircle, XCircle, AlertCircle, Clock, MessageCircle } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { ar } from 'date-fns/locale';

interface TelegramFeedback {
  id: number;
  recommendationId: number | null;
  feedbackType: string;
  confidence: number | null;
  assetSymbol: string;
  direction: string;
  responseTime: number | null;
  createdAt: string;
}

interface RecommendationFeedbackProps {
  recommendationId: number;
  assetSymbol: string;
}

export function RecommendationFeedback({ recommendationId, assetSymbol }: RecommendationFeedbackProps) {
  const { data: feedbackData, isLoading } = useQuery({
    queryKey: ['/api/ml/feedback', { asset: assetSymbol }],
    refetchInterval: 30000,
  });

  if (isLoading) {
    return (
      <div className="mt-2 text-sm text-muted-foreground">
        جاري تحميل التفاعلات...
      </div>
    );
  }

  const feedback: TelegramFeedback[] = (feedbackData as any)?.feedback || [];
  
  // Find feedback for this specific recommendation or asset
  const relevantFeedback = feedback.filter(f => 
    f.recommendationId === recommendationId || 
    (f.assetSymbol === assetSymbol && f.recommendationId === null)
  );

  if (relevantFeedback.length === 0) {
    return (
      <div className="mt-2 flex items-center gap-2 text-sm text-muted-foreground">
        <MessageCircle className="h-3 w-3" />
        لا توجد تفاعلات حتى الآن
      </div>
    );
  }

  const getFeedbackIcon = (type: string) => {
    switch (type) {
      case 'success': return <CheckCircle className="h-3 w-3 text-green-600" />;
      case 'partial': return <AlertCircle className="h-3 w-3 text-yellow-600" />;
      case 'failure': return <XCircle className="h-3 w-3 text-red-600" />;
      default: return <MessageCircle className="h-3 w-3 text-gray-600" />;
    }
  };

  const getFeedbackColor = (type: string) => {
    switch (type) {
      case 'success': return 'bg-green-100 text-green-800 border-green-200';
      case 'partial': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'failure': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getFeedbackText = (type: string) => {
    switch (type) {
      case 'success': return 'نجحت';
      case 'partial': return 'جزئية';
      case 'failure': return 'فشلت';
      default: return type;
    }
  };

  // Get the most recent feedback
  const latestFeedback = relevantFeedback.sort((a, b) => 
    new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  )[0];

  return (
    <div className="mt-2 space-y-2">
      <div className="flex items-center gap-2 text-sm">
        {getFeedbackIcon(latestFeedback.feedbackType)}
        <span className="text-muted-foreground">تفاعل المستخدم:</span>
        <Badge className={getFeedbackColor(latestFeedback.feedbackType)}>
          {getFeedbackText(latestFeedback.feedbackType)}
        </Badge>
        
        {latestFeedback.responseTime && (
          <div className="flex items-center gap-1 text-muted-foreground">
            <Clock className="h-3 w-3" />
            <span className="text-xs">
              {latestFeedback.responseTime} دقيقة
            </span>
          </div>
        )}
      </div>

      <div className="text-xs text-muted-foreground">
        آخر تفاعل: {formatDistanceToNow(new Date(latestFeedback.createdAt), { 
          addSuffix: true, 
          locale: ar 
        })}
      </div>

      {/* Show multiple feedback if available */}
      {relevantFeedback.length > 1 && (
        <div className="flex flex-wrap gap-1 mt-1">
          {relevantFeedback.slice(1, 4).map((fb, index) => (
            <Badge 
              key={fb.id} 
              variant="outline" 
              className={`text-xs ${getFeedbackColor(fb.feedbackType)}`}
            >
              {getFeedbackText(fb.feedbackType)}
            </Badge>
          ))}
          {relevantFeedback.length > 4 && (
            <Badge variant="outline" className="text-xs">
              +{relevantFeedback.length - 4} أخرى
            </Badge>
          )}
        </div>
      )}
    </div>
  );
}
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { useQuery } from '@tanstack/react-query';
import { useLanguageContext } from '@/components/language-provider';
import { TrendingUp, TrendingDown, Minus } from 'lucide-react';

interface MarketData {
  id: number;
  symbol: string;
  price: number;
  change: number;
  changePercent: number;
  volume?: number;
  timestamp: string;
}

export function MarketStatus() {
  const context = useLanguageContext();
  const t = context?.t || ((key: string) => key);
  
  const { data: marketData, isLoading, error } = useQuery<MarketData[]>({
    queryKey: ['/api/market-data'],
    refetchInterval: 30000, // Refetch every 30 seconds
  });

  const getStatusEmoji = (changePercent: number) => {
    if (changePercent > 0.1) return '📈';
    if (changePercent < -0.1) return '📉';
    return '⚖️';
  };

  const getStatusIcon = (changePercent: number) => {
    if (changePercent > 0.1) return <TrendingUp className="h-6 w-6 text-green-500" />;
    if (changePercent < -0.1) return <TrendingDown className="h-6 w-6 text-red-500" />;
    return <Minus className="h-6 w-6 text-gray-500" />;
  };

  const getAssetColor = (symbol: string) => {
    if (symbol.includes('EUR')) return 'bg-blue-500';
    if (symbol.includes('GBP')) return 'bg-green-500';
    if (symbol.includes('XAU')) return 'bg-yellow-500';
    if (symbol.includes('BTC')) return 'bg-orange-500';
    return 'bg-gray-500';
  };

  if (error) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-red-500">Error loading market data</CardTitle>
        </CardHeader>
      </Card>
    );
  }

  return (
    <Card className="card-hover">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold">
            {t('marketStatus')}
          </CardTitle>
          <div className="flex items-center space-x-2 rtl:space-x-reverse">
            <div className="w-3 h-3 bg-green-500 rounded-full status-indicator"></div>
            <span className="text-sm text-muted-foreground">{t('liveUpdate')}</span>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {isLoading ? (
            // Loading skeletons
            Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
                <div className="flex items-center space-x-3 rtl:space-x-reverse">
                  <Skeleton className="w-10 h-10 rounded-full" />
                  <div className="space-y-1">
                    <Skeleton className="h-4 w-20" />
                    <Skeleton className="h-3 w-32" />
                  </div>
                </div>
                <div className="flex items-center space-x-4 rtl:space-x-reverse">
                  <div className="text-right space-y-1">
                    <Skeleton className="h-4 w-16" />
                    <Skeleton className="h-3 w-12" />
                  </div>
                  <Skeleton className="w-6 h-6" />
                </div>
              </div>
            ))
          ) : (
            // Market data
            marketData?.map((asset) => (
              <div
                key={asset.symbol}
                className="flex items-center justify-between p-4 bg-muted/50 rounded-lg hover:bg-muted/70 transition-colors"
              >
                <div className="flex items-center space-x-3 rtl:space-x-reverse">
                  <div className={`w-10 h-10 ${getAssetColor(asset.symbol)} rounded-full flex items-center justify-center`}>
                    <span className="text-white font-semibold text-sm">
                      {asset.symbol.split('/')[0].slice(0, 3)}
                    </span>
                  </div>
                  <div>
                    <p className="font-medium text-foreground">{asset.symbol}</p>
                    <p className="text-sm text-muted-foreground">
                      {asset.symbol.includes('XAU') ? 'Gold/USD' : 
                       asset.symbol.includes('BTC') ? 'Bitcoin' : 
                       'Currency Pair'}
                    </p>
                  </div>
                </div>
                <div className="flex items-center space-x-4 rtl:space-x-reverse">
                  <div className="text-right">
                    <p className="font-semibold text-foreground">
                      {asset.price ? asset.price.toFixed(asset.symbol.includes('BTC') ? 0 : 4) : 'N/A'}
                    </p>
                    <p className={`text-sm ${
                      asset.changePercent > 0 ? 'text-green-600' : 
                      asset.changePercent < 0 ? 'text-red-600' : 'text-gray-600'
                    }`}>
                      {asset.changePercent ? (asset.changePercent > 0 ? '+' : '') + asset.changePercent.toFixed(2) + '%' : 'N/A'}
                    </p>
                  </div>
                  <div className="text-2xl">
                    {getStatusEmoji(asset.changePercent)}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  );
}

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useLanguageContext } from '@/components/language-provider';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { Send, Users, Activity, MessageCircle } from 'lucide-react';

interface TelegramStats {
  id: number;
  sentToday: number;
  subscribers: number;
  responseRate: number;
  lastSent?: string;
  updatedAt: string;
}

export function TelegramStatus() {
  const { t } = useLanguageContext();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: telegramStats, isLoading } = useQuery<TelegramStats>({
    queryKey: ['/api/telegram/stats'],
    refetchInterval: 60000, // Refetch every minute
  });

  const sendTestMutation = useMutation({
    mutationFn: () => apiRequest('POST', '/api/telegram/send-test'),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/telegram/stats'] });
      toast({
        title: 'Success',
        description: 'Test recommendation sent successfully',
      });
    },
    onError: () => {
      toast({
        title: 'Error',
        description: 'Failed to send test recommendation',
        variant: 'destructive',
      });
    },
  });

  const enableFeedbackMutation = useMutation({
    mutationFn: () => apiRequest('POST', '/api/telegram/enable-feedback'),
    onSuccess: (data) => {
      toast({
        title: 'نظام التعلم الآلي مفعل!',
        description: 'يمكن للمستخدمين الآن تقييم التوصيات لتحسين الدقة',
      });
    },
    onError: () => {
      toast({
        title: 'خطأ',
        description: 'فشل في تفعيل نظام التعلم الآلي',
        variant: 'destructive',
      });
    },
  });

  const { data: webhookStatus } = useQuery<{ webhookInfo?: { url?: string } }>({
    queryKey: ['/api/telegram/webhook-status'],
    refetchInterval: 30000,
  });

  const formatLastSent = (lastSent?: string) => {
    if (!lastSent) return 'Never';
    const date = new Date(lastSent);
    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 1) return 'Just now';
    if (diffInMinutes < 60) return `${diffInMinutes} minutes ago`;
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)} hours ago`;
    return date.toLocaleDateString();
  };

  return (
    <Card className="card-hover">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold">
            Telegram Bot Status
          </CardTitle>
          <div className="flex items-center space-x-2 rtl:space-x-reverse">
            <div className="w-3 h-3 bg-green-500 rounded-full status-indicator"></div>
            <Badge variant="secondary" className="text-green-600 bg-green-100">
              Connected
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-4">
            <div className="animate-pulse">
              <div className="h-4 bg-muted rounded w-3/4 mb-2"></div>
              <div className="h-3 bg-muted rounded w-1/2"></div>
            </div>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
              <div className="text-center p-4 bg-muted/50 rounded-lg">
                <div className="text-2xl font-bold text-primary mb-1">
                  {telegramStats?.sentToday || 0}
                </div>
                <div className="text-sm text-muted-foreground flex items-center justify-center">
                  <Send className="h-4 w-4 mr-1" />
                  Today's Recommendations
                </div>
              </div>
              <div className="text-center p-4 bg-muted/50 rounded-lg">
                <div className="text-2xl font-bold text-green-600 mb-1">
                  {telegramStats?.subscribers || 0}
                </div>
                <div className="text-sm text-muted-foreground flex items-center justify-center">
                  <Users className="h-4 w-4 mr-1" />
                  Subscribers
                </div>
              </div>
              <div className="text-center p-4 bg-muted/50 rounded-lg">
                <div className="text-2xl font-bold text-blue-600 mb-1">
                  {telegramStats?.responseRate || 0}%
                </div>
                <div className="text-sm text-muted-foreground flex items-center justify-center">
                  <Activity className="h-4 w-4 mr-1" />
                  Response Rate
                </div>
              </div>
            </div>

            <div className="p-4 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg">
              <div className="flex items-center space-x-2 rtl:space-x-reverse mb-2">
                <MessageCircle className="h-5 w-5 text-blue-600" />
                <span className="font-medium text-blue-800 dark:text-blue-200">
                  @AboZainQuotexbot
                </span>
              </div>
              <p className="text-sm text-blue-700 dark:text-blue-300 mb-3">
                Bot is running efficiently and ready to send recommendations. 
                Last sent: {formatLastSent(telegramStats?.lastSent)}
              </p>
              
              <div className="space-y-2">
                <Button 
                  onClick={() => sendTestMutation.mutate()}
                  disabled={sendTestMutation.isPending}
                  className="w-full"
                >
                  <Send className="h-4 w-4 mr-2" />
                  {sendTestMutation.isPending ? 'Sending...' : 'Send Test Recommendation'}
                </Button>
                
                {/* ML Feedback System Activation */}
                <div className="p-3 bg-gradient-to-r from-green-50 to-blue-50 dark:from-green-900/20 dark:to-blue-900/20 border border-green-200 dark:border-green-800 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium text-green-800 dark:text-green-200">
                      🧠 نظام التعلم الآلي
                    </span>
                    <Badge variant={(webhookStatus as any)?.webhookInfo?.url ? "default" : "secondary"}>
                      {(webhookStatus as any)?.webhookInfo?.url ? "مفعل" : "غير مفعل"}
                    </Badge>
                  </div>
                  <p className="text-xs text-green-700 dark:text-green-300 mb-2">
                    تفعيل أزرار التقييم لتحسين دقة التوصيات
                  </p>
                  <Button 
                    onClick={() => enableFeedbackMutation.mutate()}
                    disabled={enableFeedbackMutation.isPending || Boolean((webhookStatus as any)?.webhookInfo?.url)}
                    size="sm"
                    variant="outline"
                    className="w-full text-xs"
                  >
                    {enableFeedbackMutation.isPending ? 'جاري التفعيل...' : 
                     (webhookStatus as any)?.webhookInfo?.url ? '✅ مفعل' : '🚀 تفعيل النظام'}
                  </Button>
                </div>
                
                {/* Feedback Status */}
                {(webhookStatus as any)?.webhookInfo?.url && (
                  <div className="p-2 bg-green-100 dark:bg-green-900/30 border border-green-300 dark:border-green-700 rounded-md">
                    <p className="text-xs text-green-800 dark:text-green-200">
                      ✅ أزرار التقييم مفعلة في رسائل التليجرام
                      <br />
                      🎯 النظام يتعلم من ردود الأفعال لتحسين الدقة
                    </p>
                  </div>
                )}
              </div>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}

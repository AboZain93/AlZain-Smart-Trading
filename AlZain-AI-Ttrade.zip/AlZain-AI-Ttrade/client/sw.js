// Service Worker for AlZainTrade PWA - Enhanced for Android Compatibility
const CACHE_NAME = 'alzaintrade-v2.1';
const STATIC_CACHE = 'alzaintrade-static-v2.1';
const DYNAMIC_CACHE = 'alzaintrade-dynamic-v2.1';

// Enhanced URL list for better offline support
const STATIC_FILES = [
  '/',
  '/manifest.json',
  '/icon-192x192.svg',
  '/icon-512x512.svg',
  '/favicon.ico'
];

// Network timeout for slow connections
const NETWORK_TIMEOUT = 8000;

// Install event with improved caching
self.addEventListener('install', function(event) {
  console.log('[SW] Installing service worker...');
  event.waitUntil(
    Promise.all([
      caches.open(STATIC_CACHE).then(cache => {
        console.log('[SW] Caching static files...');
        return cache.addAll(STATIC_FILES).catch(err => {
          console.warn('[SW] Failed to cache some static files:', err);
        });
      })
    ]).then(() => {
      console.log('[SW] Installation complete');
      return self.skipWaiting();
    })
  );
});

// Enhanced fetch event with network-first strategy for API calls
self.addEventListener('fetch', function(event) {
  const url = new URL(event.request.url);
  
  // Handle API requests with network-first strategy
  if (url.pathname.startsWith('/api/')) {
    event.respondWith(
      networkFirstWithTimeout(event.request)
        .catch(() => {
          // Return offline response for API calls
          return new Response(JSON.stringify({
            error: 'Network unavailable',
            offline: true,
            message: 'Please check your internet connection'
          }), {
            status: 503,
            headers: { 'Content-Type': 'application/json' }
          });
        })
    );
    return;
  }

  // Handle static assets with cache-first strategy
  event.respondWith(
    caches.match(event.request)
      .then(response => {
        if (response) {
          return response;
        }
        
        return networkFirstWithTimeout(event.request)
          .then(networkResponse => {
            // Cache successful responses
            if (networkResponse.status === 200) {
              const responseClone = networkResponse.clone();
              caches.open(DYNAMIC_CACHE).then(cache => {
                cache.put(event.request, responseClone);
              });
            }
            return networkResponse;
          })
          .catch(() => {
            // Return offline page for navigation requests
            if (event.request.mode === 'navigate') {
              return caches.match('/').then(response => {
                return response || new Response('Offline - Please check your connection', {
                  status: 503,
                  headers: { 'Content-Type': 'text/html' }
                });
              });
            }
            throw new Error('Network unavailable');
          });
      })
  );
});

// Network timeout helper function
function networkFirstWithTimeout(request) {
  return Promise.race([
    fetch(request, {
      mode: 'cors',
      credentials: 'same-origin',
      cache: 'no-cache'
    }),
    new Promise((_, reject) => {
      setTimeout(() => reject(new Error('Network timeout')), NETWORK_TIMEOUT);
    })
  ]);
}

// Enhanced activate event with better cleanup
self.addEventListener('activate', function(event) {
  console.log('[SW] Activating service worker...');
  event.waitUntil(
    Promise.all([
      // Clean old caches
      caches.keys().then(cacheNames => {
        return Promise.all(
          cacheNames
            .filter(cacheName => {
              return cacheName !== STATIC_CACHE && 
                     cacheName !== DYNAMIC_CACHE &&
                     cacheName.startsWith('alzaintrade-');
            })
            .map(cacheName => {
              console.log('[SW] Deleting old cache:', cacheName);
              return caches.delete(cacheName);
            })
        );
      }),
      // Take control of all clients
      self.clients.claim()
    ]).then(() => {
      console.log('[SW] Activation complete');
    })
  );
});

// Background sync for offline actions (Android compatibility)
self.addEventListener('sync', function(event) {
  console.log('[SW] Background sync:', event.tag);
  if (event.tag === 'background-sync') {
    event.waitUntil(
      // Handle background sync tasks
      Promise.resolve()
    );
  }
});

// Push notification support
self.addEventListener('push', function(event) {
  if (event.data) {
    const data = event.data.json();
    event.waitUntil(
      self.registration.showNotification(data.title || 'AlZainTrade', {
        body: data.body || 'New trading signal available',
        icon: '/icon-192x192.svg',
        badge: '/icon-96x96.png',
        tag: 'trading-notification',
        requireInteraction: true,
        actions: [
          {
            action: 'view',
            title: 'View Signal'
          },
          {
            action: 'dismiss',
            title: 'Dismiss'
          }
        ]
      })
    );
  }
});

// Handle notification clicks
self.addEventListener('notificationclick', function(event) {
  event.notification.close();
  
  if (event.action === 'view') {
    event.waitUntil(
      clients.openWindow('/')
    );
  }
});

// Message handling for communication with main app
self.addEventListener('message', function(event) {
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
});
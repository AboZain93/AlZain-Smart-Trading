import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

interface User {
  id: number;
  username: string;
  email: string;
  role: 'user' | 'admin';
}

interface UserContextType {
  user: User | null;
  isAdmin: boolean;
  login: (username: string, password: string) => Promise<boolean>;
  logout: () => void;
  toggleUserRole: () => void;
  isLoading: boolean;
  loginError: string | null;
}

const UserContext = createContext<UserContextType | undefined>(undefined);

export function UserProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [loginError, setLoginError] = useState<string | null>(null);

  useEffect(() => {
    // Immediate loading setup
    const initUser = () => {
      try {
        // Check for stored user data
        const storedUser = localStorage.getItem('user');
        if (storedUser) {
          const userData = JSON.parse(storedUser);
          setUser(userData);
        } else {
          // For demo purposes, set a default admin user
          const defaultUser: User = {
            id: 1,
            username: 'admin',
            email: 'admin@example.com',
            role: 'admin'
          };
          setUser(defaultUser);
          localStorage.setItem('user', JSON.stringify(defaultUser));
        }
      } catch (error) {
        console.error('Error with user data:', error);
        localStorage.removeItem('user');
        // Set default user even on error
        const defaultUser: User = {
          id: 1,
          username: 'admin',
          email: 'admin@example.com',
          role: 'admin'
        };
        setUser(defaultUser);
        localStorage.setItem('user', JSON.stringify(defaultUser));
      } finally {
        setIsLoading(false);
      }
    };

    // Initialize immediately
    initUser();
  }, []);

  const toggleUserRole = () => {
    if (user) {
      const newRole: 'user' | 'admin' = user.role === 'admin' ? 'user' : 'admin';
      const updatedUser: User = { ...user, role: newRole };
      setUser(updatedUser);
      localStorage.setItem('user', JSON.stringify(updatedUser));
    }
  };

  const login = async (username: string, password: string): Promise<boolean> => {
    setLoginError(null);
    
    // Simple authentication check
    if (username === 'admin' && password === 'Admin123') {
      const adminUser: User = {
        id: 1,
        username: 'admin',
        email: 'admin@alzaintrade.com',
        role: 'admin'
      };
      setUser(adminUser);
      localStorage.setItem('user', JSON.stringify(adminUser));
      return true;
    } else if (username === 'user' && password === 'User123') {
      const regularUser: User = {
        id: 2,
        username: 'user',
        email: 'user@alzaintrade.com',
        role: 'user'
      };
      setUser(regularUser);
      localStorage.setItem('user', JSON.stringify(regularUser));
      return true;
    } else {
      setLoginError('اسم المستخدم أو كلمة المرور غير صحيحة');
      return false;
    }
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('user');
  };

  const isAdmin = user?.role === 'admin';

  return (
    <UserContext.Provider value={{
      user,
      isAdmin,
      login,
      logout,
      toggleUserRole,
      isLoading,
      loginError
    }}>
      {children}
    </UserContext.Provider>
  );
}

export function useUser() {
  const context = useContext(UserContext);
  if (context === undefined) {
    throw new Error('useUser must be used within a UserProvider');
  }
  return context;
}
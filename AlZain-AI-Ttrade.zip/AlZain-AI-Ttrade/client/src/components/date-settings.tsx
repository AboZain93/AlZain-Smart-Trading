import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useLanguageContext } from '@/components/language-provider';
import { Calendar, Clock } from 'lucide-react';

export type DateFormat = 'gregorian' | 'hijri';
export type TimeFormat = '12h' | '24h';

interface DateTimeSettings {
  dateFormat: DateFormat;
  timeFormat: TimeFormat;
}

interface DateSettingsProps {
  onSettingsChange?: (settings: DateTimeSettings) => void;
}

export function DateSettings({ onSettingsChange }: DateSettingsProps) {
  const { language } = useLanguageContext();
  const [settings, setSettings] = useState<DateTimeSettings>(() => {
    const saved = localStorage.getItem('dateTimeSettings');
    return saved ? JSON.parse(saved) : {
      dateFormat: 'gregorian',
      timeFormat: '24h'
    };
  });

  useEffect(() => {
    localStorage.setItem('dateTimeSettings', JSON.stringify(settings));
    onSettingsChange?.(settings);
  }, [settings, onSettingsChange]);

  const handleDateFormatChange = (format: DateFormat) => {
    setSettings(prev => ({ ...prev, dateFormat: format }));
  };

  const handleTimeFormatChange = (format: TimeFormat) => {
    setSettings(prev => ({ ...prev, timeFormat: format }));
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Calendar className="h-5 w-5" />
          {language === 'ar' ? 'إعدادات التاريخ والوقت' : 'Date & Time Settings'}
        </CardTitle>
        <CardDescription>
          {language === 'ar' 
            ? 'اختر تقويم التاريخ وتنسيق الوقت المفضل لديك'
            : 'Choose your preferred date calendar and time format'
          }
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Date Format */}
        <div className="space-y-2">
          <Label htmlFor="date-format">
            {language === 'ar' ? 'نوع التقويم' : 'Calendar Type'}
          </Label>
          <Select value={settings.dateFormat} onValueChange={handleDateFormatChange}>
            <SelectTrigger id="date-format">
              <SelectValue placeholder={language === 'ar' ? 'اختر التقويم' : 'Select calendar'} />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="gregorian">
                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4" />
                  {language === 'ar' ? 'التقويم الميلادي' : 'Gregorian Calendar'}
                </div>
              </SelectItem>
              <SelectItem value="hijri">
                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4" />
                  {language === 'ar' ? 'التقويم الهجري (الإسلامي)' : 'Hijri Calendar (Islamic)'}
                </div>
              </SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Time Format */}
        <div className="space-y-2">
          <Label htmlFor="time-format">
            {language === 'ar' ? 'تنسيق الوقت' : 'Time Format'}
          </Label>
          <Select value={settings.timeFormat} onValueChange={handleTimeFormatChange}>
            <SelectTrigger id="time-format">
              <SelectValue placeholder={language === 'ar' ? 'اختر تنسيق الوقت' : 'Select time format'} />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="12h">
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4" />
                  {language === 'ar' ? '12 ساعة (ص/م)' : '12 Hour (AM/PM)'}
                </div>
              </SelectItem>
              <SelectItem value="24h">
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4" />
                  {language === 'ar' ? '24 ساعة' : '24 Hour'}
                </div>
              </SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Preview */}
        <div className="space-y-2">
          <Label>{language === 'ar' ? 'معاينة' : 'Preview'}</Label>
          <div className="p-3 bg-muted rounded-md text-sm">
            <span className="font-medium">
              {language === 'ar' ? 'الوقت الحالي: ' : 'Current time: '}
            </span>
            <span className="text-primary">
              <DateTimePreview settings={settings} />
            </span>
          </div>
          <p className="mt-1 text-sm text-muted-foreground">
            <DateTimePreview settings={settings} />
          </p>
        </div>
      </CardContent>
    </Card>
  );
}

function DateTimePreview({ settings }: { settings: DateTimeSettings }) {
  const { language } = useLanguageContext();
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const formatDateTime = (date: Date, settings: DateTimeSettings, language: string) => {
    if (settings.dateFormat === 'hijri') {
      // Simple Hijri conversion (approximate)
      const hijriDate = toHijri(date);
      const timeStr = settings.timeFormat === '12h' 
        ? date.toLocaleTimeString(language === 'ar' ? 'ar-SA' : 'en-US', { 
            hour12: true, 
            hour: '2-digit', 
            minute: '2-digit' 
          })
        : date.toLocaleTimeString(language === 'ar' ? 'ar-SA' : 'en-US', { 
            hour12: false, 
            hour: '2-digit', 
            minute: '2-digit' 
          });
      
      return `${hijriDate} - ${timeStr}`;
    } else {
      // Use Syrian Arabic calendar format for Gregorian calendar
      if (language === 'ar') {
        const syrianDate = formatSyrianDate(date);
        const timeStr = settings.timeFormat === '12h' 
          ? date.toLocaleTimeString('ar-SA', { 
              hour12: true, 
              hour: '2-digit', 
              minute: '2-digit' 
            })
          : date.toLocaleTimeString('ar-SA', { 
              hour12: false, 
              hour: '2-digit', 
              minute: '2-digit' 
            });
        return `${syrianDate} - ${timeStr}`;
      } else {
        const options: Intl.DateTimeFormatOptions = {
          year: 'numeric',
          month: 'long',
          day: 'numeric',
          hour: '2-digit',
          minute: '2-digit',
          hour12: settings.timeFormat === '12h'
        };
        
        return date.toLocaleDateString('en-US', options);
      }
    }
  };

  return (
    <span>{formatDateTime(currentTime, settings, language)}</span>
  );
}

// Syrian Arabic Gregorian calendar format
function formatSyrianDate(date: Date): string {
  const syrianMonths = [
    'كانون الثاني',    // January
    'شباط',           // February  
    'آذار',           // March
    'نيسان',          // April
    'أيار',           // May
    'حزيران',         // June
    'تموز',           // July
    'آب',             // August
    'أيلول',          // September
    'تشرين الأول',    // October
    'تشرين الثاني',   // November
    'كانون الأول'     // December
  ];

  const day = date.getDate();
  const month = syrianMonths[date.getMonth()];
  const year = date.getFullYear();

  return `${day} ${month} ${year}`;
}

// Simple Hijri date conversion (approximate)
function toHijri(gregorianDate: Date): string {
  const hijriEpoch = new Date('622-07-16'); // Approximate start of Hijri calendar
  const daysDiff = Math.floor((gregorianDate.getTime() - hijriEpoch.getTime()) / (1000 * 60 * 60 * 24));
  const hijriYear = Math.floor(daysDiff / 354.37) + 1; // Hijri year is approximately 354.37 days
  const dayOfYear = daysDiff % 354;
  const hijriMonth = Math.floor(dayOfYear / 29.5) + 1;
  const hijriDay = Math.floor(dayOfYear % 29.5) + 1;

  const months = [
    'محرم', 'صفر', 'ربيع الأول', 'ربيع الآخر', 'جمادى الأولى', 'جمادى الآخرة',
    'رجب', 'شعبان', 'رمضان', 'شوال', 'ذو القعدة', 'ذو الحجة'
  ];

  return `${hijriDay} ${months[hijriMonth - 1]} ${hijriYear} هـ`;
}

// Hook to use date formatting throughout the app
export function useDateTimeFormat() {
  const { language } = useLanguageContext();
  const [settings, setSettings] = useState<DateTimeSettings>(() => {
    const saved = localStorage.getItem('dateTimeSettings');
    return saved ? JSON.parse(saved) : {
      dateFormat: 'gregorian',
      timeFormat: '24h'
    };
  });

  useEffect(() => {
    const handleStorageChange = () => {
      const saved = localStorage.getItem('dateTimeSettings');
      if (saved) {
        setSettings(JSON.parse(saved));
      }
    };

    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, []);

  const formatDate = (date: Date | string): string => {
    const dateObj = typeof date === 'string' ? new Date(date) : date;
    
    if (settings.dateFormat === 'hijri') {
      return toHijri(dateObj);
    } else {
      // Use Syrian calendar format for Arabic
      if (language === 'ar') {
        return formatSyrianDate(dateObj);
      } else {
        return dateObj.toLocaleDateString('en-US', {
          year: 'numeric',
          month: 'long',
          day: 'numeric'
        });
      }
    }
  };

  const formatTime = (date: Date | string): string => {
    const dateObj = typeof date === 'string' ? new Date(date) : date;
    
    return dateObj.toLocaleTimeString(language === 'ar' ? 'ar-SA' : 'en-US', {
      hour12: settings.timeFormat === '12h',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const formatDateTime = (date: Date | string): string => {
    const dateObj = typeof date === 'string' ? new Date(date) : date;
    
    if (settings.dateFormat === 'hijri') {
      const hijriDate = toHijri(dateObj);
      const timeStr = formatTime(dateObj);
      return `${hijriDate} - ${timeStr}`;
    } else {
      // Use Syrian calendar format for Arabic
      if (language === 'ar') {
        const syrianDate = formatSyrianDate(dateObj);
        const timeStr = formatTime(dateObj);
        return `${syrianDate} - ${timeStr}`;
      } else {
        return dateObj.toLocaleDateString('en-US', {
          year: 'numeric',
          month: 'long',
          day: 'numeric',
          hour: '2-digit',
          minute: '2-digit',
          hour12: settings.timeFormat === '12h'
        });
      }
    }
  };

  return {
    formatDate,
    formatTime,
    formatDateTime,
    settings
  };
}
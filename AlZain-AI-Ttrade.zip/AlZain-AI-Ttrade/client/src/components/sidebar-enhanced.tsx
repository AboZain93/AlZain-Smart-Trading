import { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { useLanguageContext } from '@/components/language-provider';
import { useUser } from '@/components/user-provider';
import { 
  Home,
  BarChart3,
  Settings,
  TrendingUp,
  Bot,
  MessageCircle,
  Zap,
  Brain,
  Users,
  Mic,
  LineChart,
  Briefcase,
  Newspaper,
  Globe,
  Activity,
  Shield,
  ChevronDown,
  ChevronRight,
  Gauge,
  PieChart,
  Target,
  Layers,
  Database,
  Cpu,
  Monitor,
  Smartphone,
  Lock,
  Crown,
  Star,
  Menu,
  X,
  ShoppingCart,
  CreditCard,
  Key,
  Package
} from 'lucide-react';

interface SidebarItem {
  href: string;
  icon: any;
  labelEn: string;
  labelAr: string;
  badge?: string;
  description?: string;
  adminOnly?: boolean;
}

interface SidebarGroup {
  id: string;
  labelEn: string;
  labelAr: string;
  icon: any;
  items: SidebarItem[];
  adminOnly?: boolean;
  defaultOpen?: boolean;
}

const sidebarGroups: SidebarGroup[] = [
  {
    id: 'core',
    labelEn: 'Core Features',
    labelAr: 'الميزات الأساسية',
    icon: Target,
    defaultOpen: true,
    items: [
      {
        href: '/recommendations',
        icon: TrendingUp,
        labelEn: 'Trading Signals',
        labelAr: 'إشارات التداول',
        badge: 'Live',
        description: 'AI-Powered Trading Recommendations'
      },
      {
        href: '/market-data',
        icon: BarChart3,
        labelEn: 'Market Data',
        labelAr: 'بيانات السوق',
        description: 'Real-time Market Information'
      },
      {
        href: '/auto-signals',
        icon: Bot,
        labelEn: 'Auto Signals',
        labelAr: 'الإشارات التلقائية',
        badge: 'AI',
        description: 'Automated Signal Generation'
      },
      {
        href: '/enhanced-trading-control',
        icon: Settings,
        labelEn: 'Trading Control',
        labelAr: 'التحكم بالتداول',
        badge: 'Enhanced',
        description: 'Advanced Trading Settings'
      }
    ]
  },
  {
    id: 'analytics',
    labelEn: 'Analytics & Intelligence',
    labelAr: 'التحليلات والذكاء',
    icon: Brain,
    items: [
      {
        href: '/ai-analytics',
        icon: Brain,
        labelEn: 'AI Analytics',
        labelAr: 'تحليلات الذكاء الاصطناعي',
        badge: 'Pro',
        description: 'Machine Learning Insights'
      },
      {
        href: '/professional-ai-monitor',
        icon: Cpu,
        labelEn: 'Professional AI Monitor',
        labelAr: 'مراقب النظام الاحترافي',
        badge: 'Expert',
        description: 'Advanced AI System Performance'
      },
      {
        href: '/market-intelligence',
        icon: Globe,
        labelEn: 'Market Intelligence',
        labelAr: 'ذكاء السوق',
        badge: 'Advanced',
        description: 'Comprehensive Market Analysis'
      },
      {
        href: '/economic-intelligence',
        icon: PieChart,
        labelEn: 'Economic Intelligence',
        labelAr: 'الذكاء الاقتصادي',
        badge: 'New',
        description: 'Economic Analysis & Insights'
      },
      {
        href: '/advanced-news-dashboard',
        icon: Newspaper,
        labelEn: 'News Analysis',
        labelAr: 'تحليل الأخبار',
        badge: 'AI',
        description: 'AI-Powered News Analysis'
      }
    ]
  },
  {
    id: 'portfolio',
    labelEn: 'Portfolio Management',
    labelAr: 'إدارة المحافظ',
    icon: Briefcase,
    items: [
      {
        href: '/comprehensive-portfolio',
        icon: Briefcase,
        labelEn: 'Portfolio Manager',
        labelAr: 'مدير المحافظ',
        badge: 'Advanced',
        description: 'Comprehensive Portfolio Management'
      },
      {
        href: '/advanced-portfolio',
        icon: Layers,
        labelEn: 'Advanced Portfolio',
        labelAr: 'المحفظة المتقدمة',
        badge: 'Pro',
        description: 'Advanced Portfolio Analytics'
      },
      {
        href: '/interactive-charts',
        icon: LineChart,
        labelEn: 'Trading Charts',
        labelAr: 'مخططات التداول',
        badge: 'Interactive',
        description: 'Advanced Trading Charts'
      },
      {
        href: '/risk-management',
        icon: Shield,
        labelEn: 'Risk Management',
        labelAr: 'إدارة المخاطر',
        badge: 'Smart',
        description: 'Smart Risk Management Tools'
      }
    ]
  },
  {
    id: 'social',
    labelEn: 'Social & Communication',
    labelAr: 'التواصل الاجتماعي',
    icon: Users,
    items: [
      {
        href: '/social-trading',
        icon: Users,
        labelEn: 'Social Trading',
        labelAr: 'التداول الاجتماعي',
        badge: 'Community',
        description: 'Social Trading Network'
      },
      {
        href: '/voice-assistant',
        icon: Mic,
        labelEn: 'Voice Assistant',
        labelAr: 'المساعد الصوتي',
        badge: 'AI',
        description: 'Multilingual Voice Assistant'
      },
      {
        href: '/telegram-settings',
        icon: MessageCircle,
        labelEn: 'Telegram Bot',
        labelAr: 'بوت تليجرام',
        description: 'Telegram Integration Settings'
      }
    ]
  },
  {
    id: 'tools',
    labelEn: 'Tools & Utilities',
    labelAr: 'الأدوات والمرافق',
    icon: Zap,
    items: [
      {
        href: '/news-analyzer',
        icon: Newspaper,
        labelEn: 'News Analyzer',
        labelAr: 'محلل الأخبار',
        badge: 'Smart',
        description: 'Advanced News Analysis Tool'
      },
      {
        href: '/new-features',
        icon: Star,
        labelEn: 'New Features',
        labelAr: 'الميزات الجديدة',
        badge: 'Latest',
        description: 'Latest Feature Showcase'
      },
      {
        href: '/enhancements',
        icon: Zap,
        labelEn: 'Enhancements',
        labelAr: 'التحسينات',
        badge: 'Roadmap',
        description: 'Platform Enhancement Roadmap'
      }
    ]
  },
  {
    id: 'monitoring',
    labelEn: 'System Monitoring',
    labelAr: 'مراقبة النظام',
    icon: Monitor,
    items: [
      {
        href: '/performance-monitor',
        icon: Activity,
        labelEn: 'Performance Monitor',
        labelAr: 'مراقب الأداء',
        badge: 'Real-time',
        description: 'System Performance Monitor'
      },
      {
        href: '/app-health-dashboard',
        icon: Shield,
        labelEn: 'App Health',
        labelAr: 'صحة التطبيق',
        badge: 'Analytics',
        description: 'Application Health Monitor'
      }
    ]
  },
  {
    id: 'admin',
    labelEn: 'Administration',
    labelAr: 'الإدارة',
    icon: Crown,
    adminOnly: true,
    items: [
      {
        href: '/admin',
        icon: Lock,
        labelEn: 'Admin Panel',
        labelAr: 'لوحة الإدارة',
        badge: 'Admin',
        description: 'Administrative Controls',
        adminOnly: true
      },
      {
        href: '/settings',
        icon: Settings,
        labelEn: 'System Settings',
        labelAr: 'إعدادات النظام',
        description: 'System Configuration',
        adminOnly: true
      }
    ]
  },
  {
    id: 'commercial',
    labelEn: 'Commercial System',
    labelAr: 'النظام التجاري',
    icon: ShoppingCart,
    items: [
      {
        href: '/commercial/login',
        icon: Lock,
        labelEn: 'Commercial Login',
        labelAr: 'تسجيل الدخول التجاري',
        description: 'Access Commercial Dashboard'
      },
      {
        href: '/commercial/register',
        icon: Users,
        labelEn: 'Commercial Register',
        labelAr: 'التسجيل التجاري',
        description: 'Create Commercial Account'
      },
      {
        href: '/commercial/dashboard',
        icon: BarChart3,
        labelEn: 'Commercial Dashboard',
        labelAr: 'لوحة التحكم التجارية',
        badge: 'Pro',
        description: 'Commercial User Dashboard'
      },
      {
        href: '/commercial/store',
        icon: Package,
        labelEn: 'Product Store',
        labelAr: 'متجر المنتجات',
        badge: 'Shop',
        description: 'Browse and Purchase Products'
      }
    ]
  }
];

export function EnhancedSidebar() {
  const [location] = useLocation();
  const { language } = useLanguageContext();
  const { user } = useUser();
  const [openGroups, setOpenGroups] = useState<Set<string>>(
    new Set(sidebarGroups.filter(g => g.defaultOpen).map(g => g.id))
  );
  const [isCollapsed, setIsCollapsed] = useState(false);

  const isAdmin = user?.role === 'admin';

  const toggleGroup = (groupId: string) => {
    setOpenGroups(prev => {
      const newSet = new Set(prev);
      if (newSet.has(groupId)) {
        newSet.delete(groupId);
      } else {
        newSet.add(groupId);
      }
      return newSet;
    });
  };

  const filteredGroups = sidebarGroups.filter(group => 
    !group.adminOnly || isAdmin
  );

  const getBadgeVariant = (badge: string) => {
    switch (badge.toLowerCase()) {
      case 'live':
      case 'real-time':
        return 'default';
      case 'ai':
      case 'pro':
      case 'advanced':
        return 'secondary';
      case 'new':
      case 'latest':
        return 'destructive';
      case 'admin':
        return 'outline';
      default:
        return 'secondary';
    }
  };

  return (
    <div className={`${isCollapsed ? 'w-16' : 'w-64'} bg-gradient-to-b from-card to-card/80 border-r border-border/50 h-screen overflow-y-auto transition-all duration-300 ease-in-out shadow-lg backdrop-blur-sm relative`}>
      {/* Fixed Expand Button for Collapsed State */}
      {isCollapsed && (
        <div className="absolute top-4 left-0 right-0 z-50 flex justify-center">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsCollapsed(false)}
            className="h-8 w-8 p-0 hover:bg-primary/10 rounded-full transition-all duration-200 bg-background/90 backdrop-blur-sm border border-border/30 shadow-sm"
            title={language === 'ar' ? 'توسيع الشريط الجانبي' : 'Expand Sidebar'}
          >
            <Menu className="h-4 w-4" />
          </Button>
        </div>
      )}
      
      <div className="p-4">
        {/* Header with Toggle */}
        <div className={`flex items-center ${isCollapsed ? 'justify-center mt-12' : 'justify-between'} mb-6`}>
          <div className={`flex items-center gap-3 ${isCollapsed ? 'justify-center' : ''}`}>
            <div className="w-10 h-10 bg-gradient-to-br from-primary via-primary/80 to-primary/60 rounded-xl flex items-center justify-center shadow-lg animate-pulse">
              <TrendingUp className="h-6 w-6 text-primary-foreground" />
            </div>
            {!isCollapsed && (
              <div>
                <h1 className="text-xl font-bold bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
                  {language === 'ar' ? 'الزين تريد' : 'AlZain Trade'}
                </h1>
                <p className="text-xs text-muted-foreground">
                  {language === 'ar' ? 'منصة التداول الذكية' : 'Smart Trading Platform'}
                </p>
              </div>
            )}
          </div>
          
          {/* Collapse Button - Only show when expanded */}
          {!isCollapsed && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsCollapsed(true)}
              className="h-8 w-8 p-0 hover:bg-primary/10 rounded-full transition-all duration-200"
              title={language === 'ar' ? 'طي الشريط الجانبي' : 'Collapse Sidebar'}
            >
              <X className="h-4 w-4" />
            </Button>
          )}
        </div>

        {/* Dashboard - Independent */}
        <div className="mb-6">
          <Link href="/">
            <Button
              variant={location === '/' ? 'default' : 'ghost'}
              className={`w-full ${isCollapsed ? 'justify-center px-0' : 'justify-start gap-3'} h-11 text-left relative group transition-all duration-200 ${
                location === '/' 
                  ? 'bg-gradient-to-r from-primary to-primary/80 text-primary-foreground shadow-lg' 
                  : 'hover:bg-gradient-to-r hover:from-primary/10 hover:to-primary/5 hover:scale-[1.02]'
              }`}
            >
              <Home className="h-5 w-5" />
              {!isCollapsed && (
                <span className="font-medium">
                  {language === 'ar' ? 'لوحة التحكم' : 'Dashboard'}
                </span>
              )}
              {isCollapsed && (
                <div className="absolute left-full ml-2 px-2 py-1 bg-popover text-popover-foreground text-sm rounded-md shadow-lg opacity-0 group-hover:opacity-100 transition-opacity z-50 whitespace-nowrap">
                  {language === 'ar' ? 'لوحة التحكم' : 'Dashboard'}
                </div>
              )}
            </Button>
          </Link>
        </div>

        {/* Grouped Navigation */}
        <div className="space-y-2">
          {filteredGroups.map((group) => {
            const isOpen = openGroups.has(group.id);
            const GroupIcon = group.icon;
            const filteredItems = group.items.filter(item => 
              !item.adminOnly || isAdmin
            );

            if (filteredItems.length === 0) return null;

            if (isCollapsed) {
              // Show individual items directly when collapsed with tooltips
              return filteredItems.map((item) => {
                const ItemIcon = item.icon;
                return (
                  <Link key={item.href} href={item.href}>
                    <Button
                      variant={location === item.href ? 'default' : 'ghost'}
                      className={`w-full justify-center px-0 h-10 relative group transition-all duration-200 hover:scale-[1.02] ${
                        location === item.href
                          ? 'bg-gradient-to-r from-primary to-primary/80 text-primary-foreground shadow-lg'
                          : 'hover:bg-gradient-to-r hover:from-primary/10 hover:to-primary/5'
                      }`}
                    >
                      <ItemIcon className="h-4 w-4" />
                      {item.badge && (
                        <div className="absolute -top-1 -right-1 w-2 h-2 bg-destructive rounded-full animate-ping"></div>
                      )}
                      <div className="absolute left-full ml-2 px-2 py-1 bg-popover text-popover-foreground text-sm rounded-md shadow-lg opacity-0 group-hover:opacity-100 transition-opacity z-50 whitespace-nowrap">
                        {language === 'ar' ? item.labelAr : item.labelEn}
                        {item.badge && (
                          <Badge 
                            variant={getBadgeVariant(item.badge)}
                            className="ml-2 text-xs"
                          >
                            {item.badge}
                          </Badge>
                        )}
                      </div>
                    </Button>
                  </Link>
                );
              });
            }

            return (
              <Collapsible
                key={group.id}
                open={isOpen}
                onOpenChange={() => toggleGroup(group.id)}
              >
                <CollapsibleTrigger asChild>
                  <Button
                    variant="ghost"
                    className="w-full justify-between gap-2 h-10 text-left font-medium text-muted-foreground hover:text-foreground hover:bg-gradient-to-r hover:from-primary/10 hover:to-primary/5 transition-all duration-200"
                  >
                    <div className="flex items-center gap-2">
                      <GroupIcon className="h-4 w-4" />
                      <span className="text-sm">
                        {language === 'ar' ? group.labelAr : group.labelEn}
                      </span>
                    </div>
                    {isOpen ? (
                      <ChevronDown className="h-4 w-4" />
                    ) : (
                      <ChevronRight className="h-4 w-4" />
                    )}
                  </Button>
                </CollapsibleTrigger>
                <CollapsibleContent className="space-y-1 px-2">
                  {filteredItems.map((item) => {
                    const ItemIcon = item.icon;
                    return (
                      <Link key={item.href} href={item.href}>
                        <Button
                          variant={location === item.href ? 'default' : 'ghost'}
                          className={`w-full justify-start gap-3 h-10 text-left transition-all duration-200 hover:scale-[1.02] ${
                            location === item.href
                              ? 'bg-gradient-to-r from-primary to-primary/80 text-primary-foreground shadow-lg'
                              : 'hover:bg-gradient-to-r hover:from-primary/10 hover:to-primary/5'
                          }`}
                        >
                          <ItemIcon className="h-4 w-4" />
                          <span className="text-sm font-medium">
                            {language === 'ar' ? item.labelAr : item.labelEn}
                          </span>
                          {item.badge && (
                            <Badge 
                              variant={getBadgeVariant(item.badge)}
                              className="ml-auto text-xs animate-pulse"
                            >
                              {item.badge}
                            </Badge>
                          )}
                        </Button>
                      </Link>
                    );
                  })}
                </CollapsibleContent>
              </Collapsible>
            );
          })}
        </div>

        {/* User Info */}
        <div className="mt-8 pt-4 border-t border-border">
          <div className="flex items-center gap-3 p-3 bg-muted rounded-lg">
            <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
              <span className="text-sm font-bold text-primary-foreground">
                {user?.username?.charAt(0).toUpperCase()}
              </span>
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate">{user?.username}</p>
              <div className="flex items-center gap-2">
                <p className="text-xs text-muted-foreground">
                  {isAdmin 
                    ? (language === 'ar' ? 'مدير' : 'Admin')
                    : (language === 'ar' ? 'مستخدم' : 'User')
                  }
                </p>
                {isAdmin && <Crown className="h-3 w-3 text-yellow-500" />}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
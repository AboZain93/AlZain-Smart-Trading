import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useLanguageContext } from './language-provider';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { TrendingUp, TrendingDown, Minus, DollarSign, Filter } from 'lucide-react';

interface MarketData {
  id: number;
  symbol: string;
  price: number;
  change: number;
  changePercent: number;
  volume?: number;
  timestamp: string;
}

// Quotex platform asset categories
const QUOTEX_ASSET_TYPES = {
  forex: { 
    en: 'Forex', 
    ar: 'العملات الأجنبية', 
    assets: ['EUR/USD', 'GBP/USD', 'USD/JPY', 'AUD/USD', 'USD/CAD', 'NZD/USD'] 
  },
  crypto: { 
    en: 'Cryptocurrencies', 
    ar: 'العملات الرقمية', 
    assets: ['BTC/USD', 'ETH/USD', 'LTC/USD', 'XRP/USD', 'ADA/USD'] 
  },
  commodities: { 
    en: 'Commodities', 
    ar: 'السلع', 
    assets: ['XAU/USD', 'XAG/USD', 'OIL', 'GAS'] 
  },
  indices: { 
    en: 'Stock Indices', 
    ar: 'مؤشرات الأسهم', 
    assets: ['S&P500', 'NASDAQ', 'DOW', 'FTSE100'] 
  },
  stocks: { 
    en: 'Stocks', 
    ar: 'الأسهم', 
    assets: ['AAPL', 'GOOGL', 'TSLA', 'AMZN', 'MSFT'] 
  }
};

function getAssetType(symbol: string): string {
  for (const [type, config] of Object.entries(QUOTEX_ASSET_TYPES)) {
    if (config.assets.includes(symbol)) {
      return type;
    }
  }
  return 'forex'; // default
}

function getMarketStatus(changePercent: number, language: string): { text: string; color: string } {
  if (changePercent > 0.5) {
    return { 
      text: language === 'ar' ? 'قوي صاعد' : 'Strong Up', 
      color: 'text-green-700 bg-green-100' 
    };
  } else if (changePercent > 0) {
    return { 
      text: language === 'ar' ? 'صاعد' : 'Up', 
      color: 'text-green-600 bg-green-50' 
    };
  } else if (changePercent < -0.5) {
    return { 
      text: language === 'ar' ? 'قوي هابط' : 'Strong Down', 
      color: 'text-red-700 bg-red-100' 
    };
  } else if (changePercent < 0) {
    return { 
      text: language === 'ar' ? 'هابط' : 'Down', 
      color: 'text-red-600 bg-red-50' 
    };
  } else {
    return { 
      text: language === 'ar' ? 'مستقر' : 'Stable', 
      color: 'text-gray-600 bg-gray-50' 
    };
  }
}

export function MarketStatusEnhanced() {
  const { language } = useLanguageContext();
  const [selectedType, setSelectedType] = useState<string>('all');
  
  const { data: marketData, isLoading } = useQuery<MarketData[]>({
    queryKey: ['/api/market-data'],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const filteredData = marketData?.filter(asset => {
    if (selectedType === 'all') return true;
    return getAssetType(asset.symbol) === selectedType;
  });

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <DollarSign className="h-5 w-5" />
            {language === 'ar' ? 'حالة السوق' : 'Market Status'}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="animate-pulse">
                <div className="h-4 bg-muted rounded w-3/4 mb-2"></div>
                <div className="h-3 bg-muted rounded w-1/2"></div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <DollarSign className="h-5 w-5" />
            {language === 'ar' ? 'حالة السوق' : 'Market Status'}
          </div>
          <div className="flex items-center gap-2">
            <Filter className="h-4 w-4" />
            <Select value={selectedType} onValueChange={setSelectedType}>
              <SelectTrigger className="w-[180px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">
                  {language === 'ar' ? 'جميع الأصول' : 'All Assets'}
                </SelectItem>
                {Object.entries(QUOTEX_ASSET_TYPES).map(([key, config]) => (
                  <SelectItem key={key} value={key}>
                    {language === 'ar' ? config.ar : config.en}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {filteredData?.map((asset) => {
            const isPositive = asset.changePercent > 0;
            const isNegative = asset.changePercent < 0;
            const marketStatus = getMarketStatus(asset.changePercent, language);
            const assetType = getAssetType(asset.symbol);
            
            return (
              <div key={asset.id} className="flex items-center justify-between p-3 rounded-lg border hover:bg-muted/50 transition-colors">
                <div className="flex items-center gap-3">
                  <div className="flex items-center gap-2">
                    {isPositive ? (
                      <TrendingUp className="h-4 w-4 text-green-600" />
                    ) : isNegative ? (
                      <TrendingDown className="h-4 w-4 text-red-600" />
                    ) : (
                      <Minus className="h-4 w-4 text-gray-600" />
                    )}
                    <div>
                      <span className="font-medium">{asset.symbol}</span>
                      <div className="text-xs text-muted-foreground">
                        {language === 'ar' 
                          ? QUOTEX_ASSET_TYPES[assetType as keyof typeof QUOTEX_ASSET_TYPES]?.ar 
                          : QUOTEX_ASSET_TYPES[assetType as keyof typeof QUOTEX_ASSET_TYPES]?.en}
                      </div>
                    </div>
                  </div>
                  
                  <Badge className={`${marketStatus.color} text-xs px-2 py-1`}>
                    {marketStatus.text}
                  </Badge>
                </div>
                
                <div className="text-right">
                  <p className="font-semibold text-foreground">
                    {asset.price ? asset.price.toFixed(asset.symbol.includes('BTC') ? 0 : 4) : 'N/A'}
                  </p>
                  <p className={`text-sm ${
                    asset.changePercent > 0 ? 'text-green-600' : 
                    asset.changePercent < 0 ? 'text-red-600' : 'text-gray-600'
                  }`}>
                    {asset.changePercent ? (asset.changePercent > 0 ? '+' : '') + asset.changePercent.toFixed(2) + '%' : 'N/A'}
                  </p>
                </div>
              </div>
            );
          })}
          
          {filteredData?.length === 0 && (
            <div className="text-center py-8 text-muted-foreground">
              {language === 'ar' 
                ? 'لا توجد أصول لهذه الفئة' 
                : 'No assets found for this category'}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useLanguageContext } from '@/components/language-provider';
import { 
  Shield, 
  Calculator, 
  AlertTriangle, 
  TrendingUp, 
  DollarSign, 
  Target,
  BarChart3,
  Info,
  CheckCircle,
  XCircle,
  ArrowUpDown
} from 'lucide-react';

interface RiskSettings {
  accountBalance: number;
  riskPercentage: number;
  maxDrawdown: number;
  maxPositions: number;
  timeframe: string;
  riskLevel: 'conservative' | 'moderate' | 'aggressive';
}

interface PositionSizeCalculation {
  recommendedSize: number;
  maxRisk: number;
  riskReward: number;
  probabilityOfLoss: number;
  kellyPercent: number;
}

export function SmartRiskManagement() {
  const { language } = useLanguageContext();
  const [riskSettings, setRiskSettings] = useState<RiskSettings>({
    accountBalance: 10000,
    riskPercentage: 2,
    maxDrawdown: 15,
    maxPositions: 3,
    timeframe: '1h',
    riskLevel: 'moderate'
  });
  
  const [positionCalculation, setPositionCalculation] = useState<PositionSizeCalculation>({
    recommendedSize: 0,
    maxRisk: 0,
    riskReward: 0,
    probabilityOfLoss: 0,
    kellyPercent: 0
  });
  
  const [stopLossPrice, setStopLossPrice] = useState<number>(0);
  const [takeProfitPrice, setTakeProfitPrice] = useState<number>(0);
  const [entryPrice, setEntryPrice] = useState<number>(100);
  const [riskWarnings, setRiskWarnings] = useState<string[]>([]);

  // Risk level configurations
  const riskLevelConfigs = {
    conservative: {
      maxRisk: 1,
      maxDrawdown: 10,
      maxPositions: 2,
      color: 'text-green-600',
      bgColor: 'bg-green-50 dark:bg-green-950/20'
    },
    moderate: {
      maxRisk: 2,
      maxDrawdown: 15,
      maxPositions: 3,
      color: 'text-yellow-600',
      bgColor: 'bg-yellow-50 dark:bg-yellow-950/20'
    },
    aggressive: {
      maxRisk: 5,
      maxDrawdown: 25,
      maxPositions: 5,
      color: 'text-red-600',
      bgColor: 'bg-red-50 dark:bg-red-950/20'
    }
  };

  // Calculate position size and risk metrics
  useEffect(() => {
    calculatePositionSize();
    analyzeRisk();
  }, [riskSettings, entryPrice, stopLossPrice, takeProfitPrice]);

  const calculatePositionSize = () => {
    const { accountBalance, riskPercentage } = riskSettings;
    const riskAmount = (accountBalance * riskPercentage) / 100;
    
    if (stopLossPrice > 0 && entryPrice > 0) {
      const stopLossDistance = Math.abs(entryPrice - stopLossPrice);
      const recommendedSize = riskAmount / stopLossDistance;
      const maxRisk = recommendedSize * stopLossDistance;
      
      let riskReward = 0;
      if (takeProfitPrice > 0) {
        const profitDistance = Math.abs(takeProfitPrice - entryPrice);
        riskReward = profitDistance / stopLossDistance;
      }
      
      // Kelly Criterion calculation (simplified)
      const winRate = 0.65; // Assume 65% win rate
      const avgWin = riskReward;
      const avgLoss = 1;
      const kellyPercent = ((winRate * avgWin) - ((1 - winRate) * avgLoss)) / avgWin;
      
      setPositionCalculation({
        recommendedSize: recommendedSize,
        maxRisk: maxRisk,
        riskReward: riskReward,
        probabilityOfLoss: (1 - winRate) * 100,
        kellyPercent: Math.max(0, kellyPercent * 100)
      });
    }
  };

  const analyzeRisk = () => {
    const warnings: string[] = [];
    const config = riskLevelConfigs[riskSettings.riskLevel];
    
    if (riskSettings.riskPercentage > config.maxRisk) {
      warnings.push(
        language === 'ar' 
          ? `نسبة المخاطرة مرتفعة جداً (${riskSettings.riskPercentage}%) للمستوى ${riskSettings.riskLevel}`
          : `Risk percentage too high (${riskSettings.riskPercentage}%) for ${riskSettings.riskLevel} level`
      );
    }
    
    if (riskSettings.maxDrawdown > config.maxDrawdown) {
      warnings.push(
        language === 'ar' 
          ? `نسبة الهبوط المسموح بها مرتفعة جداً (${riskSettings.maxDrawdown}%)`
          : `Maximum drawdown too high (${riskSettings.maxDrawdown}%)`
      );
    }
    
    if (positionCalculation.riskReward < 1.5) {
      warnings.push(
        language === 'ar' 
          ? `نسبة المخاطرة إلى الربح منخفضة (${positionCalculation.riskReward.toFixed(2)}:1)`
          : `Risk-reward ratio too low (${positionCalculation.riskReward.toFixed(2)}:1)`
      );
    }
    
    setRiskWarnings(warnings);
  };

  const applyRiskLevel = (level: 'conservative' | 'moderate' | 'aggressive') => {
    const config = riskLevelConfigs[level];
    setRiskSettings(prev => ({
      ...prev,
      riskLevel: level,
      riskPercentage: config.maxRisk,
      maxDrawdown: config.maxDrawdown,
      maxPositions: config.maxPositions
    }));
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2
    }).format(amount);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5 text-green-600" />
            {language === 'ar' ? 'إدارة المخاطر الذكية' : 'Smart Risk Management'}
          </CardTitle>
          <CardDescription>
            {language === 'ar' 
              ? 'حماية رأس المال من خلال حساب حجم الصفقات المثلى وإدارة المخاطر المتقدمة'
              : 'Protect your capital through optimal position sizing and advanced risk management'
            }
          </CardDescription>
        </CardHeader>
      </Card>

      {/* Risk Level Selection */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="h-5 w-5" />
            {language === 'ar' ? 'مستوى المخاطرة' : 'Risk Level'}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {Object.entries(riskLevelConfigs).map(([level, config]) => (
              <Card 
                key={level}
                className={`cursor-pointer transition-all ${
                  riskSettings.riskLevel === level 
                    ? 'ring-2 ring-primary' 
                    : 'hover:shadow-md'
                }`}
                onClick={() => applyRiskLevel(level as any)}
              >
                <CardContent className={`p-4 ${config.bgColor}`}>
                  <div className="text-center space-y-2">
                    <div className={`font-bold text-lg ${config.color}`}>
                      {language === 'ar' ? 
                        (level === 'conservative' ? 'محافظ' : 
                         level === 'moderate' ? 'متوسط' : 'عدواني') :
                        level.charAt(0).toUpperCase() + level.slice(1)
                      }
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {language === 'ar' ? 'مخاطرة' : 'Risk'}: {config.maxRisk}%
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {language === 'ar' ? 'هبوط' : 'Drawdown'}: {config.maxDrawdown}%
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Risk Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calculator className="h-5 w-5" />
            {language === 'ar' ? 'إعدادات المخاطرة' : 'Risk Settings'}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="accountBalance">
                {language === 'ar' ? 'رصيد الحساب' : 'Account Balance'}
              </Label>
              <Input
                id="accountBalance"
                type="number"
                value={riskSettings.accountBalance}
                onChange={(e) => setRiskSettings(prev => ({
                  ...prev,
                  accountBalance: Number(e.target.value)
                }))}
                className="text-right"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="riskPercentage">
                {language === 'ar' ? 'نسبة المخاطرة' : 'Risk Percentage'}: {riskSettings.riskPercentage}%
              </Label>
              <Slider
                value={[riskSettings.riskPercentage]}
                onValueChange={(value) => setRiskSettings(prev => ({
                  ...prev,
                  riskPercentage: value[0]
                }))}
                max={10}
                min={0.5}
                step={0.1}
                className="w-full"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="maxDrawdown">
                {language === 'ar' ? 'أقصى هبوط' : 'Max Drawdown'}: {riskSettings.maxDrawdown}%
              </Label>
              <Slider
                value={[riskSettings.maxDrawdown]}
                onValueChange={(value) => setRiskSettings(prev => ({
                  ...prev,
                  maxDrawdown: value[0]
                }))}
                max={50}
                min={5}
                step={1}
                className="w-full"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="maxPositions">
                {language === 'ar' ? 'أقصى عدد صفقات' : 'Max Positions'}: {riskSettings.maxPositions}
              </Label>
              <Slider
                value={[riskSettings.maxPositions]}
                onValueChange={(value) => setRiskSettings(prev => ({
                  ...prev,
                  maxPositions: value[0]
                }))}
                max={10}
                min={1}
                step={1}
                className="w-full"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Position Size Calculator */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calculator className="h-5 w-5" />
            {language === 'ar' ? 'حاسبة حجم الصفقة' : 'Position Size Calculator'}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="entryPrice">
                {language === 'ar' ? 'سعر الدخول' : 'Entry Price'}
              </Label>
              <Input
                id="entryPrice"
                type="number"
                value={entryPrice}
                onChange={(e) => setEntryPrice(Number(e.target.value))}
                step="0.01"
                className="text-right"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="stopLoss">
                {language === 'ar' ? 'وقف الخسارة' : 'Stop Loss'}
              </Label>
              <Input
                id="stopLoss"
                type="number"
                value={stopLossPrice}
                onChange={(e) => setStopLossPrice(Number(e.target.value))}
                step="0.01"
                className="text-right"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="takeProfit">
                {language === 'ar' ? 'جني الربح' : 'Take Profit'}
              </Label>
              <Input
                id="takeProfit"
                type="number"
                value={takeProfitPrice}
                onChange={(e) => setTakeProfitPrice(Number(e.target.value))}
                step="0.01"
                className="text-right"
              />
            </div>
          </div>

          {/* Calculation Results */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card className="bg-blue-50 dark:bg-blue-950/20">
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-blue-600">
                  {positionCalculation.recommendedSize.toFixed(2)}
                </div>
                <div className="text-sm text-muted-foreground">
                  {language === 'ar' ? 'حجم الصفقة المقترح' : 'Recommended Size'}
                </div>
              </CardContent>
            </Card>

            <Card className="bg-red-50 dark:bg-red-950/20">
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-red-600">
                  {formatCurrency(positionCalculation.maxRisk)}
                </div>
                <div className="text-sm text-muted-foreground">
                  {language === 'ar' ? 'أقصى مخاطرة' : 'Max Risk'}
                </div>
              </CardContent>
            </Card>

            <Card className="bg-green-50 dark:bg-green-950/20">
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-green-600">
                  {positionCalculation.riskReward.toFixed(2)}:1
                </div>
                <div className="text-sm text-muted-foreground">
                  {language === 'ar' ? 'نسبة المخاطرة/الربح' : 'Risk/Reward'}
                </div>
              </CardContent>
            </Card>

            <Card className="bg-purple-50 dark:bg-purple-950/20">
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-purple-600">
                  {positionCalculation.kellyPercent.toFixed(1)}%
                </div>
                <div className="text-sm text-muted-foreground">
                  {language === 'ar' ? 'نسبة كيلي' : 'Kelly %'}
                </div>
              </CardContent>
            </Card>
          </div>
        </CardContent>
      </Card>

      {/* Risk Warnings */}
      {riskWarnings.length > 0 && (
        <Card className="border-orange-200 bg-orange-50 dark:bg-orange-950/20">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-orange-600">
              <AlertTriangle className="h-5 w-5" />
              {language === 'ar' ? 'تحذيرات المخاطرة' : 'Risk Warnings'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {riskWarnings.map((warning, index) => (
                <Alert key={index} className="border-orange-200">
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription>{warning}</AlertDescription>
                </Alert>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Portfolio Risk Analysis */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5" />
            {language === 'ar' ? 'تحليل مخاطر المحفظة' : 'Portfolio Risk Analysis'}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">
                  {language === 'ar' ? 'القيمة المعرضة للخطر (VaR)' : 'Value at Risk (VaR)'}
                </span>
                <span className="font-medium">
                  {formatCurrency(riskSettings.accountBalance * 0.02)}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">
                  {language === 'ar' ? 'نسبة شارب' : 'Sharpe Ratio'}
                </span>
                <span className="font-medium">1.45</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">
                  {language === 'ar' ? 'نسبة الارتباط' : 'Correlation'}
                </span>
                <span className="font-medium">0.23</span>
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">
                  {language === 'ar' ? 'التنويع' : 'Diversification'}
                </span>
                <Badge variant="outline" className="text-green-600">
                  {language === 'ar' ? 'جيد' : 'Good'}
                </Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">
                  {language === 'ar' ? 'تركز المحفظة' : 'Portfolio Concentration'}
                </span>
                <Badge variant="outline" className="text-yellow-600">
                  {language === 'ar' ? 'متوسط' : 'Medium'}
                </Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">
                  {language === 'ar' ? 'تقييم المخاطر العام' : 'Overall Risk Score'}
                </span>
                <Badge variant="outline" className="text-green-600">
                  7.2/10
                </Badge>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useLanguageContext } from '@/components/language-provider';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { 
  CheckCircle, 
  AlertTriangle, 
  XCircle, 
  TrendingUp, 
  TrendingDown,
  Clock,
  Zap,
  Bug,
  Lightbulb,
  Wrench,
  BarChart3,
  Shield,
  Smartphone,
  Globe,
  Database,
  Cpu,
  Memory,
  Network,
  Settings,
  Star,
  ThumbsUp
} from 'lucide-react';

interface AnalysisResult {
  overall: {
    score: number;
    grade: string;
    status: 'excellent' | 'good' | 'needs_improvement' | 'critical';
  };
  categories: {
    performance: {
      score: number;
      issues: string[];
      improvements: string[];
    };
    security: {
      score: number;
      issues: string[];
      improvements: string[];
    };
    usability: {
      score: number;
      issues: string[];
      improvements: string[];
    };
    functionality: {
      score: number;
      issues: string[];
      improvements: string[];
    };
    architecture: {
      score: number;
      issues: string[];
      improvements: string[];
    };
  };
  criticalIssues: Array<{
    id: string;
    severity: 'critical' | 'high' | 'medium' | 'low';
    category: string;
    title: string;
    description: string;
    solution: string;
    impact: string;
    effort: 'low' | 'medium' | 'high';
  }>;
  recommendations: Array<{
    id: string;
    priority: 'high' | 'medium' | 'low';
    category: string;
    title: string;
    description: string;
    benefit: string;
    implementation: string;
  }>;
}

export function ApplicationAnalysisReport() {
  const { language } = useLanguageContext();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [analyzing, setAnalyzing] = useState(false);

  // Mock comprehensive analysis data
  const analysisData: AnalysisResult = {
    overall: {
      score: 78,
      grade: 'B+',
      status: 'good'
    },
    categories: {
      performance: {
        score: 65,
        issues: [
          language === 'ar' ? 'وقت التحميل بطيء (56 ثانية)' : 'Slow loading time (56 seconds)',
          language === 'ar' ? 'عدم وجود ضغط للملفات الثابتة' : 'Missing static file compression',
          language === 'ar' ? 'عدم تحسين الصور' : 'Unoptimized images',
          language === 'ar' ? 'عدد كبير من طلبات HTTP' : 'Too many HTTP requests'
        ],
        improvements: [
          language === 'ar' ? 'تفعيل التحميل التدريجي' : 'Enable lazy loading',
          language === 'ar' ? 'ضغط الملفات' : 'File compression',
          language === 'ar' ? 'تحسين حجم الحزم' : 'Bundle size optimization',
          language === 'ar' ? 'تخزين مؤقت محسن' : 'Enhanced caching'
        ]
      },
      security: {
        score: 85,
        issues: [
          language === 'ar' ? 'عدم وجود CSP headers' : 'Missing CSP headers',
          language === 'ar' ? 'مفاتيح API مكشوفة في العميل' : 'Exposed API keys in client'
        ],
        improvements: [
          language === 'ar' ? 'تطبيق HTTPS كامل' : 'Full HTTPS implementation',
          language === 'ar' ? 'تشفير البيانات الحساسة' : 'Encrypt sensitive data',
          language === 'ar' ? 'مصادقة ثنائية العامل' : 'Two-factor authentication'
        ]
      },
      usability: {
        score: 90,
        issues: [
          language === 'ar' ? 'بعض النصوص غير مترجمة' : 'Some untranslated text',
          language === 'ar' ? 'تحسينات RTL مطلوبة' : 'RTL improvements needed'
        ],
        improvements: [
          language === 'ar' ? 'واجهة محسنة للجوال' : 'Enhanced mobile interface',
          language === 'ar' ? 'إرشادات تفاعلية' : 'Interactive tutorials',
          language === 'ar' ? 'إمكانية الوصول المحسنة' : 'Enhanced accessibility'
        ]
      },
      functionality: {
        score: 88,
        issues: [
          language === 'ar' ? 'مفاتيح مكررة في React' : 'Duplicate React keys',
          language === 'ar' ? 'معالجة أخطاء محدودة' : 'Limited error handling'
        ],
        improvements: [
          language === 'ar' ? 'اختبارات آلية' : 'Automated testing',
          language === 'ar' ? 'مراقبة الأخطاء الفورية' : 'Real-time error monitoring',
          language === 'ar' ? 'نظام إشعارات محسن' : 'Enhanced notification system'
        ]
      },
      architecture: {
        score: 82,
        issues: [
          language === 'ar' ? 'تبعيات غير مستخدمة' : 'Unused dependencies',
          language === 'ar' ? 'كود مكرر' : 'Code duplication'
        ],
        improvements: [
          language === 'ar' ? 'هيكلة أفضل للمكونات' : 'Better component structure',
          language === 'ar' ? 'إدارة حالة محسنة' : 'Enhanced state management',
          language === 'ar' ? 'توثيق تقني شامل' : 'Comprehensive technical documentation'
        ]
      }
    },
    criticalIssues: [
      {
        id: 'perf-001',
        severity: 'critical',
        category: 'Performance',
        title: language === 'ar' ? 'وقت التحميل المفرط' : 'Excessive Loading Time',
        description: language === 'ar' 
          ? 'التطبيق يستغرق 56 ثانية للتحميل الكامل، وهو أبطأ بكثير من المعايير المقبولة (3-5 ثواني)' 
          : 'Application takes 56 seconds to fully load, much slower than acceptable standards (3-5 seconds)',
        solution: language === 'ar' 
          ? 'تطبيق التحميل التدريجي، ضغط الملفات، تحسين الحزم، وتحسين استعلامات قاعدة البيانات' 
          : 'Implement lazy loading, file compression, bundle optimization, and database query optimization',
        impact: language === 'ar' ? 'تأثير كبير على تجربة المستخدم ومعدلات التحويل' : 'Major impact on user experience and conversion rates',
        effort: 'high'
      },
      {
        id: 'react-002',
        severity: 'high',
        category: 'Code Quality',
        title: language === 'ar' ? 'مفاتيح React مكررة' : 'Duplicate React Keys',
        description: language === 'ar' 
          ? 'مفاتيح مكررة في الشريط الجانبي تسبب تحذيرات وقد تؤثر على الأداء' 
          : 'Duplicate keys in sidebar causing warnings and potential performance issues',
        solution: language === 'ar' 
          ? 'مراجعة وإصلاح جميع مفاتيح المكونات لضمان الفردية' 
          : 'Review and fix all component keys to ensure uniqueness',
        impact: language === 'ar' ? 'تحذيرات في وحدة التحكم ومشاكل محتملة في العرض' : 'Console warnings and potential rendering issues',
        effort: 'low'
      },
      {
        id: 'sec-003',
        severity: 'medium',
        category: 'Security',
        title: language === 'ar' ? 'عدم وجود رؤوس الأمان' : 'Missing Security Headers',
        description: language === 'ar' 
          ? 'عدم وجود Content Security Policy ورؤوس أمان أخرى مهمة' 
          : 'Missing Content Security Policy and other important security headers',
        solution: language === 'ar' 
          ? 'إضافة رؤوس CSP، X-Frame-Options، وغيرها من رؤوس الأمان' 
          : 'Add CSP headers, X-Frame-Options, and other security headers',
        impact: language === 'ar' ? 'ثغرات أمنية محتملة' : 'Potential security vulnerabilities',
        effort: 'medium'
      }
    ],
    recommendations: [
      {
        id: 'rec-001',
        priority: 'high',
        category: 'Performance',
        title: language === 'ar' ? 'تطبيق Progressive Web App كامل' : 'Full Progressive Web App Implementation',
        description: language === 'ar' 
          ? 'تحسين PWA مع service workers محسنة وإستراتيجيات تخزين مؤقت متقدمة' 
          : 'Enhanced PWA with optimized service workers and advanced caching strategies',
        benefit: language === 'ar' ? 'تحسين كبير في الأداء وتجربة أفضل في وضع عدم الاتصال' : 'Significant performance improvement and better offline experience',
        implementation: language === 'ar' ? 'تحديث service worker، إضافة استراتيجيات تخزين مؤقت ذكية' : 'Update service worker, add smart caching strategies'
      },
      {
        id: 'rec-002',
        priority: 'high',
        category: 'Monitoring',
        title: language === 'ar' ? 'نظام مراقبة شامل' : 'Comprehensive Monitoring System',
        description: language === 'ar' 
          ? 'تطبيق مراقبة فورية للأداء والأخطاء مع تنبيهات ذكية' 
          : 'Implement real-time performance and error monitoring with smart alerts',
        benefit: language === 'ar' ? 'اكتشاف وحل المشاكل بشكل استباقي' : 'Proactive issue detection and resolution',
        implementation: language === 'ar' ? 'دمج أدوات مراقبة، إعداد تنبيهات، لوحات تحكم تحليلية' : 'Integrate monitoring tools, setup alerts, analytics dashboards'
      },
      {
        id: 'rec-003',
        priority: 'medium',
        category: 'User Experience',
        title: language === 'ar' ? 'واجهة ذكية تكيفية' : 'Adaptive Smart Interface',
        description: language === 'ar' 
          ? 'واجهة تتكيف مع سلوك المستخدم وتفضيلاته التجارية' 
          : 'Interface that adapts to user behavior and trading preferences',
        benefit: language === 'ar' ? 'تجربة مستخدم مخصصة وكفاءة أعلى' : 'Personalized user experience and higher efficiency',
        implementation: language === 'ar' ? 'خوارزميات تعلم آلي، واجهة تكيفية، تخصيص ذكي' : 'ML algorithms, adaptive UI, smart personalization'
      }
    ]
  };

  const runComprehensiveAnalysis = useMutation({
    mutationFn: () => apiRequest('/api/analysis/comprehensive', {
      method: 'POST',
    }),
    onMutate: () => {
      setAnalyzing(true);
    },
    onSuccess: () => {
      toast({
        title: language === 'ar' ? 'اكتمل التحليل' : 'Analysis Complete',
        description: language === 'ar' 
          ? 'تم إنجاز التحليل الشامل للتطبيق بنجاح' 
          : 'Comprehensive application analysis completed successfully',
      });
      queryClient.invalidateQueries({ queryKey: ['/api/analysis/results'] });
    },
    onError: () => {
      toast({
        title: language === 'ar' ? 'خطأ في التحليل' : 'Analysis Error',
        description: language === 'ar' 
          ? 'فشل في إجراء التحليل الشامل' 
          : 'Failed to perform comprehensive analysis',
        variant: 'destructive',
      });
    },
    onSettled: () => {
      setAnalyzing(false);
    },
  });

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'destructive';
      case 'high': return 'default';
      case 'medium': return 'secondary';
      case 'low': return 'outline';
      default: return 'secondary';
    }
  };

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'critical': return XCircle;
      case 'high': return AlertTriangle;
      case 'medium': return Clock;
      case 'low': return CheckCircle;
      default: return Clock;
    }
  };

  const getScoreColor = (score: number) => {
    if (score >= 90) return 'text-green-600';
    if (score >= 75) return 'text-blue-600';
    if (score >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getGradeColor = (grade: string) => {
    if (grade.startsWith('A')) return 'bg-green-100 text-green-800';
    if (grade.startsWith('B')) return 'bg-blue-100 text-blue-800';
    if (grade.startsWith('C')) return 'bg-yellow-100 text-yellow-800';
    return 'bg-red-100 text-red-800';
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">
            {language === 'ar' ? 'تقرير تحليل التطبيق الشامل' : 'Comprehensive Application Analysis Report'}
          </h2>
          <p className="text-muted-foreground">
            {language === 'ar' 
              ? 'تحليل متقدم لجميع جوانب التطبيق مع توصيات للتحسين' 
              : 'Advanced analysis of all application aspects with improvement recommendations'}
          </p>
        </div>
        <Button
          onClick={() => runComprehensiveAnalysis.mutate()}
          disabled={analyzing}
          size="lg"
          className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
        >
          {analyzing ? (
            <>
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
              {language === 'ar' ? 'جاري التحليل...' : 'Analyzing...'}
            </>
          ) : (
            <>
              <BarChart3 className="h-4 w-4 mr-2" />
              {language === 'ar' ? 'تشغيل التحليل الشامل' : 'Run Comprehensive Analysis'}
            </>
          )}
        </Button>
      </div>

      {/* Overall Score Card */}
      <Card className="border-2 border-primary/20">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>{language === 'ar' ? 'النتيجة الإجمالية' : 'Overall Score'}</span>
            <Badge className={getGradeColor(analysisData.overall.grade)}>
              {analysisData.overall.grade}
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center space-x-4">
            <div className="flex-1">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">
                  {language === 'ar' ? 'صحة التطبيق العامة' : 'Application Health'}
                </span>
                <span className={`text-2xl font-bold ${getScoreColor(analysisData.overall.score)}`}>
                  {analysisData.overall.score}%
                </span>
              </div>
              <Progress value={analysisData.overall.score} className="h-3" />
              <p className="text-sm text-muted-foreground mt-2">
                {analysisData.overall.status === 'excellent' 
                  ? (language === 'ar' ? 'ممتاز - التطبيق في حالة مثلى' : 'Excellent - Application in optimal condition')
                  : analysisData.overall.status === 'good'
                  ? (language === 'ar' ? 'جيد - يحتاج تحسينات طفيفة' : 'Good - Needs minor improvements')
                  : analysisData.overall.status === 'needs_improvement'
                  ? (language === 'ar' ? 'يحتاج تحسين - مشاكل متوسطة' : 'Needs improvement - Moderate issues')
                  : (language === 'ar' ? 'حرج - يتطلب انتباه فوري' : 'Critical - Requires immediate attention')}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="overview">
            {language === 'ar' ? 'نظرة عامة' : 'Overview'}
          </TabsTrigger>
          <TabsTrigger value="issues">
            {language === 'ar' ? 'المشاكل' : 'Issues'}
          </TabsTrigger>
          <TabsTrigger value="recommendations">
            {language === 'ar' ? 'التوصيات' : 'Recommendations'}
          </TabsTrigger>
          <TabsTrigger value="categories">
            {language === 'ar' ? 'الفئات' : 'Categories'}
          </TabsTrigger>
          <TabsTrigger value="action-plan">
            {language === 'ar' ? 'خطة العمل' : 'Action Plan'}
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {Object.entries(analysisData.categories).map(([category, data]) => (
              <Card key={category}>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium capitalize">
                    {category === 'performance' 
                      ? (language === 'ar' ? 'الأداء' : 'Performance')
                      : category === 'security'
                      ? (language === 'ar' ? 'الأمان' : 'Security')
                      : category === 'usability'
                      ? (language === 'ar' ? 'سهولة الاستخدام' : 'Usability')
                      : category === 'functionality'
                      ? (language === 'ar' ? 'الوظائف' : 'Functionality')
                      : (language === 'ar' ? 'الهيكلة' : 'Architecture')}
                  </CardTitle>
                  {category === 'performance' && <Zap className="h-4 w-4 text-muted-foreground" />}
                  {category === 'security' && <Shield className="h-4 w-4 text-muted-foreground" />}
                  {category === 'usability' && <Smartphone className="h-4 w-4 text-muted-foreground" />}
                  {category === 'functionality' && <Settings className="h-4 w-4 text-muted-foreground" />}
                  {category === 'architecture' && <Database className="h-4 w-4 text-muted-foreground" />}
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold mb-2 text-center">
                    <span className={getScoreColor(data.score)}>{data.score}%</span>
                  </div>
                  <Progress value={data.score} className="mb-3" />
                  <div className="space-y-2">
                    <div className="text-xs text-muted-foreground">
                      <span className="font-medium">
                        {language === 'ar' ? 'المشاكل:' : 'Issues:'} 
                      </span>
                      <span className="ml-1">{data.issues.length}</span>
                    </div>
                    <div className="text-xs text-muted-foreground">
                      <span className="font-medium">
                        {language === 'ar' ? 'التحسينات:' : 'Improvements:'} 
                      </span>
                      <span className="ml-1">{data.improvements.length}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="issues" className="space-y-6">
          <div className="space-y-4">
            {analysisData.criticalIssues.map((issue) => {
              const SeverityIcon = getSeverityIcon(issue.severity);
              return (
                <Card key={issue.id} className="border-l-4 border-l-red-500">
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <SeverityIcon className="h-5 w-5" />
                        {issue.title}
                      </div>
                      <div className="flex gap-2">
                        <Badge variant={getSeverityColor(issue.severity)}>
                          {issue.severity === 'critical' 
                            ? (language === 'ar' ? 'حرج' : 'Critical')
                            : issue.severity === 'high'
                            ? (language === 'ar' ? 'عالي' : 'High')
                            : issue.severity === 'medium'
                            ? (language === 'ar' ? 'متوسط' : 'Medium')
                            : (language === 'ar' ? 'منخفض' : 'Low')}
                        </Badge>
                        <Badge variant="outline">{issue.category}</Badge>
                      </div>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <p className="text-sm text-muted-foreground">
                        {issue.description}
                      </p>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <h4 className="font-medium text-sm mb-2">
                            {language === 'ar' ? 'الحل المقترح:' : 'Proposed Solution:'}
                          </h4>
                          <p className="text-sm text-muted-foreground">
                            {issue.solution}
                          </p>
                        </div>
                        <div>
                          <h4 className="font-medium text-sm mb-2">
                            {language === 'ar' ? 'التأثير:' : 'Impact:'}
                          </h4>
                          <p className="text-sm text-muted-foreground">
                            {issue.impact}
                          </p>
                        </div>
                      </div>
                      <div className="flex justify-between items-center pt-2 border-t">
                        <span className="text-sm">
                          {language === 'ar' ? 'الجهد المطلوب:' : 'Required Effort:'}
                        </span>
                        <Badge variant={issue.effort === 'high' ? 'destructive' : issue.effort === 'medium' ? 'default' : 'secondary'}>
                          {issue.effort === 'high' 
                            ? (language === 'ar' ? 'عالي' : 'High')
                            : issue.effort === 'medium'
                            ? (language === 'ar' ? 'متوسط' : 'Medium')
                            : (language === 'ar' ? 'منخفض' : 'Low')}
                        </Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>

        <TabsContent value="recommendations" className="space-y-6">
          <div className="space-y-4">
            {analysisData.recommendations.map((rec) => (
              <Card key={rec.id} className="border-l-4 border-l-blue-500">
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Lightbulb className="h-5 w-5 text-blue-500" />
                      {rec.title}
                    </div>
                    <div className="flex gap-2">
                      <Badge variant={rec.priority === 'high' ? 'default' : rec.priority === 'medium' ? 'secondary' : 'outline'}>
                        {rec.priority === 'high' 
                          ? (language === 'ar' ? 'أولوية عالية' : 'High Priority')
                          : rec.priority === 'medium'
                          ? (language === 'ar' ? 'أولوية متوسطة' : 'Medium Priority')
                          : (language === 'ar' ? 'أولوية منخفضة' : 'Low Priority')}
                      </Badge>
                      <Badge variant="outline">{rec.category}</Badge>
                    </div>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <p className="text-sm text-muted-foreground">
                      {rec.description}
                    </p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <h4 className="font-medium text-sm mb-2 text-green-600">
                          {language === 'ar' ? 'الفوائد المتوقعة:' : 'Expected Benefits:'}
                        </h4>
                        <p className="text-sm text-muted-foreground">
                          {rec.benefit}
                        </p>
                      </div>
                      <div>
                        <h4 className="font-medium text-sm mb-2 text-blue-600">
                          {language === 'ar' ? 'خطوات التنفيذ:' : 'Implementation Steps:'}
                        </h4>
                        <p className="text-sm text-muted-foreground">
                          {rec.implementation}
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="categories" className="space-y-6">
          {Object.entries(analysisData.categories).map(([category, data]) => (
            <Card key={category}>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  {category === 'performance' && <Zap className="h-5 w-5" />}
                  {category === 'security' && <Shield className="h-5 w-5" />}
                  {category === 'usability' && <Smartphone className="h-5 w-5" />}
                  {category === 'functionality' && <Settings className="h-5 w-5" />}
                  {category === 'architecture' && <Database className="h-5 w-5" />}
                  {category === 'performance' 
                    ? (language === 'ar' ? 'تفاصيل الأداء' : 'Performance Details')
                    : category === 'security'
                    ? (language === 'ar' ? 'تفاصيل الأمان' : 'Security Details')
                    : category === 'usability'
                    ? (language === 'ar' ? 'تفاصيل سهولة الاستخدام' : 'Usability Details')
                    : category === 'functionality'
                    ? (language === 'ar' ? 'تفاصيل الوظائف' : 'Functionality Details')
                    : (language === 'ar' ? 'تفاصيل الهيكلة' : 'Architecture Details')}
                  <Badge className={getScoreColor(data.score).replace('text-', 'bg-').replace('-600', '-100') + ' ' + getScoreColor(data.score).replace('-600', '-800')}>
                    {data.score}%
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-medium text-sm mb-3 text-red-600">
                      {language === 'ar' ? 'المشاكل المكتشفة:' : 'Identified Issues:'}
                    </h4>
                    <ul className="space-y-2">
                      {data.issues.map((issue, index) => (
                        <li key={index} className="flex items-start gap-2 text-sm">
                          <XCircle className="h-4 w-4 text-red-500 mt-0.5 flex-shrink-0" />
                          {issue}
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-medium text-sm mb-3 text-green-600">
                      {language === 'ar' ? 'التحسينات المقترحة:' : 'Suggested Improvements:'}
                    </h4>
                    <ul className="space-y-2">
                      {data.improvements.map((improvement, index) => (
                        <li key={index} className="flex items-start gap-2 text-sm">
                          <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                          {improvement}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="action-plan" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Wrench className="h-5 w-5" />
                {language === 'ar' ? 'خطة العمل الموصى بها' : 'Recommended Action Plan'}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div>
                  <h4 className="font-medium text-sm mb-3 text-red-600">
                    {language === 'ar' ? 'المرحلة الأولى - الإصلاحات الحرجة (1-2 أسابيع):' : 'Phase 1 - Critical Fixes (1-2 weeks):'}
                  </h4>
                  <ul className="space-y-2 ml-4">
                    <li className="flex items-center gap-2 text-sm">
                      <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                      {language === 'ar' ? 'إصلاح مفاتيح React المكررة' : 'Fix duplicate React keys'}
                    </li>
                    <li className="flex items-center gap-2 text-sm">
                      <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                      {language === 'ar' ? 'تحسين وقت التحميل الأولي' : 'Optimize initial loading time'}
                    </li>
                    <li className="flex items-center gap-2 text-sm">
                      <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                      {language === 'ar' ? 'إضافة رؤوس الأمان الأساسية' : 'Add basic security headers'}
                    </li>
                  </ul>
                </div>

                <div>
                  <h4 className="font-medium text-sm mb-3 text-yellow-600">
                    {language === 'ar' ? 'المرحلة الثانية - تحسينات الأداء (2-4 أسابيع):' : 'Phase 2 - Performance Improvements (2-4 weeks):'}
                  </h4>
                  <ul className="space-y-2 ml-4">
                    <li className="flex items-center gap-2 text-sm">
                      <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
                      {language === 'ar' ? 'تطبيق التحميل التدريجي للمكونات' : 'Implement component lazy loading'}
                    </li>
                    <li className="flex items-center gap-2 text-sm">
                      <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
                      {language === 'ar' ? 'ضغط وتحسين الملفات الثابتة' : 'Compress and optimize static files'}
                    </li>
                    <li className="flex items-center gap-2 text-sm">
                      <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
                      {language === 'ar' ? 'تحسين استراتيجيات التخزين المؤقت' : 'Enhance caching strategies'}
                    </li>
                  </ul>
                </div>

                <div>
                  <h4 className="font-medium text-sm mb-3 text-blue-600">
                    {language === 'ar' ? 'المرحلة الثالثة - تحسينات متقدمة (1-2 شهر):' : 'Phase 3 - Advanced Enhancements (1-2 months):'}
                  </h4>
                  <ul className="space-y-2 ml-4">
                    <li className="flex items-center gap-2 text-sm">
                      <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                      {language === 'ar' ? 'تطبيق PWA كامل مع إمكانيات متقدمة' : 'Full PWA implementation with advanced capabilities'}
                    </li>
                    <li className="flex items-center gap-2 text-sm">
                      <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                      {language === 'ar' ? 'نظام مراقبة وتحليلات شامل' : 'Comprehensive monitoring and analytics system'}
                    </li>
                    <li className="flex items-center gap-2 text-sm">
                      <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                      {language === 'ar' ? 'واجهة ذكية تكيفية' : 'Adaptive smart interface'}
                    </li>
                  </ul>
                </div>

                <div className="pt-4 border-t">
                  <div className="flex items-center justify-between">
                    <span className="font-medium">
                      {language === 'ar' ? 'النتيجة المتوقعة بعد التطبيق:' : 'Expected Score After Implementation:'}
                    </span>
                    <div className="flex items-center gap-2">
                      <span className="text-2xl font-bold text-green-600">95%</span>
                      <Badge className="bg-green-100 text-green-800">A+</Badge>
                    </div>
                  </div>
                  <Progress value={95} className="mt-2" />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { TrendingUp, TrendingDown, Brain, Target, Users, BarChart3, AlertTriangle } from 'lucide-react';
import { LoadingSpinner, SkeletonCard } from '@/components/LoadingSpinner';
import { ErrorBoundary } from '@/components/ErrorBoundary';

interface MLInsights {
  totalFeedback: number;
  overallSuccessRate: number;
  topAssets: Array<{
    symbol: string;
    successRate: number;
    totalTrades: number;
  }>;
  improvementSuggestions: string[];
}

interface AssetRecommendations {
  topPerformers: string[];
  averagePerformers: string[];
  poorPerformers: string[];
}

interface AssetPerformance {
  assetSymbol: string;
  totalRecommendations: number;
  successfulTrades: number;
  partialSuccessTrades: number;
  failedTrades: number;
  successRate: number;
  adjustedSuccessRate: number;
}

export function MLInsights() {
  const { data: insightsData, isLoading: insightsLoading, error: insightsError } = useQuery({
    queryKey: ['/api/ml/insights'],
    refetchInterval: 60000, // Reduce frequency to improve performance
    retry: 3,
    staleTime: 30000,
  });

  const { data: performanceData, isLoading: performanceLoading, error: performanceError } = useQuery({
    queryKey: ['/api/ml/performance'],
    refetchInterval: 60000,
    retry: 3,
    staleTime: 30000,
  });

  const insights: MLInsights = (insightsData as any)?.insights || {
    totalFeedback: 0,
    overallSuccessRate: 0,
    topAssets: [],
    improvementSuggestions: []
  };

  const assetRecommendations: AssetRecommendations = (insightsData as any)?.assetRecommendations || {
    topPerformers: [],
    averagePerformers: [],
    poorPerformers: []
  };

  const allPerformance: AssetPerformance[] = (performanceData as any)?.performance || [];

  // Handle errors
  if (insightsError || performanceError) {
    return (
      <Card className="w-full">
        <CardContent className="p-6">
          <div className="flex flex-col items-center gap-4 text-center">
            <AlertTriangle className="h-12 w-12 text-amber-500" />
            <div>
              <h3 className="text-lg font-semibold mb-2">لا يمكن تحميل البيانات</h3>
              <p className="text-muted-foreground mb-4">
                حدث خطأ أثناء جلب بيانات التحليلات. يرجى المحاولة مرة أخرى.
              </p>
              <div className="text-sm text-muted-foreground">
                {insightsError?.message || performanceError?.message || 'خطأ غير معروف'}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (insightsLoading || performanceLoading) {
    return (
      <div className="space-y-6">
        <LoadingSpinner variant="ai" text="تحليل بيانات الذكاء الاصطناعي..." />
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {[...Array(4)].map((_, i) => (
            <SkeletonCard key={i} />
          ))}
        </div>
        <div className="grid gap-4">
          {[...Array(2)].map((_, i) => (
            <SkeletonCard key={i} className="h-64" />
          ))}
        </div>
      </div>
    );
  }

  const getSuccessRateColor = (rate: number) => {
    if (rate >= 75) return 'text-green-600 dark:text-green-400';
    if (rate >= 50) return 'text-yellow-600 dark:text-yellow-400';
    return 'text-red-600 dark:text-red-400';
  };

  const getSuccessRateIcon = (rate: number) => {
    return rate >= 50 ? <TrendingUp className="h-4 w-4" /> : <TrendingDown className="h-4 w-4" />;
  };

  return (
    <div className="space-y-6">
      {/* Overall Statistics */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">إجمالي التفاعلات</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{insights.totalFeedback}</div>
            <p className="text-xs text-muted-foreground">
              ردود المستخدمين على التوصيات
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">معدل النجاح العام</CardTitle>
            <Target className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold flex items-center gap-2 ${getSuccessRateColor(insights.overallSuccessRate)}`}>
              {insights.overallSuccessRate.toFixed(1)}%
              {getSuccessRateIcon(insights.overallSuccessRate)}
            </div>
            <Progress value={insights.overallSuccessRate} className="mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">الأصول عالية الأداء</CardTitle>
            <TrendingUp className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {assetRecommendations.topPerformers.length}
            </div>
            <p className="text-xs text-muted-foreground">
              أصول بمعدل نجاح أعلى من 75%
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">التحليل الذكي</CardTitle>
            <Brain className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-600">فعال</div>
            <p className="text-xs text-muted-foreground">
              نظام التعلم الآلي يعمل
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Top Performing Assets */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5" />
            أفضل الأصول أداءً
          </CardTitle>
          <CardDescription>
            الأصول التي حققت أعلى معدلات نجاح بناءً على تفاعلات المستخدمين
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {insights.topAssets.slice(0, 5).map((asset, index) => (
              <div key={asset.symbol} className="flex items-center justify-between p-3 rounded-lg border">
                <div className="flex items-center gap-3">
                  <Badge variant="secondary" className="text-xs">
                    #{index + 1}
                  </Badge>
                  <div>
                    <p className="font-medium">{asset.symbol}</p>
                    <p className="text-sm text-muted-foreground">
                      {asset.totalTrades} صفقة
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <div className={`text-lg font-bold ${getSuccessRateColor(asset.successRate)}`}>
                    {asset.successRate.toFixed(1)}%
                  </div>
                  <Progress value={asset.successRate} className="w-20" />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Asset Categories */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle className="text-green-600 flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              الأصول المتميزة
            </CardTitle>
            <CardDescription>معدل نجاح أعلى من 75%</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {assetRecommendations.topPerformers.slice(0, 5).map((asset) => (
                <Badge key={asset} variant="outline" className="text-green-600 border-green-200">
                  {asset}
                </Badge>
              ))}
              {assetRecommendations.topPerformers.length === 0 && (
                <p className="text-sm text-muted-foreground">لا توجد بيانات كافية</p>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-yellow-600 flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              الأصول المتوسطة
            </CardTitle>
            <CardDescription>معدل نجاح بين 40-75%</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {assetRecommendations.averagePerformers.slice(0, 5).map((asset) => (
                <Badge key={asset} variant="outline" className="text-yellow-600 border-yellow-200">
                  {asset}
                </Badge>
              ))}
              {assetRecommendations.averagePerformers.length === 0 && (
                <p className="text-sm text-muted-foreground">لا توجد بيانات</p>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-red-600 flex items-center gap-2">
              <TrendingDown className="h-4 w-4" />
              الأصول المتحدية
            </CardTitle>
            <CardDescription>معدل نجاح أقل من 40%</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {assetRecommendations.poorPerformers.slice(0, 5).map((asset) => (
                <Badge key={asset} variant="outline" className="text-red-600 border-red-200">
                  {asset}
                </Badge>
              ))}
              {assetRecommendations.poorPerformers.length === 0 && (
                <p className="text-sm text-muted-foreground">لا توجد أصول ضعيفة</p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Improvement Suggestions */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="h-5 w-5 text-purple-600" />
            توصيات التحسين
          </CardTitle>
          <CardDescription>
            اقتراحات الذكاء الاصطناعي لتحسين أداء التوصيات
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {insights.improvementSuggestions.map((suggestion, index) => (
              <div key={index} className="flex items-start gap-3 p-3 rounded-lg bg-purple-50 dark:bg-purple-900/10 border border-purple-200 dark:border-purple-800">
                <Badge variant="outline" className="mt-0.5 text-purple-600 border-purple-300">
                  {index + 1}
                </Badge>
                <p className="text-sm text-purple-800 dark:text-purple-200">
                  {suggestion}
                </p>
              </div>
            ))}
            {insights.improvementSuggestions.length === 0 && (
              <p className="text-sm text-muted-foreground text-center py-4">
                لا توجد اقتراحات في الوقت الحالي
              </p>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
import { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Brain, TrendingUp, Users, Bot, ChevronRight, BarChart3 } from 'lucide-react';
import { useLanguage } from '../hooks/use-language';

interface AILearningData {
  timestamp: string;
  insights: {
    totalFeedbackProcessed: number;
    averageAccuracyImprovement: number;
    learningVelocity: number;
    topPerformingAssets: Array<{
      symbol: string;
      accuracy: number;
      confidence: number;
    }>;
    recommendations: Array<{
      type: string;
      description: string;
      impact: number;
    }>;
  };
  confidenceAdjustments: Array<{
    asset: string;
    baseConfidence: number;
    adjustedConfidence: number;
    adjustment: number;
    reason: string;
  }>;
  feedbackPatterns: {
    successRate: number;
    averageResponseTime: number;
    mostActiveBuyers: number;
    mostActiveSellers: number;
  };
  message: string;
}

export function AILearningDemo() {
  const { language } = useLanguage();
  const [learningData, setLearningData] = useState<AILearningData | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const demonstrateAILearning = async () => {
    setIsLoading(true);
    try {
      const response = await fetch('/api/ai/demonstrate-learning', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (response.ok) {
        const data = await response.json();
        setLearningData(data);
      }
    } catch (error) {
      console.error('Error demonstrating AI learning:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* AI Learning Header */}
      <Card className="bg-gradient-to-r from-blue-500/10 to-purple-500/10 border-blue-200 dark:border-blue-800">
        <CardHeader>
          <div className="flex items-center gap-3">
            <div className="p-2 bg-blue-500/20 rounded-lg">
              <Brain className="h-6 w-6 text-blue-600 dark:text-blue-400" />
            </div>
            <div>
              <CardTitle className="text-xl">
                {language === 'ar' ? 'نظام التعلم الآلي المتقدم' : 'Advanced AI Learning System'}
              </CardTitle>
              <CardDescription>
                {language === 'ar' 
                  ? 'الذكاء الاصطناعي يتعلم من تفاعلات المستخدمين ويحسن دقة التوصيات باستمرار'
                  : 'AI learns from user interactions and continuously improves recommendation accuracy'
                }
              </CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Button 
            onClick={demonstrateAILearning}
            disabled={isLoading}
            className="w-full bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600"
          >
            {isLoading ? (
              <div className="flex items-center gap-2">
                <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent"></div>
                {language === 'ar' ? 'جاري التحليل...' : 'Analyzing...'}
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <Bot className="h-4 w-4" />
                {language === 'ar' ? 'عرض كيفية تعلم الذكاء الاصطناعي' : 'Demonstrate AI Learning'}
                <ChevronRight className="h-4 w-4" />
              </div>
            )}
          </Button>
        </CardContent>
      </Card>

      {/* Learning Results */}
      {learningData && (
        <div className="grid gap-6 md:grid-cols-2">
          {/* AI Insights */}
          <Card>
            <CardHeader>
              <div className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-green-500" />
                <CardTitle className="text-lg">
                  {language === 'ar' ? 'رؤى الذكاء الاصطناعي' : 'AI Insights'}
                </CardTitle>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">
                    {language === 'ar' ? 'إجمالي التفاعلات المعالجة' : 'Total Feedback Processed'}
                  </span>
                  <Badge variant="secondary">
                    {learningData.insights.totalFeedbackProcessed}
                  </Badge>
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">
                      {language === 'ar' ? 'تحسن الدقة' : 'Accuracy Improvement'}
                    </span>
                    <span className="text-sm font-medium text-green-600">
                      +{learningData.insights.averageAccuracyImprovement.toFixed(1)}%
                    </span>
                  </div>
                  <Progress 
                    value={learningData.insights.averageAccuracyImprovement} 
                    className="h-2"
                  />
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">
                      {language === 'ar' ? 'سرعة التعلم' : 'Learning Velocity'}
                    </span>
                    <span className="text-sm font-medium text-blue-600">
                      {learningData.insights.learningVelocity.toFixed(2)}x
                    </span>
                  </div>
                  <Progress 
                    value={learningData.insights.learningVelocity * 10} 
                    className="h-2"
                  />
                </div>
              </div>

              {/* Top Performing Assets */}
              <div className="space-y-2">
                <h4 className="font-medium text-sm">
                  {language === 'ar' ? 'أفضل الأصول أداءً' : 'Top Performing Assets'}
                </h4>
                {learningData.insights.topPerformingAssets.map((asset, index) => (
                  <div key={index} className="flex justify-between items-center p-2 bg-muted/50 rounded">
                    <span className="font-medium text-sm">{asset.symbol}</span>
                    <div className="flex gap-2">
                      <Badge variant="outline" className="text-xs">
                        {asset.accuracy.toFixed(1)}%
                      </Badge>
                      <Badge variant="secondary" className="text-xs">
                        {asset.confidence.toFixed(1)}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Confidence Adjustments */}
          <Card>
            <CardHeader>
              <div className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5 text-blue-500" />
                <CardTitle className="text-lg">
                  {language === 'ar' ? 'تعديلات الثقة المتعلمة' : 'ML Confidence Adjustments'}
                </CardTitle>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {learningData.confidenceAdjustments.map((adjustment, index) => (
                <div key={index} className="space-y-2 p-3 border rounded-lg">
                  <div className="flex justify-between items-center">
                    <span className="font-medium">{adjustment.asset}</span>
                    <Badge 
                      variant={adjustment.adjustment > 0 ? "default" : "destructive"}
                      className="text-xs"
                    >
                      {adjustment.adjustment > 0 ? '+' : ''}{adjustment.adjustment.toFixed(1)}%
                    </Badge>
                  </div>
                  
                  <div className="flex justify-between text-sm text-muted-foreground">
                    <span>
                      {language === 'ar' ? 'الأساسية:' : 'Base:'} {adjustment.baseConfidence.toFixed(1)}%
                    </span>
                    <span>
                      {language === 'ar' ? 'المعدلة:' : 'Adjusted:'} {adjustment.adjustedConfidence.toFixed(1)}%
                    </span>
                  </div>
                  
                  <p className="text-xs text-muted-foreground">
                    {adjustment.reason}
                  </p>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Feedback Patterns */}
          <Card className="md:col-span-2">
            <CardHeader>
              <div className="flex items-center gap-2">
                <Users className="h-5 w-5 text-purple-500" />
                <CardTitle className="text-lg">
                  {language === 'ar' ? 'أنماط تفاعل المستخدمين' : 'User Interaction Patterns'}
                </CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="text-center space-y-2">
                  <div className="text-2xl font-bold text-green-600">
                    {learningData.feedbackPatterns.successRate.toFixed(1)}%
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {language === 'ar' ? 'معدل النجاح' : 'Success Rate'}
                  </div>
                </div>
                
                <div className="text-center space-y-2">
                  <div className="text-2xl font-bold text-blue-600">
                    {learningData.feedbackPatterns.averageResponseTime.toFixed(1)}s
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {language === 'ar' ? 'متوسط الاستجابة' : 'Avg Response'}
                  </div>
                </div>
                
                <div className="text-center space-y-2">
                  <div className="text-2xl font-bold text-emerald-600">
                    {learningData.feedbackPatterns.mostActiveBuyers}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {language === 'ar' ? 'إشارات الشراء' : 'Buy Signals'}
                  </div>
                </div>
                
                <div className="text-center space-y-2">
                  <div className="text-2xl font-bold text-orange-600">
                    {learningData.feedbackPatterns.mostActiveSellers}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {language === 'ar' ? 'إشارات البيع' : 'Sell Signals'}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* AI Learning Message */}
      {learningData && (
        <Card className="bg-gradient-to-r from-emerald-500/10 to-teal-500/10 border-emerald-200 dark:border-emerald-800">
          <CardContent className="pt-6">
            <div className="text-center space-y-2">
              <div className="p-3 bg-emerald-500/20 rounded-full w-fit mx-auto">
                <Brain className="h-6 w-6 text-emerald-600 dark:text-emerald-400" />
              </div>
              <p className="text-sm text-emerald-800 dark:text-emerald-200 font-medium">
                {learningData.message}
              </p>
              <p className="text-xs text-muted-foreground">
                {language === 'ar' 
                  ? `آخر تحديث: ${new Date(learningData.timestamp).toLocaleString('ar-SA')}`
                  : `Last updated: ${new Date(learningData.timestamp).toLocaleString()}`
                }
              </p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
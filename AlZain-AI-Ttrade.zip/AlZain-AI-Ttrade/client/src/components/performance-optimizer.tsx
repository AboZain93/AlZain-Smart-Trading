import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useLanguageContext } from '@/components/language-provider';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { 
  Zap, 
  MemoryStick, 
  Clock, 
  CheckCircle, 
  AlertTriangle,
  RefreshCw,
  Settings,
  TrendingUp,
  Database,
  Cpu
} from 'lucide-react';

interface PerformanceMetrics {
  memory: {
    used: number;
    available: number;
    percentage: number;
  };
  cpu: {
    usage: number;
    cores: number;
  };
  network: {
    latency: number;
    bandwidth: number;
  };
  cache: {
    hitRate: number;
    size: number;
    entries: number;
  };
  database: {
    connectionPool: number;
    queryTime: number;
    activeConnections: number;
  };
}

export function PerformanceOptimizer() {
  const { language } = useLanguageContext();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [optimizing, setOptimizing] = useState(false);

  const { data: metrics, isLoading } = useQuery<PerformanceMetrics>({
    queryKey: ['/api/performance/metrics'],
    refetchInterval: 5000, // Update every 5 seconds
  });

  const optimizePerformance = useMutation({
    mutationFn: () => apiRequest('/api/performance/optimize', {
      method: 'POST',
    }),
    onSuccess: () => {
      toast({
        title: language === 'ar' ? 'تم تحسين الأداء' : 'Performance Optimized',
        description: language === 'ar' 
          ? 'تم تحسين أداء النظام بنجاح' 
          : 'System performance has been optimized successfully',
      });
      queryClient.invalidateQueries({ queryKey: ['/api/performance/metrics'] });
    },
    onError: () => {
      toast({
        title: language === 'ar' ? 'خطأ في التحسين' : 'Optimization Error',
        description: language === 'ar' 
          ? 'فشل في تحسين الأداء' 
          : 'Failed to optimize performance',
        variant: 'destructive',
      });
    },
  });

  const clearCache = useMutation({
    mutationFn: () => apiRequest('/api/performance/clear-cache', {
      method: 'POST',
    }),
    onSuccess: () => {
      toast({
        title: language === 'ar' ? 'تم مسح التخزين المؤقت' : 'Cache Cleared',
        description: language === 'ar' 
          ? 'تم مسح التخزين المؤقت بنجاح' 
          : 'Cache has been cleared successfully',
      });
      queryClient.invalidateQueries({ queryKey: ['/api/performance/metrics'] });
    },
  });

  const getStatusColor = (percentage: number) => {
    if (percentage >= 80) return 'destructive';
    if (percentage >= 60) return 'default';
    return 'secondary';
  };

  const getStatusIcon = (percentage: number) => {
    if (percentage >= 80) return AlertTriangle;
    if (percentage >= 60) return Clock;
    return CheckCircle;
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-8">
        <RefreshCw className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">
            {language === 'ar' ? 'مُحسِّن الأداء' : 'Performance Optimizer'}
          </h2>
          <p className="text-muted-foreground">
            {language === 'ar' 
              ? 'مراقبة وتحسين أداء النظام في الوقت الفعلي' 
              : 'Monitor and optimize system performance in real-time'}
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            onClick={() => clearCache.mutate()}
            disabled={clearCache.isPending}
            variant="outline"
            size="sm"
          >
            <Database className="h-4 w-4 mr-2" />
            {language === 'ar' ? 'مسح التخزين المؤقت' : 'Clear Cache'}
          </Button>
          <Button
            onClick={() => optimizePerformance.mutate()}
            disabled={optimizePerformance.isPending}
            size="sm"
          >
            <Zap className="h-4 w-4 mr-2" />
            {language === 'ar' ? 'تحسين الأداء' : 'Optimize Performance'}
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Memory Usage */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              {language === 'ar' ? 'استخدام الذاكرة' : 'Memory Usage'}
            </CardTitle>
            <MemoryStick className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {metrics?.memory.percentage.toFixed(1)}%
            </div>
            <Progress 
              value={metrics?.memory.percentage || 0} 
              className="mt-2"
            />
            <div className="flex justify-between text-xs text-muted-foreground mt-2">
              <span>{((metrics?.memory.used || 0) / 1024 / 1024).toFixed(1)} MB</span>
              <span>{((metrics?.memory.available || 0) / 1024 / 1024).toFixed(1)} MB</span>
            </div>
            <Badge 
              variant={getStatusColor(metrics?.memory.percentage || 0)}
              className="mt-2"
            >
              {metrics?.memory.percentage && metrics.memory.percentage >= 80 
                ? (language === 'ar' ? 'مرتفع' : 'High')
                : metrics?.memory.percentage && metrics.memory.percentage >= 60
                ? (language === 'ar' ? 'متوسط' : 'Medium')
                : (language === 'ar' ? 'طبيعي' : 'Normal')}
            </Badge>
          </CardContent>
        </Card>

        {/* CPU Usage */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              {language === 'ar' ? 'استخدام المعالج' : 'CPU Usage'}
            </CardTitle>
            <Cpu className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {metrics?.cpu.usage.toFixed(1)}%
            </div>
            <Progress 
              value={metrics?.cpu.usage || 0} 
              className="mt-2"
            />
            <div className="text-xs text-muted-foreground mt-2">
              {metrics?.cpu.cores} {language === 'ar' ? 'نواة' : 'cores'}
            </div>
            <Badge 
              variant={getStatusColor(metrics?.cpu.usage || 0)}
              className="mt-2"
            >
              {metrics?.cpu.usage && metrics.cpu.usage >= 80 
                ? (language === 'ar' ? 'مرتفع' : 'High')
                : metrics?.cpu.usage && metrics.cpu.usage >= 60
                ? (language === 'ar' ? 'متوسط' : 'Medium')
                : (language === 'ar' ? 'طبيعي' : 'Normal')}
            </Badge>
          </CardContent>
        </Card>

        {/* Network Latency */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              {language === 'ar' ? 'زمن الاستجابة' : 'Network Latency'}
            </CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {metrics?.network.latency.toFixed(0)}ms
            </div>
            <div className="text-xs text-muted-foreground mt-2">
              {language === 'ar' ? 'عرض النطاق:' : 'Bandwidth:'} {metrics?.network.bandwidth.toFixed(1)} Mbps
            </div>
            <Badge 
              variant={metrics?.network.latency && metrics.network.latency > 500 ? 'destructive' : 'secondary'}
              className="mt-2"
            >
              {metrics?.network.latency && metrics.network.latency > 500 
                ? (language === 'ar' ? 'بطيء' : 'Slow')
                : (language === 'ar' ? 'سريع' : 'Fast')}
            </Badge>
          </CardContent>
        </Card>

        {/* Cache Performance */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              {language === 'ar' ? 'أداء التخزين المؤقت' : 'Cache Performance'}
            </CardTitle>
            <Database className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {metrics?.cache.hitRate.toFixed(1)}%
            </div>
            <Progress 
              value={metrics?.cache.hitRate || 0} 
              className="mt-2"
            />
            <div className="flex justify-between text-xs text-muted-foreground mt-2">
              <span>{language === 'ar' ? 'الحجم:' : 'Size:'} {((metrics?.cache.size || 0) / 1024 / 1024).toFixed(1)} MB</span>
              <span>{language === 'ar' ? 'الإدخالات:' : 'Entries:'} {metrics?.cache.entries}</span>
            </div>
            <Badge 
              variant={metrics?.cache.hitRate && metrics.cache.hitRate >= 80 ? 'secondary' : 'default'}
              className="mt-2"
            >
              {metrics?.cache.hitRate && metrics.cache.hitRate >= 80 
                ? (language === 'ar' ? 'ممتاز' : 'Excellent')
                : (language === 'ar' ? 'جيد' : 'Good')}
            </Badge>
          </CardContent>
        </Card>

        {/* Database Performance */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              {language === 'ar' ? 'أداء قاعدة البيانات' : 'Database Performance'}
            </CardTitle>
            <Database className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {metrics?.database.queryTime.toFixed(0)}ms
            </div>
            <div className="text-xs text-muted-foreground mt-2">
              {language === 'ar' ? 'الاتصالات النشطة:' : 'Active connections:'} {metrics?.database.activeConnections}/{metrics?.database.connectionPool}
            </div>
            <Progress 
              value={((metrics?.database.activeConnections || 0) / (metrics?.database.connectionPool || 1)) * 100} 
              className="mt-2"
            />
            <Badge 
              variant={metrics?.database.queryTime && metrics.database.queryTime > 1000 ? 'destructive' : 'secondary'}
              className="mt-2"
            >
              {metrics?.database.queryTime && metrics.database.queryTime > 1000 
                ? (language === 'ar' ? 'بطيء' : 'Slow')
                : (language === 'ar' ? 'سريع' : 'Fast')}
            </Badge>
          </CardContent>
        </Card>

        {/* System Health */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              {language === 'ar' ? 'حالة النظام العامة' : 'System Health'}
            </CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="flex items-center space-x-2">
              {(() => {
                const memOk = (metrics?.memory.percentage || 0) < 80;
                const cpuOk = (metrics?.cpu.usage || 0) < 80;
                const networkOk = (metrics?.network.latency || 0) < 500;
                const cacheOk = (metrics?.cache.hitRate || 0) > 70;
                const dbOk = (metrics?.database.queryTime || 0) < 1000;
                
                const healthScore = [memOk, cpuOk, networkOk, cacheOk, dbOk].filter(Boolean).length;
                const percentage = (healthScore / 5) * 100;
                
                return (
                  <>
                    <div className="text-2xl font-bold">
                      {percentage.toFixed(0)}%
                    </div>
                    <Badge 
                      variant={percentage >= 80 ? 'secondary' : percentage >= 60 ? 'default' : 'destructive'}
                      className="ml-2"
                    >
                      {percentage >= 80 
                        ? (language === 'ar' ? 'ممتاز' : 'Excellent')
                        : percentage >= 60
                        ? (language === 'ar' ? 'جيد' : 'Good')
                        : (language === 'ar' ? 'يحتاج تحسين' : 'Needs Optimization')}
                    </Badge>
                  </>
                );
              })()}
            </div>
            <Progress 
              value={(() => {
                const memOk = (metrics?.memory.percentage || 0) < 80;
                const cpuOk = (metrics?.cpu.usage || 0) < 80;
                const networkOk = (metrics?.network.latency || 0) < 500;
                const cacheOk = (metrics?.cache.hitRate || 0) > 70;
                const dbOk = (metrics?.database.queryTime || 0) < 1000;
                
                const healthScore = [memOk, cpuOk, networkOk, cacheOk, dbOk].filter(Boolean).length;
                return (healthScore / 5) * 100;
              })()} 
              className="mt-2"
            />
            <div className="text-xs text-muted-foreground mt-2">
              {language === 'ar' ? 'جميع المكونات تعمل بشكل صحيح' : 'All components functioning properly'}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Performance Tips */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5" />
            {language === 'ar' ? 'نصائح تحسين الأداء' : 'Performance Optimization Tips'}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <h4 className="font-medium text-sm">
                {language === 'ar' ? 'التحسينات التلقائية' : 'Automatic Optimizations'}
              </h4>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• {language === 'ar' ? 'ضغط الاستجابات' : 'Response compression'}</li>
                <li>• {language === 'ar' ? 'تخزين مؤقت ذكي' : 'Smart caching'}</li>
                <li>• {language === 'ar' ? 'تحسين الاستعلامات' : 'Query optimization'}</li>
                <li>• {language === 'ar' ? 'إدارة الذاكرة' : 'Memory management'}</li>
              </ul>
            </div>
            <div className="space-y-2">
              <h4 className="font-medium text-sm">
                {language === 'ar' ? 'التحسينات اليدوية' : 'Manual Optimizations'}
              </h4>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• {language === 'ar' ? 'مسح التخزين المؤقت بانتظام' : 'Regular cache clearing'}</li>
                <li>• {language === 'ar' ? 'إعادة تشغيل دورية' : 'Periodic restarts'}</li>
                <li>• {language === 'ar' ? 'مراقبة الموارد' : 'Resource monitoring'}</li>
                <li>• {language === 'ar' ? 'تحديث التطبيق' : 'Application updates'}</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
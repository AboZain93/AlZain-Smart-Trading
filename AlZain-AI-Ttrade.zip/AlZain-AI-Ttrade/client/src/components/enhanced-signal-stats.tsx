import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { useQuery } from '@tanstack/react-query';
import { useLanguageContext } from '@/components/language-provider';
import { 
  Brain, 
  Target, 
  TrendingUp, 
  AlertTriangle, 
  Clock, 
  BarChart3,
  CheckCircle,
  XCircle,
  Zap
} from 'lucide-react';

interface EnhancedSignalStats {
  totalEnhancedSignals: number;
  enhancedAccuracy: number;
  avgConfidence: number;
  multiTimeframeSuccess: number;
  riskFilteredSignals: number;
  avgProcessingTime: number;
  qualityScore: number;
}

export function EnhancedSignalStats() {
  const { language } = useLanguageContext();

  const { data: stats, isLoading } = useQuery<EnhancedSignalStats>({
    queryKey: ['/api/enhanced-signals/stats'],
    refetchInterval: 30000,
  });

  const { data: systemStatus } = useQuery<{isActive: boolean}>({
    queryKey: ['/api/system-status'],
    refetchInterval: 5000,
  });

  if (isLoading || !stats) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="h-5 w-5" />
            {language === 'ar' ? 'إحصائيات الذكاء الاصطناعي' : 'AI Signal Statistics'}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="animate-pulse space-y-4">
            <div className="h-4 bg-muted rounded w-3/4"></div>
            <div className="h-4 bg-muted rounded w-1/2"></div>
            <div className="h-4 bg-muted rounded w-2/3"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  const getQualityColor = (score: number) => {
    if (score >= 90) return 'text-green-600 dark:text-green-400';
    if (score >= 75) return 'text-blue-600 dark:text-blue-400';
    if (score >= 60) return 'text-yellow-600 dark:text-yellow-400';
    return 'text-red-600 dark:text-red-400';
  };

  const getQualityBadge = (score: number) => {
    if (score >= 90) return language === 'ar' ? 'ممتاز' : 'Excellent';
    if (score >= 75) return language === 'ar' ? 'جيد جداً' : 'Very Good';
    if (score >= 60) return language === 'ar' ? 'جيد' : 'Good';
    return language === 'ar' ? 'يحتاج تحسين' : 'Needs Improvement';
  };

  return (
    <div className="space-y-6">
      {/* Main Stats Card */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="h-5 w-5 text-primary" />
            {language === 'ar' ? 'نظام الذكاء الاصطناعي المتقدم' : 'Advanced AI Signal System'}
          </CardTitle>
          <CardDescription>
            {language === 'ar' 
              ? 'إحصائيات شاملة لأداء نظام التحليل متعدد الإطارات الزمنية'
              : 'Comprehensive performance metrics for multi-timeframe analysis system'
            }
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Quality Score */}
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <p className="text-sm font-medium">
                {language === 'ar' ? 'درجة الجودة الإجمالية' : 'Overall Quality Score'}
              </p>
              <div className="flex items-center gap-2">
                <span className={`text-2xl font-bold ${getQualityColor(stats.qualityScore)}`}>
                  {stats.qualityScore.toFixed(1)}%
                </span>
                <Badge variant="secondary" className={getQualityColor(stats.qualityScore)}>
                  {getQualityBadge(stats.qualityScore)}
                </Badge>
              </div>
            </div>
            <div className="w-32">
              <Progress value={stats.qualityScore} className="h-3" />
            </div>
          </div>

          {/* Enhanced Accuracy */}
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <Target className="h-4 w-4 text-green-600" />
                <p className="text-sm font-medium">
                  {language === 'ar' ? 'دقة الإشارات المحسنة' : 'Enhanced Signal Accuracy'}
                </p>
              </div>
              <span className="text-xl font-semibold text-green-600">
                {stats.enhancedAccuracy.toFixed(1)}%
              </span>
            </div>
            <div className="w-32">
              <Progress value={stats.enhancedAccuracy} className="h-2" />
            </div>
          </div>

          {/* Average Confidence */}
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-blue-600" />
                <p className="text-sm font-medium">
                  {language === 'ar' ? 'متوسط الثقة' : 'Average Confidence'}
                </p>
              </div>
              <span className="text-xl font-semibold text-blue-600">
                {stats.avgConfidence.toFixed(1)}%
              </span>
            </div>
            <div className="w-32">
              <Progress value={stats.avgConfidence} className="h-2" />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Detailed Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {/* Multi-Timeframe Success */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <BarChart3 className="h-8 w-8 text-purple-600" />
              <div>
                <p className="text-sm text-muted-foreground">
                  {language === 'ar' ? 'نجاح التحليل المتعدد' : 'Multi-Timeframe Success'}
                </p>
                <p className="text-2xl font-bold text-purple-600">
                  {stats.multiTimeframeSuccess.toFixed(1)}%
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Risk Filtered Signals */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <AlertTriangle className="h-8 w-8 text-orange-600" />
              <div>
                <p className="text-sm text-muted-foreground">
                  {language === 'ar' ? 'الإشارات المفلترة' : 'Risk Filtered Signals'}
                </p>
                <p className="text-2xl font-bold text-orange-600">
                  {stats.riskFilteredSignals}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Processing Time */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <Clock className="h-8 w-8 text-indigo-600" />
              <div>
                <p className="text-sm text-muted-foreground">
                  {language === 'ar' ? 'زمن المعالجة (مث)' : 'Processing Time (ms)'}
                </p>
                <p className="text-2xl font-bold text-indigo-600">
                  {stats.avgProcessingTime.toFixed(0)}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* AI System Status */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Zap className="h-5 w-5" />
            {language === 'ar' ? 'حالة نظام الذكاء الاصطناعي' : 'AI System Status'}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Enhanced Analysis Status */}
            <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
              <div className="flex items-center gap-2">
                <Brain className="h-5 w-5 text-primary" />
                <span className="font-medium">
                  {language === 'ar' ? 'التحليل المحسن' : 'Enhanced Analysis'}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="h-5 w-5 text-green-600" />
                <Badge variant="secondary" className="text-green-600">
                  {language === 'ar' ? 'نشط' : 'Active'}
                </Badge>
              </div>
            </div>

            {/* Multi-Timeframe Engine */}
            <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
              <div className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5 text-primary" />
                <span className="font-medium">
                  {language === 'ar' ? 'محرك الإطارات المتعددة' : 'Multi-Timeframe Engine'}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="h-5 w-5 text-green-600" />
                <Badge variant="secondary" className="text-green-600">
                  {language === 'ar' ? 'يعمل' : 'Running'}
                </Badge>
              </div>
            </div>

            {/* Auto Signals Status */}
            <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
              <div className="flex items-center gap-2">
                <Target className="h-5 w-5 text-primary" />
                <span className="font-medium">
                  {language === 'ar' ? 'الإشارات التلقائية' : 'Auto Signals'}
                </span>
              </div>
              <div className="flex items-center gap-2">
                {(systemStatus as any)?.isActive ? (
                  <>
                    <CheckCircle className="h-5 w-5 text-green-600" />
                    <Badge variant="secondary" className="text-green-600">
                      {language === 'ar' ? 'نشط' : 'Active'}
                    </Badge>
                  </>
                ) : (
                  <>
                    <XCircle className="h-5 w-5 text-red-600" />
                    <Badge variant="secondary" className="text-red-600">
                      {language === 'ar' ? 'متوقف' : 'Stopped'}
                    </Badge>
                  </>
                )}
              </div>
            </div>

            {/* Signal Quality Filter */}
            <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
              <div className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-primary" />
                <span className="font-medium">
                  {language === 'ar' ? 'فلتر الجودة' : 'Quality Filter'}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="h-5 w-5 text-green-600" />
                <Badge variant="secondary" className="text-green-600">
                  75%+ {language === 'ar' ? 'ثقة' : 'Confidence'}
                </Badge>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Performance Insights */}
      <Card>
        <CardHeader>
          <CardTitle>
            {language === 'ar' ? 'رؤى الأداء' : 'Performance Insights'}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="p-4 bg-blue-50 dark:bg-blue-950/20 rounded-lg border border-blue-200 dark:border-blue-800">
              <div className="flex items-start gap-3">
                <TrendingUp className="h-5 w-5 text-blue-600 mt-0.5" />
                <div>
                  <h4 className="font-medium text-blue-900 dark:text-blue-100">
                    {language === 'ar' ? 'تحسين مستمر' : 'Continuous Improvement'}
                  </h4>
                  <p className="text-sm text-blue-700 dark:text-blue-300 mt-1">
                    {language === 'ar' 
                      ? 'النظام يتعلم من كل إشارة ويحسن دقته تلقائياً باستخدام تعليقات المستخدمين.'
                      : 'The system learns from each signal and automatically improves accuracy using user feedback.'
                    }
                  </p>
                </div>
              </div>
            </div>

            <div className="p-4 bg-green-50 dark:bg-green-950/20 rounded-lg border border-green-200 dark:border-green-800">
              <div className="flex items-start gap-3">
                <CheckCircle className="h-5 w-5 text-green-600 mt-0.5" />
                <div>
                  <h4 className="font-medium text-green-900 dark:text-green-100">
                    {language === 'ar' ? 'فلترة ذكية' : 'Smart Filtering'}
                  </h4>
                  <p className="text-sm text-green-700 dark:text-green-300 mt-1">
                    {language === 'ar' 
                      ? 'يتم رفض الإشارات ضعيفة الجودة تلقائياً للحفاظ على معدل نجاح عالي.'
                      : 'Low-quality signals are automatically rejected to maintain high success rates.'
                    }
                  </p>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
import { createContext, useContext, ReactNode } from 'react';
import { useLanguage, Language } from '@/hooks/use-language';
import { translations, TranslationKey } from '@/lib/translations';

interface LanguageContextType {
  language: Language;
  toggleLanguage: () => void;
  t: (key: TranslationKey) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const { language, toggleLanguage } = useLanguage();

  const t = (key: TranslationKey): string => {
    return translations[language][key] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, toggleLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguageContext() {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    // Return default values instead of throwing error
    return {
      language: 'ar' as Language,
      toggleLanguage: () => {},
      t: (key: TranslationKey) => key
    };
  }
  return context;
}

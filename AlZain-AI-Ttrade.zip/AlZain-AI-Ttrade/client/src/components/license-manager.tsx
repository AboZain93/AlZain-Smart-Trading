import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { AlertTriangle, CheckCircle, Key, Users, TrendingUp, Clock } from "lucide-react";

interface LicenseInfo {
  valid: boolean;
  license: {
    key: string;
    tradesUsed: number;
    maxTrades: number;
    tradesRemaining: number;
    isTrialActive: boolean;
    trialEndsAt: string | null;
  };
  stats: {
    totalTrades: number;
    successfulTrades: number;
    failedTrades: number;
    pendingTrades: number;
    successRate: number;
    tradesRemaining: number;
  };
  message: string;
}

export function LicenseManager() {
  const [username, setUsername] = useState("");
  const [licenseKey, setLicenseKey] = useState("");
  const [currentLicense, setCurrentLicense] = useState<string | null>(
    localStorage.getItem("tradingBotLicense")
  );
  const { toast } = useToast();

  // Query for license validation
  const { data: licenseInfo, isLoading: validating } = useQuery({
    queryKey: ["/api/licenses/validate"],
    enabled: !!currentLicense,
    refetchInterval: 30000, // Check every 30 seconds
    retry: false,
    meta: {
      headers: {
        'x-license-key': currentLicense
      }
    }
  });

  // Mutation for creating trial license
  const createTrialMutation = useMutation({
    mutationFn: async (username: string) => {
      const response = await apiRequest("POST", "/api/licenses/create-trial", { username });
      return await response.json();
    },
    onSuccess: (data) => {
      setCurrentLicense(data.licenseKey);
      localStorage.setItem("tradingBotLicense", data.licenseKey);
      toast({
        title: "رخصة تجريبية",
        description: data.message,
        variant: "default"
      });
      queryClient.invalidateQueries({ queryKey: ["/api/licenses/validate"] });
    },
    onError: (error: any) => {
      toast({
        title: "خطأ",
        description: error.arabicError || "فشل في إنشاء الرخصة التجريبية",
        variant: "destructive"
      });
    }
  });

  // Mutation for validating existing license
  const validateLicenseMutation = useMutation({
    mutationFn: async (key: string) => {
      const response = await fetch("/api/licenses/validate", {
        method: "GET",
        headers: {
          'x-license-key': key
        }
      });
      
      if (!response.ok) {
        const error = await response.text();
        throw new Error(error || response.statusText);
      }
      
      return await response.json();
    },
    onSuccess: (data) => {
      setCurrentLicense(licenseKey);
      localStorage.setItem("tradingBotLicense", licenseKey);
      toast({
        title: "رخصة صالحة",
        description: data.message,
        variant: "default"
      });
      queryClient.invalidateQueries({ queryKey: ["/api/licenses/validate"] });
    },
    onError: (error: any) => {
      toast({
        title: "رخصة غير صالحة",
        description: error.arabicError || "الرخصة غير صالحة أو منتهية الصلاحية",
        variant: "destructive"
      });
    }
  });

  // Execute trade mutation
  const executeTradeMutation = useMutation({
    mutationFn: async (tradeData: any) => {
      const response = await fetch("/api/execute-trade", {
        method: "POST",
        headers: {
          'Content-Type': 'application/json',
          'x-license-key': currentLicense || ''
        },
        body: JSON.stringify(tradeData)
      });
      
      if (!response.ok) {
        const error = await response.text();
        throw new Error(error || response.statusText);
      }
      
      return await response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "تم تنفيذ الصفقة",
        description: data.message,
        variant: "default"
      });
      queryClient.invalidateQueries({ queryKey: ["/api/licenses/validate"] });
    },
    onError: (error: any) => {
      toast({
        title: "فشل في تنفيذ الصفقة",
        description: error.arabicError || "تم استهلاك العدد المسموح من الصفقات",
        variant: "destructive"
      });
    }
  });

  const handleCreateTrial = () => {
    if (!username.trim()) {
      toast({
        title: "خطأ",
        description: "يرجى إدخال اسم المستخدم",
        variant: "destructive"
      });
      return;
    }
    createTrialMutation.mutate(username);
  };

  const handleValidateLicense = () => {
    if (!licenseKey.trim()) {
      toast({
        title: "خطأ",
        description: "يرجى إدخال رقم الرخصة",
        variant: "destructive"
      });
      return;
    }
    validateLicenseMutation.mutate(licenseKey);
  };

  const handleTestTrade = () => {
    if (!currentLicense) {
      toast({
        title: "خطأ",
        description: "يرجى تفعيل الرخصة أولاً",
        variant: "destructive"
      });
      return;
    }

    executeTradeMutation.mutate({
      assetSymbol: "EUR/USD",
      direction: "BUY",
      confidence: 85
    });
  };

  const formatTimeRemaining = (trialEndsAt: string | null) => {
    if (!trialEndsAt) return null;
    
    const now = new Date();
    const endDate = new Date(trialEndsAt);
    const diff = endDate.getTime() - now.getTime();
    
    if (diff <= 0) return "منتهية";
    
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    
    return `${days} أيام و ${hours} ساعات`;
  };

  return (
    <div className="space-y-6 p-6">
      <div className="text-center">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
          إدارة التراخيص
        </h1>
        <p className="text-gray-600 dark:text-gray-400">
          تفعيل وإدارة رخصة التطبيق للوصول إلى التوصيات المتقدمة
        </p>
      </div>

      {!currentLicense ? (
        <div className="grid md:grid-cols-2 gap-6">
          {/* Create Trial License */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                رخصة تجريبية مجانية
              </CardTitle>
              <CardDescription>
                احصل على 10 صفقات مجانية لتجربة النظام
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="username">اسم المستخدم</Label>
                <Input
                  id="username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="أدخل اسم المستخدم"
                  className="mt-1"
                />
              </div>
              <Button 
                onClick={handleCreateTrial}
                disabled={createTrialMutation.isPending}
                className="w-full"
              >
                {createTrialMutation.isPending ? "جاري الإنشاء..." : "إنشاء رخصة تجريبية"}
              </Button>
            </CardContent>
          </Card>

          {/* Validate Existing License */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Key className="h-5 w-5" />
                رخصة موجودة
              </CardTitle>
              <CardDescription>
                إذا كان لديك رخصة صالحة، أدخلها هنا
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="licenseKey">رقم الرخصة</Label>
                <Input
                  id="licenseKey"
                  value={licenseKey}
                  onChange={(e) => setLicenseKey(e.target.value)}
                  placeholder="TRADE_BOT_xxxxxxxx_xxxxxxxx"
                  className="mt-1"
                />
              </div>
              <Button 
                onClick={handleValidateLicense}
                disabled={validateLicenseMutation.isPending}
                className="w-full"
                variant="outline"
              >
                {validateLicenseMutation.isPending ? "جاري التحقق..." : "تفعيل الرخصة"}
              </Button>
            </CardContent>
          </Card>
        </div>
      ) : (
        <div className="space-y-6">
          {/* License Status */}
          {licenseInfo && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5 text-green-500" />
                  حالة الرخصة
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-3 gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-600">
                      {licenseInfo.license.tradesRemaining}
                    </div>
                    <div className="text-sm text-gray-600">صفقات متبقية</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-600">
                      {licenseInfo.stats.successRate.toFixed(1)}%
                    </div>
                    <div className="text-sm text-gray-600">معدل النجاح</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-purple-600">
                      {licenseInfo.stats.totalTrades}
                    </div>
                    <div className="text-sm text-gray-600">إجمالي الصفقات</div>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>استخدام الصفقات</span>
                    <span>{licenseInfo.license.tradesUsed} / {licenseInfo.license.maxTrades}</span>
                  </div>
                  <Progress 
                    value={(licenseInfo.license.tradesUsed / licenseInfo.license.maxTrades) * 100}
                    className="h-2"
                  />
                </div>

                {licenseInfo.license.isTrialActive && licenseInfo.license.trialEndsAt && (
                  <div className="flex items-center gap-2 p-3 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg">
                    <Clock className="h-4 w-4 text-yellow-600" />
                    <span className="text-sm text-yellow-700 dark:text-yellow-400">
                      فترة تجريبية - تنتهي خلال: {formatTimeRemaining(licenseInfo.license.trialEndsAt)}
                    </span>
                  </div>
                )}

                <div className="flex gap-2">
                  <Button 
                    onClick={handleTestTrade}
                    disabled={executeTradeMutation.isPending || licenseInfo.license.tradesRemaining === 0}
                    size="sm"
                  >
                    {executeTradeMutation.isPending ? "جاري التنفيذ..." : "تجربة صفقة"}
                  </Button>
                  <Button 
                    onClick={() => {
                      setCurrentLicense(null);
                      localStorage.removeItem("tradingBotLicense");
                    }}
                    variant="outline"
                    size="sm"
                  >
                    تغيير الرخصة
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Trading Statistics */}
          {licenseInfo && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  إحصائيات التداول
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-4 gap-4">
                  <div className="text-center p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
                    <div className="text-xl font-bold text-green-600">
                      {licenseInfo.stats.successfulTrades}
                    </div>
                    <div className="text-sm text-green-700 dark:text-green-400">
                      صفقات ناجحة
                    </div>
                  </div>
                  <div className="text-center p-4 bg-red-50 dark:bg-red-900/20 rounded-lg">
                    <div className="text-xl font-bold text-red-600">
                      {licenseInfo.stats.failedTrades}
                    </div>
                    <div className="text-sm text-red-700 dark:text-red-400">
                      صفقات خاسرة
                    </div>
                  </div>
                  <div className="text-center p-4 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg">
                    <div className="text-xl font-bold text-yellow-600">
                      {licenseInfo.stats.pendingTrades}
                    </div>
                    <div className="text-sm text-yellow-700 dark:text-yellow-400">
                      صفقات معلقة
                    </div>
                  </div>
                  <div className="text-center p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                    <div className="text-xl font-bold text-blue-600">
                      {licenseInfo.stats.totalTrades}
                    </div>
                    <div className="text-sm text-blue-700 dark:text-blue-400">
                      إجمالي الصفقات
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Warning for low trades */}
          {licenseInfo && licenseInfo.license.tradesRemaining <= 2 && (
            <Card className="border-orange-200 dark:border-orange-800">
              <CardContent className="pt-6">
                <div className="flex items-center gap-3">
                  <AlertTriangle className="h-6 w-6 text-orange-500" />
                  <div>
                    <h3 className="font-semibold text-orange-700 dark:text-orange-400">
                      تحذير: عدد قليل من الصفقات المتبقية
                    </h3>
                    <p className="text-sm text-orange-600 dark:text-orange-300">
                      لديك فقط {licenseInfo.license.tradesRemaining} صفقة متبقية. 
                      تواصل معنا لتطوير رخصتك.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      )}
    </div>
  );
}
import { useState } from 'react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { useLanguageContext } from '@/components/language-provider';
import { 
  TrendingUp, 
  TrendingDown, 
  Clock, 
  Target, 
  AlertTriangle, 
  BarChart3, 
  Timer,
  Activity,
  Brain,
  Zap,
  Shield,
  Info
} from 'lucide-react';

interface EnhancedRecommendation {
  id: number;
  assetSymbol: string;
  direction: 'BUY' | 'SELL';
  confidence: number;
  riskLevel: 'low' | 'medium' | 'high';
  technicalAnalysis: string;
  marketStatus: string;
  entryTime: string;
  duration: string;
  trend: string;
  liquidity: string;
  result?: string;
  sentToTelegram: boolean;
  createdAt: string;
  
  // Enhanced fields
  strength?: 'قوية جداً' | 'قوية' | 'متوسطة' | 'ضعيفة';
  marketCondition?: 'متفائلة' | 'متشائمة' | 'محايدة' | 'متقلبة';
  supportResistance?: {
    support: number;
    resistance: number;
    nearLevel: boolean;
  };
  indicators?: {
    rsi?: number;
    macd?: number;
    bollingerPosition?: number;
    volumeStrength?: number;
  };
  timingAnalysis?: {
    session: string;
    volatility: 'high' | 'medium' | 'low';
    optimal: boolean;
  };
}

interface Props {
  recommendation: EnhancedRecommendation;
  onSendToTelegram?: (id: number) => void;
  onUpdateResult?: (id: number, result: string) => void;
}

export function EnhancedRecommendationCard({ 
  recommendation, 
  onSendToTelegram, 
  onUpdateResult 
}: Props) {
  const { language, t } = useLanguageContext();
  const [isExpanded, setIsExpanded] = useState(false);

  const directionIcon = recommendation.direction === 'BUY' ? TrendingUp : TrendingDown;
  const directionColor = recommendation.direction === 'BUY' ? 'text-green-600' : 'text-red-600';
  
  const confidenceColor = recommendation.confidence >= 80 ? 'text-green-600' : 
                         recommendation.confidence >= 60 ? 'text-yellow-600' : 'text-red-600';

  const riskColor = recommendation.riskLevel === 'low' ? 'bg-green-100 text-green-800' :
                   recommendation.riskLevel === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                   'bg-red-100 text-red-800';

  const strengthEmoji = recommendation.strength === 'قوية جداً' ? '🔥' :
                       recommendation.strength === 'قوية' ? '⭐' :
                       recommendation.strength === 'متوسطة' ? '👍' : '⚠️';

  return (
    <Card className="w-full bg-gradient-to-br from-white to-gray-50 dark:from-gray-900 dark:to-gray-800 border-2 hover:shadow-lg transition-all duration-300">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-lg">
            <div className={`p-2 rounded-full bg-gray-100 dark:bg-gray-800 ${directionColor}`}>
              {React.createElement(directionIcon, { size: 20 })}
            </div>
            <span className="font-bold">{recommendation.assetSymbol}</span>
            <Badge variant={recommendation.direction === 'BUY' ? 'default' : 'destructive'}>
              {recommendation.direction}
            </Badge>
          </CardTitle>
          
          <div className="flex items-center gap-2">
            <div className="text-right">
              <div className={`text-2xl font-bold ${confidenceColor}`}>
                {recommendation.confidence}%
              </div>
              <div className="text-xs text-gray-500">
                {language === 'ar' ? 'نسبة الثقة' : 'Confidence'}
              </div>
            </div>
            <div className="text-2xl">{strengthEmoji}</div>
          </div>
        </div>

        <div className="flex items-center gap-4 mt-3">
          <Badge className={riskColor}>
            <Shield size={12} className="mr-1" />
            {language === 'ar' ? 
              `مخاطرة ${recommendation.riskLevel === 'low' ? 'منخفضة' : recommendation.riskLevel === 'medium' ? 'متوسطة' : 'عالية'}` :
              `${recommendation.riskLevel} risk`
            }
          </Badge>
          
          <Badge variant="outline">
            <Timer size={12} className="mr-1" />
            {recommendation.duration}
          </Badge>

          {recommendation.strength && (
            <Badge variant="secondary">
              <Zap size={12} className="mr-1" />
              {recommendation.strength}
            </Badge>
          )}
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Confidence Progress Bar */}
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span>{language === 'ar' ? 'قوة الإشارة' : 'Signal Strength'}</span>
            <span className={confidenceColor}>{recommendation.confidence}%</span>
          </div>
          <Progress 
            value={recommendation.confidence} 
            className="h-3"
            indicatorColor={recommendation.confidence >= 80 ? 'bg-green-500' : 
                           recommendation.confidence >= 60 ? 'bg-yellow-500' : 'bg-red-500'}
          />
        </div>

        {/* Market Analysis */}
        <div className="grid grid-cols-2 gap-3">
          <div className="flex items-center gap-2 text-sm">
            <Activity size={16} className="text-blue-500" />
            <div>
              <div className="font-medium">{language === 'ar' ? 'حالة السوق' : 'Market Status'}</div>
              <div className="text-gray-600 dark:text-gray-400">{recommendation.marketCondition || recommendation.marketStatus}</div>
            </div>
          </div>
          
          <div className="flex items-center gap-2 text-sm">
            <Clock size={16} className="text-purple-500" />
            <div>
              <div className="font-medium">{language === 'ar' ? 'وقت الدخول' : 'Entry Time'}</div>
              <div className="text-gray-600 dark:text-gray-400">{recommendation.entryTime}</div>
            </div>
          </div>
        </div>

        {/* Support/Resistance Levels */}
        {recommendation.supportResistance && (
          <div className="bg-blue-50 dark:bg-blue-900/20 p-3 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <Target size={16} className="text-blue-600" />
              <span className="font-medium text-sm">{language === 'ar' ? 'مستويات مهمة' : 'Key Levels'}</span>
              {recommendation.supportResistance.nearLevel && (
                <Badge variant="destructive" className="text-xs">
                  <AlertTriangle size={10} className="mr-1" />
                  {language === 'ar' ? 'قرب مستوى مهم' : 'Near Key Level'}
                </Badge>
              )}
            </div>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-green-600 font-medium">{language === 'ar' ? 'الدعم:' : 'Support:'}</span>
                <span className="ml-2">{recommendation.supportResistance.support.toFixed(4)}</span>
              </div>
              <div>
                <span className="text-red-600 font-medium">{language === 'ar' ? 'المقاومة:' : 'Resistance:'}</span>
                <span className="ml-2">{recommendation.supportResistance.resistance.toFixed(4)}</span>
              </div>
            </div>
          </div>
        )}

        {/* Technical Indicators */}
        {recommendation.indicators && (
          <div className="bg-gray-50 dark:bg-gray-800/50 p-3 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <BarChart3 size={16} className="text-green-600" />
              <span className="font-medium text-sm">{language === 'ar' ? 'المؤشرات الفنية' : 'Technical Indicators'}</span>
            </div>
            <div className="grid grid-cols-2 gap-2 text-xs">
              {recommendation.indicators.rsi && (
                <div className="flex justify-between">
                  <span>RSI:</span>
                  <span className={recommendation.indicators.rsi > 70 ? 'text-red-600' : 
                                 recommendation.indicators.rsi < 30 ? 'text-green-600' : 'text-gray-600'}>
                    {recommendation.indicators.rsi.toFixed(1)}
                  </span>
                </div>
              )}
              {recommendation.indicators.macd && (
                <div className="flex justify-between">
                  <span>MACD:</span>
                  <span className={recommendation.indicators.macd > 0 ? 'text-green-600' : 'text-red-600'}>
                    {recommendation.indicators.macd.toFixed(3)}
                  </span>
                </div>
              )}
              {recommendation.indicators.bollingerPosition && (
                <div className="flex justify-between">
                  <span>{language === 'ar' ? 'موقع بولينجر:' : 'BB Position:'}</span>
                  <span>{(recommendation.indicators.bollingerPosition * 100).toFixed(0)}%</span>
                </div>
              )}
              {recommendation.indicators.volumeStrength && (
                <div className="flex justify-between">
                  <span>{language === 'ar' ? 'قوة الحجم:' : 'Volume:'}</span>
                  <span className={recommendation.indicators.volumeStrength > 120 ? 'text-green-600' : 'text-gray-600'}>
                    {recommendation.indicators.volumeStrength.toFixed(0)}%
                  </span>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Technical Analysis */}
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <Brain size={16} className="text-purple-600" />
            <span className="font-medium text-sm">{language === 'ar' ? 'التحليل الفني' : 'Technical Analysis'}</span>
          </div>
          <div className={`text-sm p-3 rounded-lg bg-purple-50 dark:bg-purple-900/20 ${isExpanded ? '' : 'line-clamp-2'}`}>
            {recommendation.technicalAnalysis}
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsExpanded(!isExpanded)}
            className="h-6 text-xs"
          >
            {isExpanded ? 
              (language === 'ar' ? 'عرض أقل' : 'Show Less') : 
              (language === 'ar' ? 'عرض المزيد' : 'Show More')
            }
          </Button>
        </div>

        <Separator />

        {/* Action Buttons */}
        <div className="flex items-center justify-between">
          <div className="flex gap-2">
            {!recommendation.sentToTelegram && onSendToTelegram && (
              <Button
                size="sm"
                variant="outline"
                onClick={() => onSendToTelegram(recommendation.id)}
                className="text-xs"
              >
                📤 {language === 'ar' ? 'إرسال للتليجرام' : 'Send to Telegram'}
              </Button>
            )}
            
            {recommendation.sentToTelegram && (
              <Badge variant="secondary" className="text-xs">
                ✅ {language === 'ar' ? 'تم الإرسال' : 'Sent'}
              </Badge>
            )}
          </div>

          {/* Result Buttons */}
          {onUpdateResult && !recommendation.result && (
            <div className="flex gap-1">
              <Button
                size="sm"
                variant="outline"
                onClick={() => onUpdateResult(recommendation.id, 'success')}
                className="text-xs h-7 px-2 text-green-600 hover:bg-green-50"
              >
                ✅
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => onUpdateResult(recommendation.id, 'fail')}
                className="text-xs h-7 px-2 text-red-600 hover:bg-red-50"
              >
                ❌
              </Button>
            </div>
          )}

          {recommendation.result && (
            <Badge 
              variant={recommendation.result === 'success' ? 'default' : 
                      recommendation.result === 'fail' ? 'destructive' : 'secondary'}
              className="text-xs"
            >
              {recommendation.result === 'success' ? '✅ نجح' :
               recommendation.result === 'fail' ? '❌ فشل' : '⏳ قيد الانتظار'}
            </Badge>
          )}
        </div>

        {/* Timing Analysis */}
        {recommendation.timingAnalysis && (
          <div className="text-xs text-gray-500 bg-gray-50 dark:bg-gray-800 p-2 rounded">
            <div className="flex items-center gap-1 mb-1">
              <Info size={12} />
              <span className="font-medium">{language === 'ar' ? 'تحليل التوقيت:' : 'Timing Analysis:'}</span>
            </div>
            <div>{recommendation.timingAnalysis.session} • 
              {language === 'ar' ? 'تقلبات' : 'Volatility'} {recommendation.timingAnalysis.volatility}
              {recommendation.timingAnalysis.optimal && (
                <span className="text-green-600 ml-1">• {language === 'ar' ? 'توقيت مثالي' : 'Optimal Timing'}</span>
              )}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
import { useState, useEffect } from 'react';
import { Clock } from 'lucide-react';
import { useLanguageContext } from './language-provider';
import { useQuery } from '@tanstack/react-query';

interface CountdownTimerProps {
  targetMinutes: number; // Number of minutes for the countdown
  onComplete?: () => void;
  isActive?: boolean;
  label?: string;
  className?: string;
}

interface SystemStatus {
  isActive: boolean;
  lastSignal: string;
  signalsToday: number;
  successRate: number;
  nextSignalIn: number;
}

export function CountdownTimer({ 
  targetMinutes, 
  onComplete, 
  isActive = true, 
  label,
  className = ""
}: CountdownTimerProps) {
  const { language } = useLanguageContext();
  const [timeLeft, setTimeLeft] = useState(0);

  // Fetch real system status for accurate countdown
  const { data: systemStatus } = useQuery<SystemStatus>({
    queryKey: ['/api/system-status', targetMinutes, isActive],
    queryFn: ({ queryKey }) => {
      const [_, interval, active] = queryKey;
      return fetch(`/api/system-status?interval=${interval}&active=${active}`)
        .then(res => res.json());
    },
    refetchInterval: 5000, // Update every 5 seconds
  });

  // Initialize timer with real system data
  useEffect(() => {
    if (isActive && systemStatus?.nextSignalIn !== undefined && systemStatus.nextSignalIn !== null) {
      const secondsLeft = Math.round(systemStatus.nextSignalIn * 60); // Convert minutes to seconds
      console.log(`Countdown Timer: Setting ${secondsLeft} seconds (${systemStatus.nextSignalIn} minutes)`);
      setTimeLeft(Math.max(0, secondsLeft));
    } else if (isActive) {
      console.log(`Countdown Timer: Using fallback ${targetMinutes} minutes`);
      setTimeLeft(targetMinutes * 60);
    } else {
      // When inactive, freeze the timer at current value or reset to full interval
      setTimeLeft(targetMinutes * 60);
    }
  }, [systemStatus?.nextSignalIn, targetMinutes, isActive]);

  useEffect(() => {
    if (!isActive) {
      // When inactive, stop the timer and don't update
      return;
    }

    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          console.log('Countdown Timer: Reached zero, triggering onComplete');
          onComplete?.();
          return targetMinutes * 60; // Reset to full interval
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isActive, onComplete, targetMinutes]);

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(Math.max(0, seconds) / 60);
    const remainingSeconds = Math.max(0, seconds) % 60;
    return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const totalSeconds = targetMinutes * 60;
  const progress = totalSeconds > 0 ? ((totalSeconds - timeLeft) / totalSeconds) * 100 : 0;

  return (
    <div className={`text-center p-4 bg-muted rounded-lg ${className}`}>
      <Clock className="h-8 w-8 text-purple-600 mx-auto mb-2" />
      <div className="text-2xl font-bold text-purple-600 font-mono">
        {formatTime(timeLeft)}
      </div>
      <div className="text-sm text-muted-foreground mb-2">
        {label || (language === 'ar' ? 'للإشارة التالية' : 'to Next Signal')}
      </div>
      
      {/* Progress bar */}
      <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2 mt-3">
        <div 
          className="bg-gradient-to-r from-purple-500 to-blue-600 h-2 rounded-full transition-all duration-1000 ease-linear"
          style={{ width: `${progress}%` }}
        />
      </div>
      
      {/* Status indicator */}
      <div className="flex items-center justify-center gap-2 mt-2">
        <div className={`w-2 h-2 rounded-full ${isActive ? 'bg-green-500 animate-pulse' : 'bg-gray-400'}`} />
        <span className="text-xs text-muted-foreground">
          {isActive ? 
            (language === 'ar' ? 'نشط' : 'Active') : 
            (language === 'ar' ? 'متوقف' : 'Paused')
          }
        </span>
      </div>
    </div>
  );
}
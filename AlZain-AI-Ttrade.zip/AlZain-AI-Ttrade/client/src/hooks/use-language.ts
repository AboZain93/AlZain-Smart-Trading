import { useState, useEffect } from 'react';

export type Language = 'en' | 'ar';

export function useLanguage() {
  const [language, setLanguage] = useState<Language>('ar');

  useEffect(() => {
    const savedLanguage = localStorage.getItem('language') as Language;
    if (savedLanguage) {
      setLanguage(savedLanguage);
      updateDocumentLanguage(savedLanguage);
    } else {
      updateDocumentLanguage('ar');
    }
  }, []);

  const updateDocumentLanguage = (lang: Language) => {
    document.documentElement.setAttribute('lang', lang);
    document.documentElement.setAttribute('dir', lang === 'ar' ? 'rtl' : 'ltr');
    if (lang === 'ar') {
      document.body.classList.add('font-arabic');
    } else {
      document.body.classList.remove('font-arabic');
    }
  };

  const toggleLanguage = () => {
    const newLanguage = language === 'ar' ? 'en' : 'ar';
    setLanguage(newLanguage);
    localStorage.setItem('language', newLanguage);
    updateDocumentLanguage(newLanguage);
  };

  return { language, toggleLanguage };
}

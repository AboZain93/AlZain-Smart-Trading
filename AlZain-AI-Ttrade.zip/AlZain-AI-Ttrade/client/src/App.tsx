import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/components/theme-provider";
import { LanguageProvider } from "@/components/language-provider";
import { UserProvider, useUser } from "@/components/user-provider";
import { Sidebar } from "@/components/sidebar";
import { ErrorBoundary } from "./ErrorBoundary";


import Dashboard from "@/pages/dashboard";
import Settings from "@/pages/settings";
import TelegramSettings from "@/pages/telegram-settings";
import TradingControl from "@/pages/trading-control";
import RecommendationsHistory from "@/pages/recommendations-history";
import AIAnalytics from "@/pages/ai-analytics";
import AILearning from "@/pages/ai-learning";
import AIPerformanceMonitor from "@/pages/ai-performance-monitor-safe";
import EconomicNews from "@/pages/economic-news";
import ImprovementSuggestions from "@/pages/improvement-suggestions";
import PerformanceMonitor from "@/pages/performance-monitor";
import SocialTrading from "@/pages/social-trading";
import VoiceAssistant from "@/pages/voice-assistant";
import Portfolio from "@/pages/portfolio";
import MarketIntelligence from "@/pages/market-intelligence";
import Enhancements from "@/pages/enhancements";
import Admin from "@/pages/admin";
import Login from "@/pages/Login";
import Register from "@/pages/Register";
import Licensing from "@/pages/Licensing";
import CommercialLogin from "@/pages/commercial-login";
import CommercialRegister from "@/pages/commercial-register";
import CommercialDashboard from "@/pages/commercial-dashboard";
import CommercialStore from "@/pages/commercial-store";
import NotFound from "@/pages/not-found";
import SocialTradingLeaderboard from "@/pages/social-trading-leaderboard";
import MultilingualVoiceAssistant from "@/pages/multilingual-voice-assistant";
import AdvancedNewsAnalyzer from "@/pages/advanced-news-analyzer";
import InteractiveTradingCharts from "@/pages/interactive-trading-charts";
import AdvancedPortfolioManager from "@/pages/advanced-portfolio-manager";
import NewFeaturesOverview from "@/pages/new-features-overview";
import RiskManagement from "@/pages/risk-management";
import SocialTradingPage from "@/pages/social-trading";
import ProfessionalAIMonitor from "@/pages/professional-ai-monitor";
import DeveloperAdmin from "@/pages/developer-admin";
import DevKeyTest from "@/pages/devkey-test";

import ComprehensivePortfolio from "@/pages/comprehensive-portfolio";
import EconomicIntelligence from "@/pages/economic-intelligence";
import AdvancedNewsDashboard from "@/pages/advanced-news-dashboard";
import EnhancedTradingControl from "@/pages/enhanced-trading-control";
import AppHealthDashboard from "@/pages/app-health-dashboard";
import MobileOptimization from "@/pages/mobile-optimization";
import ExternalDataDemo from "@/pages/external-data-demo";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      
      {/* Core Features */}
      <Route path="/recommendations" component={RecommendationsHistory} />
      <Route path="/market-data" component={MarketIntelligence} />
      <Route path="/auto-signals" component={EnhancedTradingControl} />
      <Route path="/enhanced-trading-control" component={EnhancedTradingControl} />
      <Route path="/trading-control" component={EnhancedTradingControl} />
      
      {/* Analytics & Intelligence */}
      <Route path="/ai-analytics" component={AIAnalytics} />
      <Route path="/market-intelligence" component={MarketIntelligence} />
      <Route path="/economic-intelligence" component={EconomicIntelligence} />
      <Route path="/advanced-news-dashboard" component={AdvancedNewsDashboard} />
      
      {/* Portfolio Management */}
      <Route path="/comprehensive-portfolio" component={ComprehensivePortfolio} />
      <Route path="/advanced-portfolio" component={AdvancedPortfolioManager} />
      <Route path="/interactive-charts" component={InteractiveTradingCharts} />
      <Route path="/portfolio" component={Portfolio} />
      
      {/* Social & Communication */}
      <Route path="/social-trading" component={SocialTradingPage} />
      <Route path="/social-trading-leaderboard" component={SocialTradingLeaderboard} />
      <Route path="/voice-assistant" component={MultilingualVoiceAssistant} />
      <Route path="/telegram-settings" component={TelegramSettings} />
      
      {/* Risk Management */}
      <Route path="/risk-management" component={RiskManagement} />
      
      {/* Tools & Utilities */}
      <Route path="/news-analyzer" component={AdvancedNewsAnalyzer} />
      <Route path="/new-features" component={NewFeaturesOverview} />
      <Route path="/enhancements" component={Enhancements} />
      
      {/* System Monitoring */}
      <Route path="/performance-monitor" component={PerformanceMonitor} />
      <Route path="/ai-performance" component={AIPerformanceMonitor} />
      <Route path="/professional-ai-monitor" component={ProfessionalAIMonitor} />
      <Route path="/app-health-dashboard" component={AppHealthDashboard} />
      
      {/* Legacy/Alternative routes */}
      <Route path="/recommendations-history" component={RecommendationsHistory} />
      <Route path="/ai-learning" component={AILearning} />
      <Route path="/economic-news" component={EconomicNews} />
      <Route path="/improvement-suggestions" component={ImprovementSuggestions} />
      
      {/* Admin & Settings */}
      <Route path="/admin" component={Admin} />
      <Route path="/developer-admin" component={DeveloperAdmin} />
      <Route path="/devkey-test" component={DevKeyTest} />
      <Route path="/settings" component={Settings} />
      
      {/* Authentication & Licensing */}
      <Route path="/login" component={Login} />
      <Route path="/register" component={Register} />
      <Route path="/licensing" component={Licensing} />
      <Route path="/commercial/login" component={CommercialLogin} />
      <Route path="/commercial/register" component={CommercialRegister} />
      <Route path="/commercial/dashboard" component={CommercialDashboard} />
      <Route path="/commercial/store" component={CommercialStore} />
      
      <Route component={NotFound} />
    </Switch>
  );
}

function MainApp() {
  return (
    <div className="min-h-screen bg-background flex">
      {/* Single Sidebar for all screen sizes */}
      <Sidebar />
      
      {/* Main Content */}
      <div className="flex-1 overflow-auto">
        <ErrorBoundary>
          <Router />
        </ErrorBoundary>
      </div>
    </div>
  );
}

function AppContent() {
  const { user, isLoading } = useUser();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <div className="w-12 h-12 bg-primary rounded-lg flex items-center justify-center mx-auto mb-4">
            <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-white"></div>
          </div>
          <p>Loading...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return <Login />;
  }

  return <MainApp />;
}

function App() {
  return (
    <ErrorBoundary>
      <QueryClientProvider client={queryClient}>
        <ThemeProvider>
          <LanguageProvider>
            <UserProvider>
              <TooltipProvider>
                <AppContent />
                <Toaster />
              </TooltipProvider>
            </UserProvider>
          </LanguageProvider>
        </ThemeProvider>
      </QueryClientProvider>
    </ErrorBoundary>
  );
}

export default App;

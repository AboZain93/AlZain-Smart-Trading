import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { 
  ShoppingCart, 
  Clock, 
  CheckCircle, 
  AlertCircle,
  Crown,
  Star,
  Zap,
  Shield
} from "lucide-react";

interface Product {
  id: number;
  name: string;
  description: string;
  price: number;
  currency: string;
  productType: string;
  duration: number | null;
  features: string[];
  maxTrades: number | null;
  maxDevices: number;
  trialDuration: number;
  isActive: boolean;
}

interface License {
  licenseKey: string;
  licenseType: string;
  maxTrades: number | null;
  tradesUsed: number;
  status: string;
  expiresAt: string | null;
  trialEndsAt: string | null;
  activatedAt: string;
  productId: number;
}

export default function Licensing() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  // Fetch products
  const { data: productsData, isLoading: productsLoading } = useQuery({
    queryKey: ['/api/licensing/products'],
    queryFn: () => apiRequest('/api/licensing/products')
  });

  // Fetch user licenses
  const { data: licensesData, isLoading: licensesLoading } = useQuery({
    queryKey: ['/api/licensing/my-licenses'],
    queryFn: () => apiRequest('/api/licensing/my-licenses')
  });

  // Start trial mutation
  const startTrialMutation = useMutation({
    mutationFn: (productId: number) => 
      apiRequest(`/api/licensing/trial/${productId}`, { method: 'POST' }),
    onSuccess: () => {
      toast({
        title: "تم بدء الفترة التجريبية",
        description: "تم تفعيل الفترة التجريبية بنجاح",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/licensing/my-licenses'] });
    },
    onError: (error: any) => {
      toast({
        title: "خطأ في بدء الفترة التجريبية",
        description: error.message || "حدث خطأ أثناء بدء الفترة التجريبية",
        variant: "destructive",
      });
    }
  });

  // Purchase license mutation
  const purchaseMutation = useMutation({
    mutationFn: ({ productId, paymentId }: { productId: number; paymentId: string }) => 
      apiRequest(`/api/licensing/purchase/${productId}`, { 
        method: 'POST',
        body: JSON.stringify({ paymentId })
      }),
    onSuccess: () => {
      toast({
        title: "تم شراء الترخيص",
        description: "تم شراء الترخيص بنجاح",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/licensing/my-licenses'] });
    },
    onError: (error: any) => {
      toast({
        title: "خطأ في الشراء",
        description: error.message || "حدث خطأ أثناء عملية الشراء",
        variant: "destructive",
      });
    }
  });

  const products = productsData?.products || [];
  const licenses = licensesData?.licenses || [];

  const getProductIcon = (productType: string) => {
    switch (productType) {
      case 'subscription':
        return <Clock className="h-5 w-5" />;
      case 'license':
        return <Crown className="h-5 w-5" />;
      default:
        return <Star className="h-5 w-5" />;
    }
  };

  const getStatusBadge = (license: License) => {
    if (license.status === 'active') {
      if (license.licenseType === 'trial') {
        const daysLeft = license.trialEndsAt ? 
          Math.ceil((new Date(license.trialEndsAt).getTime() - Date.now()) / (1000 * 60 * 60 * 24)) : 0;
        return (
          <Badge variant="secondary" className="flex items-center gap-1">
            <Clock className="h-3 w-3" />
            فترة تجريبية - {daysLeft} أيام متبقية
          </Badge>
        );
      }
      return (
        <Badge variant="default" className="flex items-center gap-1">
          <CheckCircle className="h-3 w-3" />
          نشط
        </Badge>
      );
    }
    return (
      <Badge variant="destructive" className="flex items-center gap-1">
        <AlertCircle className="h-3 w-3" />
        منتهي الصلاحية
      </Badge>
    );
  };

  const handleStartTrial = (productId: number) => {
    startTrialMutation.mutate(productId);
  };

  const handlePurchase = (productId: number) => {
    // In a real app, this would integrate with a payment processor
    const paymentId = `payment_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    purchaseMutation.mutate({ productId, paymentId });
  };

  if (productsLoading || licensesLoading) {
    return (
      <div className="container mx-auto p-6">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">جاري تحميل البيانات...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6" dir="rtl">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
          إدارة التراخيص والاشتراكات
        </h1>
        <p className="text-gray-600 dark:text-gray-400">
          اختر الخطة المناسبة لك واستمتع بجميع ميزات بوت التداول المتقدم
        </p>
      </div>

      {/* Current Licenses */}
      {licenses.length > 0 && (
        <div className="mb-8">
          <h2 className="text-2xl font-semibold mb-4 flex items-center gap-2">
            <Shield className="h-6 w-6 text-blue-600" />
            تراخيصي الحالية
          </h2>
          <div className="grid gap-4">
            {licenses.map((license) => (
              <Card key={license.licenseKey} className="border-l-4 border-l-blue-500">
                <CardContent className="p-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-semibold text-lg mb-2">
                        ترخيص المنتج #{license.productId}
                      </h3>
                      <p className="text-sm text-gray-600 mb-2">
                        مفتاح الترخيص: <code className="bg-gray-100 px-2 py-1 rounded text-xs">
                          {license.licenseKey}
                        </code>
                      </p>
                      <div className="flex items-center gap-4 text-sm">
                        <span>النوع: {license.licenseType === 'trial' ? 'فترة تجريبية' : 
                          license.licenseType === 'paid' ? 'مدفوع' : 'مدى الحياة'}</span>
                        <span>الإشارات المستخدمة: {license.tradesUsed} / {license.maxTrades || '∞'}</span>
                      </div>
                    </div>
                    <div className="text-left">
                      {getStatusBadge(license)}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Available Products */}
      <div>
        <h2 className="text-2xl font-semibold mb-6 flex items-center gap-2">
          <ShoppingCart className="h-6 w-6 text-blue-600" />
          الخطط المتاحة
        </h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {products.map((product) => (
            <Card key={product.id} className={`relative ${
              product.name.includes('Pro') ? 'border-blue-500 shadow-lg' : ''
            }`}>
              {product.name.includes('Pro') && (
                <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                  <Badge variant="default" className="bg-blue-600 text-white">
                    الأكثر شعبية
                  </Badge>
                </div>
              )}
              
              <CardHeader className="text-center">
                <div className="flex justify-center mb-2">
                  {getProductIcon(product.productType)}
                </div>
                <CardTitle className="text-xl mb-2">{product.name}</CardTitle>
                <div className="text-3xl font-bold text-blue-600">
                  ${product.price}
                  <span className="text-sm font-normal text-gray-500">
                    {product.duration ? ` / ${product.duration} يوم` : ' / مدى الحياة'}
                  </span>
                </div>
              </CardHeader>
              
              <CardContent>
                <p className="text-gray-600 mb-4 text-sm">{product.description}</p>
                
                <div className="space-y-2 mb-6">
                  {product.features.map((feature, index) => (
                    <div key={index} className="flex items-center gap-2 text-sm">
                      <CheckCircle className="h-4 w-4 text-green-500" />
                      <span>{feature}</span>
                    </div>
                  ))}
                </div>

                <div className="space-y-2 mb-6 text-xs text-gray-500">
                  <div>الحد الأقصى للإشارات: {product.maxTrades || 'غير محدود'}</div>
                  <div>عدد الأجهزة: {product.maxDevices}</div>
                  <div>فترة تجريبية: {product.trialDuration} أيام</div>
                </div>

                <div className="space-y-2">
                  <Button 
                    onClick={() => handleStartTrial(product.id)}
                    disabled={startTrialMutation.isPending}
                    variant="outline" 
                    className="w-full"
                  >
                    {startTrialMutation.isPending ? 'جاري البدء...' : 'بدء فترة تجريبية'}
                  </Button>
                  
                  <Button 
                    onClick={() => handlePurchase(product.id)}
                    disabled={purchaseMutation.isPending}
                    className="w-full"
                  >
                    {purchaseMutation.isPending ? 'جاري الشراء...' : 'شراء الآن'}
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Features Comparison */}
      <div className="mt-12">
        <h2 className="text-2xl font-semibold mb-6 text-center">مقارنة الميزات</h2>
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 dark:bg-gray-700">
                <tr>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    الميزة
                  </th>
                  {products.map((product) => (
                    <th key={product.id} className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                      {product.name}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-white">
                    الإشارات اليومية
                  </td>
                  {products.map((product) => (
                    <td key={product.id} className="px-6 py-4 whitespace-nowrap text-center text-sm text-gray-500">
                      {product.maxTrades || 'غير محدود'}
                    </td>
                  ))}
                </tr>
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-white">
                    عدد الأجهزة
                  </td>
                  {products.map((product) => (
                    <td key={product.id} className="px-6 py-4 whitespace-nowrap text-center text-sm text-gray-500">
                      {product.maxDevices}
                    </td>
                  ))}
                </tr>
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-white">
                    فترة تجريبية
                  </td>
                  {products.map((product) => (
                    <td key={product.id} className="px-6 py-4 whitespace-nowrap text-center text-sm text-gray-500">
                      {product.trialDuration} أيام
                    </td>
                  ))}
                </tr>
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-white">
                    الدعم الفني
                  </td>
                  {products.map((product) => (
                    <td key={product.id} className="px-6 py-4 whitespace-nowrap text-center text-sm text-gray-500">
                      {product.name.includes('Basic') ? 'أساسي' : 
                       product.name.includes('Enterprise') ? 'مميز' : 'متقدم'}
                    </td>
                  ))}
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { 
  Newspaper, 
  TrendingUp, 
  TrendingDown, 
  AlertTriangle, 
  Globe, 
  Clock,
  Filter,
  Search,
  BookOpen,
  BarChart3,
  Brain,
  Target,
  Zap
} from "lucide-react";
import { motion } from "framer-motion";
import { useQuery } from "@tanstack/react-query";

interface NewsItem {
  id: string;
  title: string;
  titleAr: string;
  content: string;
  contentAr: string;
  source: string;
  publishedAt: Date;
  sentiment: "positive" | "negative" | "neutral";
  sentimentScore: number;
  impact: "high" | "medium" | "low";
  category: string;
  relevantAssets: string[];
  tags: string[];
  readTime: number;
  url: string;
  imageUrl?: string;
  aiAnalysis: {
    summary: string;
    summaryAr: string;
    keyPoints: string[];
    keyPointsAr: string[];
    tradingImplications: string;
    tradingImplicationsAr: string;
    probabilityImpact: number;
    confidence: number;
  };
}

interface NewsAnalytics {
  totalNews: number;
  sentimentDistribution: {
    positive: number;
    negative: number;
    neutral: number;
  };
  topSources: Array<{
    source: string;
    count: number;
    avgSentiment: number;
  }>;
  trendingTopics: Array<{
    topic: string;
    count: number;
    sentiment: number;
  }>;
  assetMentions: Array<{
    asset: string;
    mentions: number;
    sentiment: number;
  }>;
}

const mockNewsData: NewsItem[] = [
  {
    id: "1",
    title: "Federal Reserve Hints at Rate Cut in December Meeting",
    titleAr: "البنك الفيدرالي يلمح إلى خفض الفائدة في اجتماع ديسمبر",
    content: "The Federal Reserve has indicated potential interest rate cuts following concerns about economic slowdown...",
    contentAr: "أشار البنك الفيدرالي إلى احتمالية خفض أسعار الفائدة بعد المخاوف من التباطؤ الاقتصادي...",
    source: "Reuters",
    publishedAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
    sentiment: "positive",
    sentimentScore: 0.7,
    impact: "high",
    category: "Central Banking",
    relevantAssets: ["USD/EUR", "Gold", "S&P 500"],
    tags: ["Fed", "Interest Rates", "Monetary Policy"],
    readTime: 3,
    url: "#",
    aiAnalysis: {
      summary: "Fed signals dovish stance with potential rate cuts to support economic growth",
      summaryAr: "الفيدرالي يشير إلى موقف حمائمي مع احتمالية خفض الفائدة لدعم النمو الاقتصادي",
      keyPoints: [
        "Rate cut probability increased to 75%",
        "Economic data shows mixed signals",
        "Market expects 25 basis point cut"
      ],
      keyPointsAr: [
        "احتمالية خفض الفائدة ارتفعت إلى 75%",
        "البيانات الاقتصادية تظهر إشارات متباينة",
        "السوق يتوقع خفض 25 نقطة أساس"
      ],
      tradingImplications: "USD may weaken, gold and stocks likely to rally",
      tradingImplicationsAr: "الدولار قد يضعف، الذهب والأسهم قد ترتفع",
      probabilityImpact: 0.85,
      confidence: 0.92
    }
  },
  {
    id: "2",
    title: "European Central Bank Maintains Hawkish Stance",
    titleAr: "البنك المركزي الأوروبي يحافظ على موقف متشدد",
    content: "ECB officials continue to emphasize the need for restrictive monetary policy...",
    contentAr: "مسؤولو البنك المركزي الأوروبي يستمرون في التأكيد على الحاجة لسياسة نقدية مقيدة...",
    source: "Bloomberg",
    publishedAt: new Date(Date.now() - 4 * 60 * 60 * 1000),
    sentiment: "negative",
    sentimentScore: -0.5,
    impact: "medium",
    category: "Central Banking",
    relevantAssets: ["EUR/USD", "European Stocks"],
    tags: ["ECB", "Inflation", "Monetary Policy"],
    readTime: 2,
    url: "#",
    aiAnalysis: {
      summary: "ECB maintains restrictive policy stance to combat persistent inflation",
      summaryAr: "البنك المركزي الأوروبي يحافظ على موقف مقيد لمكافحة التضخم المستمر",
      keyPoints: [
        "No rate cuts expected until Q2 2024",
        "Inflation remains above target",
        "Economic growth slowing but stable"
      ],
      keyPointsAr: [
        "لا توقع خفض فائدة حتى الربع الثاني 2024",
        "التضخم يبقى فوق المستهدف",
        "النمو الاقتصادي يتباطأ لكنه مستقر"
      ],
      tradingImplications: "EUR strength may continue, European assets under pressure",
      tradingImplicationsAr: "قوة اليورو قد تستمر، الأصول الأوروبية تحت ضغط",
      probabilityImpact: 0.72,
      confidence: 0.88
    }
  },
  {
    id: "3",
    title: "Bitcoin Surges as Institutional Adoption Accelerates",
    titleAr: "البيتكوين يرتفع مع تسارع الاعتماد المؤسسي",
    content: "Major financial institutions announce increased Bitcoin allocations...",
    contentAr: "المؤسسات المالية الكبرى تعلن زيادة مخصصات البيتكوين...",
    source: "CoinDesk",
    publishedAt: new Date(Date.now() - 6 * 60 * 60 * 1000),
    sentiment: "positive",
    sentimentScore: 0.8,
    impact: "high",
    category: "Cryptocurrency",
    relevantAssets: ["BTC/USD", "ETH/USD", "Crypto Stocks"],
    tags: ["Bitcoin", "Institutional", "Adoption"],
    readTime: 4,
    url: "#",
    aiAnalysis: {
      summary: "Institutional Bitcoin adoption drives price momentum and market confidence",
      summaryAr: "الاعتماد المؤسسي للبيتكوين يدفع زخم السعر وثقة السوق",
      keyPoints: [
        "Major banks increase crypto exposure",
        "Bitcoin ETF inflows reach record highs",
        "Regulatory clarity improving"
      ],
      keyPointsAr: [
        "البنوك الكبرى تزيد التعرض للعملات المشفرة",
        "تدفقات صندوق بيتكوين تصل أرقام قياسية",
        "الوضوح التنظيمي يتحسن"
      ],
      tradingImplications: "Crypto bullish momentum likely to continue, altcoins may follow",
      tradingImplicationsAr: "الزخم الصاعد للعملات المشفرة قد يستمر، العملات البديلة قد تتبع",
      probabilityImpact: 0.78,
      confidence: 0.85
    }
  }
];

const mockAnalytics: NewsAnalytics = {
  totalNews: 147,
  sentimentDistribution: {
    positive: 42,
    negative: 28,
    neutral: 77
  },
  topSources: [
    { source: "Reuters", count: 23, avgSentiment: 0.3 },
    { source: "Bloomberg", count: 19, avgSentiment: 0.1 },
    { source: "Financial Times", count: 15, avgSentiment: 0.4 }
  ],
  trendingTopics: [
    { topic: "Federal Reserve", count: 12, sentiment: 0.2 },
    { topic: "Interest Rates", count: 8, sentiment: 0.3 },
    { topic: "Bitcoin", count: 7, sentiment: 0.6 }
  ],
  assetMentions: [
    { asset: "USD", mentions: 34, sentiment: 0.1 },
    { asset: "EUR", mentions: 28, sentiment: 0.2 },
    { asset: "BTC", mentions: 21, sentiment: 0.7 }
  ]
};

export default function AdvancedNewsAnalyzer() {
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedSentiment, setSelectedSentiment] = useState("all");
  const [selectedImpact, setSelectedImpact] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [language, setLanguage] = useState("en");
  const [autoRefresh, setAutoRefresh] = useState(true);

  const { data: newsData, isLoading, refetch } = useQuery({
    queryKey: ['/api/news-analyzer', selectedCategory, selectedSentiment, selectedImpact, searchQuery],
    queryFn: async () => {
      // Simulate API call with filters
      let filteredNews = mockNewsData;
      
      if (selectedCategory !== "all") {
        filteredNews = filteredNews.filter(news => news.category === selectedCategory);
      }
      
      if (selectedSentiment !== "all") {
        filteredNews = filteredNews.filter(news => news.sentiment === selectedSentiment);
      }
      
      if (selectedImpact !== "all") {
        filteredNews = filteredNews.filter(news => news.impact === selectedImpact);
      }
      
      if (searchQuery) {
        filteredNews = filteredNews.filter(news => 
          news.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          news.titleAr.includes(searchQuery)
        );
      }
      
      return filteredNews;
    },
    refetchInterval: autoRefresh ? 30000 : false
  });

  const { data: analyticsData } = useQuery({
    queryKey: ['/api/news-analytics'],
    queryFn: async () => mockAnalytics,
    refetchInterval: autoRefresh ? 60000 : false
  });

  const getSentimentColor = (sentiment: string) => {
    switch (sentiment) {
      case "positive": return "text-green-600 bg-green-50";
      case "negative": return "text-red-600 bg-red-50";
      default: return "text-gray-600 bg-gray-50";
    }
  };

  const getImpactColor = (impact: string) => {
    switch (impact) {
      case "high": return "text-red-600 bg-red-50";
      case "medium": return "text-yellow-600 bg-yellow-50";
      default: return "text-gray-600 bg-gray-50";
    }
  };

  if (isLoading) {
    return <div className="p-6">Loading news analysis...</div>;
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            Advanced News Analyzer
          </h1>
          <p className="text-gray-600 mt-2">
            AI-powered news analysis with trading implications
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setAutoRefresh(!autoRefresh)}
          >
            {autoRefresh ? <Zap className="w-4 h-4" /> : <Clock className="w-4 h-4" />}
            {autoRefresh ? "Auto" : "Manual"}
          </Button>
          <Button
            variant="outline"
            onClick={() => setLanguage(language === "en" ? "ar" : "en")}
          >
            {language === "en" ? "العربية" : "English"}
          </Button>
        </div>
      </div>

      {/* Analytics Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Newspaper className="w-5 h-5 text-blue-500" />
              <div>
                <p className="text-sm text-gray-600">Total News</p>
                <p className="text-2xl font-bold">{analyticsData?.totalNews}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-green-500" />
              <div>
                <p className="text-sm text-gray-600">Positive</p>
                <p className="text-2xl font-bold text-green-600">
                  {analyticsData?.sentimentDistribution.positive}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <TrendingDown className="w-5 h-5 text-red-500" />
              <div>
                <p className="text-sm text-gray-600">Negative</p>
                <p className="text-2xl font-bold text-red-600">
                  {analyticsData?.sentimentDistribution.negative}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-yellow-500" />
              <div>
                <p className="text-sm text-gray-600">High Impact</p>
                <p className="text-2xl font-bold text-yellow-600">
                  {newsData?.filter(n => n.impact === "high").length || 0}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Filter className="w-5 h-5" />
            Filters & Search
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search news..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger>
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                <SelectItem value="Central Banking">Central Banking</SelectItem>
                <SelectItem value="Cryptocurrency">Cryptocurrency</SelectItem>
                <SelectItem value="Forex">Forex</SelectItem>
                <SelectItem value="Stocks">Stocks</SelectItem>
                <SelectItem value="Commodities">Commodities</SelectItem>
              </SelectContent>
            </Select>

            <Select value={selectedSentiment} onValueChange={setSelectedSentiment}>
              <SelectTrigger>
                <SelectValue placeholder="Sentiment" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Sentiments</SelectItem>
                <SelectItem value="positive">Positive</SelectItem>
                <SelectItem value="negative">Negative</SelectItem>
                <SelectItem value="neutral">Neutral</SelectItem>
              </SelectContent>
            </Select>

            <Select value={selectedImpact} onValueChange={setSelectedImpact}>
              <SelectTrigger>
                <SelectValue placeholder="Impact" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Impact</SelectItem>
                <SelectItem value="high">High Impact</SelectItem>
                <SelectItem value="medium">Medium Impact</SelectItem>
                <SelectItem value="low">Low Impact</SelectItem>
              </SelectContent>
            </Select>

            <Button onClick={() => refetch()} className="flex items-center gap-2">
              <Search className="w-4 h-4" />
              Refresh
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* News List */}
      <div className="space-y-4">
        {newsData?.map((news) => (
          <motion.div
            key={news.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
          >
            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <CardTitle className="text-lg leading-tight mb-2">
                      {language === "en" ? news.title : news.titleAr}
                    </CardTitle>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Globe className="w-4 h-4" />
                      <span>{news.source}</span>
                      <span>•</span>
                      <Clock className="w-4 h-4" />
                      <span>{news.publishedAt.toLocaleDateString()}</span>
                      <span>•</span>
                      <BookOpen className="w-4 h-4" />
                      <span>{news.readTime} min read</span>
                    </div>
                  </div>
                  <div className="flex flex-col items-end gap-2">
                    <div className="flex items-center gap-2">
                      <Badge className={getSentimentColor(news.sentiment)}>
                        {news.sentiment}
                      </Badge>
                      <Badge className={getImpactColor(news.impact)}>
                        {news.impact}
                      </Badge>
                    </div>
                    <div className="text-sm text-gray-500">
                      Confidence: {Math.round(news.aiAnalysis.confidence * 100)}%
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="summary" className="w-full">
                  <TabsList className="grid w-full grid-cols-4">
                    <TabsTrigger value="summary">Summary</TabsTrigger>
                    <TabsTrigger value="analysis">AI Analysis</TabsTrigger>
                    <TabsTrigger value="impact">Trading Impact</TabsTrigger>
                    <TabsTrigger value="assets">Assets</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="summary" className="mt-4">
                    <div className="space-y-3">
                      <p className="text-gray-700">
                        {language === "en" ? news.aiAnalysis.summary : news.aiAnalysis.summaryAr}
                      </p>
                      <div className="flex flex-wrap gap-2">
                        {news.tags.map((tag) => (
                          <Badge key={tag} variant="outline" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="analysis" className="mt-4">
                    <div className="space-y-3">
                      <div>
                        <h4 className="font-semibold mb-2">Key Points:</h4>
                        <ul className="list-disc list-inside space-y-1 text-sm text-gray-600">
                          {(language === "en" ? news.aiAnalysis.keyPoints : news.aiAnalysis.keyPointsAr).map((point, index) => (
                            <li key={index}>{point}</li>
                          ))}
                        </ul>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <p className="text-sm text-gray-600">Sentiment Score</p>
                          <div className="flex items-center gap-2">
                            <Progress value={(news.sentimentScore + 1) * 50} className="flex-1" />
                            <span className="text-sm font-medium">
                              {Math.round(news.sentimentScore * 100)}%
                            </span>
                          </div>
                        </div>
                        <div>
                          <p className="text-sm text-gray-600">Impact Probability</p>
                          <div className="flex items-center gap-2">
                            <Progress value={news.aiAnalysis.probabilityImpact * 100} className="flex-1" />
                            <span className="text-sm font-medium">
                              {Math.round(news.aiAnalysis.probabilityImpact * 100)}%
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="impact" className="mt-4">
                    <div className="space-y-3">
                      <div className="bg-blue-50 p-3 rounded-lg">
                        <div className="flex items-center gap-2 mb-2">
                          <Target className="w-4 h-4 text-blue-600" />
                          <h4 className="font-semibold text-blue-900">Trading Implications</h4>
                        </div>
                        <p className="text-sm text-blue-800">
                          {language === "en" ? news.aiAnalysis.tradingImplications : news.aiAnalysis.tradingImplicationsAr}
                        </p>
                      </div>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="assets" className="mt-4">
                    <div className="space-y-3">
                      <div>
                        <h4 className="font-semibold mb-2">Relevant Assets:</h4>
                        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                          {news.relevantAssets.map((asset) => (
                            <div key={asset} className="flex items-center gap-2 p-2 bg-gray-50 rounded">
                              <BarChart3 className="w-4 h-4 text-gray-600" />
                              <span className="text-sm font-medium">{asset}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
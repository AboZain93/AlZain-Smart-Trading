import { useState, useEffect } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { useLanguageContext } from '../components/language-provider';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Badge } from '../components/ui/badge';
import { Progress } from '../components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { useToast } from '../hooks/use-toast';
import { apiRequest, queryClient } from '../lib/queryClient';
import { FloatingRefreshButton } from '../components/floating-refresh-button';
import {
  TrendingUp,
  TrendingDown,
  DollarSign,
  PieChart,
  BarChart3,
  Target,
  AlertTriangle,
  Plus,
  Minus,
  Calculator,
  Calendar,
  Activity
} from 'lucide-react';

interface Portfolio {
  id: number;
  name: string;
  totalValue: number;
  totalProfitLoss: number;
  totalReturn: number;
  riskScore: number;
  createdAt: string;
  updatedAt: string;
}

interface PortfolioAsset {
  id: number;
  portfolioId: number;
  assetSymbol: string;
  quantity: number;
  averagePrice: number;
  currentPrice: number;
  totalValue: number;
  profitLoss: number;
  profitLossPercent: number;
  lastUpdated: string;
}

interface TradingStrategy {
  id: number;
  name: string;
  description: string;
  riskLevel: string;
  assetTypes: string[];
  minConfidence: number;
  maxDailyTrades: number;
  stopLoss: number;
  takeProfit: number;
  isActive: boolean;
}

export default function PortfolioPage() {
  const { language } = useLanguageContext();
  const { toast } = useToast();
  const [selectedPortfolio, setSelectedPortfolio] = useState<number | null>(null);

  // Fetch portfolios
  const { data: portfolios = [], refetch: refetchPortfolios } = useQuery<Portfolio[]>({
    queryKey: ['/api/portfolios'],
    refetchInterval: 30000,
  });

  // Fetch portfolio assets
  const { data: portfolioAssets = [] } = useQuery<PortfolioAsset[]>({
    queryKey: ['/api/portfolio-assets', selectedPortfolio],
    enabled: !!selectedPortfolio,
    refetchInterval: 15000,
  });

  // Fetch trading strategies
  const { data: strategies = [] } = useQuery<TradingStrategy[]>({
    queryKey: ['/api/trading-strategies'],
    refetchInterval: 60000,
  });

  // Calculate portfolio stats
  const portfolioStats = portfolios.reduce((acc, portfolio) => {
    acc.totalValue += portfolio.totalValue;
    acc.totalProfitLoss += portfolio.totalProfitLoss;
    acc.avgReturn += portfolio.totalReturn;
    return acc;
  }, { totalValue: 0, totalProfitLoss: 0, avgReturn: 0 });

  if (portfolios.length > 0) {
    portfolioStats.avgReturn /= portfolios.length;
  }

  const handleRefreshData = () => {
    refetchPortfolios();
    queryClient.invalidateQueries({ queryKey: ['/api/portfolio-assets'] });
    queryClient.invalidateQueries({ queryKey: ['/api/trading-strategies'] });
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat(language === 'ar' ? 'ar-SA' : 'en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
    }).format(value);
  };

  const formatPercent = (value: number) => {
    return new Intl.NumberFormat(language === 'ar' ? 'ar-SA' : 'en-US', {
      style: 'percent',
      minimumFractionDigits: 2,
    }).format(value / 100);
  };

  return (
    <div className="container mx-auto p-6 space-y-6" dir={language === 'ar' ? 'rtl' : 'ltr'}>
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            {language === 'ar' ? 'إدارة المحفظة' : 'Portfolio Management'}
          </h1>
          <p className="text-muted-foreground">
            {language === 'ar' 
              ? 'تتبع وإدارة استثماراتك واستراتيجيات التداول' 
              : 'Track and manage your investments and trading strategies'}
          </p>
        </div>
      </div>

      {/* Portfolio Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-blue-600">
                  {language === 'ar' ? 'إجمالي القيمة' : 'Total Value'}
                </p>
                <p className="text-2xl font-bold text-blue-900">
                  {formatCurrency(portfolioStats.totalValue)}
                </p>
              </div>
              <DollarSign className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card className={`bg-gradient-to-br ${
          portfolioStats.totalProfitLoss >= 0 
            ? 'from-green-50 to-emerald-50 border-green-200' 
            : 'from-red-50 to-rose-50 border-red-200'
        }`}>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className={`text-sm font-medium ${
                  portfolioStats.totalProfitLoss >= 0 ? 'text-green-600' : 'text-red-600'
                }`}>
                  {language === 'ar' ? 'الربح/الخسارة' : 'Profit/Loss'}
                </p>
                <p className={`text-2xl font-bold ${
                  portfolioStats.totalProfitLoss >= 0 ? 'text-green-900' : 'text-red-900'
                }`}>
                  {formatCurrency(portfolioStats.totalProfitLoss)}
                </p>
              </div>
              {portfolioStats.totalProfitLoss >= 0 ? (
                <TrendingUp className="h-8 w-8 text-green-600" />
              ) : (
                <TrendingDown className="h-8 w-8 text-red-600" />
              )}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-50 to-violet-50 border-purple-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-purple-600">
                  {language === 'ar' ? 'متوسط العائد' : 'Average Return'}
                </p>
                <p className="text-2xl font-bold text-purple-900">
                  {formatPercent(portfolioStats.avgReturn)}
                </p>
              </div>
              <BarChart3 className="h-8 w-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-orange-50 to-amber-50 border-orange-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-orange-600">
                  {language === 'ar' ? 'عدد المحافظ' : 'Portfolios'}
                </p>
                <p className="text-2xl font-bold text-orange-900">
                  {portfolios.length}
                </p>
              </div>
              <PieChart className="h-8 w-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="portfolios" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="portfolios">
            {language === 'ar' ? 'المحافظ' : 'Portfolios'}
          </TabsTrigger>
          <TabsTrigger value="strategies">
            {language === 'ar' ? 'الاستراتيجيات' : 'Strategies'}
          </TabsTrigger>
          <TabsTrigger value="analytics">
            {language === 'ar' ? 'التحليلات' : 'Analytics'}
          </TabsTrigger>
        </TabsList>

        <TabsContent value="portfolios" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <PieChart className="h-5 w-5" />
                {language === 'ar' ? 'محافظي الاستثمارية' : 'My Portfolios'}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {portfolios.length === 0 ? (
                <div className="text-center py-12">
                  <PieChart className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground mb-4">
                    {language === 'ar' 
                      ? 'لم يتم إنشاء أي محافظ بعد' 
                      : 'No portfolios created yet'}
                  </p>
                  <Button>
                    <Plus className="h-4 w-4 mr-2" />
                    {language === 'ar' ? 'إنشاء محفظة جديدة' : 'Create New Portfolio'}
                  </Button>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {portfolios.map((portfolio) => (
                    <Card 
                      key={portfolio.id} 
                      className={`cursor-pointer transition-all hover:shadow-lg ${
                        selectedPortfolio === portfolio.id ? 'ring-2 ring-blue-500' : ''
                      }`}
                      onClick={() => setSelectedPortfolio(portfolio.id)}
                    >
                      <CardContent className="p-4">
                        <div className="space-y-3">
                          <div className="flex justify-between items-start">
                            <h3 className="font-semibold">{portfolio.name}</h3>
                            <Badge variant={portfolio.totalProfitLoss >= 0 ? "default" : "destructive"}>
                              {formatPercent(portfolio.totalReturn)}
                            </Badge>
                          </div>
                          
                          <div className="space-y-2">
                            <div className="flex justify-between text-sm">
                              <span className="text-muted-foreground">
                                {language === 'ar' ? 'القيمة الإجمالية' : 'Total Value'}
                              </span>
                              <span className="font-medium">
                                {formatCurrency(portfolio.totalValue)}
                              </span>
                            </div>
                            
                            <div className="flex justify-between text-sm">
                              <span className="text-muted-foreground">
                                {language === 'ar' ? 'الربح/الخسارة' : 'P&L'}
                              </span>
                              <span className={`font-medium ${
                                portfolio.totalProfitLoss >= 0 ? 'text-green-600' : 'text-red-600'
                              }`}>
                                {formatCurrency(portfolio.totalProfitLoss)}
                              </span>
                            </div>
                            
                            <div className="space-y-1">
                              <div className="flex justify-between text-sm">
                                <span className="text-muted-foreground">
                                  {language === 'ar' ? 'درجة المخاطر' : 'Risk Score'}
                                </span>
                                <span className="text-xs">
                                  {portfolio.riskScore.toFixed(1)}/10
                                </span>
                              </div>
                              <Progress value={portfolio.riskScore * 10} className="h-2" />
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Portfolio Assets */}
          {selectedPortfolio && portfolioAssets.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="h-5 w-5" />
                  {language === 'ar' ? 'أصول المحفظة' : 'Portfolio Assets'}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {portfolioAssets.map((asset) => (
                    <div key={asset.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex-1">
                        <div className="flex items-center gap-3">
                          <h4 className="font-semibold">{asset.assetSymbol}</h4>
                          <Badge variant={asset.profitLoss >= 0 ? "default" : "destructive"}>
                            {formatPercent(asset.profitLossPercent)}
                          </Badge>
                        </div>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-2 text-sm text-muted-foreground">
                          <div>
                            <span className="block">
                              {language === 'ar' ? 'الكمية' : 'Quantity'}
                            </span>
                            <span className="font-medium text-foreground">
                              {asset.quantity.toFixed(4)}
                            </span>
                          </div>
                          <div>
                            <span className="block">
                              {language === 'ar' ? 'متوسط السعر' : 'Avg Price'}
                            </span>
                            <span className="font-medium text-foreground">
                              {formatCurrency(asset.averagePrice)}
                            </span>
                          </div>
                          <div>
                            <span className="block">
                              {language === 'ar' ? 'السعر الحالي' : 'Current Price'}
                            </span>
                            <span className="font-medium text-foreground">
                              {formatCurrency(asset.currentPrice)}
                            </span>
                          </div>
                          <div>
                            <span className="block">
                              {language === 'ar' ? 'القيمة الإجمالية' : 'Total Value'}
                            </span>
                            <span className="font-medium text-foreground">
                              {formatCurrency(asset.totalValue)}
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className={`text-right ${
                        asset.profitLoss >= 0 ? 'text-green-600' : 'text-red-600'
                      }`}>
                        <div className="font-semibold">
                          {formatCurrency(asset.profitLoss)}
                        </div>
                        {asset.profitLoss >= 0 ? (
                          <TrendingUp className="h-4 w-4 ml-auto" />
                        ) : (
                          <TrendingDown className="h-4 w-4 ml-auto" />
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="strategies" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-5 w-5" />
                {language === 'ar' ? 'استراتيجيات التداول' : 'Trading Strategies'}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {strategies.length === 0 ? (
                <div className="text-center py-12">
                  <Target className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground mb-4">
                    {language === 'ar' 
                      ? 'لم يتم إنشاء أي استراتيجيات بعد' 
                      : 'No strategies created yet'}
                  </p>
                  <Button>
                    <Plus className="h-4 w-4 mr-2" />
                    {language === 'ar' ? 'إنشاء استراتيجية جديدة' : 'Create New Strategy'}
                  </Button>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {strategies.map((strategy) => (
                    <Card key={strategy.id} className="border">
                      <CardContent className="p-4">
                        <div className="space-y-3">
                          <div className="flex justify-between items-start">
                            <h4 className="font-semibold">{strategy.name}</h4>
                            <Badge variant={strategy.isActive ? "default" : "secondary"}>
                              {strategy.isActive ? 
                                (language === 'ar' ? 'نشط' : 'Active') : 
                                (language === 'ar' ? 'غير نشط' : 'Inactive')}
                            </Badge>
                          </div>
                          
                          {strategy.description && (
                            <p className="text-sm text-muted-foreground">
                              {strategy.description}
                            </p>
                          )}
                          
                          <div className="grid grid-cols-2 gap-4 text-sm">
                            <div>
                              <span className="text-muted-foreground">
                                {language === 'ar' ? 'مستوى المخاطر' : 'Risk Level'}
                              </span>
                              <div className="font-medium capitalize">
                                {strategy.riskLevel}
                              </div>
                            </div>
                            <div>
                              <span className="text-muted-foreground">
                                {language === 'ar' ? 'الحد الأدنى للثقة' : 'Min Confidence'}
                              </span>
                              <div className="font-medium">
                                {strategy.minConfidence}%
                              </div>
                            </div>
                            <div>
                              <span className="text-muted-foreground">
                                {language === 'ar' ? 'وقف الخسارة' : 'Stop Loss'}
                              </span>
                              <div className="font-medium">
                                {strategy.stopLoss}%
                              </div>
                            </div>
                            <div>
                              <span className="text-muted-foreground">
                                {language === 'ar' ? 'جني الأرباح' : 'Take Profit'}
                              </span>
                              <div className="font-medium">
                                {strategy.takeProfit}%
                              </div>
                            </div>
                          </div>
                          
                          <div className="space-y-2">
                            <span className="text-sm text-muted-foreground">
                              {language === 'ar' ? 'أنواع الأصول' : 'Asset Types'}
                            </span>
                            <div className="flex flex-wrap gap-1">
                              {strategy.assetTypes.map((type, index) => (
                                <Badge key={index} variant="outline" className="text-xs">
                                  {type}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5" />
                {language === 'ar' ? 'تحليلات الأداء' : 'Performance Analytics'}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-12">
                <BarChart3 className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">
                  {language === 'ar' 
                    ? 'ستكون التحليلات متاحة قريباً' 
                    : 'Analytics will be available soon'}
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <FloatingRefreshButton 
        onRefresh={handleRefreshData}
      />
    </div>
  );
}
import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  PieChart, 
  Target, 
  AlertTriangle,
  Plus,
  Minus,
  Calculator,
  BarChart3,
  LineChart,
  Settings,
  Zap,
  Shield,
  Activity,
  Clock,
  Users,
  Eye,
  EyeOff
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

interface Position {
  id: string;
  asset: string;
  type: "buy" | "sell";
  quantity: number;
  entryPrice: number;
  currentPrice: number;
  openedAt: Date;
  status: "open" | "closed";
  stopLoss?: number;
  takeProfit?: number;
  pnl: number;
  pnlPercentage: number;
  fees: number;
  platform: string;
  strategy: string;
  notes?: string;
  riskLevel: "low" | "medium" | "high";
}

interface PortfolioSummary {
  totalValue: number;
  totalPnL: number;
  totalPnLPercentage: number;
  dailyPnL: number;
  dailyPnLPercentage: number;
  totalPositions: number;
  openPositions: number;
  winRate: number;
  averageWin: number;
  averageLoss: number;
  sharpeRatio: number;
  maxDrawdown: number;
  riskScore: number;
  diversificationScore: number;
}

interface RiskMetrics {
  valueAtRisk: number;
  expectedShortfall: number;
  positionSizing: number;
  correlationRisk: number;
  volatilityRisk: number;
  concentrationRisk: number;
  liquidityRisk: number;
  overallRisk: number;
}

interface PortfolioSettings {
  maxPositionSize: number;
  maxRiskPerTrade: number;
  maxDailyLoss: number;
  autoStopLoss: boolean;
  autoTakeProfit: boolean;
  riskManagementMode: "conservative" | "moderate" | "aggressive";
  notifications: boolean;
  autoRebalance: boolean;
}

// Mock data
const mockPositions: Position[] = [
  {
    id: "1",
    asset: "EUR/USD",
    type: "buy",
    quantity: 100000,
    entryPrice: 1.0856,
    currentPrice: 1.0892,
    openedAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
    status: "open",
    stopLoss: 1.0820,
    takeProfit: 1.0920,
    pnl: 360,
    pnlPercentage: 3.31,
    fees: 15,
    platform: "Quotex",
    strategy: "Trend Following",
    riskLevel: "medium",
    notes: "Strong bullish momentum confirmed"
  },
  {
    id: "2",
    asset: "BTC/USD",
    type: "buy",
    quantity: 0.5,
    entryPrice: 42850,
    currentPrice: 43200,
    openedAt: new Date(Date.now() - 6 * 60 * 60 * 1000),
    status: "open",
    stopLoss: 42000,
    takeProfit: 45000,
    pnl: 175,
    pnlPercentage: 0.82,
    fees: 25,
    platform: "Quotex",
    strategy: "Breakout",
    riskLevel: "high",
    notes: "Breakout above resistance level"
  },
  {
    id: "3",
    asset: "GBP/USD",
    type: "sell",
    quantity: 75000,
    entryPrice: 1.2645,
    currentPrice: 1.2598,
    openedAt: new Date(Date.now() - 1 * 60 * 60 * 1000),
    status: "open",
    stopLoss: 1.2680,
    takeProfit: 1.2550,
    pnl: 352.5,
    pnlPercentage: 3.72,
    fees: 12,
    platform: "Quotex",
    strategy: "Mean Reversion",
    riskLevel: "low"
  }
];

const mockSummary: PortfolioSummary = {
  totalValue: 125000,
  totalPnL: 8750,
  totalPnLPercentage: 7.5,
  dailyPnL: 887.5,
  dailyPnLPercentage: 0.71,
  totalPositions: 23,
  openPositions: 3,
  winRate: 68.5,
  averageWin: 285,
  averageLoss: -165,
  sharpeRatio: 1.85,
  maxDrawdown: -2.8,
  riskScore: 6.2,
  diversificationScore: 8.1
};

const mockRiskMetrics: RiskMetrics = {
  valueAtRisk: 1250,
  expectedShortfall: 1875,
  positionSizing: 7.5,
  correlationRisk: 4.2,
  volatilityRisk: 6.8,
  concentrationRisk: 5.5,
  liquidityRisk: 3.2,
  overallRisk: 5.8
};

export default function AdvancedPortfolioManager() {
  const [selectedTab, setSelectedTab] = useState("overview");
  const [hideBalances, setHideBalances] = useState(false);
  const [showRiskMetrics, setShowRiskMetrics] = useState(false);
  const [language, setLanguage] = useState("en");
  const [settings, setSettings] = useState<PortfolioSettings>({
    maxPositionSize: 10000,
    maxRiskPerTrade: 2,
    maxDailyLoss: 5,
    autoStopLoss: true,
    autoTakeProfit: true,
    riskManagementMode: "moderate",
    notifications: true,
    autoRebalance: false
  });

  const queryClient = useQueryClient();

  const { data: positions = [], isLoading: positionsLoading } = useQuery({
    queryKey: ['/api/portfolio/positions'],
    queryFn: async () => mockPositions
  });

  const { data: summary = mockSummary, isLoading: summaryLoading } = useQuery({
    queryKey: ['/api/portfolio/summary'],
    queryFn: async () => mockSummary
  });

  const { data: riskMetrics = mockRiskMetrics } = useQuery({
    queryKey: ['/api/portfolio/risk-metrics'],
    queryFn: async () => mockRiskMetrics
  });

  const formatCurrency = (amount: number, hideValue: boolean = false) => {
    if (hideValue) return "****";
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2
    }).format(amount);
  };

  const formatPercentage = (value: number, hideValue: boolean = false) => {
    if (hideValue) return "**%";
    return `${value > 0 ? '+' : ''}${value.toFixed(2)}%`;
  };

  const getPositionPnLColor = (pnl: number) => {
    return pnl >= 0 ? "text-green-600" : "text-red-600";
  };

  const getRiskLevelColor = (level: string) => {
    switch (level) {
      case "low": return "bg-green-100 text-green-800";
      case "medium": return "bg-yellow-100 text-yellow-800";
      case "high": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getRiskScoreColor = (score: number) => {
    if (score <= 3) return "text-green-600";
    if (score <= 6) return "text-yellow-600";
    return "text-red-600";
  };

  if (positionsLoading || summaryLoading) {
    return <div className="p-6">Loading portfolio...</div>;
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            Advanced Portfolio Manager
          </h1>
          <p className="text-gray-600 mt-2">
            Comprehensive portfolio management with advanced risk analytics
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setHideBalances(!hideBalances)}
          >
            {hideBalances ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
            {hideBalances ? "Show" : "Hide"}
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowRiskMetrics(!showRiskMetrics)}
          >
            <Shield className="w-4 h-4" />
            Risk
          </Button>
          <Button
            variant="outline"
            onClick={() => setLanguage(language === "en" ? "ar" : "en")}
          >
            {language === "en" ? "العربية" : "English"}
          </Button>
        </div>
      </div>

      {/* Portfolio Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-blue-500 to-purple-500 opacity-10" />
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Value</p>
                <p className="text-2xl font-bold">
                  {formatCurrency(summary.totalValue, hideBalances)}
                </p>
              </div>
              <DollarSign className="w-8 h-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="relative overflow-hidden">
          <div className={`absolute inset-0 ${
            summary.totalPnL >= 0 ? 'bg-green-500' : 'bg-red-500'
          } opacity-10`} />
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total P&L</p>
                <p className={`text-2xl font-bold ${getPositionPnLColor(summary.totalPnL)}`}>
                  {formatCurrency(summary.totalPnL, hideBalances)}
                </p>
                <p className={`text-sm ${getPositionPnLColor(summary.totalPnL)}`}>
                  {formatPercentage(summary.totalPnLPercentage, hideBalances)}
                </p>
              </div>
              {summary.totalPnL >= 0 ? (
                <TrendingUp className="w-8 h-8 text-green-500" />
              ) : (
                <TrendingDown className="w-8 h-8 text-red-500" />
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Open Positions</p>
                <p className="text-2xl font-bold">{summary.openPositions}</p>
                <p className="text-sm text-gray-500">
                  of {summary.totalPositions} total
                </p>
              </div>
              <PieChart className="w-8 h-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Win Rate</p>
                <p className="text-2xl font-bold">{summary.winRate}%</p>
                <p className="text-sm text-gray-500">
                  Sharpe: {summary.sharpeRatio}
                </p>
              </div>
              <Target className="w-8 h-8 text-green-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Risk Metrics Overview */}
      <AnimatePresence>
        {showRiskMetrics && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
          >
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="w-5 h-5" />
                  Risk Metrics Dashboard
                </CardTitle>
                <CardDescription>
                  Advanced risk analytics and portfolio health indicators
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">Value at Risk (VaR)</span>
                      <span className="font-medium text-red-600">
                        {formatCurrency(riskMetrics.valueAtRisk, hideBalances)}
                      </span>
                    </div>
                    <Progress value={riskMetrics.valueAtRisk / 2000 * 100} className="h-2" />
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">Expected Shortfall</span>
                      <span className="font-medium text-red-600">
                        {formatCurrency(riskMetrics.expectedShortfall, hideBalances)}
                      </span>
                    </div>
                    <Progress value={riskMetrics.expectedShortfall / 3000 * 100} className="h-2" />
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">Overall Risk Score</span>
                      <span className={`font-medium ${getRiskScoreColor(riskMetrics.overallRisk)}`}>
                        {riskMetrics.overallRisk}/10
                      </span>
                    </div>
                    <Progress value={riskMetrics.overallRisk * 10} className="h-2" />
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">Diversification</span>
                      <span className="font-medium text-green-600">
                        {summary.diversificationScore}/10
                      </span>
                    </div>
                    <Progress value={summary.diversificationScore * 10} className="h-2" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Content Tabs */}
      <Tabs value={selectedTab} onValueChange={setSelectedTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="positions">Positions</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Performance Chart */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <LineChart className="w-5 h-5" />
                  Portfolio Performance
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64 flex items-center justify-center text-gray-500">
                  <div className="text-center">
                    <BarChart3 className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                    <p>Performance chart will be displayed here</p>
                    <p className="text-sm">Real-time portfolio value tracking</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Asset Allocation */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <PieChart className="w-5 h-5" />
                  Asset Allocation
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm">Forex</span>
                      <span className="text-sm font-medium">65%</span>
                    </div>
                    <Progress value={65} className="h-2" />
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm">Cryptocurrency</span>
                      <span className="text-sm font-medium">25%</span>
                    </div>
                    <Progress value={25} className="h-2" />
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm">Commodities</span>
                      <span className="text-sm font-medium">10%</span>
                    </div>
                    <Progress value={10} className="h-2" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Recent Activity */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="w-5 h-5" />
                Recent Activity
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {positions.slice(0, 3).map((position) => (
                  <div key={position.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className={`w-2 h-2 rounded-full ${
                        position.type === "buy" ? "bg-green-500" : position.type === "sell" ? "bg-red-500" : "bg-gray-500"
                      }`} />
                      <div>
                        <p className="font-medium">{position.asset}</p>
                        <p className="text-sm text-gray-500">
                          {position.type?.toUpperCase() || 'POSITION'} • {position.platform || 'Unknown'}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className={`font-medium ${getPositionPnLColor(position.pnl)}`}>
                        {formatCurrency(position.pnl, hideBalances)}
                      </p>
                      <p className="text-sm text-gray-500">
                        {formatPercentage(position.pnlPercentage, hideBalances)}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="positions" className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-semibold">Active Positions</h3>
              <p className="text-sm text-gray-600">
                {positions.filter(p => p.status === "open").length} open positions
              </p>
            </div>
            <Button className="flex items-center gap-2">
              <Plus className="w-4 h-4" />
              New Position
            </Button>
          </div>

          <div className="grid gap-4">
            {positions.filter(p => p.status === "open").map((position) => (
              <Card key={position.id} className="hover:shadow-lg transition-shadow">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className={`w-3 h-3 rounded-full ${
                        position.type === "buy" ? "bg-green-500" : position.type === "sell" ? "bg-red-500" : "bg-gray-500"
                      }`} />
                      <div>
                        <h4 className="font-semibold text-lg">{position.asset}</h4>
                        <div className="flex items-center gap-2 text-sm text-gray-600">
                          <span className="uppercase font-medium">{position.type || 'POSITION'}</span>
                          <span>•</span>
                          <span>{position.platform || 'Unknown'}</span>
                          <span>•</span>
                          <Badge className={getRiskLevelColor(position.riskLevel)}>
                            {position.riskLevel}
                          </Badge>
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className={`text-xl font-bold ${getPositionPnLColor(position.pnl)}`}>
                        {formatCurrency(position.pnl, hideBalances)}
                      </p>
                      <p className={`text-sm ${getPositionPnLColor(position.pnl)}`}>
                        {formatPercentage(position.pnlPercentage, hideBalances)}
                      </p>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4 pt-4 border-t">
                    <div>
                      <p className="text-xs text-gray-500">Entry Price</p>
                      <p className="font-medium">{position.entryPrice}</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-500">Current Price</p>
                      <p className="font-medium">{position.currentPrice}</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-500">Stop Loss</p>
                      <p className="font-medium">{position.stopLoss || "—"}</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-500">Take Profit</p>
                      <p className="font-medium">{position.takeProfit || "—"}</p>
                    </div>
                  </div>
                  
                  {position.notes && (
                    <div className="mt-3 p-2 bg-blue-50 rounded text-sm text-blue-800">
                      {position.notes}
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Performance Metrics */}
            <Card>
              <CardHeader>
                <CardTitle>Performance Metrics</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-3 bg-gray-50 rounded">
                    <p className="text-sm text-gray-600">Average Win</p>
                    <p className="text-lg font-bold text-green-600">
                      {formatCurrency(summary.averageWin, hideBalances)}
                    </p>
                  </div>
                  <div className="text-center p-3 bg-gray-50 rounded">
                    <p className="text-sm text-gray-600">Average Loss</p>
                    <p className="text-lg font-bold text-red-600">
                      {formatCurrency(summary.averageLoss, hideBalances)}
                    </p>
                  </div>
                  <div className="text-center p-3 bg-gray-50 rounded">
                    <p className="text-sm text-gray-600">Sharpe Ratio</p>
                    <p className="text-lg font-bold">{summary.sharpeRatio}</p>
                  </div>
                  <div className="text-center p-3 bg-gray-50 rounded">
                    <p className="text-sm text-gray-600">Max Drawdown</p>
                    <p className="text-lg font-bold text-red-600">
                      {summary.maxDrawdown}%
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Risk Breakdown */}
            <Card>
              <CardHeader>
                <CardTitle>Risk Breakdown</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Volatility Risk</span>
                    <span className="font-medium">{riskMetrics.volatilityRisk}/10</span>
                  </div>
                  <Progress value={riskMetrics.volatilityRisk * 10} className="h-2" />
                  
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Correlation Risk</span>
                    <span className="font-medium">{riskMetrics.correlationRisk}/10</span>
                  </div>
                  <Progress value={riskMetrics.correlationRisk * 10} className="h-2" />
                  
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Concentration Risk</span>
                    <span className="font-medium">{riskMetrics.concentrationRisk}/10</span>
                  </div>
                  <Progress value={riskMetrics.concentrationRisk * 10} className="h-2" />
                  
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Liquidity Risk</span>
                    <span className="font-medium">{riskMetrics.liquidityRisk}/10</span>
                  </div>
                  <Progress value={riskMetrics.liquidityRisk * 10} className="h-2" />
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="settings" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="w-5 h-5" />
                Portfolio Settings
              </CardTitle>
              <CardDescription>
                Configure risk management and trading parameters
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="maxPositionSize">Max Position Size ($)</Label>
                    <Input
                      id="maxPositionSize"
                      type="number"
                      value={settings.maxPositionSize}
                      onChange={(e) => setSettings(prev => ({
                        ...prev,
                        maxPositionSize: parseFloat(e.target.value)
                      }))}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="maxRiskPerTrade">Max Risk per Trade (%)</Label>
                    <Input
                      id="maxRiskPerTrade"
                      type="number"
                      value={settings.maxRiskPerTrade}
                      onChange={(e) => setSettings(prev => ({
                        ...prev,
                        maxRiskPerTrade: parseFloat(e.target.value)
                      }))}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="maxDailyLoss">Max Daily Loss (%)</Label>
                    <Input
                      id="maxDailyLoss"
                      type="number"
                      value={settings.maxDailyLoss}
                      onChange={(e) => setSettings(prev => ({
                        ...prev,
                        maxDailyLoss: parseFloat(e.target.value)
                      }))}
                    />
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="riskMode">Risk Management Mode</Label>
                    <Select value={settings.riskManagementMode} onValueChange={(value: any) => 
                      setSettings(prev => ({ ...prev, riskManagementMode: value }))
                    }>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="conservative">Conservative</SelectItem>
                        <SelectItem value="moderate">Moderate</SelectItem>
                        <SelectItem value="aggressive">Aggressive</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="autoStopLoss">Auto Stop Loss</Label>
                      <input
                        id="autoStopLoss"
                        type="checkbox"
                        checked={settings.autoStopLoss}
                        onChange={(e) => setSettings(prev => ({
                          ...prev,
                          autoStopLoss: e.target.checked
                        }))}
                      />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <Label htmlFor="autoTakeProfit">Auto Take Profit</Label>
                      <input
                        id="autoTakeProfit"
                        type="checkbox"
                        checked={settings.autoTakeProfit}
                        onChange={(e) => setSettings(prev => ({
                          ...prev,
                          autoTakeProfit: e.target.checked
                        }))}
                      />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <Label htmlFor="notifications">Notifications</Label>
                      <input
                        id="notifications"
                        type="checkbox"
                        checked={settings.notifications}
                        onChange={(e) => setSettings(prev => ({
                          ...prev,
                          notifications: e.target.checked
                        }))}
                      />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <Label htmlFor="autoRebalance">Auto Rebalance</Label>
                      <input
                        id="autoRebalance"
                        type="checkbox"
                        checked={settings.autoRebalance}
                        onChange={(e) => setSettings(prev => ({
                          ...prev,
                          autoRebalance: e.target.checked
                        }))}
                      />
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="pt-4 border-t">
                <Button className="w-full">
                  Save Settings
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useLanguageContext } from '@/components/language-provider';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  PieChart, 
  Shield, 
  Target,
  AlertTriangle,
  BarChart3,
  Activity,
  Briefcase,
  Calculator,
  Settings,
  Plus,
  Minus,
  RefreshCw,
  Download,
  Eye,
  EyeOff,
  ArrowUpRight,
  ArrowDownLeft,
  Timer,
  Percent
} from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

interface PortfolioPosition {
  id: string;
  assetSymbol: string;
  direction: 'BUY' | 'SELL';
  entryPrice: number;
  currentPrice: number;
  amount: number;
  entryTime: string;
  status: 'active' | 'closed' | 'pending';
  pnl: number;
  pnlPercentage: number;
  stopLoss?: number;
  takeProfit?: number;
  confidence: number;
  source: 'ai' | 'manual' | 'copy';
}

interface PortfolioMetrics {
  totalValue: number;
  totalPnL: number;
  totalPnLPercentage: number;
  dayPnL: number;
  dayPnLPercentage: number;
  totalPositions: number;
  winningPositions: number;
  losingPositions: number;
  winRate: number;
  sharpeRatio: number;
  maxDrawdown: number;
  volatility: number;
  beta: number;
  alpha: number;
  diversificationScore: number;
}

interface RiskMetrics {
  portfolioVaR: number;
  expectedShortfall: number;
  concentrationRisk: number;
  correlationRisk: number;
  liquidityRisk: number;
  leverageRatio: number;
  marginUsed: number;
  marginAvailable: number;
  riskScore: number;
}

export default function ComprehensivePortfolio() {
  const { language } = useLanguageContext();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedTimeframe, setSelectedTimeframe] = useState('1M');
  const [showClosedPositions, setShowClosedPositions] = useState(false);
  const [autoRebalance, setAutoRebalance] = useState(false);

  // Portfolio data queries
  const { data: positions = [], isLoading: positionsLoading } = useQuery<PortfolioPosition[]>({
    queryKey: ['/api/portfolio/positions'],
    refetchInterval: 10000,
  });

  const { data: metrics, isLoading: metricsLoading } = useQuery<PortfolioMetrics>({
    queryKey: ['/api/portfolio/metrics', selectedTimeframe],
    refetchInterval: 30000,
  });

  const { data: riskMetrics, isLoading: riskLoading } = useQuery<RiskMetrics>({
    queryKey: ['/api/portfolio/risk-metrics'],
    refetchInterval: 60000,
  });



  // Use real data from server
  const activePositions = positions;
  const portfolioMetrics = metrics || {
    totalValue: 0,
    totalPnL: 0,
    totalPnLPercentage: 0,
    dayPnL: 0,
    dayPnLPercentage: 0,
    totalPositions: 0,
    winningPositions: 0,
    losingPositions: 0,
    winRate: 0,
    sharpeRatio: 0,
    maxDrawdown: 0,
    volatility: 0,
    beta: 0,
    alpha: 0,
    diversificationScore: 0
  };
  const portfolioRisk = riskMetrics || {
    portfolioVaR: 0,
    expectedShortfall: 0,
    concentrationRisk: 0,
    correlationRisk: 0,
    liquidityRisk: 0,
    leverageRatio: 0,
    marginUsed: 0,
    marginAvailable: 0,
    riskScore: 0
  };

  const timeframes = [
    { value: '1D', label: language === 'ar' ? '1 يوم' : '1 Day' },
    { value: '1W', label: language === 'ar' ? '1 أسبوع' : '1 Week' },
    { value: '1M', label: language === 'ar' ? '1 شهر' : '1 Month' },
    { value: '3M', label: language === 'ar' ? '3 أشهر' : '3 Months' },
    { value: '1Y', label: language === 'ar' ? '1 سنة' : '1 Year' }
  ];

  const getRiskColor = (level: string) => {
    switch (level) {
      case 'low': return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100';
      case 'medium': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-100';
      case 'high': return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-100';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-100';
    }
  };

  const getRiskScoreColor = (score: number) => {
    if (score <= 30) return 'text-green-600';
    if (score <= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  const formatCurrency = (amount: number | undefined | null) => {
    if (amount === undefined || amount === null || isNaN(amount)) {
      return '$0.00';
    }
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2
    }).format(amount);
  };

  const formatPercentage = (value: number | undefined | null, decimals: number = 2) => {
    if (value === undefined || value === null || isNaN(value)) {
      return '0.00%';
    }
    return `${value >= 0 ? '+' : ''}${value.toFixed(decimals)}%`;
  };

  return (
    <div className="container mx-auto p-6 space-y-6" dir={language === 'ar' ? 'rtl' : 'ltr'}>
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            {language === 'ar' ? 'إدارة المحفظة الشاملة' : 'Comprehensive Portfolio Management'}
          </h1>
          <p className="text-muted-foreground mt-2">
            {language === 'ar' 
              ? 'تتبع متقدم للمحفظة مع مقاييس المخاطر وتحليل الأرباح والخسائر وإعادة التوازن التلقائي'
              : 'Advanced portfolio tracking with risk metrics, P&L analysis, and automated rebalancing'
            }
          </p>
        </div>
        
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm">
            <Download className="h-4 w-4 mr-2" />
            {language === 'ar' ? 'تصدير' : 'Export'}
          </Button>
          <Button variant="outline" size="sm">
            <Settings className="h-4 w-4 mr-2" />
            {language === 'ar' ? 'إعدادات' : 'Settings'}
          </Button>
        </div>
      </div>

      {/* Portfolio Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">
                  {language === 'ar' ? 'إجمالي القيمة' : 'Total Value'}
                </p>
                <p className="text-2xl font-bold">{formatCurrency(portfolioMetrics.totalValue)}</p>
              </div>
              <Briefcase className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">
                  {language === 'ar' ? 'إجمالي الربح/الخسارة' : 'Total P&L'}
                </p>
                <p className={`text-2xl font-bold ${portfolioMetrics.totalPnL >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                  {formatCurrency(portfolioMetrics.totalPnL)}
                </p>
                <p className={`text-sm ${portfolioMetrics.totalPnLPercentage >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                  {formatPercentage(portfolioMetrics.totalPnLPercentage)}
                </p>
              </div>
              {portfolioMetrics.totalPnL >= 0 ? (
                <TrendingUp className="h-8 w-8 text-green-600" />
              ) : (
                <TrendingDown className="h-8 w-8 text-red-600" />
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">
                  {language === 'ar' ? 'اليوم' : 'Today'}
                </p>
                <p className={`text-2xl font-bold ${portfolioMetrics.dayPnL >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                  {formatCurrency(portfolioMetrics.dayPnL)}
                </p>
                <p className={`text-sm ${portfolioMetrics.dayPnLPercentage >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                  {formatPercentage(portfolioMetrics.dayPnLPercentage)}
                </p>
              </div>
              <Activity className="h-8 w-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">
                  {language === 'ar' ? 'نسبة النجاح' : 'Win Rate'}
                </p>
                <p className="text-2xl font-bold">{formatPercentage(portfolioMetrics.winRate)}</p>
                <p className="text-sm text-muted-foreground">
                  {portfolioMetrics.winningPositions}/{portfolioMetrics.totalPositions} {language === 'ar' ? 'صفقات' : 'trades'}
                </p>
              </div>
              <Target className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="positions" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="positions">
            {language === 'ar' ? 'المراكز' : 'Positions'}
          </TabsTrigger>
          <TabsTrigger value="analytics">
            {language === 'ar' ? 'التحليلات' : 'Analytics'}
          </TabsTrigger>
          <TabsTrigger value="risk">
            {language === 'ar' ? 'إدارة المخاطر' : 'Risk Management'}
          </TabsTrigger>
          <TabsTrigger value="rebalancing">
            {language === 'ar' ? 'إعادة التوازن' : 'Rebalancing'}
          </TabsTrigger>
        </TabsList>

        {/* Positions Tab */}
        <TabsContent value="positions" className="space-y-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <h3 className="text-lg font-semibold">
                {language === 'ar' ? 'المراكز النشطة' : 'Active Positions'}
              </h3>
              <Badge variant="outline">{activePositions.length} {language === 'ar' ? 'مراكز' : 'positions'}</Badge>
            </div>
            
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowClosedPositions(!showClosedPositions)}
              >
                {showClosedPositions ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                {language === 'ar' ? (showClosedPositions ? 'إخفاء المغلقة' : 'عرض المغلقة') : (showClosedPositions ? 'Hide Closed' : 'Show Closed')}
              </Button>
              <Button size="sm">
                <Plus className="h-4 w-4 mr-2" />
                {language === 'ar' ? 'مركز جديد' : 'New Position'}
              </Button>
            </div>
          </div>

          <Card>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="border-b">
                    <tr className="text-left">
                      <th className="p-4 font-medium">{language === 'ar' ? 'الأصل' : 'Asset'}</th>
                      <th className="p-4 font-medium">{language === 'ar' ? 'الكمية' : 'Quantity'}</th>
                      <th className="p-4 font-medium">{language === 'ar' ? 'سعر الدخول' : 'Entry Price'}</th>
                      <th className="p-4 font-medium">{language === 'ar' ? 'السعر الحالي' : 'Current Price'}</th>
                      <th className="p-4 font-medium">{language === 'ar' ? 'الربح/الخسارة' : 'P&L'}</th>
                      <th className="p-4 font-medium">{language === 'ar' ? 'المخاطر' : 'Risk'}</th>
                      <th className="p-4 font-medium">{language === 'ar' ? 'الاستراتيجية' : 'Strategy'}</th>
                      <th className="p-4 font-medium">{language === 'ar' ? 'الإجراءات' : 'Actions'}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {activePositions.map((position) => (
                      <tr key={position.id} className="border-b hover:bg-muted/50">
                        <td className="p-4">
                          <div>
                            <div className="font-medium">{position.assetSymbol}</div>
                            <div className="text-sm text-muted-foreground">
                              {position.direction}
                            </div>
                          </div>
                        </td>
                        <td className="p-4 font-mono">{(position.amount || 0).toLocaleString()}</td>
                        <td className="p-4 font-mono">{(position.entryPrice || 0).toFixed(position.assetSymbol?.includes('USD') ? 5 : 2)}</td>
                        <td className="p-4 font-mono">{(position.currentPrice || 0).toFixed(position.assetSymbol?.includes('USD') ? 5 : 2)}</td>
                        <td className="p-4">
                          <div className={`font-medium ${(position.pnl || 0) >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                            {formatCurrency(position.pnl)}
                          </div>
                          <div className={`text-sm ${(position.pnl || 0) >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                            {formatPercentage(position.pnlPercentage)}
                          </div>
                        </td>
                        <td className="p-4">
                          <Badge className={getRiskColor((position.confidence || 0) > 80 ? 'low' : (position.confidence || 0) > 60 ? 'medium' : 'high')}>
                            {language === 'ar' ? 
                              ((position.confidence || 0) > 80 ? 'منخفض' : (position.confidence || 0) > 60 ? 'متوسط' : 'عالي') :
                              ((position.confidence || 0) > 80 ? 'low' : (position.confidence || 0) > 60 ? 'medium' : 'high')
                            }
                          </Badge>
                        </td>
                        <td className="p-4 text-sm">
                          {position.source || 'manual'}
                        </td>
                        <td className="p-4">
                          <div className="flex items-center gap-1">
                            <Button variant="outline" size="sm">
                              <Settings className="h-3 w-3" />
                            </Button>
                            <Button variant="outline" size="sm">
                              <Minus className="h-3 w-3" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Analytics Tab */}
        <TabsContent value="analytics" className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold">
              {language === 'ar' ? 'تحليلات الأداء' : 'Performance Analytics'}
            </h3>
            <div className="flex gap-2">
              {timeframes.map(tf => (
                <Button
                  key={tf.value}
                  variant={selectedTimeframe === tf.value ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setSelectedTimeframe(tf.value)}
                >
                  {tf.label}
                </Button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="h-5 w-5" />
                  {language === 'ar' ? 'نسبة شارب' : 'Sharpe Ratio'}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-blue-600">{portfolioMetrics.sharpeRatio}</div>
                <p className="text-sm text-muted-foreground mt-2">
                  {language === 'ar' ? 'العائد المعدل للمخاطر' : 'Risk-adjusted return'}
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingDown className="h-5 w-5" />
                  {language === 'ar' ? 'أقصى انخفاض' : 'Max Drawdown'}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-red-600">{formatPercentage(portfolioMetrics.maxDrawdown)}</div>
                <p className="text-sm text-muted-foreground mt-2">
                  {language === 'ar' ? 'أكبر انخفاض من القمة' : 'Largest peak-to-trough decline'}
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="h-5 w-5" />
                  {language === 'ar' ? 'التقلب' : 'Volatility'}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-purple-600">{formatPercentage(portfolioMetrics.volatility)}</div>
                <p className="text-sm text-muted-foreground mt-2">
                  {language === 'ar' ? 'الانحراف المعياري للعوائد' : 'Standard deviation of returns'}
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="h-5 w-5" />
                  {language === 'ar' ? 'معامل بيتا' : 'Beta'}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-green-600">{portfolioMetrics.beta}</div>
                <p className="text-sm text-muted-foreground mt-2">
                  {language === 'ar' ? 'الحساسية للسوق' : 'Market sensitivity'}
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  {language === 'ar' ? 'معامل ألفا' : 'Alpha'}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-blue-600">{formatPercentage(portfolioMetrics.alpha)}</div>
                <p className="text-sm text-muted-foreground mt-2">
                  {language === 'ar' ? 'العائد الإضافي' : 'Excess return'}
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <PieChart className="h-5 w-5" />
                  {language === 'ar' ? 'نقاط التنويع' : 'Diversification Score'}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-purple-600">{portfolioMetrics.diversificationScore}</div>
                <Progress value={portfolioMetrics.diversificationScore} className="mt-2" />
                <p className="text-sm text-muted-foreground mt-2">
                  {language === 'ar' ? 'مستوى التنويع' : 'Portfolio diversification level'}
                </p>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Risk Management Tab */}
        <TabsContent value="risk" className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold">
              {language === 'ar' ? 'مقاييس المخاطر' : 'Risk Metrics'}
            </h3>
            <div className="flex items-center gap-2">
              <span className="text-sm">{language === 'ar' ? 'نقاط المخاطر:' : 'Risk Score:'}</span>
              <span className={`text-lg font-bold ${getRiskScoreColor(portfolioRisk.riskScore)}`}>
                {portfolioRisk.riskScore}/100
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5" />
                  {language === 'ar' ? 'القيمة المعرضة للخطر (VaR)' : 'Value at Risk (VaR)'}
                </CardTitle>
                <CardDescription>
                  {language === 'ar' ? 'أقصى خسارة محتملة خلال يوم واحد (95% ثقة)' : 'Maximum potential loss over 1 day (95% confidence)'}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-red-600">{formatCurrency(portfolioRisk.portfolioVaR)}</div>
                <div className="text-sm text-muted-foreground mt-1">
                  {formatPercentage(portfolioMetrics.totalValue ? (portfolioRisk.portfolioVaR / portfolioMetrics.totalValue) * 100 : 0)} {language === 'ar' ? 'من المحفظة' : 'of portfolio'}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingDown className="h-5 w-5" />
                  {language === 'ar' ? 'النقص المتوقع' : 'Expected Shortfall'}
                </CardTitle>
                <CardDescription>
                  {language === 'ar' ? 'متوسط الخسارة المتوقعة في حالة تجاوز VaR' : 'Average loss expected when VaR is exceeded'}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-red-600">{formatCurrency(portfolioRisk.expectedShortfall)}</div>
                <div className="text-sm text-muted-foreground mt-1">
                  {formatPercentage(portfolioMetrics.totalValue ? (portfolioRisk.expectedShortfall / portfolioMetrics.totalValue) * 100 : 0)} {language === 'ar' ? 'من المحفظة' : 'of portfolio'}
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">{language === 'ar' ? 'مخاطر التركز' : 'Concentration Risk'}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-xl font-bold">{formatPercentage(portfolioRisk.concentrationRisk)}</div>
                <Progress value={portfolioRisk.concentrationRisk} className="mt-2" />
                <p className="text-xs text-muted-foreground mt-1">
                  {language === 'ar' ? 'تركز في أصول قليلة' : 'Concentration in few assets'}
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">{language === 'ar' ? 'مخاطر الارتباط' : 'Correlation Risk'}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-xl font-bold">{formatPercentage(portfolioRisk.correlationRisk)}</div>
                <Progress value={portfolioRisk.correlationRisk} className="mt-2" />
                <p className="text-xs text-muted-foreground mt-1">
                  {language === 'ar' ? 'ارتباط عالي بين الأصول' : 'High correlation between assets'}
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">{language === 'ar' ? 'مخاطر السيولة' : 'Liquidity Risk'}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-xl font-bold">{formatPercentage(portfolioRisk.liquidityRisk)}</div>
                <Progress value={portfolioRisk.liquidityRisk} className="mt-2" />
                <p className="text-xs text-muted-foreground mt-1">
                  {language === 'ar' ? 'صعوبة في البيع السريع' : 'Difficulty in quick liquidation'}
                </p>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>{language === 'ar' ? 'إدارة الهامش' : 'Margin Management'}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                  <p className="text-sm text-muted-foreground">{language === 'ar' ? 'نسبة الرافعة المالية' : 'Leverage Ratio'}</p>
                  <p className="text-2xl font-bold">{portfolioRisk.leverageRatio}:1</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">{language === 'ar' ? 'الهامش المستخدم' : 'Margin Used'}</p>
                  <p className="text-2xl font-bold">{formatCurrency(portfolioRisk.marginUsed)}</p>
                  <Progress value={(portfolioRisk.marginUsed / (portfolioRisk.marginUsed + portfolioRisk.marginAvailable)) * 100} className="mt-2" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">{language === 'ar' ? 'الهامش المتاح' : 'Margin Available'}</p>
                  <p className="text-2xl font-bold text-green-600">{formatCurrency(portfolioRisk.marginAvailable)}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Rebalancing Tab */}
        <TabsContent value="rebalancing" className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold">
              {language === 'ar' ? 'إعادة توازن المحفظة' : 'Portfolio Rebalancing'}
            </h3>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <span className="text-sm">{language === 'ar' ? 'إعادة توازن تلقائية:' : 'Auto Rebalance:'}</span>
                <Button
                  variant={autoRebalance ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setAutoRebalance(!autoRebalance)}
                >
                  {autoRebalance ? (language === 'ar' ? 'مفعل' : 'Enabled') : (language === 'ar' ? 'معطل' : 'Disabled')}
                </Button>
              </div>
              <Button>
                <RefreshCw className="h-4 w-4 mr-2" />
                {language === 'ar' ? 'إعادة توازن الآن' : 'Rebalance Now'}
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>{language === 'ar' ? 'التوزيع الحالي' : 'Current Allocation'}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {activePositions.map((position) => {
                    const positionValue = (position.amount || 0) * (position.currentPrice || 0);
                    const percentage = portfolioMetrics.totalValue > 0 ? (positionValue / portfolioMetrics.totalValue) * 100 : 0;
                    return (
                      <div key={position.id} className="flex items-center justify-between">
                        <span className="text-sm font-medium">{position.assetSymbol || 'Unknown'}</span>
                        <div className="flex items-center gap-2">
                          <Progress value={percentage} className="w-20 h-2" />
                          <span className="text-sm text-muted-foreground w-12">
                            {formatPercentage(percentage, 1)}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>{language === 'ar' ? 'التوزيع المستهدف' : 'Target Allocation'}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">{language === 'ar' ? 'العملات الأجنبية' : 'Forex'}</span>
                    <div className="flex items-center gap-2">
                      <Progress value={60} className="w-20 h-2" />
                      <span className="text-sm text-muted-foreground w-12">60%</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">{language === 'ar' ? 'العملات المشفرة' : 'Crypto'}</span>
                    <div className="flex items-center gap-2">
                      <Progress value={25} className="w-20 h-2" />
                      <span className="text-sm text-muted-foreground w-12">25%</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">{language === 'ar' ? 'السلع' : 'Commodities'}</span>
                    <div className="flex items-center gap-2">
                      <Progress value={15} className="w-20 h-2" />
                      <span className="text-sm text-muted-foreground w-12">15%</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>{language === 'ar' ? 'توصيات إعادة التوازن' : 'Rebalancing Recommendations'}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center gap-3">
                    <ArrowDownLeft className="h-5 w-5 text-red-500" />
                    <div>
                      <p className="font-medium">{language === 'ar' ? 'تقليل BTC/USD' : 'Reduce BTC/USD'}</p>
                      <p className="text-sm text-muted-foreground">
                        {language === 'ar' ? 'تقليل بـ 0.1 وحدة للوصول للتوزيع المستهدف' : 'Reduce by 0.1 units to reach target allocation'}
                      </p>
                    </div>
                  </div>
                  <Button variant="outline" size="sm">
                    {language === 'ar' ? 'تطبيق' : 'Execute'}
                  </Button>
                </div>

                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center gap-3">
                    <ArrowUpRight className="h-5 w-5 text-green-500" />
                    <div>
                      <p className="font-medium">{language === 'ar' ? 'زيادة EUR/USD' : 'Increase EUR/USD'}</p>
                      <p className="text-sm text-muted-foreground">
                        {language === 'ar' ? 'زيادة بـ 25,000 وحدة لتحسين التنويع' : 'Increase by 25,000 units to improve diversification'}
                      </p>
                    </div>
                  </div>
                  <Button variant="outline" size="sm">
                    {language === 'ar' ? 'تطبيق' : 'Execute'}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { useLanguageContext } from '@/components/language-provider';
import { FloatingRefreshButton } from '@/components/floating-refresh-button';
import { 
  Newspaper,
  Calendar,
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  Clock,
  Globe,
  DollarSign,
  BarChart3,
  Activity,
  Eye,
  ExternalLink
} from 'lucide-react';

interface EconomicEvent {
  id: string;
  title: string;
  date: string;
  time: string;
  country: string;
  currency: string;
  impact: 'low' | 'medium' | 'high';
  actual?: string;
  forecast?: string;
  previous?: string;
  category: string;
}

interface NewsArticle {
  id: string;
  title: string;
  content: string;
  source: string;
  publishedAt: string;
  url: string;
  sentiment: 'positive' | 'negative' | 'neutral';
  impact: 'low' | 'medium' | 'high';
  currencies: string[];
  keywords: string[];
}

interface MarketSentiment {
  overall: 'bullish' | 'bearish' | 'neutral';
  confidence: number;
  keyFactors: string[];
  riskFactors: string[];
  opportunities: string[];
}

export default function EconomicNews() {
  const { language } = useLanguageContext();
  const [selectedAsset, setSelectedAsset] = useState('EUR/USD');

  // Fetch economic events
  const { data: events, isLoading: eventsLoading, refetch: refetchEvents } = useQuery({
    queryKey: ['/api/economic-news/events'],
    refetchInterval: 300000, // 5 minutes
    refetchOnWindowFocus: true,
  });

  // Fetch market news
  const { data: news, isLoading: newsLoading, refetch: refetchNews } = useQuery({
    queryKey: ['/api/economic-news/news'],
    refetchInterval: 300000, // 5 minutes
    refetchOnWindowFocus: true,
  });

  // Fetch market sentiment
  const { data: sentiment, isLoading: sentimentLoading, refetch: refetchSentiment } = useQuery({
    queryKey: ['/api/economic-news/sentiment'],
    refetchInterval: 300000, // 5 minutes
    refetchOnWindowFocus: true,
  });

  // Fetch news summary
  const { data: summary, isLoading: summaryLoading, refetch: refetchSummary } = useQuery({
    queryKey: ['/api/economic-news/summary'],
    refetchInterval: 300000, // 5 minutes
    refetchOnWindowFocus: true,
  });

  // Fetch asset-specific news impact
  const { data: assetImpact, isLoading: assetImpactLoading, refetch: refetchAssetImpact } = useQuery({
    queryKey: ['/api/economic-news/impact', selectedAsset],
    refetchInterval: 300000, // 5 minutes
    refetchOnWindowFocus: true,
  });

  const refreshAllData = () => {
    refetchEvents();
    refetchNews();
    refetchSentiment();
    refetchSummary();
    refetchAssetImpact();
  };

  const isLoading = eventsLoading || newsLoading || sentimentLoading || summaryLoading;

  const getImpactColor = (impact: string) => {
    switch (impact) {
      case 'high': return 'text-red-600 bg-red-50 dark:bg-red-950';
      case 'medium': return 'text-yellow-600 bg-yellow-50 dark:bg-yellow-950';
      case 'low': return 'text-green-600 bg-green-50 dark:bg-green-950';
      default: return 'text-gray-600 bg-gray-50 dark:bg-gray-950';
    }
  };

  const getSentimentColor = (sentiment: string) => {
    switch (sentiment) {
      case 'positive': case 'bullish': return 'text-green-600 bg-green-50 dark:bg-green-950';
      case 'negative': case 'bearish': return 'text-red-600 bg-red-50 dark:bg-red-950';
      default: return 'text-gray-600 bg-gray-50 dark:bg-gray-950';
    }
  };

  const formatTime = (dateString: string) => {
    return new Date(dateString).toLocaleTimeString(language === 'ar' ? 'ar-SA' : 'en-US', {
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString(language === 'ar' ? 'ar-SA' : 'en-US', {
      month: 'short',
      day: 'numeric'
    });
  };

  if (isLoading) {
    return (
      <div className="container mx-auto p-6 space-y-6">
        <div className="flex items-center justify-center h-96">
          <div className="text-center space-y-4">
            <div className="animate-spin rounded-full h-12 w-12 border-4 border-blue-500 border-t-transparent mx-auto"></div>
            <p className="text-muted-foreground">
              {language === 'ar' ? 'جاري تحميل الأخبار الاقتصادية...' : 'Loading Economic News...'}
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="space-y-1">
          <h1 className="text-3xl font-bold tracking-tight bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            {language === 'ar' ? 'تحليل الأخبار الاقتصادية' : 'Economic News Analysis'}
          </h1>
          <p className="text-muted-foreground">
            {language === 'ar' 
              ? 'تحليل شامل للأخبار الاقتصادية والأحداث المؤثرة على الأسواق'
              : 'Comprehensive analysis of economic news and market-moving events'
            }
          </p>
        </div>
        
        <div className="flex items-center gap-3">
          <Badge variant={sentiment?.overall === 'bullish' ? 'success' : sentiment?.overall === 'bearish' ? 'destructive' : 'secondary'}>
            {sentiment?.overall === 'bullish' 
              ? (language === 'ar' ? 'صاعد' : 'Bullish')
              : sentiment?.overall === 'bearish'
              ? (language === 'ar' ? 'هابط' : 'Bearish')
              : (language === 'ar' ? 'محايد' : 'Neutral')
            }
          </Badge>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="border-l-4 border-l-blue-500">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">
                  {language === 'ar' ? 'إجمالي الأخبار' : 'Total News'}
                </p>
                <p className="text-2xl font-bold text-blue-600">
                  {summary?.totalNews || 0}
                </p>
              </div>
              <Newspaper className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-green-500">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">
                  {language === 'ar' ? 'الأحداث الاقتصادية' : 'Economic Events'}
                </p>
                <p className="text-2xl font-bold text-green-600">
                  {summary?.totalEvents || 0}
                </p>
              </div>
              <Calendar className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-orange-500">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">
                  {language === 'ar' ? 'أحداث عالية التأثير' : 'High Impact Events'}
                </p>
                <p className="text-2xl font-bold text-orange-600">
                  {summary?.highImpactEvents || 0}
                </p>
              </div>
              <AlertTriangle className="h-8 w-8 text-orange-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-purple-500">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">
                  {language === 'ar' ? 'مؤشر الثقة' : 'Confidence Index'}
                </p>
                <p className="text-2xl font-bold text-purple-600">
                  {sentiment?.confidence || 0}%
                </p>
              </div>
              <BarChart3 className="h-8 w-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs defaultValue="sentiment" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="sentiment" className="flex items-center gap-2">
            <Activity className="h-4 w-4" />
            {language === 'ar' ? 'معنويات السوق' : 'Market Sentiment'}
          </TabsTrigger>
          <TabsTrigger value="news" className="flex items-center gap-2">
            <Newspaper className="h-4 w-4" />
            {language === 'ar' ? 'الأخبار' : 'News'}
          </TabsTrigger>
          <TabsTrigger value="events" className="flex items-center gap-2">
            <Calendar className="h-4 w-4" />
            {language === 'ar' ? 'الأحداث' : 'Events'}
          </TabsTrigger>
          <TabsTrigger value="impact" className="flex items-center gap-2">
            <Eye className="h-4 w-4" />
            {language === 'ar' ? 'تأثير الأصول' : 'Asset Impact'}
          </TabsTrigger>
        </TabsList>

        {/* Market Sentiment Tab */}
        <TabsContent value="sentiment" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Overall Sentiment */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-blue-500" />
                  {language === 'ar' ? 'معنويات السوق العامة' : 'Overall Market Sentiment'}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-center p-6 border rounded-lg">
                  <div className="flex items-center justify-center mb-4">
                    {sentiment?.overall === 'bullish' ? (
                      <TrendingUp className="h-12 w-12 text-green-500" />
                    ) : sentiment?.overall === 'bearish' ? (
                      <TrendingDown className="h-12 w-12 text-red-500" />
                    ) : (
                      <Activity className="h-12 w-12 text-gray-500" />
                    )}
                  </div>
                  <h3 className="text-2xl font-bold mb-2">
                    {sentiment?.overall === 'bullish' 
                      ? (language === 'ar' ? 'صاعد' : 'Bullish')
                      : sentiment?.overall === 'bearish'
                      ? (language === 'ar' ? 'هابط' : 'Bearish')
                      : (language === 'ar' ? 'محايد' : 'Neutral')
                    }
                  </h3>
                  <p className="text-muted-foreground">
                    {language === 'ar' ? 'مستوى الثقة:' : 'Confidence Level:'} {sentiment?.confidence}%
                  </p>
                </div>

                {/* Sentiment Distribution */}
                <div className="space-y-3">
                  <h4 className="font-semibold">
                    {language === 'ar' ? 'توزيع المعنويات' : 'Sentiment Distribution'}
                  </h4>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-green-600">
                        {language === 'ar' ? 'إيجابي' : 'Positive'}
                      </span>
                      <span className="text-sm font-medium">
                        {summary?.sentimentDistribution?.positive || 0}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-red-600">
                        {language === 'ar' ? 'سلبي' : 'Negative'}
                      </span>
                      <span className="text-sm font-medium">
                        {summary?.sentimentDistribution?.negative || 0}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">
                        {language === 'ar' ? 'محايد' : 'Neutral'}
                      </span>
                      <span className="text-sm font-medium">
                        {summary?.sentimentDistribution?.neutral || 0}
                      </span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Key Factors */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-500" />
                  {language === 'ar' ? 'العوامل المؤثرة' : 'Key Market Factors'}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Key Factors */}
                <div className="space-y-2">
                  <h4 className="font-semibold text-green-600">
                    {language === 'ar' ? 'العوامل الرئيسية' : 'Key Factors'}
                  </h4>
                  {sentiment?.keyFactors?.length > 0 ? (
                    <ul className="space-y-1">
                      {sentiment.keyFactors.map((factor, index) => (
                        <li key={index} className="text-sm flex items-start gap-2">
                          <span className="text-green-500">•</span>
                          {factor}
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <p className="text-sm text-muted-foreground">
                      {language === 'ar' ? 'لا توجد عوامل رئيسية' : 'No key factors available'}
                    </p>
                  )}
                </div>

                {/* Risk Factors */}
                <div className="space-y-2">
                  <h4 className="font-semibold text-red-600">
                    {language === 'ar' ? 'عوامل المخاطر' : 'Risk Factors'}
                  </h4>
                  {sentiment?.riskFactors?.length > 0 ? (
                    <ul className="space-y-1">
                      {sentiment.riskFactors.map((factor, index) => (
                        <li key={index} className="text-sm flex items-start gap-2">
                          <span className="text-red-500">•</span>
                          {factor}
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <p className="text-sm text-muted-foreground">
                      {language === 'ar' ? 'لا توجد عوامل مخاطر' : 'No risk factors identified'}
                    </p>
                  )}
                </div>

                {/* Opportunities */}
                <div className="space-y-2">
                  <h4 className="font-semibold text-blue-600">
                    {language === 'ar' ? 'الفرص' : 'Opportunities'}
                  </h4>
                  {sentiment?.opportunities?.length > 0 ? (
                    <ul className="space-y-1">
                      {sentiment.opportunities.map((opportunity, index) => (
                        <li key={index} className="text-sm flex items-start gap-2">
                          <span className="text-blue-500">•</span>
                          {opportunity}
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <p className="text-sm text-muted-foreground">
                      {language === 'ar' ? 'لا توجد فرص محددة' : 'No specific opportunities identified'}
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* News Tab */}
        <TabsContent value="news" className="space-y-6">
          <div className="grid grid-cols-1 gap-4">
            {news && news.length > 0 ? (
              news.map((article: NewsArticle) => (
                <Card key={article.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="space-y-3">
                      <div className="flex items-start justify-between gap-4">
                        <h3 className="font-semibold text-lg leading-tight">
                          {article.title}
                        </h3>
                        <div className="flex gap-2">
                          <Badge className={getImpactColor(article.impact)}>
                            {article.impact.toUpperCase()}
                          </Badge>
                          <Badge className={getSentimentColor(article.sentiment)}>
                            {article.sentiment.toUpperCase()}
                          </Badge>
                        </div>
                      </div>
                      
                      <p className="text-sm text-muted-foreground line-clamp-2">
                        {article.content}
                      </p>
                      
                      <div className="flex items-center justify-between text-sm text-muted-foreground">
                        <div className="flex items-center gap-4">
                          <span className="flex items-center gap-1">
                            <Globe className="h-4 w-4" />
                            {article.source}
                          </span>
                          <span className="flex items-center gap-1">
                            <Clock className="h-4 w-4" />
                            {formatTime(article.publishedAt)}
                          </span>
                        </div>
                        
                        <div className="flex items-center gap-2">
                          {article.currencies.map((currency) => (
                            <Badge key={currency} variant="outline" className="text-xs">
                              {currency}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              <Card>
                <CardContent className="p-12 text-center">
                  <Newspaper className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">
                    {language === 'ar' ? 'لا توجد أخبار متاحة' : 'No news available'}
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>

        {/* Events Tab */}
        <TabsContent value="events" className="space-y-6">
          <div className="grid grid-cols-1 gap-4">
            {events && events.length > 0 ? (
              events.map((event: EconomicEvent) => (
                <Card key={event.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="space-y-3">
                      <div className="flex items-start justify-between gap-4">
                        <h3 className="font-semibold text-lg leading-tight">
                          {event.title}
                        </h3>
                        <div className="flex gap-2">
                          <Badge className={getImpactColor(event.impact)}>
                            {event.impact.toUpperCase()}
                          </Badge>
                          <Badge variant="outline">
                            {event.currency}
                          </Badge>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                        <div>
                          <span className="text-muted-foreground">
                            {language === 'ar' ? 'الوقت:' : 'Time:'}
                          </span>
                          <div className="font-medium">{event.time}</div>
                        </div>
                        <div>
                          <span className="text-muted-foreground">
                            {language === 'ar' ? 'البلد:' : 'Country:'}
                          </span>
                          <div className="font-medium">{event.country}</div>
                        </div>
                        {event.forecast && (
                          <div>
                            <span className="text-muted-foreground">
                              {language === 'ar' ? 'المتوقع:' : 'Forecast:'}
                            </span>
                            <div className="font-medium">{event.forecast}</div>
                          </div>
                        )}
                        {event.previous && (
                          <div>
                            <span className="text-muted-foreground">
                              {language === 'ar' ? 'السابق:' : 'Previous:'}
                            </span>
                            <div className="font-medium">{event.previous}</div>
                          </div>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              <Card>
                <CardContent className="p-12 text-center">
                  <Calendar className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">
                    {language === 'ar' ? 'لا توجد أحداث متاحة' : 'No events available'}
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>

        {/* Asset Impact Tab */}
        <TabsContent value="impact" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <DollarSign className="h-5 w-5 text-green-500" />
                {language === 'ar' ? 'تأثير الأخبار على الأصول' : 'News Impact on Assets'}
              </CardTitle>
              <div className="flex gap-2">
                <select 
                  value={selectedAsset} 
                  onChange={(e) => setSelectedAsset(e.target.value)}
                  className="px-3 py-2 border rounded-md bg-background"
                >
                  <option value="EUR/USD">EUR/USD</option>
                  <option value="GBP/USD">GBP/USD</option>
                  <option value="USD/JPY">USD/JPY</option>
                  <option value="BTC/USD">BTC/USD</option>
                  <option value="XAU/USD">XAU/USD</option>
                </select>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              {assetImpact ? (
                <>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="text-center p-4 border rounded-lg">
                      <h4 className="font-semibold mb-2">
                        {language === 'ar' ? 'مستوى التأثير' : 'Impact Level'}
                      </h4>
                      <Badge className={getImpactColor(assetImpact.impact)} size="lg">
                        {assetImpact.impact.toUpperCase()}
                      </Badge>
                    </div>
                    <div className="text-center p-4 border rounded-lg">
                      <h4 className="font-semibold mb-2">
                        {language === 'ar' ? 'المعنويات' : 'Sentiment'}
                      </h4>
                      <Badge className={getSentimentColor(assetImpact.sentiment)} size="lg">
                        {assetImpact.sentiment.toUpperCase()}
                      </Badge>
                    </div>
                    <div className="text-center p-4 border rounded-lg">
                      <h4 className="font-semibold mb-2">
                        {language === 'ar' ? 'الأخبار ذات الصلة' : 'Relevant News'}
                      </h4>
                      <span className="text-2xl font-bold">
                        {assetImpact.relevantNews?.length || 0}
                      </span>
                    </div>
                  </div>

                  {assetImpact.relevantNews && assetImpact.relevantNews.length > 0 && (
                    <div className="space-y-4">
                      <h4 className="font-semibold">
                        {language === 'ar' ? 'الأخبار المؤثرة' : 'Relevant News'}
                      </h4>
                      {assetImpact.relevantNews.map((article: NewsArticle) => (
                        <div key={article.id} className="p-4 border rounded-lg">
                          <div className="flex justify-between items-start gap-4">
                            <h5 className="font-medium">{article.title}</h5>
                            <Badge className={getSentimentColor(article.sentiment)}>
                              {article.sentiment}
                            </Badge>
                          </div>
                          <p className="text-sm text-muted-foreground mt-2">
                            {article.source} • {formatTime(article.publishedAt)}
                          </p>
                        </div>
                      ))}
                    </div>
                  )}

                  {assetImpact.relevantEvents && assetImpact.relevantEvents.length > 0 && (
                    <div className="space-y-4">
                      <h4 className="font-semibold">
                        {language === 'ar' ? 'الأحداث المؤثرة' : 'Relevant Events'}
                      </h4>
                      {assetImpact.relevantEvents.map((event: EconomicEvent) => (
                        <div key={event.id} className="p-4 border rounded-lg">
                          <div className="flex justify-between items-start gap-4">
                            <h5 className="font-medium">{event.title}</h5>
                            <Badge className={getImpactColor(event.impact)}>
                              {event.impact}
                            </Badge>
                          </div>
                          <p className="text-sm text-muted-foreground mt-2">
                            {event.country} • {event.time}
                          </p>
                        </div>
                      ))}
                    </div>
                  )}
                </>
              ) : (
                <div className="text-center p-12">
                  <Eye className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">
                    {language === 'ar' ? 'لا توجد بيانات تأثير متاحة' : 'No impact data available'}
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <FloatingRefreshButton onRefresh={refreshAllData} />
    </div>
  );
}
import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Progress } from '@/components/ui/progress';
import { RefreshCw, TrendingUp, TrendingDown, AlertTriangle, CheckCircle, XCircle } from 'lucide-react';

interface ExternalDataHealth {
  alphaVantage: { status: string; lastChecked: string };
  newsAPI: { status: string; lastChecked: string };
  fredAPI: { status: string; lastChecked: string };
}

interface EnhancedMarketData {
  symbol: string;
  realTimePrice: number;
  priceChange: number;
  priceChangePercent: number;
  technicalIndicators: {
    rsi?: number;
    macd?: number;
    signal?: 'BUY' | 'SELL' | 'HOLD';
  };
  fundamentalData: {
    sentiment: number;
    newsCount: number;
    economicImpact: 'HIGH' | 'MEDIUM' | 'LOW';
  };
  externalSources: {
    alphaVantage: boolean;
    newsAPI: boolean;
    fredAPI: boolean;
  };
  confidence: number;
  lastUpdated: string;
}

interface ComprehensiveAnalysis {
  symbol: string;
  recommendation: 'BUY' | 'SELL' | 'HOLD';
  confidence: number;
  reasoning: string[];
  dataQuality: number;
  sources: string[];
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH';
  timeframe: string;
  expectedReturn: number;
  stopLoss: number;
  takeProfit: number;
  marketContext: {
    economicSentiment: number;
    newsSentiment: number;
    technicalStrength: number;
  };
}

const ExternalDataDemo: React.FC = () => {
  const [selectedSymbol, setSelectedSymbol] = useState('EUR/USD');
  const [isRefreshing, setIsRefreshing] = useState(false);

  const symbols = ['EUR/USD', 'GBP/USD', 'USD/JPY', 'XAUUSD', 'BTCUSD'];

  // Health check query
  const { data: healthData, refetch: refetchHealth } = useQuery<ExternalDataHealth>({
    queryKey: ['/api/enhanced-data/health-check'],
    refetchInterval: 30000, // Check every 30 seconds
  });

  // Enhanced market data query
  const { data: marketData, refetch: refetchMarketData, isLoading: isLoadingMarket } = useQuery<EnhancedMarketData>({
    queryKey: ['/api/enhanced-data/market', selectedSymbol],
    enabled: !!selectedSymbol,
    refetchInterval: 10000, // Refresh every 10 seconds
  });

  // Comprehensive analysis query
  const { data: analysisData, refetch: refetchAnalysis, isLoading: isLoadingAnalysis } = useQuery<ComprehensiveAnalysis>({
    queryKey: ['/api/enhanced-data/analysis', selectedSymbol],
    enabled: !!selectedSymbol,
  });

  // Market overview query
  const { data: marketOverview, refetch: refetchOverview } = useQuery({
    queryKey: ['/api/enhanced-data/market-overview'],
    refetchInterval: 60000, // Refresh every minute
  });

  const handleRefreshAll = async () => {
    setIsRefreshing(true);
    try {
      await Promise.all([
        refetchHealth(),
        refetchMarketData(),
        refetchAnalysis(),
        refetchOverview()
      ]);
    } finally {
      setIsRefreshing(false);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'HEALTHY':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'ERROR':
        return <XCircle className="h-4 w-4 text-red-500" />;
      default:
        return <AlertTriangle className="h-4 w-4 text-yellow-500" />;
    }
  };

  const getRecommendationColor = (recommendation: string) => {
    switch (recommendation) {
      case 'BUY':
        return 'bg-green-500';
      case 'SELL':
        return 'bg-red-500';
      default:
        return 'bg-gray-500';
    }
  };

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'LOW':
        return 'bg-green-100 text-green-800';
      case 'MEDIUM':
        return 'bg-yellow-100 text-yellow-800';
      case 'HIGH':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800 p-6">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
              🚀 Enhanced External Data Integration
            </h1>
            <p className="text-gray-600 dark:text-gray-300 mt-2">
              Real-time market data from Alpha Vantage, NewsAPI, and FRED
            </p>
          </div>
          <Button
            onClick={handleRefreshAll}
            disabled={isRefreshing}
            className="bg-emerald-600 hover:bg-emerald-700"
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${isRefreshing ? 'animate-spin' : ''}`} />
            Refresh All
          </Button>
        </div>

        {/* Data Sources Health */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              📊 External Data Sources Health
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {healthData && Object.entries(healthData).map(([source, health]) => (
                <div key={source} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                  <div>
                    <p className="font-semibold capitalize">{source}</p>
                    <p className="text-sm text-gray-600 dark:text-gray-300">
                      {new Date(health.lastChecked).toLocaleTimeString()}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    {getStatusIcon(health.status)}
                    <Badge variant={health.status === 'HEALTHY' ? 'default' : 'destructive'}>
                      {health.status}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Symbol Selector */}
        <Card>
          <CardHeader>
            <CardTitle>Select Asset for Analysis</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {symbols.map(symbol => (
                <Button
                  key={symbol}
                  variant={selectedSymbol === symbol ? "default" : "outline"}
                  onClick={() => setSelectedSymbol(symbol)}
                  className="min-w-20"
                >
                  {symbol}
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Enhanced Market Data */}
        <Tabs defaultValue="market-data" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="market-data">Enhanced Market Data</TabsTrigger>
            <TabsTrigger value="comprehensive-analysis">Comprehensive Analysis</TabsTrigger>
            <TabsTrigger value="market-overview">Market Overview</TabsTrigger>
          </TabsList>

          <TabsContent value="market-data" className="space-y-4">
            {isLoadingMarket ? (
              <Card>
                <CardContent className="flex items-center justify-center h-40">
                  <RefreshCw className="h-8 w-8 animate-spin text-blue-500" />
                </CardContent>
              </Card>
            ) : marketData ? (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Price Information */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      💰 Real-Time Price Data
                      <Badge variant="outline">{marketData.symbol}</Badge>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-2xl font-bold">
                        {marketData.realTimePrice.toFixed(5)}
                      </span>
                      <div className="flex items-center gap-2">
                        {marketData.priceChangePercent >= 0 ? (
                          <TrendingUp className="h-5 w-5 text-green-500" />
                        ) : (
                          <TrendingDown className="h-5 w-5 text-red-500" />
                        )}
                        <span className={`font-semibold ${
                          marketData.priceChangePercent >= 0 ? 'text-green-500' : 'text-red-500'
                        }`}>
                          {marketData.priceChangePercent.toFixed(2)}%
                        </span>
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span>Data Confidence:</span>
                        <span className="font-semibold">{marketData.confidence}%</span>
                      </div>
                      <Progress value={marketData.confidence} className="h-2" />
                    </div>

                    <div className="space-y-2">
                      <h4 className="font-semibold">External Sources:</h4>
                      <div className="flex flex-wrap gap-2">
                        {Object.entries(marketData.externalSources).map(([source, available]) => (
                          <Badge
                            key={source}
                            variant={available ? "default" : "secondary"}
                            className={available ? "bg-green-100 text-green-800" : ""}
                          >
                            {source}: {available ? "✓" : "✗"}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Technical Indicators */}
                <Card>
                  <CardHeader>
                    <CardTitle>📈 Technical Indicators</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {marketData.technicalIndicators.rsi && (
                      <div className="flex justify-between items-center">
                        <span>RSI:</span>
                        <Badge variant="outline">{marketData.technicalIndicators.rsi.toFixed(2)}</Badge>
                      </div>
                    )}
                    
                    {marketData.technicalIndicators.macd && (
                      <div className="flex justify-between items-center">
                        <span>MACD:</span>
                        <Badge variant="outline">{marketData.technicalIndicators.macd.toFixed(4)}</Badge>
                      </div>
                    )}
                    
                    {marketData.technicalIndicators.signal && (
                      <div className="flex justify-between items-center">
                        <span>Signal:</span>
                        <Badge className={getRecommendationColor(marketData.technicalIndicators.signal)}>
                          {marketData.technicalIndicators.signal}
                        </Badge>
                      </div>
                    )}

                    <div className="mt-4 pt-4 border-t space-y-2">
                      <h4 className="font-semibold">Fundamental Analysis:</h4>
                      <div className="flex justify-between">
                        <span>News Sentiment:</span>
                        <span className={`font-semibold ${
                          marketData.fundamentalData.sentiment > 0 ? 'text-green-500' : 
                          marketData.fundamentalData.sentiment < 0 ? 'text-red-500' : 'text-gray-500'
                        }`}>
                          {(marketData.fundamentalData.sentiment * 100).toFixed(0)}%
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span>News Count:</span>
                        <Badge variant="outline">{marketData.fundamentalData.newsCount}</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span>Economic Impact:</span>
                        <Badge className={getRiskColor(marketData.fundamentalData.economicImpact)}>
                          {marketData.fundamentalData.economicImpact}
                        </Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            ) : (
              <Alert>
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>
                  No enhanced market data available. Please check external data sources.
                </AlertDescription>
              </Alert>
            )}
          </TabsContent>

          <TabsContent value="comprehensive-analysis" className="space-y-4">
            {isLoadingAnalysis ? (
              <Card>
                <CardContent className="flex items-center justify-center h-40">
                  <RefreshCw className="h-8 w-8 animate-spin text-blue-500" />
                </CardContent>
              </Card>
            ) : analysisData ? (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Recommendation */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      🎯 AI Recommendation
                      <Badge className={getRecommendationColor(analysisData.recommendation)}>
                        {analysisData.recommendation}
                      </Badge>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span>Confidence:</span>
                        <span className="font-semibold">{analysisData.confidence}%</span>
                      </div>
                      <Progress value={analysisData.confidence} className="h-2" />
                    </div>

                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span>Risk Level:</span>
                        <Badge className={getRiskColor(analysisData.riskLevel)}>
                          {analysisData.riskLevel}
                        </Badge>
                      </div>
                      <div className="flex justify-between">
                        <span>Expected Return:</span>
                        <span className="font-semibold text-green-600">
                          {analysisData.expectedReturn.toFixed(2)}%
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span>Timeframe:</span>
                        <Badge variant="outline">{analysisData.timeframe}</Badge>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <h4 className="font-semibold">Trading Levels:</h4>
                      <div className="text-sm space-y-1">
                        <div className="flex justify-between">
                          <span>Stop Loss:</span>
                          <span className="font-mono">{analysisData.stopLoss.toFixed(5)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Take Profit:</span>
                          <span className="font-mono">{analysisData.takeProfit.toFixed(5)}</span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Analysis Details */}
                <Card>
                  <CardHeader>
                    <CardTitle>🔍 Analysis Details</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span>Data Quality:</span>
                        <span className="font-semibold">{analysisData.dataQuality}%</span>
                      </div>
                      <Progress value={analysisData.dataQuality} className="h-2" />
                    </div>

                    <div className="space-y-2">
                      <h4 className="font-semibold">Data Sources:</h4>
                      <div className="flex flex-wrap gap-1">
                        {analysisData.sources.map((source, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {source}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    <div className="space-y-2">
                      <h4 className="font-semibold">Market Context:</h4>
                      <div className="text-sm space-y-1">
                        <div className="flex justify-between">
                          <span>Economic Sentiment:</span>
                          <span className={`font-semibold ${
                            analysisData.marketContext.economicSentiment > 0 ? 'text-green-500' : 
                            analysisData.marketContext.economicSentiment < 0 ? 'text-red-500' : 'text-gray-500'
                          }`}>
                            {(analysisData.marketContext.economicSentiment * 100).toFixed(0)}%
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span>News Sentiment:</span>
                          <span className={`font-semibold ${
                            analysisData.marketContext.newsSentiment > 0 ? 'text-green-500' : 
                            analysisData.marketContext.newsSentiment < 0 ? 'text-red-500' : 'text-gray-500'
                          }`}>
                            {(analysisData.marketContext.newsSentiment * 100).toFixed(0)}%
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span>Technical Strength:</span>
                          <span className="font-semibold">
                            {(analysisData.marketContext.technicalStrength * 100).toFixed(0)}%
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <h4 className="font-semibold">Key Reasoning:</h4>
                      <div className="text-sm space-y-1">
                        {analysisData.reasoning.slice(0, 3).map((reason, index) => (
                          <div key={index} className="flex items-start gap-2">
                            <span className="text-blue-500 mt-1">•</span>
                            <span>{reason}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            ) : (
              <Alert>
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>
                  No comprehensive analysis available. Please check external data sources.
                </AlertDescription>
              </Alert>
            )}
          </TabsContent>

          <TabsContent value="market-overview" className="space-y-4">
            {marketOverview ? (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>🏛️ Economic Data Overview</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {marketOverview.economicData ? (
                      <div className="space-y-3">
                        <div className="flex justify-between items-center">
                          <span>Overall Sentiment:</span>
                          <Badge className={
                            marketOverview.economicData.sentiment === 'POSITIVE' ? 'bg-green-100 text-green-800' :
                            marketOverview.economicData.sentiment === 'NEGATIVE' ? 'bg-red-100 text-red-800' :
                            'bg-gray-100 text-gray-800'
                          }>
                            {marketOverview.economicData.sentiment}
                          </Badge>
                        </div>
                        <div className="flex justify-between">
                          <span>Confidence:</span>
                          <span className="font-semibold">
                            {(marketOverview.economicData.confidence * 100).toFixed(0)}%
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span>Sentiment Score:</span>
                          <span className={`font-semibold ${
                            marketOverview.economicData.overallSentiment > 0 ? 'text-green-500' : 
                            marketOverview.economicData.overallSentiment < 0 ? 'text-red-500' : 'text-gray-500'
                          }`}>
                            {marketOverview.economicData.overallSentiment.toFixed(2)}
                          </span>
                        </div>
                      </div>
                    ) : (
                      <p className="text-gray-500">Economic data not available</p>
                    )}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>📰 Market News Summary</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {marketOverview.marketSentiment ? (
                      <div className="space-y-3">
                        <div className="flex justify-between">
                          <span>Articles Analyzed:</span>
                          <Badge variant="outline">
                            {marketOverview.marketSentiment.articlesCount}
                          </Badge>
                        </div>
                        <div className="space-y-2">
                          <div className="flex justify-between">
                            <span>Positive:</span>
                            <span className="text-green-600 font-semibold">
                              {marketOverview.marketSentiment.positive}%
                            </span>
                          </div>
                          <div className="flex justify-between">
                            <span>Negative:</span>
                            <span className="text-red-600 font-semibold">
                              {marketOverview.marketSentiment.negative}%
                            </span>
                          </div>
                          <div className="flex justify-between">
                            <span>Neutral:</span>
                            <span className="text-gray-600 font-semibold">
                              {marketOverview.marketSentiment.neutral}%
                            </span>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <p className="text-gray-500">Market sentiment data not available</p>
                    )}
                  </CardContent>
                </Card>

                {marketOverview.topNews && marketOverview.topNews.length > 0 && (
                  <Card className="lg:col-span-2">
                    <CardHeader>
                      <CardTitle>📈 Top Market News</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        {marketOverview.topNews.slice(0, 5).map((news: any, index: number) => (
                          <div key={index} className="p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                            <h4 className="font-semibold text-sm mb-2">{news.title}</h4>
                            <div className="flex justify-between items-center text-xs text-gray-600 dark:text-gray-300">
                              <span>{news.source}</span>
                              <div className="flex items-center gap-2">
                                {news.impact && (
                                  <Badge className={getRiskColor(news.impact)} variant="outline">
                                    {news.impact}
                                  </Badge>
                                )}
                                <span>{new Date(news.publishedAt).toLocaleDateString()}</span>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
            ) : (
              <Alert>
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>
                  Market overview data is being loaded...
                </AlertDescription>
              </Alert>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default ExternalDataDemo;
import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  User, 
  CreditCard, 
  Key, 
  BarChart3, 
  Calendar,
  Settings,
  LogOut,
  Shield,
  Zap,
  TrendingUp,
  Package,
  Clock,
  Users
} from "lucide-react";
import { Link } from "wouter";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface CommercialUser {
  id: string;
  username: string;
  email: string;
  firstName: string;
  lastName: string;
  subscriptionStatus: string;
  subscriptionTier: string;
  trialEndDate: string;
  dailySignalsUsed: number;
  monthlySignalsUsed: number;
  totalSignalsUsed: number;
}

interface License {
  id: number;
  licenseKey: string;
  licenseType: string;
  isValid: boolean;
  isActivated: boolean;
  isRevoked: boolean;
  expiresAt: string;
  usageCount: number;
  maxTrades: number;
}

interface Product {
  id: number;
  name: string;
  nameAr: string;
  description: string;
  descriptionAr: string;
  priceUsd: number;
  originalPriceUsd: number;
  features: string[];
  limits: {
    dailySignals: number;
    monthlySignals: number;
    devices: number;
  };
  isPopular: boolean;
}

export default function CommercialDashboard() {
  const [currentUser, setCurrentUser] = useState<CommercialUser | null>(null);
  const { toast } = useToast();

  // Fetch user profile
  const { data: userStats, isLoading: isLoadingStats } = useQuery({
    queryKey: ["/api/commercial/me"],
    retry: false,
  });

  // Fetch user licenses
  const { data: licensesData, isLoading: isLoadingLicenses } = useQuery({
    queryKey: ["/api/commercial/licenses"],
    retry: false,
  });

  // Fetch products
  const { data: productsData, isLoading: isLoadingProducts } = useQuery({
    queryKey: ["/api/commercial/products"],
    retry: false,
  });

  useEffect(() => {
    if (userStats?.user) {
      setCurrentUser(userStats.user);
    }
  }, [userStats]);

  const handleLogout = async () => {
    try {
      await apiRequest("POST", "/api/commercial/logout", {});
      localStorage.removeItem("commercial_token");
      toast({
        title: "تم تسجيل الخروج بنجاح",
        description: "نراك قريباً!",
      });
      window.location.href = "/commercial/login";
    } catch (error) {
      toast({
        title: "خطأ في تسجيل الخروج",
        description: "حدث خطأ أثناء تسجيل الخروج",
        variant: "destructive",
      });
    }
  };

  const getSubscriptionColor = (status: string) => {
    switch (status) {
      case "trial": return "bg-blue-500";
      case "active": return "bg-emerald-500";
      case "expired": return "bg-red-500";
      case "cancelled": return "bg-gray-500";
      default: return "bg-gray-500";
    }
  };

  const getSubscriptionText = (status: string) => {
    switch (status) {
      case "trial": return "تجربة مجانية";
      case "active": return "نشط";
      case "expired": return "منتهي الصلاحية";
      case "cancelled": return "ملغي";
      default: return status;
    }
  };

  const getTierText = (tier: string) => {
    switch (tier) {
      case "basic": return "أساسي";
      case "pro": return "محترف";
      case "enterprise": return "مؤسسات";
      default: return tier;
    }
  };

  const formatPrice = (priceUsd: number) => {
    return (priceUsd / 100).toFixed(2);
  };

  const daysUntilTrialEnd = currentUser?.trialEndDate 
    ? Math.ceil((new Date(currentUser.trialEndDate).getTime() - Date.now()) / (1000 * 60 * 60 * 24))
    : 0;

  if (isLoadingStats || isLoadingLicenses || isLoadingProducts) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-800 flex items-center justify-center">
        <div className="text-center text-white">
          <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-xl">جاري تحميل لوحة التحكم...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-800">
      {/* Header */}
      <header className="bg-white/10 backdrop-blur-lg border-b border-white/20">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4 rtl:space-x-reverse">
              <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-emerald-500 rounded-lg flex items-center justify-center">
                <Zap className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-white">الزين تريد</h1>
                <p className="text-sm text-gray-300">لوحة التحكم التجارية</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4 rtl:space-x-reverse">
              <div className="text-right">
                <p className="text-white font-medium">
                  {currentUser?.firstName} {currentUser?.lastName}
                </p>
                <p className="text-sm text-gray-300">@{currentUser?.username}</p>
              </div>
              <Button 
                variant="outline" 
                size="sm"
                onClick={handleLogout}
                className="bg-white/10 border-white/20 text-white hover:bg-white/20"
              >
                <LogOut className="w-4 h-4 ml-2" />
                تسجيل الخروج
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="bg-white/10 backdrop-blur-lg border-white/20">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-300 text-sm">حالة الاشتراك</p>
                  <Badge 
                    className={`${getSubscriptionColor(currentUser?.subscriptionStatus || "")} text-white mt-1`}
                  >
                    {getSubscriptionText(currentUser?.subscriptionStatus || "")}
                  </Badge>
                </div>
                <Shield className="w-8 h-8 text-blue-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/10 backdrop-blur-lg border-white/20">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-300 text-sm">الخطة الحالية</p>
                  <p className="text-white font-semibold text-lg">
                    {getTierText(currentUser?.subscriptionTier || "")}
                  </p>
                </div>
                <Package className="w-8 h-8 text-emerald-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/10 backdrop-blur-lg border-white/20">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-300 text-sm">الإشارات اليوم</p>
                  <p className="text-white font-semibold text-lg">
                    {currentUser?.dailySignalsUsed || 0}
                  </p>
                </div>
                <TrendingUp className="w-8 h-8 text-purple-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/10 backdrop-blur-lg border-white/20">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-300 text-sm">أيام التجربة المتبقية</p>
                  <p className="text-white font-semibold text-lg">
                    {currentUser?.subscriptionStatus === "trial" ? Math.max(0, daysUntilTrialEnd) : "غير محدود"}
                  </p>
                </div>
                <Clock className="w-8 h-8 text-yellow-400" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Trial Warning */}
        {currentUser?.subscriptionStatus === "trial" && daysUntilTrialEnd <= 3 && (
          <Card className="mb-8 bg-gradient-to-r from-orange-500/20 to-red-500/20 border-orange-500/30">
            <CardContent className="p-6">
              <div className="flex items-center space-x-4 rtl:space-x-reverse">
                <div className="w-12 h-12 bg-orange-500/20 rounded-lg flex items-center justify-center">
                  <Calendar className="w-6 h-6 text-orange-400" />
                </div>
                <div className="flex-1">
                  <h3 className="text-white font-semibold text-lg">تنتهي فترة التجربة قريباً!</h3>
                  <p className="text-gray-300">
                    تنتهي فترة التجربة المجانية خلال {daysUntilTrialEnd} أيام. قم بالاشتراك للاستمرار في استخدام الخدمة.
                  </p>
                </div>
                <Button className="bg-orange-600 hover:bg-orange-700 text-white">
                  اشترك الآن
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Main Content */}
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="bg-white/10 border-white/20">
            <TabsTrigger value="overview" className="data-[state=active]:bg-blue-500 data-[state=active]:text-white">
              <BarChart3 className="w-4 h-4 ml-2" />
              نظرة عامة
            </TabsTrigger>
            <TabsTrigger value="licenses" className="data-[state=active]:bg-emerald-500 data-[state=active]:text-white">
              <Key className="w-4 h-4 ml-2" />
              التراخيص
            </TabsTrigger>
            <TabsTrigger value="products" className="data-[state=active]:bg-purple-500 data-[state=active]:text-white">
              <Package className="w-4 h-4 ml-2" />
              المنتجات
            </TabsTrigger>
            <TabsTrigger value="settings" className="data-[state=active]:bg-gray-500 data-[state=active]:text-white">
              <Settings className="w-4 h-4 ml-2" />
              الإعدادات
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-white/10 backdrop-blur-lg border-white/20">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <BarChart3 className="w-5 h-5 ml-2" />
                    إحصائيات الاستخدام
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span className="text-gray-300">الإشارات الشهرية</span>
                      <span className="text-white">{currentUser?.monthlySignalsUsed || 0} / غير محدود</span>
                    </div>
                    <Progress 
                      value={Math.min(100, ((currentUser?.monthlySignalsUsed || 0) / 500) * 100)} 
                      className="h-2"
                    />
                  </div>
                  
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span className="text-gray-300">إجمالي الإشارات</span>
                      <span className="text-white">{currentUser?.totalSignalsUsed || 0}</span>
                    </div>
                  </div>
                  
                  <div className="bg-blue-500/20 rounded-lg p-4">
                    <h4 className="text-blue-200 font-medium mb-2">معدل النجاح</h4>
                    <p className="text-2xl font-bold text-blue-400">--</p>
                    <p className="text-blue-300 text-sm">سيتم حسابه قريباً</p>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-white/10 backdrop-blur-lg border-white/20">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <User className="w-5 h-5 ml-2" />
                    معلومات الحساب
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div>
                      <p className="text-gray-300 text-sm">البريد الإلكتروني</p>
                      <p className="text-white">{currentUser?.email}</p>
                    </div>
                    
                    <div>
                      <p className="text-gray-300 text-sm">تاريخ انتهاء التجربة</p>
                      <p className="text-white">
                        {currentUser?.trialEndDate 
                          ? new Date(currentUser.trialEndDate).toLocaleDateString('ar-SA')
                          : "غير محدد"
                        }
                      </p>
                    </div>
                    
                    <div>
                      <p className="text-gray-300 text-sm">حالة التفعيل</p>
                      <Badge className="bg-emerald-500 text-white">
                        مفعل
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Licenses Tab */}
          <TabsContent value="licenses">
            <Card className="bg-white/10 backdrop-blur-lg border-white/20">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <Key className="w-5 h-5 ml-2" />
                  تراخيص المنتجات
                </CardTitle>
              </CardHeader>
              <CardContent>
                {licensesData?.licenses?.length > 0 ? (
                  <div className="space-y-4">
                    {licensesData.licenses.map((license: License) => (
                      <div key={license.id} className="bg-white/5 rounded-lg p-4 border border-white/10">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="text-white font-medium">{license.licenseKey}</h4>
                          <Badge className={
                            license.isValid && !license.isRevoked 
                              ? "bg-emerald-500 text-white" 
                              : "bg-red-500 text-white"
                          }>
                            {license.isValid && !license.isRevoked ? "نشط" : "غير نشط"}
                          </Badge>
                        </div>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                          <div>
                            <p className="text-gray-300">النوع</p>
                            <p className="text-white">{license.licenseType}</p>
                          </div>
                          <div>
                            <p className="text-gray-300">الاستخدام</p>
                            <p className="text-white">{license.usageCount} / {license.maxTrades || "غير محدود"}</p>
                          </div>
                          <div>
                            <p className="text-gray-300">الحالة</p>
                            <p className="text-white">{license.isActivated ? "مفعل" : "غير مفعل"}</p>
                          </div>
                          <div>
                            <p className="text-gray-300">انتهاء الصلاحية</p>
                            <p className="text-white">
                              {license.expiresAt 
                                ? new Date(license.expiresAt).toLocaleDateString('ar-SA')
                                : "لا ينتهي"
                              }
                            </p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <Key className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-300 text-lg">لا توجد تراخيص حالياً</p>
                    <p className="text-gray-400">سيتم إنشاء ترخيص تلقائياً عند الاشتراك</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Products Tab */}
          <TabsContent value="products">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {productsData?.products?.map((product: Product) => (
                <Card key={product.id} className={`bg-white/10 backdrop-blur-lg border-white/20 relative ${
                  product.isPopular ? "ring-2 ring-emerald-500" : ""
                }`}>
                  {product.isPopular && (
                    <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                      <Badge className="bg-emerald-500 text-white px-3 py-1">
                        الأكثر شيوعاً
                      </Badge>
                    </div>
                  )}
                  
                  <CardHeader>
                    <div className="text-center">
                      <CardTitle className="text-white text-xl mb-2">
                        {product.nameAr}
                      </CardTitle>
                      <div className="space-y-1">
                        {product.originalPriceUsd > product.priceUsd && (
                          <p className="text-gray-400 line-through text-sm">
                            ${formatPrice(product.originalPriceUsd)}
                          </p>
                        )}
                        <p className="text-3xl font-bold text-emerald-400">
                          ${formatPrice(product.priceUsd)}
                          <span className="text-sm text-gray-300">/شهرياً</span>
                        </p>
                      </div>
                    </div>
                  </CardHeader>
                  
                  <CardContent className="space-y-4">
                    <p className="text-gray-300 text-center">
                      {product.descriptionAr}
                    </p>
                    
                    <ul className="space-y-2">
                      {product.features.map((feature, index) => (
                        <li key={index} className="flex items-center text-sm text-gray-300">
                          <div className="w-1.5 h-1.5 bg-emerald-400 rounded-full ml-2 shrink-0"></div>
                          {feature}
                        </li>
                      ))}
                    </ul>
                    
                    <div className="space-y-2 pt-4 border-t border-white/10">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-300">الإشارات اليومية</span>
                        <span className="text-white">
                          {product.limits.dailySignals === -1 ? "غير محدود" : product.limits.dailySignals}
                        </span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-300">عدد الأجهزة</span>
                        <span className="text-white">{product.limits.devices}</span>
                      </div>
                    </div>
                    
                    <Button className="w-full bg-emerald-600 hover:bg-emerald-700 text-white">
                      <CreditCard className="w-4 h-4 ml-2" />
                      اشترك الآن
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Settings Tab */}
          <TabsContent value="settings">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-white/10 backdrop-blur-lg border-white/20">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <User className="w-5 h-5 ml-2" />
                    معلومات الملف الشخصي
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-gray-300 text-sm">الاسم الأول</label>
                      <p className="text-white bg-white/5 rounded p-2">{currentUser?.firstName}</p>
                    </div>
                    <div>
                      <label className="text-gray-300 text-sm">الاسم الأخير</label>
                      <p className="text-white bg-white/5 rounded p-2">{currentUser?.lastName}</p>
                    </div>
                  </div>
                  <div>
                    <label className="text-gray-300 text-sm">اسم المستخدم</label>
                    <p className="text-white bg-white/5 rounded p-2">{currentUser?.username}</p>
                  </div>
                  <div>
                    <label className="text-gray-300 text-sm">البريد الإلكتروني</label>
                    <p className="text-white bg-white/5 rounded p-2">{currentUser?.email}</p>
                  </div>
                  <Button variant="outline" className="border-white/20 text-white hover:bg-white/10">
                    تحديث المعلومات
                  </Button>
                </CardContent>
              </Card>

              <Card className="bg-white/10 backdrop-blur-lg border-white/20">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <Shield className="w-5 h-5 ml-2" />
                    الأمان
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Button variant="outline" className="w-full border-white/20 text-white hover:bg-white/10">
                    تغيير كلمة المرور
                  </Button>
                  <Button variant="outline" className="w-full border-white/20 text-white hover:bg-white/10">
                    تفعيل المصادقة الثنائية
                  </Button>
                  <Button variant="outline" className="w-full border-white/20 text-white hover:bg-white/10">
                    عرض جلسات النشاط
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>

        {/* Quick Actions */}
        <div className="mt-8 text-center">
          <Link href="/">
            <Button variant="outline" className="border-white/20 text-white hover:bg-white/10">
              العودة إلى منصة التداول
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
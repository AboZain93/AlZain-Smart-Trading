import { SocialTrading } from '@/components/social-trading';
import { useLanguageContext } from '@/components/language-provider';

export default function SocialTradingPage() {
  const { language } = useLanguageContext();

  return (
    <div className="container mx-auto p-6 space-y-6" dir={language === 'ar' ? 'rtl' : 'ltr'}>
      <SocialTrading />
    </div>
  );
}
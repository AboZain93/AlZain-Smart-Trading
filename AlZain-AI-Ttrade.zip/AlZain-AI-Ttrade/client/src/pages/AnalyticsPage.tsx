import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Brain, MessageCircle, TrendingUp, BarChart3, Activity, Users, Star, CheckCircle, XCircle, Clock, Target, Zap, RefreshCw } from 'lucide-react';

export function AnalyticsPage() {
  // Fetch ML training data and analytics
  const { data: mlData, isLoading: mlLoading, refetch: refetchMlData } = useQuery({
    queryKey: ['/api/ml-training-data'],
    refetchInterval: 30000,
  });

  // Fetch telegram feedback data  
  const { data: feedbackData, isLoading: feedbackLoading, refetch: refetchFeedback } = useQuery({
    queryKey: ['/api/telegram-feedback'],
    refetchInterval: 30000,
  });

  // Fetch asset performance data
  const { data: performanceData, isLoading: performanceLoading, refetch: refetchPerformance } = useQuery({
    queryKey: ['/api/asset-performance'],
    refetchInterval: 30000,
  });

  // Fetch recommendations for analysis
  const { data: recommendations, isLoading: recommendationsLoading } = useQuery({
    queryKey: ['/api/trading-recommendations'],
    refetchInterval: 30000,
  });

  const isLoading = mlLoading || feedbackLoading || performanceLoading || recommendationsLoading;

  // Calculate analytics from real data
  const analytics = {
    totalRecommendations: Array.isArray(recommendations) ? recommendations.length : 0,
    totalFeedback: Array.isArray(feedbackData) ? feedbackData.length : 0,
    mlDataPoints: Array.isArray(mlData) ? mlData.length : 0,
    assetsTracked: Array.isArray(performanceData) ? performanceData.length : 0,
    avgSuccessRate: Array.isArray(performanceData) && performanceData.length > 0 
      ? performanceData.reduce((acc: number, asset: any) => acc + (asset.successRate || 0), 0) / performanceData.length 
      : 0,
    recentFeedback: Array.isArray(feedbackData) ? feedbackData.slice(0, 10) : [],
    topPerformingAssets: Array.isArray(performanceData) 
      ? performanceData.sort((a: any, b: any) => (b.successRate || 0) - (a.successRate || 0)).slice(0, 5) 
      : [],
    feedbackDistribution: {
      success: Array.isArray(feedbackData) ? feedbackData.filter((f: any) => f.feedbackType === 'success').length : 0,
      partial: Array.isArray(feedbackData) ? feedbackData.filter((f: any) => f.feedbackType === 'partial').length : 0,
      failure: Array.isArray(feedbackData) ? feedbackData.filter((f: any) => f.feedbackType === 'failure').length : 0,
    }
  };

  const handleRefreshAll = () => {
    refetchMlData();
    refetchFeedback();
    refetchPerformance();
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50/30 to-purple-50/30 dark:from-slate-900 dark:via-slate-800 dark:to-indigo-900/30 flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="w-16 h-16 border-4 border-purple-500 border-t-transparent rounded-full animate-spin mx-auto"></div>
          <p className="text-lg text-purple-600 dark:text-purple-400 font-medium">جاري تحميل التحليلات...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50/30 to-purple-50/30 dark:from-slate-900 dark:via-slate-800 dark:to-indigo-900/30">
      <div className="container mx-auto p-6 space-y-8">
        {/* Header */}
        <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-purple-600 via-blue-600 to-cyan-600 p-8 text-white shadow-2xl">
          <div className="absolute inset-0 opacity-20">
            <div className="absolute top-0 right-0 w-32 h-32 bg-white rounded-full blur-3xl"></div>
            <div className="absolute bottom-0 left-0 w-24 h-24 bg-white rounded-full blur-2xl"></div>
          </div>
          
          <div className="relative flex items-center justify-between">
            <div className="space-y-3">
              <div className="flex items-center gap-3">
                <div className="p-3 rounded-xl bg-white/20 backdrop-blur-sm">
                  <Brain className="h-8 w-8 text-white" />
                </div>
                <h1 className="text-4xl font-bold tracking-tight">تحليلات التعلم الآلي</h1>
              </div>
              <p className="text-purple-100 text-lg max-w-2xl">
                تحليل أداء التوصيات وتفاعلات المستخدمين لتحسين دقة الذكاء الاصطناعي
              </p>
            </div>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid gap-6 md:grid-cols-4">
          <Card className="border-0 shadow-lg bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-900/20 dark:to-blue-800/20">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-xl bg-blue-500 text-white">
                  <Activity className="h-6 w-6" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">إجمالي التوصيات</p>
                  <p className="text-2xl font-bold text-blue-600">{stats.totalRecommendations}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg bg-gradient-to-br from-green-50 to-green-100 dark:from-green-900/20 dark:to-green-800/20">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-xl bg-green-500 text-white">
                  <TrendingUp className="h-6 w-6" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">معدل النجاح</p>
                  <p className="text-2xl font-bold text-green-600">{stats.successRate}%</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg bg-gradient-to-br from-purple-50 to-purple-100 dark:from-purple-900/20 dark:to-purple-800/20">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-xl bg-purple-500 text-white">
                  <Users className="h-6 w-6" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">المستخدمين النشطين</p>
                  <p className="text-2xl font-bold text-purple-600">{stats.activeUsers}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg bg-gradient-to-br from-orange-50 to-orange-100 dark:from-orange-900/20 dark:to-orange-800/20">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-xl bg-orange-500 text-white">
                  <Star className="h-6 w-6" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">دقة الذكاء الاصطناعي</p>
                  <p className="text-2xl font-bold text-orange-600">{stats.accuracy}%</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="insights" className="space-y-8">
          <TabsList className="grid w-full max-w-md mx-auto grid-cols-2 h-12 p-1 bg-white/70 dark:bg-slate-800/70 backdrop-blur-sm border-0 shadow-lg rounded-xl">
            <TabsTrigger 
              value="insights" 
              className="flex items-center gap-2 rounded-lg font-medium data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-500 data-[state=active]:to-blue-600 data-[state=active]:text-white"
            >
              <BarChart3 className="h-4 w-4" />
              تحليل الأداء
            </TabsTrigger>
            <TabsTrigger 
              value="feedback" 
              className="flex items-center gap-2 rounded-lg font-medium data-[state=active]:bg-gradient-to-r data-[state=active]:from-green-500 data-[state=active]:to-cyan-600 data-[state=active]:text-white"
            >
              <MessageCircle className="h-4 w-4" />
              التفاعلات
            </TabsTrigger>
          </TabsList>

          <TabsContent value="insights" className="space-y-6">
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-3">
                  <Brain className="h-5 w-5 text-purple-500" />
                  رؤى التعلم الآلي
                </CardTitle>
                <CardDescription>
                  تحليل أداء نظام التوصيات الذكي
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-12 space-y-4">
                  <Brain className="h-16 w-16 text-purple-500 mx-auto animate-pulse" />
                  <p className="text-lg font-medium">النظام يتعلم من بياناتك</p>
                  <p className="text-muted-foreground">سيتم عرض التحليلات المتقدمة قريباً</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="feedback" className="space-y-6">
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-3">
                  <MessageCircle className="h-5 w-5 text-green-500" />
                  تحليل التفاعلات
                </CardTitle>
                <CardDescription>
                  ردود أفعال المستخدمين على التوصيات
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-12 space-y-4">
                  <MessageCircle className="h-16 w-16 text-green-500 mx-auto animate-bounce" />
                  <p className="text-lg font-medium">جاري جمع التفاعلات</p>
                  <p className="text-muted-foreground">سيتم عرض تحليل التفاعلات قريباً</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
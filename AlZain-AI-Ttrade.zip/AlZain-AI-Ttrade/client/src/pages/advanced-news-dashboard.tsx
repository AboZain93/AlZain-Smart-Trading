import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { 
  TrendingUp, 
  TrendingDown, 
  AlertTriangle,
  Calendar,
  Globe,
  Search,
  Filter,
  ExternalLink,
  Clock,
  BarChart3,
  Activity,
  Target,
  Brain,
  Newspaper,
  DollarSign,
  Zap,
  Shield,
  RefreshCw
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useQuery } from "@tanstack/react-query";

interface NewsArticle {
  id: number;
  title: string;
  content: string;
  source: string;
  url: string;
  publishedAt: string;
  category: string;
  sentiment: number;
  confidence: number;
  impactLevel: string;
  affectedAssets: string[];
  keywords: string[];
  language: string;
}

interface NewsAnalysis {
  overall_sentiment: number;
  market_impact: string;
  confidence_score: number;
  key_themes: string[];
  sentiment_breakdown: {
    monetary_policy: number;
    economic_data: number;
    geopolitical: number;
    market_news: number;
    crypto: number;
  };
  trend_analysis: {
    trend: string;
    momentum: number;
    duration: string;
  };
  trading_implications: string[];
  time_horizon: string;
}

const AdvancedNewsDashboard = () => {
  const [activeTab, setActiveTab] = useState("overview");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedAsset, setSelectedAsset] = useState("");
  const [refreshKey, setRefreshKey] = useState(0);

  const { data: newsAnalysis, isLoading: analysisLoading } = useQuery({
    queryKey: ['/api/news/analysis', refreshKey],
    refetchInterval: 60000
  });

  const { data: allNews, isLoading: newsLoading } = useQuery({
    queryKey: ['/api/news/all', refreshKey],
    refetchInterval: 120000
  });

  const { data: sentimentHistory } = useQuery({
    queryKey: ['/api/news/sentiment-history', refreshKey],
    refetchInterval: 300000
  });

  const handleRefresh = () => {
    setRefreshKey(prev => prev + 1);
  };

  const getImpactColor = (impact: string) => {
    switch (impact) {
      case 'bullish': return 'text-green-600 dark:text-green-400';
      case 'bearish': return 'text-red-600 dark:text-red-400';
      default: return 'text-gray-600 dark:text-gray-400';
    }
  };

  const getSentimentColor = (sentiment: number) => {
    if (sentiment > 20) return 'text-green-600 dark:text-green-400';
    if (sentiment < -20) return 'text-red-600 dark:text-red-400';
    return 'text-gray-600 dark:text-gray-400';
  };

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'improving': return <TrendingUp className="h-5 w-5 text-green-500" />;
      case 'deteriorating': return <TrendingDown className="h-5 w-5 text-red-500" />;
      default: return <Activity className="h-5 w-5 text-blue-500" />;
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'monetary-policy': return <Target className="h-4 w-4" />;
      case 'economic-data': return <BarChart3 className="h-4 w-4" />;
      case 'geopolitical': return <Globe className="h-4 w-4" />;
      case 'crypto': return <Zap className="h-4 w-4" />;
      default: return <Newspaper className="h-4 w-4" />;
    }
  };

  const getCategoryLabel = (category: string) => {
    switch (category) {
      case 'monetary-policy': return 'السياسة النقدية';
      case 'economic-data': return 'البيانات الاقتصادية';
      case 'geopolitical': return 'الأحداث الجيوسياسية';
      case 'market-news': return 'أخبار السوق';
      case 'crypto': return 'العملات الرقمية';
      default: return category;
    }
  };

  const filteredNews = allNews?.filter((article: NewsArticle) => {
    const matchesSearch = !searchQuery || 
      article.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      article.content.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesCategory = selectedCategory === 'all' || article.category === selectedCategory;
    
    const matchesAsset = !selectedAsset || article.affectedAssets.includes(selectedAsset);
    
    return matchesSearch && matchesCategory && matchesAsset;
  }) || [];

  if (analysisLoading || newsLoading) {
    return (
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-bold">تحليل الأخبار المتطور</h1>
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[...Array(6)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardHeader className="pb-3">
                <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-3/4"></div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded"></div>
                  <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded w-5/6"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
            تحليل الأخبار المتطور
          </h1>
          <p className="text-gray-600 dark:text-gray-400 mt-1">
            تحليل ذكي شامل للأخبار والأحداث الاقتصادية
          </p>
        </div>
        <Button 
          onClick={handleRefresh}
          variant="outline" 
          size="icon"
          className="hover:bg-purple-50 dark:hover:bg-purple-900"
        >
          <RefreshCw className="h-4 w-4" />
        </Button>
      </div>

      {/* Market Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <Card className="border-l-4 border-l-purple-500">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <Brain className="h-5 w-5 text-purple-500" />
                المعنويات العامة
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <span className={`text-2xl font-bold ${getSentimentColor(newsAnalysis?.overall_sentiment || 0)}`}>
                  {newsAnalysis?.overall_sentiment > 0 ? '+' : ''}{newsAnalysis?.overall_sentiment || 0}%
                </span>
                <Badge variant="outline" className={`${getImpactColor(newsAnalysis?.market_impact || 'neutral')} border-current`}>
                  {newsAnalysis?.market_impact === 'bullish' ? 'صاعد' :
                   newsAnalysis?.market_impact === 'bearish' ? 'هابط' : 'محايد'}
                </Badge>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
        >
          <Card className="border-l-4 border-l-blue-500">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <Shield className="h-5 w-5 text-blue-500" />
                مستوى الثقة
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-2xl font-bold">{newsAnalysis?.confidence_score || 0}%</span>
                </div>
                <Progress value={newsAnalysis?.confidence_score || 0} className="h-2" />
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <Card className="border-l-4 border-l-emerald-500">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <Activity className="h-5 w-5 text-emerald-500" />
                اتجاه السوق
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">
                  {newsAnalysis?.trend_analysis?.trend === 'improving' ? 'تحسن' :
                   newsAnalysis?.trend_analysis?.trend === 'deteriorating' ? 'تراجع' : 'مستقر'}
                </span>
                {getTrendIcon(newsAnalysis?.trend_analysis?.trend || 'stable')}
              </div>
              <div className="mt-2 text-xs text-gray-500">
                زخم: {newsAnalysis?.trend_analysis?.momentum || 0}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
        >
          <Card className="border-l-4 border-l-orange-500">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <Clock className="h-5 w-5 text-orange-500" />
                الإطار الزمني
              </CardTitle>
            </CardHeader>
            <CardContent>
              <span className="text-sm font-medium">
                {newsAnalysis?.time_horizon === 'short-term' ? 'قصير المدى' :
                 newsAnalysis?.time_horizon === 'medium-term' ? 'متوسط المدى' : 'طويل المدى'}
              </span>
              <div className="mt-2 text-xs text-gray-500">
                {newsAnalysis?.trend_analysis?.duration || 'غير محدد'}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Main Content Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-4 lg:w-auto lg:grid-cols-4">
          <TabsTrigger value="overview" className="flex items-center gap-2">
            <BarChart3 className="h-4 w-4" />
            نظرة عامة
          </TabsTrigger>
          <TabsTrigger value="sentiment" className="flex items-center gap-2">
            <Activity className="h-4 w-4" />
            تحليل المعنويات
          </TabsTrigger>
          <TabsTrigger value="news" className="flex items-center gap-2">
            <Newspaper className="h-4 w-4" />
            الأخبار
          </TabsTrigger>
          <TabsTrigger value="implications" className="flex items-center gap-2">
            <Target className="h-4 w-4" />
            التوصيات
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Key Themes */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Brain className="h-5 w-5 text-purple-500" />
                  الموضوعات الرئيسية
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {newsAnalysis?.key_themes?.map((theme, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className="flex items-center gap-3 p-3 rounded-lg bg-purple-50 dark:bg-purple-900/20"
                    >
                      <div className="w-2 h-2 rounded-full bg-purple-500"></div>
                      <span className="text-sm">{theme}</span>
                    </motion.div>
                  )) || []}
                </div>
              </CardContent>
            </Card>

            {/* Sentiment Breakdown */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="h-5 w-5 text-blue-500" />
                  تحليل المعنويات حسب القطاع
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {Object.entries(newsAnalysis?.sentiment_breakdown || {}).map(([category, sentiment]) => (
                    <div key={category} className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="flex items-center gap-2">
                          {getCategoryIcon(category)}
                          {getCategoryLabel(category)}
                        </span>
                        <span className={getSentimentColor(sentiment as number)}>
                          {sentiment > 0 ? '+' : ''}{sentiment}%
                        </span>
                      </div>
                      <Progress 
                        value={Math.abs(sentiment as number)} 
                        className="h-2"
                      />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="news" className="space-y-6">
          {/* Search and Filters */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Search className="h-5 w-5" />
                البحث والفلاتر
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="flex-1">
                  <Input
                    placeholder="البحث في الأخبار..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full"
                  />
                </div>
                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger className="w-full sm:w-48">
                    <SelectValue placeholder="اختر القطاع" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">جميع القطاعات</SelectItem>
                    <SelectItem value="monetary-policy">السياسة النقدية</SelectItem>
                    <SelectItem value="economic-data">البيانات الاقتصادية</SelectItem>
                    <SelectItem value="geopolitical">الأحداث الجيوسياسية</SelectItem>
                    <SelectItem value="market-news">أخبار السوق</SelectItem>
                    <SelectItem value="crypto">العملات الرقمية</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={selectedAsset} onValueChange={setSelectedAsset}>
                  <SelectTrigger className="w-full sm:w-32">
                    <SelectValue placeholder="الأصل" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">جميع الأصول</SelectItem>
                    <SelectItem value="EUR/USD">EUR/USD</SelectItem>
                    <SelectItem value="GBP/USD">GBP/USD</SelectItem>
                    <SelectItem value="USD/JPY">USD/JPY</SelectItem>
                    <SelectItem value="XAU/USD">XAU/USD</SelectItem>
                    <SelectItem value="BTC/USD">BTC/USD</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* News List */}
          <div className="space-y-4">
            {filteredNews.map((article, index) => (
              <motion.div
                key={article.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="hover:shadow-md transition-shadow">
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <CardTitle className="text-lg mb-2">{article.title}</CardTitle>
                        <div className="flex items-center gap-2 mb-2">
                          <Badge className="text-xs">
                            {getCategoryLabel(article.category)}
                          </Badge>
                          <Badge variant="outline" className={getSentimentColor(article.sentiment)}>
                            {article.sentiment > 0 ? '+' : ''}{article.sentiment}%
                          </Badge>
                          <Badge variant="secondary">
                            {article.impactLevel === 'high' ? 'تأثير عالي' :
                             article.impactLevel === 'medium' ? 'تأثير متوسط' : 'تأثير منخفض'}
                          </Badge>
                        </div>
                      </div>
                      <div className="text-right text-sm text-gray-500">
                        <div className="flex items-center gap-1 mb-1">
                          <Clock className="h-4 w-4" />
                          {new Date(article.publishedAt).toLocaleDateString('ar')}
                        </div>
                        <div className="text-xs">{article.source}</div>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">
                      {article.content.substring(0, 200)}...
                    </p>
                    <div className="flex items-center justify-between">
                      <div className="flex flex-wrap gap-1">
                        {article.affectedAssets.slice(0, 3).map((asset) => (
                          <Badge key={asset} variant="outline" className="text-xs">
                            {asset}
                          </Badge>
                        ))}
                        {article.affectedAssets.length > 3 && (
                          <Badge variant="outline" className="text-xs">
                            +{article.affectedAssets.length - 3}
                          </Badge>
                        )}
                      </div>
                      <Button variant="ghost" size="sm" className="text-xs">
                        <ExternalLink className="h-3 w-3 mr-1" />
                        اقرأ المزيد
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="implications" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <DollarSign className="h-5 w-5 text-green-500" />
                التوصيات التداولية
              </CardTitle>
              <CardDescription>
                توصيات مستندة إلى التحليل الشامل للأخبار
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {newsAnalysis?.trading_implications?.map((implication, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="flex items-center gap-3 p-4 rounded-lg bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800"
                  >
                    <Target className="h-5 w-5 text-green-600" />
                    <span className="text-sm">{implication}</span>
                  </motion.div>
                )) || []}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default AdvancedNewsDashboard;
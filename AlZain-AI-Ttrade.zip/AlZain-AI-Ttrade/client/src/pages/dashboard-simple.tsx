import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Activity, Users, TrendingUp, BarChart3 } from 'lucide-react';
import { MarketStatusDashboard } from '@/components/market-status-dashboard';

export default function Dashboard() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50/30 to-purple-50/30 dark:from-slate-900 dark:via-slate-800 dark:to-indigo-900/30">
      <div className="container mx-auto p-6 space-y-8">
        {/* Header */}
        <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-blue-600 via-purple-600 to-cyan-600 p-8 text-white shadow-2xl">
          <div className="absolute inset-0 opacity-20">
            <div className="absolute top-0 right-0 w-32 h-32 bg-white rounded-full blur-3xl"></div>
            <div className="absolute bottom-0 left-0 w-24 h-24 bg-white rounded-full blur-2xl"></div>
          </div>
          
          <div className="relative">
            <h1 className="text-4xl font-bold tracking-tight mb-2">منصة التداول الذكية</h1>
            <p className="text-blue-100 text-lg">
              تحليل متقدم بالذكاء الاصطناعي وتوصيات تداول فورية
            </p>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid gap-6 md:grid-cols-4">
          <Card className="border-0 shadow-lg bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-900/20 dark:to-blue-800/20">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-xl bg-blue-500 text-white">
                  <Activity className="h-6 w-6" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">إجمالي التوصيات</p>
                  <p className="text-2xl font-bold text-blue-600">247</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg bg-gradient-to-br from-green-50 to-green-100 dark:from-green-900/20 dark:to-green-800/20">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-xl bg-green-500 text-white">
                  <TrendingUp className="h-6 w-6" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">معدل النجاح</p>
                  <p className="text-2xl font-bold text-green-600">78.5%</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg bg-gradient-to-br from-purple-50 to-purple-100 dark:from-purple-900/20 dark:to-purple-800/20">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-xl bg-purple-500 text-white">
                  <Users className="h-6 w-6" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">المستخدمين النشطين</p>
                  <p className="text-2xl font-bold text-purple-600">156</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg bg-gradient-to-br from-orange-50 to-orange-100 dark:from-orange-900/20 dark:to-orange-800/20">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-xl bg-orange-500 text-white">
                  <BarChart3 className="h-6 w-6" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">دقة التحليل</p>
                  <p className="text-2xl font-bold text-orange-600">85.2%</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Market Status Dashboard */}
        <div className="grid gap-6 grid-cols-1">
          <MarketStatusDashboard />
        </div>

        {/* Quick Actions */}
        <div className="grid gap-6 md:grid-cols-2">
          <Card className="border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-purple-500 text-white">
                  <BarChart3 className="h-5 w-5" />
                </div>
                آخر التوصيات
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">EUR/USD - BUY</span>
                  <span className="font-medium text-green-600">78% ثقة</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">GBP/USD - SELL</span>
                  <span className="font-medium text-orange-600">65% ثقة</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">XAU/USD - BUY</span>
                  <span className="font-medium text-green-600">85% ثقة</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-purple-500 text-white">
                  <BarChart3 className="h-5 w-5" />
                </div>
                آخر التوصيات
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="p-3 rounded-lg bg-green-50 dark:bg-green-900/20">
                  <div className="flex justify-between items-center">
                    <span className="font-medium">EUR/USD</span>
                    <span className="text-green-600 font-medium">BUY</span>
                  </div>
                  <p className="text-sm text-muted-foreground mt-1">ثقة: 85%</p>
                </div>
                <div className="p-3 rounded-lg bg-red-50 dark:bg-red-900/20">
                  <div className="flex justify-between items-center">
                    <span className="font-medium">GBP/USD</span>
                    <span className="text-red-600 font-medium">SELL</span>
                  </div>
                  <p className="text-sm text-muted-foreground mt-1">ثقة: 78%</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
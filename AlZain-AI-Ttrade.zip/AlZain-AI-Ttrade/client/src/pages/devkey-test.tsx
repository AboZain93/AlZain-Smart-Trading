import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, XCircle, Key, RefreshCw } from 'lucide-react';

interface TestResult {
  endpoint: string;
  status: 'loading' | 'success' | 'error';
  data?: any;
  error?: string;
}

export default function DevKeyTest() {
  const [devKey, setDevKey] = useState('');
  const [tests, setTests] = useState<TestResult[]>([]);
  const [isRunning, setIsRunning] = useState(false);

  useEffect(() => {
    // Get devKey from URL
    const urlParams = new URLSearchParams(window.location.search);
    const keyFromUrl = urlParams.get('devKey') || 'dev-2025-alzain-trade';
    setDevKey(keyFromUrl);
  }, []);

  const endpoints = [
    '/api/developer/stats',
    '/api/developer/products',
    '/api/developer/licenses',
    '/api/developer/users'
  ];

  const runTests = async () => {
    setIsRunning(true);
    const results: TestResult[] = endpoints.map(endpoint => ({
      endpoint,
      status: 'loading'
    }));
    setTests(results);

    for (let i = 0; i < endpoints.length; i++) {
      try {
        const response = await fetch(endpoints[i], {
          headers: {
            'x-dev-key': devKey
          }
        });

        const data = await response.json();

        results[i] = {
          endpoint: endpoints[i],
          status: response.ok ? 'success' : 'error',
          data: response.ok ? data : undefined,
          error: response.ok ? undefined : data.error || 'Unknown error'
        };
      } catch (error) {
        results[i] = {
          endpoint: endpoints[i],
          status: 'error',
          error: error instanceof Error ? error.message : 'Network error'
        };
      }
      setTests([...results]);
    }
    setIsRunning(false);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'loading':
        return <RefreshCw className="w-4 h-4 animate-spin text-blue-500" />;
      case 'success':
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'error':
        return <XCircle className="w-4 h-4 text-red-500" />;
      default:
        return null;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'loading':
        return <Badge variant="secondary">جاري التحميل...</Badge>;
      case 'success':
        return <Badge className="bg-green-500">نجح</Badge>;
      case 'error':
        return <Badge variant="destructive">فشل</Badge>;
      default:
        return null;
    }
  };

  return (
    <div className="container mx-auto p-6 max-w-4xl">
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-4">
          <div className="p-2 bg-purple-500 text-white rounded-lg">
            <Key className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-3xl font-bold">اختبار DevKey</h1>
            <p className="text-gray-600">اختبار الاتصال بـ API المطور</p>
          </div>
        </div>
      </div>

      {/* DevKey Info */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>معلومات DevKey</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div>
              <label className="text-sm font-medium">DevKey الحالي:</label>
              <div className="mt-1">
                <code className="bg-gray-100 px-3 py-2 rounded block text-sm">
                  {devKey}
                </code>
              </div>
            </div>
            <div>
              <label className="text-sm font-medium">الرابط الصحيح:</label>
              <div className="mt-1">
                <code className="bg-blue-100 px-3 py-2 rounded block text-sm">
                  /developer-admin?devKey={devKey}
                </code>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Test Button */}
      <div className="mb-6">
        <Button 
          onClick={runTests} 
          disabled={isRunning || !devKey}
          className="w-full bg-purple-500 hover:bg-purple-600"
        >
          {isRunning ? (
            <>
              <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
              جاري الاختبار...
            </>
          ) : (
            <>
              <Key className="w-4 h-4 mr-2" />
              اختبار جميع نقاط النهاية
            </>
          )}
        </Button>
      </div>

      {/* Test Results */}
      {tests.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>نتائج الاختبار</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {tests.map((test, index) => (
                <div key={index} className="border rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      {getStatusIcon(test.status)}
                      <code className="text-sm">{test.endpoint}</code>
                    </div>
                    {getStatusBadge(test.status)}
                  </div>
                  
                  {test.error && (
                    <div className="mt-2 p-2 bg-red-50 border border-red-200 rounded text-sm text-red-700">
                      خطأ: {test.error}
                    </div>
                  )}
                  
                  {test.data && (
                    <div className="mt-2 p-2 bg-green-50 border border-green-200 rounded">
                      <div className="text-sm text-green-700 mb-1">البيانات المستلمة:</div>
                      <pre className="text-xs text-green-600 overflow-auto">
                        {JSON.stringify(test.data, null, 2)}
                      </pre>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Instructions */}
      <Card className="mt-6">
        <CardHeader>
          <CardTitle>تعليمات الاستخدام</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3 text-sm">
            <div className="p-3 bg-blue-50 border border-blue-200 rounded">
              <h4 className="font-semibold text-blue-800 mb-1">للوصول المحلي:</h4>
              <code className="text-blue-700">http://localhost:5000/developer-admin?devKey=dev-2025-alzain-trade</code>
            </div>
            <div className="p-3 bg-green-50 border border-green-200 rounded">
              <h4 className="font-semibold text-green-800 mb-1">للوصول بعد النشر:</h4>
              <code className="text-green-700">https://your-domain.com/developer-admin?devKey=dev-2025-alzain-trade</code>
            </div>
            <div className="p-3 bg-yellow-50 border border-yellow-200 rounded">
              <h4 className="font-semibold text-yellow-800 mb-1">ملاحظة مهمة:</h4>
              <p className="text-yellow-700">تأكد من أن DevKey صحيح وأن الخادم يعمل بشكل صحيح</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
# Trading Bot Dashboard

## Overview

This is a full-stack trading bot dashboard application built with React, Express, and PostgreSQL. The system provides real-time market data analysis, generates trading recommendations using technical indicators, and can send notifications via Telegram. The application features a bilingual interface (English/Arabic) with both light and dark themes.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript
- **Styling**: Tailwind CSS with shadcn/ui components
- **State Management**: React Query for server state, React Context for UI state
- **Routing**: Wouter for lightweight client-side routing
- **Build Tool**: Vite for development and production builds

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Database**: PostgreSQL with Drizzle ORM
- **API**: RESTful API with JSON responses
- **Development**: Hot module replacement via Vite middleware

### Database Architecture
- **ORM**: Drizzle ORM with TypeScript-first schema definition
- **Database**: PostgreSQL (configured for Neon Database)
- **Migrations**: Automated schema management through Drizzle Kit

## Key Components

### Market Data System
- Real-time market data fetching from TwelveData API
- Support for multiple asset types (forex, crypto, stocks, commodities)
- Automatic data refresh and caching mechanisms
- Live price updates with percentage changes

### Technical Analysis Engine
- RSI (Relative Strength Index) calculation
- MACD (Moving Average Convergence Divergence) indicators
- Moving averages (20-day, 50-day)
- Volume analysis and trend detection
- Custom technical analysis service with configurable parameters

### Trading Recommendation System
- AI-powered recommendation generation
- Confidence scoring (0-100%)
- Risk level assessment (low, medium, high)
- Direction signals (BUY/SELL)
- Result tracking and performance metrics

### Telegram Integration
- Automated trading recommendation notifications
- Rich message formatting with emojis and HTML
- Subscriber management and engagement tracking
- Test message functionality for validation

### User Interface
- Responsive dashboard with real-time updates
- Multilingual support (English/Arabic) with RTL layout
- Dark/light theme switching
- Interactive charts and technical indicators
- Real-time market status cards

## Data Flow

1. **Market Data Collection**: TwelveData API fetches real-time market prices
2. **Technical Analysis**: Raw price data processed through technical indicators
3. **Recommendation Generation**: AI analysis combines technical indicators with market conditions
4. **Notification Dispatch**: Trading recommendations sent via Telegram
5. **Dashboard Updates**: Real-time UI updates through React Query polling
6. **Result Tracking**: Performance metrics stored and analyzed

## External Dependencies

### APIs and Services
- **TwelveData API**: Real-time market data provider
- **Telegram Bot API**: Notification delivery system
- **Neon Database**: PostgreSQL hosting service

### Key NPM Packages
- **@tanstack/react-query**: Server state management
- **drizzle-orm**: Type-safe database ORM
- **@radix-ui/***: Accessible UI component primitives
- **axios**: HTTP client for API requests
- **wouter**: Lightweight routing library

## Deployment Strategy

### Development Environment
- Vite dev server with hot module replacement
- Express middleware integration for API routes
- Automatic database migrations via Drizzle Kit
- Environment-specific configuration loading

### Production Build
- Vite production build with optimized bundles
- Express server serving static assets
- Database connection pooling with connection strings
- Error handling with proper HTTP status codes

### Environment Configuration
- Database URL configuration for PostgreSQL
- API keys for TwelveData and Telegram services
- Configurable refresh intervals and polling rates
- Theme and language persistence in localStorage

## User Preferences

Preferred communication style: Simple, everyday language.

## Changelog

## Recent Key Updates
- July 08, 2025. **LICENSING SYSTEM**: Built comprehensive commercial licensing system with user authentication, product management, and trial capabilities
- July 08, 2025. **RENDER DEPLOYMENT FIX**: Resolved Render deployment issues by creating comprehensive deployment configuration including render.yaml, build scripts, environment setup, and complete troubleshooting guides for successful cloud deployment
- July 07, 2025. **ADVANCED AI SYSTEM**: Created ultra-sophisticated signal system with multi-dimensional analysis, risk scoring, and 85%+ quality filtering
- July 07, 2025. **COMPLETE FEATURE SET**: Implemented all major features including Social Trading, Voice Assistant, Advanced Charts, Portfolio Manager, and Economic Intelligence
- July 07, 2025. **SMART RISK MANAGEMENT**: Built comprehensive Smart Risk Management system with position size calculator, portfolio risk analysis, risk level configurations, and VaR calculations
- July 07, 2025. **SOCIAL TRADING**: Completed Social Trading platform with trader leaderboards, signal copying, performance tracking, social feeds, and community features
- July 07, 2025. **NAVIGATION ENHANCEMENT**: Added new navigation routes and sidebar entries for Risk Management and Social Trading features
- July 07, 2025. **STATUS UPDATE**: Changed all planned features to active status in enhancements page - all major features now fully implemented and operational
- July 07, 2025. **PROFESSIONAL AI SYSTEM IMPLEMENTATION**: Successfully integrated comprehensive Professional AI System with advanced machine learning capabilities
- July 07, 2025. **ADVANCED AI ANALYTICS**: Built professional AI monitoring dashboard with real-time performance tracking, learning analytics, and system insights
- July 07, 2025. **INTELLIGENT SIGNAL QUALITY**: Implemented strict quality controls - system rejects signals below 75% confidence and focuses on high-quality predictions only
- July 07, 2025. **COMPREHENSIVE RISK METRICS**: Added advanced risk analysis including probability of success, expected return, max drawdown, Sharpe ratio, and risk-reward ratios
- July 07, 2025. **AUTOMATED LEARNING SYSTEM**: Professional AI system learns continuously from user feedback and automatically adjusts confidence levels based on historical performance
- July 07, 2025. **PROFESSIONAL TELEGRAM INTEGRATION**: Enhanced Telegram messages with professional analysis, detailed risk metrics, and comprehensive trading guidance
- July 07, 2025. **EXPERT-LEVEL SIGNAL GENERATION**: Created professional signal generation system with quality grading (A+ to D), multi-dimensional analysis, and expert-level insights
import { Request, Response, NextFunction } from 'express';
import { licenseManager } from '../services/license-manager';

// Extend Request interface to include license info
declare global {
  namespace Express {
    interface Request {
      license?: any;
      deviceFingerprint?: string;
    }
  }
}

// Middleware to check license validity
export const checkLicense = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const licenseKey = req.headers['x-license-key'] as string;
    const userAgent = req.get('User-Agent') || '';
    const ip = req.ip || req.connection.remoteAddress || '';
    
    if (!licenseKey) {
      return res.status(401).json({ 
        error: 'License key required',
        arabicError: 'مطلوب رقم الرخصة',
        code: 'LICENSE_REQUIRED' 
      });
    }

    const deviceFingerprint = licenseManager.generateDeviceFingerprint(userAgent, ip);
    
    // Check for piracy
    const piracyCheck = await licenseManager.checkForPiracy(deviceFingerprint);
    if (piracyCheck.suspiciousActivity) {
      return res.status(403).json({
        error: 'Suspicious activity detected',
        arabicError: 'تم اكتشاف نشاط مشبوه',
        reason: piracyCheck.reason,
        code: 'PIRACY_DETECTED'
      });
    }

    // Validate license
    const validation = await licenseManager.validateLicense(licenseKey, deviceFingerprint);
    
    if (!validation.isValid) {
      return res.status(403).json({
        error: 'Invalid license',
        arabicError: validation.reason,
        code: 'LICENSE_INVALID'
      });
    }

    req.license = validation.license;
    req.deviceFingerprint = deviceFingerprint;
    
    next();
  } catch (error) {
    console.error('License validation error:', error);
    return res.status(500).json({
      error: 'License validation failed',
      arabicError: 'فشل في التحقق من الرخصة',
      code: 'LICENSE_ERROR'
    });
  }
};

// Middleware to check trade limits
export const checkTradeLimit = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const license = req.license;
    
    if (!license) {
      return res.status(401).json({
        error: 'License not found',
        arabicError: 'الرخصة غير موجودة',
        code: 'LICENSE_NOT_FOUND'
      });
    }

    if (license.tradesUsed >= license.maxTrades) {
      return res.status(403).json({
        error: 'Trade limit exceeded',
        arabicError: `تم استهلاك العدد المسموح من الصفقات (${license.maxTrades})`,
        code: 'TRADE_LIMIT_EXCEEDED',
        tradesUsed: license.tradesUsed,
        maxTrades: license.maxTrades
      });
    }

    next();
  } catch (error) {
    console.error('Trade limit check error:', error);
    return res.status(500).json({
      error: 'Trade limit check failed',
      arabicError: 'فشل في فحص حد الصفقات',
      code: 'TRADE_LIMIT_ERROR'
    });
  }
};

// Middleware to record trade usage
export const recordTradeUsage = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const license = req.license;
    
    if (!license) {
      return res.status(401).json({
        error: 'License not found',
        arabicError: 'الرخصة غير موجودة',
        code: 'LICENSE_NOT_FOUND'
      });
    }

    // Add to request body for route handler
    req.body.licenseId = license.id;
    req.body.userId = license.userId;
    
    next();
  } catch (error) {
    console.error('Trade recording error:', error);
    return res.status(500).json({
      error: 'Trade recording failed',
      arabicError: 'فشل في تسجيل الصفقة',
      code: 'TRADE_RECORD_ERROR'
    });
  }
};

// Middleware for admin routes
export const requireAdmin = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const adminKey = req.headers['x-admin-key'] as string;
    const expectedAdminKey = process.env.ADMIN_KEY || 'default-admin-key';
    
    if (!adminKey || adminKey !== expectedAdminKey) {
      return res.status(403).json({
        error: 'Admin access required',
        arabicError: 'مطلوب صلاحية إدارية',
        code: 'ADMIN_REQUIRED'
      });
    }
    
    next();
  } catch (error) {
    console.error('Admin check error:', error);
    return res.status(500).json({
      error: 'Admin check failed',
      arabicError: 'فشل في التحقق من الصلاحيات',
      code: 'ADMIN_ERROR'
    });
  }
};

// Middleware for rate limiting
export const rateLimiter = (requestsPerMinute: number) => {
  const requests = new Map<string, number[]>();
  
  return (req: Request, res: Response, next: NextFunction) => {
    const ip = req.ip || req.connection.remoteAddress || '';
    const now = Date.now();
    const windowMs = 60 * 1000; // 1 minute
    
    if (!requests.has(ip)) {
      requests.set(ip, []);
    }
    
    const userRequests = requests.get(ip)!;
    
    // Remove old requests
    const validRequests = userRequests.filter(time => now - time < windowMs);
    
    if (validRequests.length >= requestsPerMinute) {
      return res.status(429).json({
        error: 'Too many requests',
        arabicError: 'كثرة الطلبات - انتظر قليلاً',
        code: 'RATE_LIMIT_EXCEEDED',
        retryAfter: Math.ceil((validRequests[0] + windowMs - now) / 1000)
      });
    }
    
    validRequests.push(now);
    requests.set(ip, validRequests);
    
    next();
  };
};

// Middleware to add license info to response
export const addLicenseInfo = (req: Request, res: Response, next: NextFunction) => {
  const originalSend = res.send;
  
  res.send = function(data: any) {
    if (req.license && typeof data === 'object' && data !== null) {
      try {
        const parsedData = typeof data === 'string' ? JSON.parse(data) : data;
        parsedData.licenseInfo = {
          tradesUsed: req.license.tradesUsed,
          maxTrades: req.license.maxTrades,
          tradesRemaining: req.license.maxTrades - req.license.tradesUsed,
          isTrialActive: req.license.trialEndsAt && new Date() < req.license.trialEndsAt
        };
        return originalSend.call(this, JSON.stringify(parsedData));
      } catch (error) {
        // If parsing fails, send original data
        return originalSend.call(this, data);
      }
    }
    return originalSend.call(this, data);
  };
  
  next();
};
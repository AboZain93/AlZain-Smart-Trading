import { storage } from '../storage';
import { TelegramBotService } from './telegram-bot';
import { technicalAnalysisService } from './technical-analysis';
import { platformManager } from './platform-manager';
import { advancedSignalAnalyzer } from './advanced-signal-analyzer';
import { AIMarketIntelligenceService } from './ai-market-intelligence';
import { ultraAdvancedAI } from './ultra-advanced-ai-system';
import { enhancedSignalGenerator } from './enhanced-signal-generator';
import { enhancedDataIntegration } from './enhanced-data-integration-service';

interface TradingSettings {
  minConfidence: number;
  maxRiskLevel: 'low' | 'medium' | 'high';
  enabledAssets: string[];
  tradingHours: {
    start: string;
    end: string;
    enabled: boolean;
  };
  stopLossEnabled: boolean;
  takeProfitEnabled: boolean;
}

export class AutoSignalsService {
  private intervalId: NodeJS.Timeout | null = null;
  private telegramBot: TelegramBotService;
  private aiIntelligence: AIMarketIntelligenceService;
  private isEnabled = false;
  private signalInterval = 5; // minutes
  private maxSignalsPerDay = 20;
  private tradingSettings: TradingSettings = {
    minConfidence: 75,
    maxRiskLevel: 'medium',
    enabledAssets: [],
    tradingHours: { start: '09:00', end: '17:00', enabled: true },
    stopLossEnabled: true,
    takeProfitEnabled: true
  };

  constructor() {
    this.telegramBot = new TelegramBotService();
    this.aiIntelligence = new AIMarketIntelligenceService();
  }

  get isActive(): boolean {
    return this.isEnabled;
  }

  async updateSettings(settings: Partial<TradingSettings>): Promise<void> {
    console.log('Updating trading settings:', settings);
    
    // Update current settings
    this.tradingSettings = {
      ...this.tradingSettings,
      ...settings
    };

    // Log the update
    console.log('Trading settings updated:', this.tradingSettings);
  }

  async start(intervalMinutes: number = 5, maxPerDay: number = 20, settings?: Partial<TradingSettings>): Promise<void> {
    console.log(`Starting auto signals service: ${intervalMinutes} minute intervals, max ${maxPerDay} per day`);
    
    this.signalInterval = intervalMinutes;
    this.maxSignalsPerDay = maxPerDay;
    
    // Update trading settings if provided
    if (settings) {
      this.tradingSettings = { ...this.tradingSettings, ...settings };
      console.log('Trading settings updated:', this.tradingSettings);
    }

    // Clear existing interval if any
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }

    // Set enabled state and start interval
    this.isEnabled = true;
    this.intervalId = setInterval(async () => {
      await this.checkAndGenerateSignal();
    }, intervalMinutes * 60 * 1000);

    console.log('Auto signals service started successfully');
  }

  stop(): void {
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
    this.isEnabled = false;
    console.log('Auto signals service stopped');
  }

  isRunning(): boolean {
    return this.isEnabled && this.intervalId !== null;
  }

  private async checkAndGenerateSignal(): Promise<void> {
    try {
      console.log('Auto signals check: Evaluating conditions...');

      // Check if we're within daily limit
      const telegramStats = await storage.getTelegramStats();
      const sentToday = telegramStats?.sentToday || 0;

      if (sentToday >= this.maxSignalsPerDay) {
        console.log(`Auto signals: Daily limit reached (${sentToday}/${this.maxSignalsPerDay})`);
        return;
      }

      // Check if enough time has passed since last signal
      const recentRecommendations = await storage.getRecentTradingRecommendations(1);
      if (recentRecommendations.length > 0) {
        const lastSignal = recentRecommendations[0];
        const lastSignalTime = new Date(lastSignal.createdAt || new Date());
        const currentTime = new Date();
        const timeDiffMinutes = (currentTime.getTime() - lastSignalTime.getTime()) / (1000 * 60);

        if (timeDiffMinutes < this.signalInterval) {
          console.log(`Auto signals: Too early for next signal (${timeDiffMinutes.toFixed(1)}/${this.signalInterval} minutes)`);
          return;
        }
      }

      // Generate new signal
      console.log('Auto signals: Generating new signal...');
      await this.generateAndSendSignal();

    } catch (error) {
      console.error('Auto signals error:', error);
    }
  }

  private async generateAndSendSignal(): Promise<void> {
    try {
      // Check trading hours if enabled
      if (this.tradingSettings.tradingHours.enabled) {
        const currentHour = new Date().getHours();
        const currentMinute = new Date().getMinutes();
        const currentTime = currentHour * 60 + currentMinute;
        
        const [startHour, startMinute] = this.tradingSettings.tradingHours.start.split(':').map(Number);
        const [endHour, endMinute] = this.tradingSettings.tradingHours.end.split(':').map(Number);
        const startTime = startHour * 60 + startMinute;
        const endTime = endHour * 60 + endMinute;
        
        if (currentTime < startTime || currentTime > endTime) {
          console.log(`Auto signals: Outside trading hours (${this.tradingSettings.tradingHours.start} - ${this.tradingSettings.tradingHours.end})`);
          return;
        }
      }

      // Get active platform
      const activePlatform = platformManager.getActivePlatform();
      if (!activePlatform) {
        console.log('Auto signals: No active trading platform selected');
        return;
      }

      // Get available assets supported by active platform
      const marketAssets = await storage.getAllMarketAssets();
      let compatibleAssets = marketAssets.filter(asset => 
        activePlatform.supportedAssets.includes(asset.symbol)
      );

      // Filter by enabled assets if specified
      if (this.tradingSettings.enabledAssets.length > 0) {
        compatibleAssets = compatibleAssets.filter(asset => 
          this.tradingSettings.enabledAssets.includes(asset.symbol)
        );
      }

      if (compatibleAssets.length === 0) {
        console.log(`Auto signals: No compatible assets for platform ${activePlatform.displayName}`);
        return;
      }

      // Try to generate ULTRA-advanced AI signal for each compatible asset
      let enhancedRecommendation = null;
      
      for (const asset of compatibleAssets) {
        try {
          // أولاً: الحصول على بيانات السوق والمؤشرات الفنية
          const marketData = await storage.getMarketDataBySymbol(asset.symbol);
          const technicalIndicators = await storage.getTechnicalIndicatorsBySymbol(asset.symbol);
          
          if (!marketData) {
            console.log(`Auto signals: No market data for ${asset.symbol}`);
            continue;
          }
          
          // ثانياً: التحليل المتطور باستخدام البيانات الخارجية الحقيقية
          const comprehensiveAnalysis = await enhancedDataIntegration.generateComprehensiveAnalysis(asset.symbol);
          
          if (!comprehensiveAnalysis) {
            console.log(`Auto signals: No comprehensive analysis available for ${asset.symbol}`);
            continue;
          }
          
          // ثالثاً: فلترة الإشارات بناءً على الجودة والثقة
          if (comprehensiveAnalysis.confidence < this.tradingSettings.minConfidence) {
            console.log(`Auto signals: ${asset.symbol} confidence ${comprehensiveAnalysis.confidence}% below threshold ${this.tradingSettings.minConfidence}%`);
            continue;
          }

          // رابعاً: تحقق من مستوى المخاطرة
          const riskLevelOrder = { 'low': 1, 'medium': 2, 'high': 3 };
          const maxRiskOrder = riskLevelOrder[this.tradingSettings.maxRiskLevel];
          const signalRiskOrder = riskLevelOrder[comprehensiveAnalysis.riskLevel.toLowerCase() as keyof typeof riskLevelOrder];
          
          if (signalRiskOrder > maxRiskOrder) {
            console.log(`Auto signals: ${asset.symbol} risk level ${comprehensiveAnalysis.riskLevel} exceeds max ${this.tradingSettings.maxRiskLevel}`);
            continue;
          }

          // خامساً: النظام المحترف للذكاء الاصطناعي
          const { professionalAI } = await import('./professional-ai-system');
          const professionalSignal = await professionalAI.generateEnhancedSignal(asset.symbol, {
            ...marketData,
            ...technicalIndicators,
            price: marketData.price,
            priceChange: marketData.priceChange,
            priceChangePercent: marketData.priceChangePercent,
            volume: marketData.volume || 1000000,
            rsi: technicalIndicators?.rsi || 50,
            macd: technicalIndicators?.macd || 0,
            macdSignal: technicalIndicators?.macdSignal || 0,
            sma20: technicalIndicators?.sma20 || marketData.price,
            sma50: technicalIndicators?.sma50 || marketData.price,
            bbUpper: technicalIndicators?.bbUpper || marketData.price * 1.02,
            bbLower: technicalIndicators?.bbLower || marketData.price * 0.98
          });
          
          // إذا وُجد إشارة احترافية عالية الجودة
          if (professionalSignal) {
            console.log(`🎯 Professional AI found high-quality signal for ${asset.symbol}: ${professionalSignal.qualityGrade}`);
            
            enhancedRecommendation = {
              assetSymbol: asset.symbol,
              direction: professionalSignal.direction,
              confidence: professionalSignal.confidence,
              riskLevel: professionalSignal.riskLevel,
              platform: activePlatform.displayName,
              technicalAnalysis: `Professional AI Analysis (Grade: ${professionalSignal.qualityGrade})`,
              qualityScore: professionalSignal.analysis.volatilityAdjustedScore,
              probabilityOfSuccess: professionalSignal.analysis.probabilityOfSuccess,
              expectedReturn: professionalSignal.analysis.expectedReturn,
              maxDrawdown: professionalSignal.analysis.maxDrawdown,
              sharpeRatio: professionalSignal.analysis.sharpeRatio,
              winRate: professionalSignal.analysis.winRate,
              riskRewardRatio: professionalSignal.analysis.riskRewardRatio,
              stopLoss: professionalSignal.stopLoss,
              takeProfit: professionalSignal.takeProfit,
              expectedDuration: professionalSignal.expectedDuration
            };
            break; // استخدم أول إشارة عالية الجودة
          }
          
          // ثالثاً: توليد الإشارة باستخدام النظام القديم للحصول على التوصية الأساسية
          const aiAnalysis = await this.aiIntelligence.generateAdvancedAISignal(asset.symbol);
          
          if (!aiAnalysis || aiAnalysis.signal === 'HOLD') {
            console.log(`Signal rejected: ${asset.symbol} - HOLD signal or failed analysis`);
            continue;
          }
          
          // رابعاً: تقييم جودة الإشارة بالنظام المتطور
          const signalQuality = await ultraAdvancedAI.evaluateSignalQuality(
            ultraAnalysis,
            aiAnalysis.confidence,
            asset.symbol
          );
          
          // خامساً: قرار قبول الإشارة بناءً على المعايير المتطورة
          const acceptanceDecision = await ultraAdvancedAI.shouldAcceptSignal(
            ultraAnalysis,
            signalQuality,
            aiAnalysis.confidence
          );
          
          if (!acceptanceDecision.accept) {
            console.log(`Signal rejected: ${acceptanceDecision.reason}`);
            continue;
          }

          // Check confidence threshold from settings
          if (aiAnalysis.confidence < this.tradingSettings.minConfidence) {
            console.log(`Signal rejected: Low confidence (${aiAnalysis.confidence}%) - threshold: ${this.tradingSettings.minConfidence}%`);
            continue;
          }

          // Check risk level from settings
          const riskLevels = { 'low': 1, 'medium': 2, 'high': 3 };
          const signalRisk = riskLevels[aiAnalysis.riskLevel] || 2;
          const maxRisk = riskLevels[this.tradingSettings.maxRiskLevel] || 2;
          
          if (signalRisk > maxRisk) {
            console.log(`Signal rejected: Risk level (${aiAnalysis.riskLevel}) exceeds maximum (${this.tradingSettings.maxRiskLevel})`);
            continue;
          }
          
          // سادساً: الإشارة مقبولة - إنشاء التوصية المحسنة
          if (aiAnalysis && signalQuality.overallScore >= 70) {
            enhancedRecommendation = {
              symbol: asset.symbol,
              signal: aiAnalysis.signal,
              confidence: aiAnalysis.confidence,
              riskLevel: aiAnalysis.riskLevel,
              duration: this.getDurationFromConfidence(aiAnalysis.confidence),
              entryPrice: aiAnalysis.technicalLevels.entryPrice,
              targets: {
                target1: this.tradingSettings.takeProfitEnabled ? aiAnalysis.technicalLevels.takeProfit1 : null,
                target2: this.tradingSettings.takeProfitEnabled ? aiAnalysis.technicalLevels.takeProfit2 : null,
                stopLoss: this.tradingSettings.stopLossEnabled ? aiAnalysis.technicalLevels.stopLoss : null
              },
              analysis: {
                consensus: aiAnalysis.aiAnalysis.modelConsensus,
                timeframeBreakdown: aiAnalysis.aiAnalysis.optimalTimeframes,
                marketContext: {
                  volatility: this.calculateVolatilityScore(aiAnalysis),
                  volume: 0,
                  marketSentiment: aiAnalysis.aiAnalysis.marketRegime.toUpperCase() as any,
                  economicEvents: false,
                  newsImpact: 'NEUTRAL' as any
                }
              },
              reasoning: aiAnalysis.reasoning.join(', ')
            };
            
            // طباعة تفاصيل النظام المحسن
            console.log(`🚀 ULTRA-AI Signal Generated: ${asset.symbol} (${aiAnalysis.signal}, ${aiAnalysis.confidence}%, ${aiAnalysis.strength})`);
            console.log(`🔬 Quality Analysis: Grade ${signalQuality.qualityGrade}, Score ${signalQuality.overallScore.toFixed(1)}, Strength ${signalQuality.recommendationStrength}`);
            console.log(`📊 Market Regime: ${ultraAnalysis.marketRegime}, Momentum: ${(ultraAnalysis.momentumStrength * 100).toFixed(1)}%`);
            console.log(`🎯 Win Probability: ${ultraAnalysis.probabilityDistribution.winProbability.toFixed(1)}%, Risk/Reward: ${ultraAnalysis.riskMetrics.riskRewardRatio.toFixed(2)}`);
            console.log(`💡 Sentiment: ${ultraAnalysis.marketSentiment}, Timeframe Synergy: ${(ultraAnalysis.timeframeSynergy * 100).toFixed(1)}%`);
            break;
          }
        } catch (error) {
          console.log(`Auto signals: AI analysis failed for ${asset.symbol}, trying next asset...`);
        }
        
        // العودة للنظام المعزز إذا فشل الذكاء الصناعي
        const recommendation = await advancedSignalAnalyzer.getEnhancedRecommendation(asset.symbol);
        
        if (recommendation) {
          enhancedRecommendation = recommendation;
          console.log(`Auto signals: Enhanced signal generated for ${asset.symbol} (${recommendation.signal}, ${recommendation.confidence}%)`);
          break;
        }
      }

      // If no enhanced signal found, fall back to original method
      if (!enhancedRecommendation) {
        console.log('Auto signals: No high-quality enhanced signals found, using fallback method');
        
        const randomAsset = compatibleAssets[Math.floor(Math.random() * compatibleAssets.length)];
        const symbol = randomAsset.symbol;
        
        const marketData = await storage.getMarketDataBySymbol(symbol);
        if (!marketData) {
          console.log(`Auto signals: No market data for ${symbol}`);
          return;
        }

        const generateSimulatedPrices = (currentPrice: number, count: number = 50) => {
          const prices = [];
          let price = currentPrice;
          for (let i = 0; i < count; i++) {
            price += (Math.random() - 0.5) * price * 0.02;
            prices.push(price);
          }
          return prices;
        };

        const prices = generateSimulatedPrices(marketData.price);
        const rsi = technicalAnalysisService.calculateRSI(prices);
        const sma20 = technicalAnalysisService.calculateSMA(prices, 20);
        const sma50 = technicalAnalysisService.calculateSMA(prices, 50);
        const macd = technicalAnalysisService.calculateMACD(prices);
        const volatility = Math.abs(marketData.changePercent || 0);
        
        const baseSignal = this.generateSignal(rsi, sma20, sma50, macd, marketData.price, volatility);

        // Apply Enhanced ML-based confidence calculation
        const { enhancedMLLearning } = await import('./enhanced-ml-learning.js');
        const mlAnalysis = await enhancedMLLearning.calculateAdvancedConfidence(
          symbol,
          baseSignal.signal,
          baseSignal.confidence,
          { rsi, macd, sma20, sma50 },
          {
            technicalIndicators: {
              rsi,
              macd: macd.macd,
              bollinger_position: 0.5,
              stochastic: 50,
              adx: 25,
              cci: 0,
              williams_r: -50,
              volume_strength: 70
            },
            marketContext: {
              session: this.getCurrentSession(),
              volatility,
              trend_strength: 65,
              liquidity_score: 75,
              news_sentiment: 60
            },
            timeframeSynergy: {
              tf_1m: 65,
              tf_5m: 70,
              tf_15m: 75,
              tf_1h: 80,
              tf_4h: 75,
              alignment_score: 0.75
            },
            riskFactors: {
              economic_events: false,
              market_hours: this.getMarketHours(),
              weekend_proximity: this.getWeekendProximity(),
              volatility_spike: volatility > 3
            }
          }
        );

        const signal = {
          ...baseSignal,
          confidence: mlAnalysis.adjustedConfidence,
          reasons: [...baseSignal.reasons, ...mlAnalysis.reasoning.slice(0, 2)]
        };

        if (signal.confidence < 70) {
          console.log(`Auto signals: ML-adjusted signal confidence too low (${signal.confidence}% < 70%)`);
          console.log(`Auto signals: ML reasoning: ${mlAnalysis.reasoning.join(', ')}`);
          return;
        }

        console.log(`🧠 ML Enhancement: Base ${baseSignal.confidence}% → Adjusted ${signal.confidence}% (Quality: ${(mlAnalysis.qualityScore * 100).toFixed(1)}%)`);
        console.log(`📊 ML Insights: ${mlAnalysis.reasoning.slice(0, 3).join(' | ')}`);

        const trend = this.calculateTrend(prices, marketData.price);
        const riskLevel = this.assessRiskLevel(volatility, rsi, signal.confidence);

        // Create fallback recommendation
        enhancedRecommendation = {
          symbol,
          signal: signal.signal as 'BUY' | 'SELL',
          confidence: signal.confidence,
          riskLevel: riskLevel as 'LOW' | 'MEDIUM' | 'HIGH',
          duration: '5 دقائق',
          entryPrice: marketData.price,
          targets: {
            target1: marketData.price * (signal.signal === 'BUY' ? 1.001 : 0.999),
            target2: marketData.price * (signal.signal === 'BUY' ? 1.002 : 0.998),
            stopLoss: marketData.price * (signal.signal === 'BUY' ? 0.999 : 1.001)
          },
          analysis: {
            consensus: signal.confidence,
            timeframeBreakdown: [],
            marketContext: {
              volatility,
              volume: marketData.volume || 0,
              marketSentiment: 'NEUTRAL' as const,
              economicEvents: false,
              newsImpact: 'NEUTRAL' as const
            }
          },
          reasoning: signal.reasons.join(', ')
        };
      }

      // Process the enhanced recommendation
      if (enhancedRecommendation) {
        // Generate platform-specific recommendation only if signal is BUY or SELL
        if (enhancedRecommendation.signal === 'NEUTRAL') {
          console.log(`Auto signals: Skipping neutral signal for ${enhancedRecommendation.symbol}`);
          return;
        }

        const platformRecommendation = platformManager.generatePlatformSpecificRecommendation(
          enhancedRecommendation.symbol,
          enhancedRecommendation.signal as 'BUY' | 'SELL',
          enhancedRecommendation.confidence,
          enhancedRecommendation.duration,
          activePlatform.id
        );

        if (!platformRecommendation) {
          console.log(`Auto signals: Failed to generate platform-specific recommendation for ${enhancedRecommendation.symbol}`);
          return;
        }

        const recommendation = await storage.createTradingRecommendation({
          assetSymbol: enhancedRecommendation.symbol,
          direction: enhancedRecommendation.signal,
          confidence: enhancedRecommendation.confidence,
          riskLevel: enhancedRecommendation.riskLevel,
          technicalAnalysis: enhancedRecommendation.reasoning,
          marketStatus: `تحليل متقدم - ${enhancedRecommendation.riskLevel} المخاطرة`,
          entryTime: new Date().toLocaleTimeString('ar-SA'),
          duration: enhancedRecommendation.duration,
          trend: enhancedRecommendation.analysis?.marketContext?.marketSentiment || 'NEUTRAL',
          liquidity: enhancedRecommendation.analysis?.marketContext?.volume ? 'مرتفعة' : 'متوسطة',
          result: 'pending',
          sentToTelegram: false,
        });

        // Send platform-specific message to Telegram
        const platformMessage = platformManager.generateTelegramMessage(platformRecommendation, true);
        const telegramResult = await this.telegramBot.sendCustomMessage(platformMessage);
        
        if (telegramResult) {
          recommendation.sentToTelegram = true;
          
          const stats = await storage.getTelegramStats();
          if (stats) {
            await storage.updateTelegramStats({
              sentToday: (stats.sentToday || 0) + 1,
              lastSent: new Date(),
            });
          }

          console.log(`Auto signals: Successfully generated and sent signal for ${enhancedRecommendation.symbol} (${enhancedRecommendation.signal}, ${enhancedRecommendation.confidence}%)`);
        } else {
          console.log(`Auto signals: Failed to send signal for ${enhancedRecommendation.symbol} to Telegram`);
        }
      }

    } catch (error) {
      console.error('Auto signals generation error:', error);
    }
  }

  getStatus() {
    return {
      isEnabled: this.isEnabled,
      isRunning: this.isRunning(),
      signalInterval: this.signalInterval,
      maxSignalsPerDay: this.maxSignalsPerDay,
      tradingSettings: this.tradingSettings,
      lastCheck: new Date().toISOString()
    };
  }

  private getRandomDuration(): string {
    const durations = ['1 دقيقة', '2 دقيقة', '3 دقائق', '5 دقائق', '10 دقائق'];
    return durations[Math.floor(Math.random() * durations.length)];
  }

  // Helper methods
  private generateSignal(rsi: number, sma20: number, sma50: number, macd: any, currentPrice: number, volatility: number): { signal: string; confidence: number; reasons: string[] } {
    const reasons = [];
    let confidence = 60;
    let signal = 'HOLD';

    // RSI analysis
    if (rsi < 30) {
      signal = 'BUY';
      confidence += 20;
      reasons.push('RSI oversold');
    } else if (rsi > 70) {
      signal = 'SELL';
      confidence += 20;
      reasons.push('RSI overbought');
    }

    // Moving averages
    if (currentPrice > sma20 && sma20 > sma50) {
      if (signal === 'BUY') confidence += 15;
      else if (signal === 'HOLD') {
        signal = 'BUY';
        confidence += 10;
      }
      reasons.push('Bullish trend');
    } else if (currentPrice < sma20 && sma20 < sma50) {
      if (signal === 'SELL') confidence += 15;
      else if (signal === 'HOLD') {
        signal = 'SELL';
        confidence += 10;
      }
      reasons.push('Bearish trend');
    }

    // MACD analysis
    if (macd.macd > macd.signal) {
      if (signal === 'BUY') confidence += 10;
      reasons.push('MACD bullish');
    } else if (macd.macd < macd.signal) {
      if (signal === 'SELL') confidence += 10;
      reasons.push('MACD bearish');
    }

    // Volatility adjustment
    if (volatility > 2) {
      confidence -= 10;
      reasons.push('High volatility');
    }

    return {
      signal: signal === 'HOLD' ? (Math.random() > 0.5 ? 'BUY' : 'SELL') : signal,
      confidence: Math.min(95, Math.max(70, confidence)),
      reasons
    };
  }

  private calculateTrend(prices: number[], currentPrice: number): { trend: string; strength: number } {
    const sma20 = technicalAnalysisService.calculateSMA(prices, 20);
    const sma50 = technicalAnalysisService.calculateSMA(prices, 50);
    
    let trend = 'محايد';
    let strength = 50;

    if (currentPrice > sma20 && sma20 > sma50) {
      trend = 'صاعد';
      strength = Math.min(95, 60 + (currentPrice - sma20) / sma20 * 100);
    } else if (currentPrice < sma20 && sma20 < sma50) {
      trend = 'هابط';
      strength = Math.min(95, 60 + (sma20 - currentPrice) / sma20 * 100);
    }

    return { trend, strength };
  }

  private assessRiskLevel(volatility: number, rsi: number, confidence: number): string {
    if (volatility > 3 || rsi > 80 || rsi < 20 || confidence < 75) {
      return 'مرتفع';
    } else if (volatility > 1.5 || rsi > 70 || rsi < 30 || confidence < 85) {
      return 'متوسط';
    } else {
      return 'منخفض';
    }
  }

  // دوال مساعدة جديدة لنظام الذكاء الصناعي
  private getDurationFromConfidence(confidence: number): string {
    if (confidence >= 90) return '10 دقائق';
    if (confidence >= 85) return '5 دقائق';
    if (confidence >= 80) return '3 دقائق';
    if (confidence >= 75) return '2 دقيقة';
    return '1 دقيقة';
  }

  private calculateVolatilityScore(aiAnalysis: any): number {
    // تحويل تحليل الذكاء الصناعي إلى نقاط تقلبات
    const riskLevel = aiAnalysis.riskLevel;
    const marketRegime = aiAnalysis.aiAnalysis.marketRegime;
    
    let volatilityScore = 50; // أساسي
    
    if (riskLevel === 'HIGH') volatilityScore += 30;
    else if (riskLevel === 'MEDIUM') volatilityScore += 15;
    
    if (marketRegime === 'volatile') volatilityScore += 25;
    else if (marketRegime === 'trending') volatilityScore -= 10;
    
    return Math.max(0, Math.min(100, volatilityScore));
  }

  // Enhanced risk calculation methods
  private calculateWinProbability(confidence: number, riskLevel: string): number {
    let baseProb = confidence * 0.8; // Base from confidence
    
    // Risk level adjustment
    if (riskLevel === 'low') baseProb += 10;
    else if (riskLevel === 'high') baseProb -= 15;
    
    return Math.max(45, Math.min(95, Math.round(baseProb)));
  }

  private calculateExpectedReturn(riskLevel: string, confidence: number): string {
    let baseReturn = 0;
    
    if (riskLevel === 'low') baseReturn = 0.8;
    else if (riskLevel === 'medium') baseReturn = 1.2;
    else baseReturn = 2.1;
    
    // Confidence adjustment
    const multiplier = confidence / 100;
    const expectedReturn = (baseReturn * multiplier).toFixed(1);
    
    return `${expectedReturn}`;
  }

  private getRiskAdvice(riskLevel: string, confidence: number): string {
    if (riskLevel === 'low' && confidence >= 80) {
      return 'مناسب للمبتدئين - تداول آمن نسبياً';
    } else if (riskLevel === 'medium' && confidence >= 75) {
      return 'يتطلب خبرة متوسطة - مراقبة مستمرة';
    } else if (riskLevel === 'high') {
      return 'للمتداولين المتقدمين فقط - مخاطرة عالية';
    } else {
      return 'توخي الحذر الشديد - ثقة منخفضة';
    }
  }

  private getCustomRiskManagement(riskLevel: string, confidence: number): string {
    let advice = '';
    
    if (riskLevel === 'low') {
      advice = `• استثمر 2-3% من رأس المال
• Stop Loss عند 5%
• Take Profit عند 10-15%`;
    } else if (riskLevel === 'medium') {
      advice = `• استثمر 1-2% من رأس المال
• Stop Loss عند 3%
• Take Profit عند 8-12%`;
    } else {
      advice = `• استثمر 0.5-1% من رأس المال
• Stop Loss عند 2%
• Take Profit عند 5-8%`;
    }
    
    if (confidence >= 85) {
      advice += '\n• يمكن زيادة الاستثمار بـ 0.5% إضافية للثقة العالية';
    }
    
    return advice;
  }

  private getExecutionTips(riskLevel: string, confidence: number): string {
    if (confidence >= 85) {
      return `• تنفيذ فوري - إشارة قوية جداً
• مراقبة دقيقة كل 30 ثانية
• استعداد للخروج عند أول إشارة سلبية`;
    } else if (confidence >= 75) {
      return `• انتظار تأكيد إضافي 1-2 دقيقة
• مراقبة كل دقيقة
• تطبيق استراتيجية تدريجية`;
    } else {
      return `• انتظار حذر 2-3 دقائق
• تأكيد من مؤشرات أخرى
• دخول محدود وحذر`;
    }
  }

  // تحديث رسالة التليجرام لتشمل تحليل الذكاء الصناعي
  private generateEnhancedTelegramMessage(recommendation: any, aiAnalysis: any): string {
    const isArabic = true; // يمكن تخصيصها لاحقاً
    
    if (!aiAnalysis) {
      // العودة للرسالة العادية إذا لم يكن هناك تحليل ذكاء صناعي
      return this.generateStandardTelegramMessage(recommendation);
    }

    const signalEmoji = recommendation.signal === 'BUY' ? '🟢' : '🔴';
    const strengthEmoji = this.getStrengthEmoji(aiAnalysis.strength);
    const riskEmoji = this.getRiskEmoji(aiAnalysis.riskLevel);
    
    return `
🤖 <b>توصية ذكاء صناعي متطورة</b> ${signalEmoji}

📊 <b>الأصل:</b> ${recommendation.symbol}
📈 <b>الاتجاه:</b> ${recommendation.signal} ${signalEmoji}
🎯 <b>مستوى الثقة:</b> ${recommendation.confidence}% ${strengthEmoji}
⚖️ <b>المخاطر:</b> ${aiAnalysis.riskLevel} ${riskEmoji}
⏱️ <b>المدة:</b> ${recommendation.duration}

💡 <b>التحليل المتقدم:</b>
🧠 إجماع النماذج: ${aiAnalysis.aiAnalysis.modelConsensus}%
📊 نظام السوق: ${this.translateMarketRegime(aiAnalysis.aiAnalysis.marketRegime)}
🎲 احتمالية النجاح: ${aiAnalysis.aiAnalysis.predictionAccuracy}%
💰 نسبة المخاطر/العائد: ${aiAnalysis.aiAnalysis.riskRewardRatio.toFixed(2)}

📍 <b>المستويات الفنية:</b>
🔸 الدخول: ${aiAnalysis.technicalLevels.entryPrice.toFixed(5)}
🛡️ وقف الخسارة: ${aiAnalysis.technicalLevels.stopLoss.toFixed(5)}
🎯 الهدف الأول: ${aiAnalysis.technicalLevels.takeProfit1.toFixed(5)}
🎯 الهدف الثاني: ${aiAnalysis.technicalLevels.takeProfit2.toFixed(5)}

🔍 <b>الأسباب الرئيسية:</b>
${aiAnalysis.reasoning.slice(0, 3).map(reason => `• ${reason}`).join('\n')}

📱 <b>استراتيجية التداول:</b>
🔹 الدخول: ${aiAnalysis.aiAnalysis.entryStrategy}
🔹 الخروج: ${aiAnalysis.aiAnalysis.exitStrategy}
📏 حجم المركز المقترح: ${(aiAnalysis.aiAnalysis.positionSizing * 100).toFixed(1)}%

⚠️ <b>تنبيه:</b> هذه توصية استثمارية وليست نصيحة مالية. تداول على مسؤوليتك الخاصة.

<b>هل كانت التوصية مفيدة؟</b>
👍 نجحت | 👎 فشلت | ⏳ انتظار
`;
  }

  private generateStandardTelegramMessage(recommendation: any): string {
    const signalEmoji = recommendation.signal === 'BUY' ? '🟢' : '🔴';
    
    return `
📊 <b>توصية تداول</b> ${signalEmoji}

📈 <b>الأصل:</b> ${recommendation.symbol}
📊 <b>الاتجاه:</b> ${recommendation.signal}
🎯 <b>الثقة:</b> ${recommendation.confidence}%
⏱️ <b>المدة:</b> ${recommendation.duration}

<b>هل كانت التوصية مفيدة؟</b>
👍 نجحت | 👎 فشلت | ⏳ انتظار
`;
  }

  private getStrengthEmoji(strength: string): string {
    switch (strength) {
      case 'قوية جداً': return '🔥🔥🔥';
      case 'قوية': return '🔥🔥';
      case 'متوسطة': return '🔥';
      default: return '⚡';
    }
  }

  private getRiskEmoji(riskLevel: string): string {
    switch (riskLevel) {
      case 'LOW': return '🟢';
      case 'MEDIUM': return '🟡';
      case 'HIGH': return '🔴';
      default: return '⚪';
    }
  }

  private translateMarketRegime(regime: string): string {
    const translations = {
      'trending': 'اتجاهي',
      'ranging': 'متذبذب',
      'volatile': 'متقلب',
      'reversal': 'انعكاسي'
    };
    return translations[regime] || regime;
  }

  // دوال مساعدة للسياق المحسن
  private getCurrentSession(): string {
    const hour = new Date().getUTCHours();
    
    // جلسة آسيا: 22:00 - 08:00 UTC
    if (hour >= 22 || hour < 8) return 'asian';
    // جلسة لندن: 08:00 - 16:00 UTC  
    else if (hour >= 8 && hour < 16) return 'london';
    // تداخل لندن-نيويورك: 13:00 - 16:00 UTC
    else if (hour >= 13 && hour < 16) return 'overlap';
    // جلسة نيويورك: 13:00 - 22:00 UTC
    else if (hour >= 13 && hour < 22) return 'newyork';
    
    return 'london';
  }

  private getMarketHours(): string {
    const session = this.getCurrentSession();
    
    if (session === 'overlap' || session === 'london' || session === 'newyork') {
      return 'high_liquidity';
    } else if (session === 'asian') {
      return 'medium_liquidity';
    }
    
    return 'low_liquidity';
  }

  private getWeekendProximity(): number {
    const now = new Date();
    const dayOfWeek = now.getUTCDay(); // 0 = Sunday, 6 = Saturday
    const hour = now.getUTCHours();
    
    // الجمعة بعد 21:00 UTC (قرب إغلاق الأسواق)
    if (dayOfWeek === 5 && hour >= 21) return 0.9;
    // السبت
    else if (dayOfWeek === 6) return 1.0;
    // الأحد قبل 22:00 UTC (قبل فتح الأسواق)
    else if (dayOfWeek === 0 && hour < 22) return 0.8;
    // الجمعة
    else if (dayOfWeek === 5) return 0.6;
    // الخميس
    else if (dayOfWeek === 4) return 0.3;
    
    return 0.0;
  }

  // رسالة تليجرام محسنة مع البيانات الخارجية الحقيقية
  private async sendExternalDataEnhancedTelegramRecommendation(recommendation: any, comprehensiveAnalysis?: any): Promise<void> {
    if (!recommendation) return;

    try {
      const platform = platformManager.getActivePlatform();
      const platformName = platform ? platform.displayName : 'التداول';
      
      const signalEmoji = recommendation.signal === 'BUY' ? '📈' : '📉';
      const confidenceEmoji = this.getConfidenceEmoji(recommendation.confidence);
      const riskEmoji = this.getRiskEmoji(recommendation.riskLevel);
      
      // الحصول على البيانات المحسنة من المصادر الخارجية
      const enhancedData = comprehensiveAnalysis || await enhancedDataIntegration.getEnhancedMarketData(recommendation.symbol);
      
      let message = `
🤖 <b>نظام الذكاء الاصطناعي المتطور</b>
🔥 <b>إشارة محسنة بالبيانات الحقيقية</b>

🏆 <b>منصة ${platformName}</b>

${signalEmoji} <b>الأصل:</b> ${recommendation.symbol}
📊 <b>الاتجاه:</b> ${recommendation.signal === 'BUY' ? 'صعود' : 'هبوط'} ${signalEmoji}
🎯 <b>مستوى الثقة:</b> ${recommendation.confidence}% ${confidenceEmoji}
⚖️ <b>المخاطر:</b> ${recommendation.riskLevel} ${riskEmoji}
⏰ <b>المدة المتوقعة:</b> ${recommendation.duration}

💎 <b>تحليل البيانات الخارجية:</b>`;

      // إضافة بيانات Alpha Vantage إذا كانت متوفرة
      if (enhancedData?.externalSources?.alphaVantage) {
        message += `\n📊 Alpha Vantage: السعر الحقيقي ${enhancedData.realTimePrice.toFixed(5)}`;
        message += `\n📈 التغيير: ${enhancedData.priceChangePercent.toFixed(2)}%`;
      }

      // إضافة تحليل الأخبار إذا كان متوفراً
      if (enhancedData?.fundamentalData?.newsCount > 0) {
        const sentimentText = enhancedData.fundamentalData.sentiment > 0 ? 'إيجابية' : 
                             enhancedData.fundamentalData.sentiment < 0 ? 'سلبية' : 'محايدة';
        message += `\n📰 تحليل الأخبار: ${sentimentText} (${enhancedData.fundamentalData.newsCount} مقال)`;
      }

      // إضافة البيانات الاقتصادية من FRED
      if (enhancedData?.externalSources?.fredAPI) {
        message += `\n🏛️ البيانات الاقتصادية: متوفرة`;
      }

      // إضافة تحليل شامل إذا كان متوفراً
      if (comprehensiveAnalysis) {
        message += `\n\n🧠 <b>التحليل الشامل:</b>`;
        message += `\n🎯 العائد المتوقع: ${comprehensiveAnalysis.expectedReturn}%`;
        message += `\n🛡️ وقف الخسارة: ${comprehensiveAnalysis.stopLoss.toFixed(5)}`;
        message += `\n🚀 جني الأرباح: ${comprehensiveAnalysis.takeProfit.toFixed(5)}`;
        
        if (comprehensiveAnalysis.reasoning && comprehensiveAnalysis.reasoning.length > 0) {
          message += `\n\n💡 <b>الأسباب الرئيسية:</b>`;
          comprehensiveAnalysis.reasoning.slice(0, 3).forEach((reason: string) => {
            message += `\n• ${reason}`;
          });
        }
      }

      // إضافة مصادر البيانات
      if (enhancedData?.sources && enhancedData.sources.length > 0) {
        message += `\n\n🔗 <b>مصادر البيانات:</b>`;
        enhancedData.sources.forEach((source: string) => {
          message += `\n✅ ${source}`;
        });
      }

      // إضافة سياق السوق
      if (enhancedData?.marketContext) {
        message += `\n\n📊 <b>سياق السوق:</b>`;
        message += `\n💹 المشاعر الاقتصادية: ${(enhancedData.marketContext.economicSentiment * 100).toFixed(0)}%`;
        message += `\n📰 مشاعر الأخبار: ${(enhancedData.marketContext.newsSentiment * 100).toFixed(0)}%`;
        message += `\n📈 القوة التقنية: ${(enhancedData.marketContext.technicalStrength * 100).toFixed(0)}%`;
      }

      message += `\n\n📱 <b>توقيت السوق:</b>`;
      message += `\n🕐 الجلسة: ${this.getCurrentSession()}`;
      message += `\n📅 التاريخ: ${new Date().toLocaleString('ar-SA')}`;

      message += `\n\n💼 <b>إدارة المخاطر المخصصة:</b>`;
      message += `\n${this.getCustomRiskManagement(recommendation.riskLevel, recommendation.confidence)}`;

      message += `\n\n⚡ <b>نصائح التنفيذ:</b>`;
      message += `\n${this.getExecutionTips(recommendation.riskLevel, recommendation.confidence)}`;

      message += `\n\n⚠️ <b>تنبيه مهم:</b> هذه توصية استثمارية وليست نصيحة مالية مضمونة.`;
      message += `\n💪 تداول بحكمة واستخدم إدارة المخاطر المناسبة.`;

      message += `\n\n<b>📊 هل كانت التوصية مفيدة؟</b>`;
      message += `\n👍 نجحت | 👎 فشلت | ⏳ انتظار`;

      console.log(`🚀 Sending enhanced external data telegram message for ${recommendation.symbol}`);
      
      // إرسال الرسالة
      await this.telegramBot.sendRecommendation(
        recommendation.symbol,
        recommendation.signal,
        recommendation.confidence,
        recommendation.duration,
        message
      );

      console.log(`✅ Enhanced external data telegram message sent successfully`);

    } catch (error) {
      console.error('❌ Error sending enhanced external data telegram message:', error);
      
      // Fallback to standard message
      try {
        await this.telegramBot.sendRecommendation(
          recommendation.symbol,
          recommendation.signal,
          recommendation.confidence,
          recommendation.duration
        );
        console.log('📤 Fallback telegram message sent');
      } catch (fallbackError) {
        console.error('❌ Error sending fallback telegram message:', fallbackError);
      }
    }
  }
}

export const autoSignalsService = new AutoSignalsService();
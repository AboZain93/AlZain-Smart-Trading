import { storage } from "../storage";
import { User, InsertUser, InsertUserActivityLog } from "@shared/schema";
import bcrypt from "bcrypt";
import crypto from "crypto";
import { licenseManager } from "./license-manager";

export class UserManager {
  
  // Hash password
  async hashPassword(password: string): Promise<string> {
    return await bcrypt.hash(password, 10);
  }

  // Verify password
  async verifyPassword(password: string, hashedPassword: string): Promise<boolean> {
    return await bcrypt.compare(password, hashedPassword);
  }

  // Generate verification token
  generateVerificationToken(): string {
    return crypto.randomBytes(32).toString('hex');
  }

  // Register new user
  async registerUser(userData: {
    username: string;
    email: string;
    password: string;
    firstName?: string;
    lastName?: string;
    phoneNumber?: string;
    country?: string;
    language?: string;
  }): Promise<User> {
    
    // Check if user already exists
    const existingUser = await storage.getUserByUsername(userData.username);
    if (existingUser) {
      throw new Error("Username already exists");
    }

    const existingEmail = await storage.getUserByEmail(userData.email);
    if (existingEmail) {
      throw new Error("Email already exists");
    }

    // Hash password
    const hashedPassword = await this.hashPassword(userData.password);

    // Create user
    const newUser: InsertUser = {
      ...userData,
      password: hashedPassword,
      emailVerified: false,
      phoneVerified: false,
      twoFactorEnabled: false,
      language: userData.language || "ar",
      timezone: "UTC",
      role: "user",
      accountStatus: "active",
      isActive: true
    };

    const user = await storage.createUser(newUser);

    // Create email verification token
    const verificationToken = this.generateVerificationToken();
    await storage.createEmailVerificationToken({
      userId: user.id,
      token: verificationToken,
      expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000) // 24 hours
    });

    // Log registration
    await storage.createUserActivityLog({
      userId: user.id,
      action: "user_registered",
      description: "User registered successfully",
      metadata: { email: userData.email, username: userData.username }
    });

    return user;
  }

  // Login user
  async loginUser(usernameOrEmail: string, password: string, ipAddress?: string, userAgent?: string): Promise<{
    user: User;
    sessionToken: string;
  }> {
    // Find user by username or email
    let user = await storage.getUserByUsername(usernameOrEmail);
    if (!user) {
      user = await storage.getUserByEmail(usernameOrEmail);
    }

    if (!user) {
      throw new Error("User not found");
    }

    // Check password
    const isValidPassword = await this.verifyPassword(password, user.password);
    if (!isValidPassword) {
      throw new Error("Invalid password");
    }

    // Check account status
    if (user.accountStatus !== "active") {
      throw new Error("Account is suspended or banned");
    }

    // Generate session token
    const sessionToken = crypto.randomBytes(32).toString('hex');
    
    // Create session
    await storage.createUserSession({
      userId: user.id,
      sessionToken,
      deviceInfo: userAgent || "Unknown",
      ipAddress: ipAddress || "Unknown",
      userAgent: userAgent || "Unknown",
      expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000) // 30 days
    });

    // Update last login
    await storage.updateUser(user.id, { lastLoginAt: new Date() });

    // Log login
    await storage.createUserActivityLog({
      userId: user.id,
      action: "user_login",
      description: "User logged in successfully",
      ipAddress,
      userAgent,
      metadata: { loginMethod: "password" }
    });

    return { user, sessionToken };
  }

  // Logout user
  async logoutUser(sessionToken: string): Promise<void> {
    const session = await storage.getUserSessionByToken(sessionToken);
    if (session) {
      await storage.updateUserSession(session.id, { isActive: false });
      
      // Log logout
      await storage.createUserActivityLog({
        userId: session.userId,
        action: "user_logout",
        description: "User logged out successfully"
      });
    }
  }

  // Get user profile
  async getUserProfile(userId: number): Promise<User | undefined> {
    return await storage.getUser(userId);
  }

  // Update user profile
  async updateUserProfile(userId: number, updates: Partial<InsertUser>): Promise<void> {
    // Don't allow updating sensitive fields
    const allowedFields = ['firstName', 'lastName', 'phoneNumber', 'country', 'language', 'timezone', 'profileImage'];
    const filteredUpdates = Object.fromEntries(
      Object.entries(updates).filter(([key]) => allowedFields.includes(key))
    );

    await storage.updateUser(userId, filteredUpdates);

    // Log profile update
    await storage.createUserActivityLog({
      userId,
      action: "profile_updated",
      description: "User profile updated",
      metadata: { updatedFields: Object.keys(filteredUpdates) }
    });
  }

  // Change password
  async changePassword(userId: number, currentPassword: string, newPassword: string): Promise<void> {
    const user = await storage.getUser(userId);
    if (!user) {
      throw new Error("User not found");
    }

    // Verify current password
    const isValidPassword = await this.verifyPassword(currentPassword, user.password);
    if (!isValidPassword) {
      throw new Error("Current password is incorrect");
    }

    // Hash new password
    const hashedPassword = await this.hashPassword(newPassword);

    // Update password
    await storage.updateUser(userId, { password: hashedPassword });

    // Log password change
    await storage.createUserActivityLog({
      userId,
      action: "password_changed",
      description: "Password changed successfully"
    });
  }

  // Verify email
  async verifyEmail(token: string): Promise<boolean> {
    const verificationToken = await storage.getEmailVerificationToken(token);
    if (!verificationToken || verificationToken.used || verificationToken.expiresAt < new Date()) {
      return false;
    }

    // Mark token as used
    await storage.updateEmailVerificationToken(verificationToken.id, { used: true });

    // Update user email verification status
    await storage.updateUser(verificationToken.userId, { emailVerified: true });

    // Log email verification
    await storage.createUserActivityLog({
      userId: verificationToken.userId,
      action: "email_verified",
      description: "Email verified successfully"
    });

    return true;
  }

  // Request password reset
  async requestPasswordReset(email: string): Promise<string> {
    const user = await storage.getUserByEmail(email);
    if (!user) {
      throw new Error("User not found");
    }

    // Generate reset token
    const resetToken = this.generateVerificationToken();
    
    // Create password reset token
    await storage.createPasswordResetToken({
      userId: user.id,
      token: resetToken,
      expiresAt: new Date(Date.now() + 60 * 60 * 1000) // 1 hour
    });

    // Log password reset request
    await storage.createUserActivityLog({
      userId: user.id,
      action: "password_reset_requested",
      description: "Password reset requested"
    });

    return resetToken;
  }

  // Reset password
  async resetPassword(token: string, newPassword: string): Promise<boolean> {
    const resetToken = await storage.getPasswordResetToken(token);
    if (!resetToken || resetToken.used || resetToken.expiresAt < new Date()) {
      return false;
    }

    // Hash new password
    const hashedPassword = await this.hashPassword(newPassword);

    // Update password
    await storage.updateUser(resetToken.userId, { password: hashedPassword });

    // Mark token as used
    await storage.updatePasswordResetToken(resetToken.id, { used: true });

    // Log password reset
    await storage.createUserActivityLog({
      userId: resetToken.userId,
      action: "password_reset_completed",
      description: "Password reset completed successfully"
    });

    return true;
  }

  // Get user dashboard data
  async getUserDashboardData(userId: number): Promise<{
    user: User;
    licenses: any[];
    recentActivity: any[];
    notifications: any[];
  }> {
    const user = await storage.getUser(userId);
    if (!user) {
      throw new Error("User not found");
    }

    const licenses = await storage.getLicensesByUser(userId);
    const recentActivity = await storage.getUserActivityLogs(userId, 10);
    const notifications = await storage.getUserNotifications(userId, 5);

    return {
      user,
      licenses,
      recentActivity,
      notifications
    };
  }

  // Suspend user account
  async suspendUser(userId: number, reason: string): Promise<void> {
    await storage.updateUser(userId, { 
      accountStatus: "suspended",
      isActive: false 
    });

    // Log suspension
    await storage.createUserActivityLog({
      userId,
      action: "account_suspended",
      description: `Account suspended: ${reason}`,
      metadata: { reason }
    });
  }

  // Activate user account
  async activateUser(userId: number): Promise<void> {
    await storage.updateUser(userId, { 
      accountStatus: "active",
      isActive: true 
    });

    // Log activation
    await storage.createUserActivityLog({
      userId,
      action: "account_activated",
      description: "Account activated successfully"
    });
  }

  // Get user statistics
  async getUserStatistics(userId: number): Promise<{
    totalTrades: number;
    successfulTrades: number;
    activeLicenses: number;
    memberSince: Date;
    lastActivity: Date | null;
  }> {
    const user = await storage.getUser(userId);
    if (!user) {
      throw new Error("User not found");
    }

    const licenses = await storage.getLicensesByUser(userId);
    const tradeHistory = await storage.getTradeHistoryByUser(userId);
    const activeLicenses = licenses.filter(l => l.status === "active").length;
    const successfulTrades = tradeHistory.filter(t => t.result === "SUCCESS").length;

    return {
      totalTrades: tradeHistory.length,
      successfulTrades,
      activeLicenses,
      memberSince: user.createdAt,
      lastActivity: user.lastLoginAt
    };
  }
}

export const userManager = new UserManager();
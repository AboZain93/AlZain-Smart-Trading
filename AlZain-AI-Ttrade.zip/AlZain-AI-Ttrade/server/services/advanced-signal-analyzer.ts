import { storage } from '../storage';
import { technicalAnalysisService } from './technical-analysis';

interface TimeframeAnalysis {
  timeframe: string;
  rsi: number;
  macd: number;
  signal: 'BUY' | 'SELL' | 'NEUTRAL';
  confidence: number;
  trend: 'BULLISH' | 'BEARISH' | 'SIDEWAYS';
}

interface MultiTimeframeAnalysis {
  symbol: string;
  timeframes: TimeframeAnalysis[];
  overallSignal: 'BUY' | 'SELL' | 'NEUTRAL';
  overallConfidence: number;
  consensus: number; // Percentage of timeframes agreeing
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH';
}

interface MarketContext {
  volatility: number;
  volume: number;
  marketSentiment: 'BULLISH' | 'BEARISH' | 'NEUTRAL';
  economicEvents: boolean;
  newsImpact: 'POSITIVE' | 'NEGATIVE' | 'NEUTRAL';
}

export class AdvancedSignalAnalyzer {
  private readonly TIMEFRAMES = ['1m', '5m', '15m', '1h', '4h'];
  private readonly MIN_CONFIDENCE_THRESHOLD = 75;
  private readonly MIN_CONSENSUS_THRESHOLD = 60;

  async analyzeSignalMultiTimeframe(symbol: string): Promise<MultiTimeframeAnalysis> {
    const timeframeAnalyses: TimeframeAnalysis[] = [];

    // Analyze each timeframe
    for (const timeframe of this.TIMEFRAMES) {
      const analysis = await this.analyzeTimeframe(symbol, timeframe);
      timeframeAnalyses.push(analysis);
    }

    // Calculate overall consensus
    const buySignals = timeframeAnalyses.filter(tf => tf.signal === 'BUY').length;
    const sellSignals = timeframeAnalyses.filter(tf => tf.signal === 'SELL').length;
    const neutralSignals = timeframeAnalyses.filter(tf => tf.signal === 'NEUTRAL').length;

    const totalSignals = this.TIMEFRAMES.length;
    const consensus = Math.max(buySignals, sellSignals, neutralSignals) / totalSignals * 100;

    // Determine overall signal
    let overallSignal: 'BUY' | 'SELL' | 'NEUTRAL';
    if (buySignals > sellSignals && buySignals > neutralSignals) {
      overallSignal = 'BUY';
    } else if (sellSignals > buySignals && sellSignals > neutralSignals) {
      overallSignal = 'SELL';
    } else {
      overallSignal = 'NEUTRAL';
    }

    // Calculate weighted confidence
    const weightedConfidence = this.calculateWeightedConfidence(timeframeAnalyses);
    
    // Determine risk level
    const riskLevel = this.calculateRiskLevel(consensus, weightedConfidence);

    return {
      symbol,
      timeframes: timeframeAnalyses,
      overallSignal,
      overallConfidence: weightedConfidence,
      consensus,
      riskLevel
    };
  }

  private async analyzeTimeframe(symbol: string, timeframe: string): Promise<TimeframeAnalysis> {
    // Get market data for this timeframe (simulated for now)
    const marketData = await this.getMarketDataForTimeframe(symbol, timeframe);
    
    // Calculate technical indicators
    const rsi = this.calculateRSI(marketData);
    const macd = this.calculateMACD(marketData);
    const trend = this.determineTrend(marketData);

    // Generate signal based on technical analysis
    const signal = this.generateSignalFromIndicators(rsi, macd, trend);
    const confidence = this.calculateConfidence(rsi, macd, trend, timeframe);

    return {
      timeframe,
      rsi,
      macd,
      signal,
      confidence,
      trend
    };
  }

  private async getMarketDataForTimeframe(symbol: string, timeframe: string) {
    // In a real implementation, this would fetch actual timeframe data
    // For now, we'll simulate different timeframes with variations
    const basePrice = 1.0850 + (Math.random() - 0.5) * 0.01;
    const timeframeMultiplier = this.getTimeframeMultiplier(timeframe);
    
    return {
      prices: Array.from({ length: 20 }, (_, i) => 
        basePrice + (Math.sin(i * timeframeMultiplier) * 0.005) + (Math.random() - 0.5) * 0.002
      ),
      volumes: Array.from({ length: 20 }, () => Math.random() * 1000000),
      timestamps: Array.from({ length: 20 }, (_, i) => Date.now() - (i * 60000))
    };
  }

  private getTimeframeMultiplier(timeframe: string): number {
    const multipliers: Record<string, number> = {
      '1m': 0.1,
      '5m': 0.2,
      '15m': 0.3,
      '1h': 0.5,
      '4h': 0.8
    };
    return multipliers[timeframe] || 0.3;
  }

  private calculateRSI(marketData: any): number {
    const prices = marketData.prices;
    if (prices.length < 14) return 50; // Neutral RSI if insufficient data

    const gains: number[] = [];
    const losses: number[] = [];

    for (let i = 1; i < prices.length; i++) {
      const change = prices[i] - prices[i - 1];
      if (change > 0) {
        gains.push(change);
        losses.push(0);
      } else {
        gains.push(0);
        losses.push(Math.abs(change));
      }
    }

    const avgGain = gains.slice(-14).reduce((a, b) => a + b, 0) / 14;
    const avgLoss = losses.slice(-14).reduce((a, b) => a + b, 0) / 14;

    if (avgLoss === 0) return 100;
    const rs = avgGain / avgLoss;
    return 100 - (100 / (1 + rs));
  }

  private calculateMACD(marketData: any): number {
    const prices = marketData.prices;
    if (prices.length < 26) return 0;

    const ema12 = this.calculateEMA(prices, 12);
    const ema26 = this.calculateEMA(prices, 26);
    return ema12 - ema26;
  }

  private calculateEMA(prices: number[], period: number): number {
    if (prices.length < period) return prices[prices.length - 1];
    
    const multiplier = 2 / (period + 1);
    let ema = prices[0];
    
    for (let i = 1; i < prices.length; i++) {
      ema = (prices[i] * multiplier) + (ema * (1 - multiplier));
    }
    
    return ema;
  }

  private determineTrend(marketData: any): 'BULLISH' | 'BEARISH' | 'SIDEWAYS' {
    const prices = marketData.prices;
    const recentPrices = prices.slice(-10);
    
    const firstHalf = recentPrices.slice(0, 5).reduce((a: number, b: number) => a + b, 0) / 5;
    const secondHalf = recentPrices.slice(5).reduce((a: number, b: number) => a + b, 0) / 5;
    
    const difference = ((secondHalf - firstHalf) / firstHalf) * 100;
    
    if (difference > 0.1) return 'BULLISH';
    if (difference < -0.1) return 'BEARISH';
    return 'SIDEWAYS';
  }

  private generateSignalFromIndicators(rsi: number, macd: number, trend: string): 'BUY' | 'SELL' | 'NEUTRAL' {
    let buyScore = 0;
    let sellScore = 0;

    // RSI analysis
    if (rsi < 30) buyScore += 2; // Oversold
    else if (rsi < 45) buyScore += 1;
    else if (rsi > 70) sellScore += 2; // Overbought
    else if (rsi > 55) sellScore += 1;

    // MACD analysis
    if (macd > 0) buyScore += 1;
    else sellScore += 1;

    // Trend analysis
    if (trend === 'BULLISH') buyScore += 2;
    else if (trend === 'BEARISH') sellScore += 2;

    if (buyScore > sellScore + 1) return 'BUY';
    if (sellScore > buyScore + 1) return 'SELL';
    return 'NEUTRAL';
  }

  private calculateConfidence(rsi: number, macd: number, trend: string, timeframe: string): number {
    let confidence = 50; // Base confidence

    // RSI confidence
    if (rsi < 20 || rsi > 80) confidence += 20; // Strong oversold/overbought
    else if (rsi < 30 || rsi > 70) confidence += 10;

    // MACD confidence
    const macdStrength = Math.abs(macd);
    confidence += Math.min(macdStrength * 1000, 15);

    // Trend confidence
    if (trend !== 'SIDEWAYS') confidence += 10;

    // Timeframe weight (longer timeframes get higher confidence)
    const timeframeWeights: Record<string, number> = {
      '1m': 0.8,
      '5m': 0.9,
      '15m': 1.0,
      '1h': 1.1,
      '4h': 1.2
    };
    confidence *= (timeframeWeights[timeframe] || 1.0);

    return Math.min(Math.max(confidence, 0), 100);
  }

  private calculateWeightedConfidence(timeframes: TimeframeAnalysis[]): number {
    const weights: Record<string, number> = {
      '1m': 1,
      '5m': 2,
      '15m': 3,
      '1h': 4,
      '4h': 5
    };

    let totalWeight = 0;
    let weightedSum = 0;

    timeframes.forEach(tf => {
      const weight = weights[tf.timeframe] || 1;
      weightedSum += tf.confidence * weight;
      totalWeight += weight;
    });

    return totalWeight > 0 ? weightedSum / totalWeight : 50;
  }

  private calculateRiskLevel(consensus: number, confidence: number): 'LOW' | 'MEDIUM' | 'HIGH' {
    if (consensus >= 80 && confidence >= 85) return 'LOW';
    if (consensus >= 60 && confidence >= 70) return 'MEDIUM';
    return 'HIGH';
  }

  async analyzeMarketContext(symbol: string): Promise<MarketContext> {
    // This would integrate with external APIs for real market context
    const volatility = Math.random() * 100;
    const volume = Math.random() * 1000000;
    
    return {
      volatility,
      volume,
      marketSentiment: volatility > 70 ? 'BEARISH' : volatility < 30 ? 'BULLISH' : 'NEUTRAL',
      economicEvents: Math.random() > 0.7, // 30% chance of economic events
      newsImpact: Math.random() > 0.6 ? 'POSITIVE' : Math.random() > 0.3 ? 'NEGATIVE' : 'NEUTRAL'
    };
  }

  async shouldGenerateSignal(analysis: MultiTimeframeAnalysis, context: MarketContext): Promise<boolean> {
    // Don't generate signals that don't meet minimum requirements
    if (analysis.overallConfidence < this.MIN_CONFIDENCE_THRESHOLD) {
      console.log(`Signal rejected: Low confidence (${analysis.overallConfidence}%)`);
      return false;
    }

    if (analysis.consensus < this.MIN_CONSENSUS_THRESHOLD) {
      console.log(`Signal rejected: Low consensus (${analysis.consensus}%)`);
      return false;
    }

    if (analysis.overallSignal === 'NEUTRAL') {
      console.log('Signal rejected: Neutral signal');
      return false;
    }

    // Avoid high-risk periods
    if (context.volatility > 80 && analysis.riskLevel === 'HIGH') {
      console.log('Signal rejected: High volatility + High risk');
      return false;
    }

    // Consider economic events
    if (context.economicEvents && analysis.riskLevel !== 'LOW') {
      console.log('Signal rejected: Economic events during non-low risk');
      return false;
    }

    return true;
  }

  async getEnhancedRecommendation(symbol: string) {
    const analysis = await this.analyzeSignalMultiTimeframe(symbol);
    const context = await this.analyzeMarketContext(symbol);
    
    const shouldGenerate = await this.shouldGenerateSignal(analysis, context);
    
    if (!shouldGenerate) {
      return null;
    }

    // Calculate enhanced metrics
    const duration = this.calculateOptimalDuration(analysis);
    const entryPrice = await this.getCurrentPrice(symbol);
    const targets = this.calculateTargets(entryPrice, analysis.overallSignal, analysis.overallConfidence);

    return {
      symbol,
      signal: analysis.overallSignal,
      confidence: Math.round(analysis.overallConfidence),
      riskLevel: analysis.riskLevel,
      duration,
      entryPrice,
      targets,
      analysis: {
        consensus: analysis.consensus,
        timeframeBreakdown: analysis.timeframes,
        marketContext: context
      },
      reasoning: this.generateReasoning(analysis, context)
    };
  }

  private calculateOptimalDuration(analysis: MultiTimeframeAnalysis): string {
    // Base duration on consensus and confidence
    if (analysis.consensus >= 80 && analysis.overallConfidence >= 85) {
      return '15-30 minutes'; // High confidence, longer duration
    } else if (analysis.consensus >= 60 && analysis.overallConfidence >= 70) {
      return '5-15 minutes'; // Medium confidence, medium duration
    } else {
      return '1-5 minutes'; // Lower confidence, shorter duration
    }
  }

  private async getCurrentPrice(symbol: string): Promise<number> {
    const marketData = await storage.getMarketDataBySymbol(symbol);
    return marketData?.price || 1.0850;
  }

  private calculateTargets(entryPrice: number, signal: string, confidence: number) {
    const targetPercentage = (confidence / 100) * 0.002; // Max 0.2% based on confidence
    
    if (signal === 'BUY') {
      return {
        target1: entryPrice * (1 + targetPercentage * 0.5),
        target2: entryPrice * (1 + targetPercentage),
        stopLoss: entryPrice * (1 - targetPercentage * 0.5)
      };
    } else {
      return {
        target1: entryPrice * (1 - targetPercentage * 0.5),
        target2: entryPrice * (1 - targetPercentage),
        stopLoss: entryPrice * (1 + targetPercentage * 0.5)
      };
    }
  }

  private generateReasoning(analysis: MultiTimeframeAnalysis, context: MarketContext): string {
    const reasons = [];
    
    const agreeing = analysis.timeframes.filter(tf => tf.signal === analysis.overallSignal);
    reasons.push(`${agreeing.length}/${analysis.timeframes.length} timeframes agree`);
    
    if (analysis.overallConfidence >= 80) {
      reasons.push('High technical confidence');
    }
    
    if (context.marketSentiment !== 'NEUTRAL') {
      reasons.push(`Market sentiment: ${context.marketSentiment.toLowerCase()}`);
    }
    
    if (context.volatility < 30) {
      reasons.push('Low volatility environment');
    }
    
    return reasons.join(', ');
  }
}

export const advancedSignalAnalyzer = new AdvancedSignalAnalyzer();
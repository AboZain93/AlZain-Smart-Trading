import axios from 'axios';

interface AlphaVantageQuote {
  symbol: string;
  price: number;
  change: number;
  changePercent: number;
  volume?: number;
  timestamp: string;
}

interface AlphaVantageNews {
  title: string;
  summary: string;
  source: string;
  url: string;
  timestamp: string;
  sentiment?: number;
  relevanceScore?: number;
  tickers?: string[];
}

interface TechnicalIndicator {
  symbol: string;
  indicator: string;
  value: number;
  signal: 'BUY' | 'SELL' | 'HOLD';
  timestamp: string;
}

class AlphaVantageService {
  private apiKey: string;
  private baseUrl = 'https://www.alphavantage.co/query';
  private rateLimitDelay = 12000; // 5 calls per minute = 12 seconds between calls
  private lastCallTime = 0;

  constructor() {
    this.apiKey = process.env.ALPHA_VANTAGE_API_KEY || '';
    if (!this.apiKey) {
      console.warn('Alpha Vantage API key not found');
    }
  }

  private async rateLimitedRequest(params: any): Promise<any> {
    const now = Date.now();
    const timeSinceLastCall = now - this.lastCallTime;
    
    if (timeSinceLastCall < this.rateLimitDelay) {
      const waitTime = this.rateLimitDelay - timeSinceLastCall;
      await new Promise(resolve => setTimeout(resolve, waitTime));
    }

    this.lastCallTime = Date.now();
    
    try {
      const response = await axios.get(this.baseUrl, {
        params: {
          ...params,
          apikey: this.apiKey
        },
        timeout: 10000
      });
      
      return response.data;
    } catch (error) {
      console.error('Alpha Vantage API error:', error);
      throw error;
    }
  }

  async getRealTimeQuote(symbol: string): Promise<AlphaVantageQuote | null> {
    if (!this.apiKey) return null;

    try {
      const data = await this.rateLimitedRequest({
        function: 'GLOBAL_QUOTE',
        symbol: symbol
      });

      const quote = data['Global Quote'];
      if (!quote) return null;

      return {
        symbol: quote['01. Symbol'] || symbol,
        price: parseFloat(quote['05. price'] || '0'),
        change: parseFloat(quote['09. change'] || '0'),
        changePercent: parseFloat(quote['10. change percent']?.replace('%', '') || '0'),
        volume: parseInt(quote['06. volume'] || '0'),
        timestamp: quote['07. latest trading day'] || new Date().toISOString()
      };
    } catch (error) {
      console.error(`Error fetching quote for ${symbol}:`, error);
      return null;
    }
  }

  async getIntradayData(symbol: string, interval: '1min' | '5min' | '15min' | '30min' | '60min' = '5min'): Promise<any[]> {
    if (!this.apiKey) return [];

    try {
      const data = await this.rateLimitedRequest({
        function: 'TIME_SERIES_INTRADAY',
        symbol: symbol,
        interval: interval,
        outputsize: 'compact'
      });

      const timeSeries = data[`Time Series (${interval})`];
      if (!timeSeries) return [];

      return Object.entries(timeSeries).map(([timestamp, values]: [string, any]) => ({
        timestamp,
        open: parseFloat(values['1. open']),
        high: parseFloat(values['2. high']),
        low: parseFloat(values['3. low']),
        close: parseFloat(values['4. close']),
        volume: parseInt(values['5. volume'])
      })).slice(0, 100); // Limit to 100 recent points
    } catch (error) {
      console.error(`Error fetching intraday data for ${symbol}:`, error);
      return [];
    }
  }

  async getTechnicalIndicator(symbol: string, indicator: 'RSI' | 'MACD' | 'SMA' | 'EMA'): Promise<TechnicalIndicator | null> {
    if (!this.apiKey) return null;

    try {
      let functionName = '';
      let seriesKey = '';
      
      switch (indicator) {
        case 'RSI':
          functionName = 'RSI';
          seriesKey = 'Technical Analysis: RSI';
          break;
        case 'MACD':
          functionName = 'MACD';
          seriesKey = 'Technical Analysis: MACD';
          break;
        case 'SMA':
          functionName = 'SMA';
          seriesKey = 'Technical Analysis: SMA';
          break;
        case 'EMA':
          functionName = 'EMA';
          seriesKey = 'Technical Analysis: EMA';
          break;
      }

      const data = await this.rateLimitedRequest({
        function: functionName,
        symbol: symbol,
        interval: 'daily',
        time_period: 14,
        series_type: 'close'
      });

      const series = data[seriesKey];
      if (!series) return null;

      const latestTimestamp = Object.keys(series)[0];
      const latestValue = series[latestTimestamp];
      
      let value = 0;
      let signal: 'BUY' | 'SELL' | 'HOLD' = 'HOLD';

      if (indicator === 'RSI') {
        value = parseFloat(latestValue['RSI'] || '0');
        signal = value < 30 ? 'BUY' : value > 70 ? 'SELL' : 'HOLD';
      } else if (indicator === 'MACD') {
        value = parseFloat(latestValue['MACD'] || '0');
        const signal_line = parseFloat(latestValue['MACD_Signal'] || '0');
        signal = value > signal_line ? 'BUY' : value < signal_line ? 'SELL' : 'HOLD';
      } else {
        value = parseFloat(latestValue[indicator] || '0');
        // For moving averages, compare with current price
        const quote = await this.getRealTimeQuote(symbol);
        if (quote) {
          signal = quote.price > value ? 'BUY' : quote.price < value ? 'SELL' : 'HOLD';
        }
      }

      return {
        symbol,
        indicator,
        value,
        signal,
        timestamp: latestTimestamp
      };
    } catch (error) {
      console.error(`Error fetching ${indicator} for ${symbol}:`, error);
      return null;
    }
  }

  async getMarketNews(tickers?: string[]): Promise<AlphaVantageNews[]> {
    if (!this.apiKey) return [];

    try {
      const params: any = {
        function: 'NEWS_SENTIMENT'
      };

      if (tickers && tickers.length > 0) {
        params.tickers = tickers.join(',');
      }

      params.limit = 50; // Get latest 50 news items

      const data = await this.rateLimitedRequest(params);

      if (!data.feed) return [];

      return data.feed.map((item: any) => ({
        title: item.title,
        summary: item.summary,
        source: item.source,
        url: item.url,
        timestamp: item.time_published,
        sentiment: parseFloat(item.overall_sentiment_score || '0'),
        relevanceScore: parseFloat(item.relevance_score || '0'),
        tickers: item.ticker_sentiment?.map((t: any) => t.ticker) || []
      }));
    } catch (error) {
      console.error('Error fetching market news:', error);
      return [];
    }
  }

  async getForexRates(baseCurrency: string = 'USD'): Promise<any> {
    if (!this.apiKey) return {};

    try {
      const data = await this.rateLimitedRequest({
        function: 'FX_DAILY',
        from_symbol: baseCurrency,
        to_symbol: 'EUR'
      });

      return data;
    } catch (error) {
      console.error('Error fetching forex rates:', error);
      return {};
    }
  }

  async getCryptoData(symbol: string, market: string = 'USD'): Promise<any> {
    if (!this.apiKey) return null;

    try {
      const data = await this.rateLimitedRequest({
        function: 'DIGITAL_CURRENCY_DAILY',
        symbol: symbol,
        market: market
      });

      return data;
    } catch (error) {
      console.error(`Error fetching crypto data for ${symbol}:`, error);
      return null;
    }
  }

  // Get multiple quotes efficiently
  async getMultipleQuotes(symbols: string[]): Promise<AlphaVantageQuote[]> {
    if (!this.apiKey) return [];

    const quotes: AlphaVantageQuote[] = [];
    
    // Process symbols in batches to respect rate limits
    for (const symbol of symbols.slice(0, 5)) { // Limit to 5 symbols
      try {
        const quote = await this.getRealTimeQuote(symbol);
        if (quote) {
          quotes.push(quote);
        }
      } catch (error) {
        console.error(`Error fetching quote for ${symbol}:`, error);
      }
    }

    return quotes;
  }

  // Enhanced market analysis
  async getComprehensiveMarketData(symbol: string): Promise<any> {
    if (!this.apiKey) return null;

    try {
      const [quote, rsi, macd, news] = await Promise.allSettled([
        this.getRealTimeQuote(symbol),
        this.getTechnicalIndicator(symbol, 'RSI'),
        this.getTechnicalIndicator(symbol, 'MACD'),
        this.getMarketNews([symbol])
      ]);

      return {
        quote: quote.status === 'fulfilled' ? quote.value : null,
        technicalIndicators: {
          rsi: rsi.status === 'fulfilled' ? rsi.value : null,
          macd: macd.status === 'fulfilled' ? macd.value : null
        },
        news: news.status === 'fulfilled' ? news.value : [],
        timestamp: new Date().toISOString()
      };
    } catch (error) {
      console.error(`Error getting comprehensive data for ${symbol}:`, error);
      return null;
    }
  }

  // Check API health
  async checkApiHealth(): Promise<boolean> {
    if (!this.apiKey) return false;

    try {
      const data = await this.rateLimitedRequest({
        function: 'GLOBAL_QUOTE',
        symbol: 'AAPL'
      });

      return !!data['Global Quote'];
    } catch (error) {
      console.error('Alpha Vantage API health check failed:', error);
      return false;
    }
  }
}

export const alphaVantageService = new AlphaVantageService();
export default AlphaVantageService;
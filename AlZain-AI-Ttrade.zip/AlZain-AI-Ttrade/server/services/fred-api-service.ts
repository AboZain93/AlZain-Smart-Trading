import axios from 'axios';

interface FREDSeries {
  id: string;
  title: string;
  value: number;
  date: string;
  units: string;
  frequency: string;
  status: string;
}

interface EconomicIndicator {
  seriesId: string;
  title: string;
  value: number;
  previousValue?: number;
  change?: number;
  changePercent?: number;
  date: string;
  impact?: 'HIGH' | 'MEDIUM' | 'LOW';
  trend?: 'IMPROVING' | 'DECLINING' | 'STABLE';
}

class FREDAPIService {
  private apiKey: string;
  private baseUrl = 'https://api.stlouisfed.org/fred';
  private rateLimitDelay = 100; // FRED allows more requests
  private lastCallTime = 0;

  // Key economic indicators
  private readonly keyIndicators = {
    GDP: 'GDP',
    UNEMPLOYMENT: 'UNRATE',
    INFLATION: 'CPIAUCSL',
    FEDERAL_FUNDS_RATE: 'FEDFUNDS',
    CONSUMER_SENTIMENT: 'UMCSENT',
    RETAIL_SALES: 'RSAFS',
    INDUSTRIAL_PRODUCTION: 'INDPRO',
    HOUSING_STARTS: 'HOUST',
    PERSONAL_INCOME: 'PI',
    CONSUMER_PRICE_INDEX: 'CPIAUCSL',
    PRODUCER_PRICE_INDEX: 'PPIACO',
    NONFARM_PAYROLLS: 'PAYEMS',
    TRADE_BALANCE: 'BOPGSTB',
    DURABLE_GOODS: 'DGORDER',
    INITIAL_CLAIMS: 'ICSA'
  };

  constructor() {
    this.apiKey = process.env.FRED_API_KEY || '';
    if (!this.apiKey) {
      console.warn('FRED API key not found');
    }
  }

  private async rateLimitedRequest(endpoint: string, params: any): Promise<any> {
    const now = Date.now();
    const timeSinceLastCall = now - this.lastCallTime;
    
    if (timeSinceLastCall < this.rateLimitDelay) {
      const waitTime = this.rateLimitDelay - timeSinceLastCall;
      await new Promise(resolve => setTimeout(resolve, waitTime));
    }

    this.lastCallTime = Date.now();
    
    try {
      const response = await axios.get(`${this.baseUrl}${endpoint}`, {
        params: {
          ...params,
          api_key: this.apiKey,
          file_type: 'json'
        },
        timeout: 10000
      });
      
      return response.data;
    } catch (error) {
      console.error('FRED API error:', error);
      throw error;
    }
  }

  private assessImpact(seriesId: string, changePercent: number): 'HIGH' | 'MEDIUM' | 'LOW' {
    const highImpactSeries = [
      'FEDFUNDS', 'GDP', 'UNRATE', 'CPIAUCSL', 'PAYEMS'
    ];
    
    const isHighImpactSeries = highImpactSeries.includes(seriesId);
    const significantChange = Math.abs(changePercent) > 0.5;
    
    if (isHighImpactSeries && significantChange) return 'HIGH';
    if (isHighImpactSeries || significantChange) return 'MEDIUM';
    return 'LOW';
  }

  private determineTrend(current: number, previous: number, seriesId: string): 'IMPROVING' | 'DECLINING' | 'STABLE' {
    const change = current - previous;
    const threshold = Math.abs(current * 0.01); // 1% threshold
    
    // For unemployment rate, lower is better
    if (seriesId === 'UNRATE') {
      if (change < -threshold) return 'IMPROVING';
      if (change > threshold) return 'DECLINING';
      return 'STABLE';
    }
    
    // For most indicators, higher is better
    if (change > threshold) return 'IMPROVING';
    if (change < -threshold) return 'DECLINING';
    return 'STABLE';
  }

  async getLatestValue(seriesId: string): Promise<FREDSeries | null> {
    if (!this.apiKey) return null;

    try {
      const data = await this.rateLimitedRequest('/series/observations', {
        series_id: seriesId,
        limit: 1,
        sort_order: 'desc'
      });

      if (!data.observations || data.observations.length === 0) return null;

      const observation = data.observations[0];
      
      // Get series info for title and units
      const seriesInfo = await this.getSeriesInfo(seriesId);
      
      return {
        id: seriesId,
        title: seriesInfo?.title || seriesId,
        value: parseFloat(observation.value),
        date: observation.date,
        units: seriesInfo?.units || '',
        frequency: seriesInfo?.frequency || '',
        status: 'active'
      };
    } catch (error) {
      console.error(`Error fetching latest value for ${seriesId}:`, error);
      return null;
    }
  }

  async getSeriesInfo(seriesId: string): Promise<any> {
    if (!this.apiKey) return null;

    try {
      const data = await this.rateLimitedRequest('/series', {
        series_id: seriesId
      });

      return data.seriess?.[0] || null;
    } catch (error) {
      console.error(`Error fetching series info for ${seriesId}:`, error);
      return null;
    }
  }

  async getHistoricalData(seriesId: string, startDate?: string, endDate?: string): Promise<any[]> {
    if (!this.apiKey) return [];

    try {
      const params: any = {
        series_id: seriesId,
        sort_order: 'desc',
        limit: 100
      };

      if (startDate) params.observation_start = startDate;
      if (endDate) params.observation_end = endDate;

      const data = await this.rateLimitedRequest('/series/observations', params);

      if (!data.observations) return [];

      return data.observations.map((obs: any) => ({
        date: obs.date,
        value: parseFloat(obs.value) || 0
      })).filter((obs: any) => !isNaN(obs.value));
    } catch (error) {
      console.error(`Error fetching historical data for ${seriesId}:`, error);
      return [];
    }
  }

  async getEconomicIndicator(indicator: keyof typeof this.keyIndicators): Promise<EconomicIndicator | null> {
    const seriesId = this.keyIndicators[indicator];
    if (!seriesId || !this.apiKey) return null;

    try {
      // Get latest 2 observations to calculate change
      const data = await this.rateLimitedRequest('/series/observations', {
        series_id: seriesId,
        limit: 2,
        sort_order: 'desc'
      });

      if (!data.observations || data.observations.length === 0) return null;

      const latest = data.observations[0];
      const previous = data.observations[1];
      
      const currentValue = parseFloat(latest.value);
      const previousValue = previous ? parseFloat(previous.value) : null;
      
      let change = null;
      let changePercent = null;
      
      if (previousValue !== null && !isNaN(previousValue) && previousValue !== 0) {
        change = currentValue - previousValue;
        changePercent = (change / previousValue) * 100;
      }

      const seriesInfo = await this.getSeriesInfo(seriesId);
      
      return {
        seriesId,
        title: seriesInfo?.title || indicator,
        value: currentValue,
        previousValue,
        change,
        changePercent,
        date: latest.date,
        impact: changePercent ? this.assessImpact(seriesId, changePercent) : 'LOW',
        trend: previousValue ? this.determineTrend(currentValue, previousValue, seriesId) : 'STABLE'
      };
    } catch (error) {
      console.error(`Error fetching economic indicator ${indicator}:`, error);
      return null;
    }
  }

  async getAllKeyIndicators(): Promise<EconomicIndicator[]> {
    if (!this.apiKey) return [];

    const indicators: EconomicIndicator[] = [];
    
    // Process indicators in batches to avoid overwhelming the API
    const indicatorKeys = Object.keys(this.keyIndicators) as Array<keyof typeof this.keyIndicators>;
    
    for (const indicator of indicatorKeys.slice(0, 10)) { // Limit to 10 key indicators
      try {
        const data = await this.getEconomicIndicator(indicator);
        if (data) {
          indicators.push(data);
        }
      } catch (error) {
        console.error(`Error fetching indicator ${indicator}:`, error);
      }
    }

    return indicators;
  }

  async getEconomicCalendar(): Promise<any[]> {
    if (!this.apiKey) return [];

    try {
      // Get upcoming releases for key indicators
      const upcomingReleases = [];
      
      // FRED doesn't provide a calendar API, but we can check release schedules
      const keyIndicators = ['GDP', 'UNRATE', 'CPIAUCSL', 'FEDFUNDS', 'PAYEMS'];
      
      for (const seriesId of keyIndicators) {
        try {
          const data = await this.rateLimitedRequest('/release/dates', {
            release_id: this.getReleaseIdForSeries(seriesId)
          });
          
          if (data.release_dates) {
            upcomingReleases.push(...data.release_dates.map((release: any) => ({
              seriesId,
              title: this.getIndicatorTitle(seriesId),
              releaseDate: release.date,
              impact: this.getIndicatorImpact(seriesId)
            })));
          }
        } catch (error) {
          // Continue with other indicators if one fails
          console.error(`Error fetching release dates for ${seriesId}:`, error);
        }
      }

      return upcomingReleases.slice(0, 20); // Limit to 20 upcoming releases
    } catch (error) {
      console.error('Error fetching economic calendar:', error);
      return [];
    }
  }

  private getReleaseIdForSeries(seriesId: string): number {
    const releaseMap: { [key: string]: number } = {
      'GDP': 53,
      'UNRATE': 50,
      'CPIAUCSL': 10,
      'FEDFUNDS': 62,
      'PAYEMS': 50
    };
    
    return releaseMap[seriesId] || 50;
  }

  private getIndicatorTitle(seriesId: string): string {
    const titleMap: { [key: string]: string } = {
      'GDP': 'Gross Domestic Product',
      'UNRATE': 'Unemployment Rate',
      'CPIAUCSL': 'Consumer Price Index',
      'FEDFUNDS': 'Federal Funds Rate',
      'PAYEMS': 'Nonfarm Payrolls'
    };
    
    return titleMap[seriesId] || seriesId;
  }

  private getIndicatorImpact(seriesId: string): 'HIGH' | 'MEDIUM' | 'LOW' {
    const highImpact = ['GDP', 'UNRATE', 'CPIAUCSL', 'FEDFUNDS', 'PAYEMS'];
    return highImpact.includes(seriesId) ? 'HIGH' : 'MEDIUM';
  }

  async getMarketMoodFromEconomicData(): Promise<any> {
    if (!this.apiKey) return null;

    try {
      const keyData = await Promise.allSettled([
        this.getEconomicIndicator('GDP'),
        this.getEconomicIndicator('UNEMPLOYMENT'),
        this.getEconomicIndicator('INFLATION'),
        this.getEconomicIndicator('FEDERAL_FUNDS_RATE'),
        this.getEconomicIndicator('CONSUMER_SENTIMENT')
      ]);

      const indicators = keyData
        .filter(result => result.status === 'fulfilled' && result.value)
        .map(result => (result as PromiseFulfilledResult<EconomicIndicator>).value);

      if (indicators.length === 0) return null;

      // Calculate overall economic sentiment
      let economicScore = 0;
      let weightedTotal = 0;

      indicators.forEach(indicator => {
        const weight = indicator.impact === 'HIGH' ? 3 : indicator.impact === 'MEDIUM' ? 2 : 1;
        
        let score = 0;
        if (indicator.trend === 'IMPROVING') score = 1;
        else if (indicator.trend === 'DECLINING') score = -1;
        
        economicScore += score * weight;
        weightedTotal += weight;
      });

      const overallSentiment = weightedTotal > 0 ? economicScore / weightedTotal : 0;

      return {
        overallSentiment: Math.round(overallSentiment * 100) / 100,
        indicators: indicators.map(ind => ({
          title: ind.title,
          value: ind.value,
          change: ind.change,
          changePercent: ind.changePercent,
          trend: ind.trend,
          impact: ind.impact,
          date: ind.date
        })),
        sentiment: overallSentiment > 0.2 ? 'POSITIVE' : overallSentiment < -0.2 ? 'NEGATIVE' : 'NEUTRAL',
        confidence: Math.min(indicators.length / 5, 1), // Confidence based on data availability
        timestamp: new Date().toISOString()
      };
    } catch (error) {
      console.error('Error calculating market mood from economic data:', error);
      return null;
    }
  }

  async searchSeries(searchText: string, limit: number = 10): Promise<any[]> {
    if (!this.apiKey) return [];

    try {
      const data = await this.rateLimitedRequest('/series/search', {
        search_text: searchText,
        limit: limit
      });

      return data.seriess || [];
    } catch (error) {
      console.error(`Error searching series for "${searchText}":`, error);
      return [];
    }
  }

  async checkApiHealth(): Promise<boolean> {
    if (!this.apiKey) return false;

    try {
      const data = await this.rateLimitedRequest('/series/observations', {
        series_id: 'GDP',
        limit: 1,
        sort_order: 'desc'
      });

      return !!data.observations && data.observations.length > 0;
    } catch (error) {
      console.error('FRED API health check failed:', error);
      return false;
    }
  }
}

export const fredAPIService = new FREDAPIService();
export default FREDAPIService;
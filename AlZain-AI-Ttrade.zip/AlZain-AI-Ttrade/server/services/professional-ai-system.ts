import { storage } from '../storage';

export interface TradingResult {
  assetSymbol: string;
  direction: 'BUY' | 'SELL';
  confidence: number;
  result: 'win' | 'loss' | 'breakeven';
  timestamp: Date;
  entryPrice?: number;
  exitPrice?: number;
  profit?: number;
  duration?: number;
}

export interface MarketCondition {
  volatility: 'low' | 'medium' | 'high';
  trend: 'bullish' | 'bearish' | 'sideways';
  volume: 'low' | 'normal' | 'high';
  sessionType: 'asian' | 'european' | 'american' | 'overlap';
}

export interface AdvancedSignalData {
  technicalScore: number;
  fundamentalScore: number;
  sentimentScore: number;
  volumeScore: number;
  momentumScore: number;
  riskScore: number;
  marketRegimeScore: number;
  probabilityOfSuccess: number;
  expectedReturn: number;
  maxDrawdown: number;
  sharpeRatio: number;
  winRate: number;
  riskRewardRatio: number;
  volatilityAdjustedScore: number;
}

export class ProfessionalAISystem {
  private learningData: Map<string, TradingResult[]> = new Map();
  private marketPatterns: Map<string, any> = new Map();
  private assetPerformance: Map<string, any> = new Map();
  private confidenceAdjustments: Map<string, number> = new Map();

  constructor() {
    this.initializeLearningSystem();
  }

  private async initializeLearningSystem() {
    // تحميل البيانات السابقة
    const mlData = await storage.getAllMlTrainingData();
    const feedback = await storage.getAllTelegramFeedback();
    
    // تحليل النتائج السابقة
    for (const data of mlData) {
      if (!this.learningData.has(data.assetSymbol)) {
        this.learningData.set(data.assetSymbol, []);
      }
    }

    for (const fb of feedback) {
      this.processUserFeedback(fb);
    }

    this.calculateAssetPerformanceMetrics();
    console.log('🧠 Professional AI System initialized with learning data');
  }

  // تحليل متقدم للسوق مع الذكاء الاصطناعي
  async analyzeMarketWithAI(assetSymbol: string, marketData: any): Promise<AdvancedSignalData> {
    const historicalData = this.learningData.get(assetSymbol) || [];
    const assetPerf = this.assetPerformance.get(assetSymbol) || {};
    
    // 1. التحليل الفني المتقدم
    const technicalScore = await this.calculateTechnicalScore(assetSymbol, marketData);
    
    // 2. تحليل الأساسيات
    const fundamentalScore = await this.calculateFundamentalScore(assetSymbol);
    
    // 3. تحليل المشاعر
    const sentimentScore = await this.calculateSentimentScore(assetSymbol);
    
    // 4. تحليل الحجم
    const volumeScore = await this.calculateVolumeScore(marketData);
    
    // 5. تحليل الزخم
    const momentumScore = await this.calculateMomentumScore(marketData);
    
    // 6. تقييم المخاطر
    const riskScore = await this.calculateRiskScore(assetSymbol, historicalData);
    
    // 7. تحليل نظام السوق
    const marketRegimeScore = await this.calculateMarketRegimeScore(assetSymbol);
    
    // 8. احتمالية النجاح بناءً على التعلم
    const probabilityOfSuccess = this.calculateSuccessProbability(assetSymbol, historicalData);
    
    // 9. العائد المتوقع
    const expectedReturn = this.calculateExpectedReturn(assetSymbol, historicalData);
    
    // 10. الحد الأقصى للخسارة
    const maxDrawdown = this.calculateMaxDrawdown(historicalData);
    
    // 11. نسبة شارب
    const sharpeRatio = this.calculateSharpeRatio(historicalData);
    
    // 12. معدل الفوز
    const winRate = this.calculateWinRate(historicalData);
    
    // 13. نسبة المخاطرة إلى العائد
    const riskRewardRatio = this.calculateRiskRewardRatio(historicalData);
    
    // 14. درجة معدلة للتقلبات
    const volatilityAdjustedScore = this.calculateVolatilityAdjustedScore(
      technicalScore, fundamentalScore, sentimentScore, marketData
    );

    return {
      technicalScore,
      fundamentalScore,
      sentimentScore,
      volumeScore,
      momentumScore,
      riskScore,
      marketRegimeScore,
      probabilityOfSuccess,
      expectedReturn,
      maxDrawdown,
      sharpeRatio,
      winRate,
      riskRewardRatio,
      volatilityAdjustedScore
    };
  }

  // معالجة تفاعل المستخدم وتحديث نظام التعلم
  async processUserFeedback(feedback: any): Promise<void> {
    const assetSymbol = feedback.assetSymbol;
    const isSuccess = feedback.feedbackType === 'success';
    
    if (!this.learningData.has(assetSymbol)) {
      this.learningData.set(assetSymbol, []);
    }

    const tradingResult: TradingResult = {
      assetSymbol,
      direction: feedback.direction || 'BUY',
      confidence: feedback.confidence || 75,
      result: isSuccess ? 'win' : 'loss',
      timestamp: new Date(feedback.timestamp),
      profit: isSuccess ? (feedback.profit || 0.02) : (feedback.profit || -0.02)
    };

    this.learningData.get(assetSymbol)!.push(tradingResult);
    
    // تحديث تعديلات الثقة بناءً على النتائج
    this.updateConfidenceAdjustments(assetSymbol, isSuccess);
    
    // تحديث أداء الأصل
    await this.updateAssetPerformanceMetrics(assetSymbol);
    
    console.log(`🎯 AI Learning: ${assetSymbol} result processed - ${isSuccess ? 'WIN' : 'LOSS'}`);
  }

  // حساب التحليل الفني المتقدم
  private async calculateTechnicalScore(assetSymbol: string, marketData: any): Promise<number> {
    let score = 50; // نقطة البداية
    
    // RSI Analysis
    if (marketData.rsi) {
      if (marketData.rsi < 30) score += 15; // oversold = buy signal
      else if (marketData.rsi > 70) score -= 15; // overbought = sell signal
      else if (marketData.rsi >= 40 && marketData.rsi <= 60) score += 10; // neutral good
    }
    
    // MACD Analysis
    if (marketData.macd && marketData.macdSignal) {
      if (marketData.macd > marketData.macdSignal) score += 12; // bullish crossover
      else score -= 8;
    }
    
    // Moving Averages
    if (marketData.price && marketData.sma20 && marketData.sma50) {
      if (marketData.price > marketData.sma20 && marketData.sma20 > marketData.sma50) {
        score += 15; // strong uptrend
      } else if (marketData.price < marketData.sma20 && marketData.sma20 < marketData.sma50) {
        score -= 15; // strong downtrend
      }
    }
    
    // Bollinger Bands
    if (marketData.bbUpper && marketData.bbLower && marketData.price) {
      const bbPosition = (marketData.price - marketData.bbLower) / (marketData.bbUpper - marketData.bbLower);
      if (bbPosition < 0.2) score += 10; // near lower band = buy
      else if (bbPosition > 0.8) score -= 10; // near upper band = sell
    }

    return Math.max(0, Math.min(100, score));
  }

  // تحليل الأساسيات
  private async calculateFundamentalScore(assetSymbol: string): Promise<number> {
    let score = 50;
    
    // تحليل نوع الأصل
    if (assetSymbol.includes('USD')) {
      score += 5; // USD pairs generally more stable
    }
    
    if (assetSymbol.includes('EUR') || assetSymbol.includes('GBP')) {
      score += 3; // Major currencies
    }
    
    if (assetSymbol.includes('JPY')) {
      score += 2; // Safe haven currency
    }
    
    // تحليل التقلبات التاريخية
    const assetData = this.learningData.get(assetSymbol);
    if (assetData && assetData.length > 5) {
      const winRate = assetData.filter(r => r.result === 'win').length / assetData.length;
      score += (winRate - 0.5) * 30; // adjust based on historical performance
    }

    return Math.max(0, Math.min(100, score));
  }

  // تحليل المشاعر
  private async calculateSentimentScore(assetSymbol: string): Promise<number> {
    // محاكاة تحليل المشاعر بناءً على الوقت والحجم
    let score = 50;
    
    const hour = new Date().getHours();
    
    // تحليل جلسات التداول
    if (hour >= 8 && hour <= 12) score += 10; // European session
    else if (hour >= 13 && hour <= 17) score += 15; // American session
    else if (hour >= 22 || hour <= 6) score += 5; // Asian session
    else score -= 5; // Low activity periods
    
    return Math.max(0, Math.min(100, score));
  }

  // تحليل الحجم
  private async calculateVolumeScore(marketData: any): Promise<number> {
    let score = 50;
    
    if (marketData.volume) {
      // simulate volume analysis
      if (marketData.volume > 1000000) score += 15; // High volume
      else if (marketData.volume > 500000) score += 10; // Medium volume
      else if (marketData.volume < 100000) score -= 10; // Low volume
    }
    
    return Math.max(0, Math.min(100, score));
  }

  // تحليل الزخم
  private async calculateMomentumScore(marketData: any): Promise<number> {
    let score = 50;
    
    if (marketData.priceChange && marketData.priceChangePercent) {
      const changePercent = Math.abs(marketData.priceChangePercent);
      
      if (changePercent > 2) score += 15; // Strong momentum
      else if (changePercent > 1) score += 10; // Medium momentum
      else if (changePercent < 0.1) score -= 10; // Weak momentum
    }
    
    return Math.max(0, Math.min(100, score));
  }

  // تقييم المخاطر
  private async calculateRiskScore(assetSymbol: string, historicalData: TradingResult[]): Promise<number> {
    if (historicalData.length === 0) return 50;
    
    const losses = historicalData.filter(r => r.result === 'loss');
    const lossRate = losses.length / historicalData.length;
    
    let riskScore = 100 - (lossRate * 100);
    
    // تحليل الخسائر المتتالية
    let consecutiveLosses = 0;
    let maxConsecutiveLosses = 0;
    
    for (const result of historicalData.slice(-10)) {
      if (result.result === 'loss') {
        consecutiveLosses++;
        maxConsecutiveLosses = Math.max(maxConsecutiveLosses, consecutiveLosses);
      } else {
        consecutiveLosses = 0;
      }
    }
    
    riskScore -= maxConsecutiveLosses * 5; // Penalty for consecutive losses
    
    return Math.max(0, Math.min(100, riskScore));
  }

  // تحليل نظام السوق
  private async calculateMarketRegimeScore(assetSymbol: string): Promise<number> {
    const hour = new Date().getHours();
    let score = 50;
    
    // تحليل جلسات التداول المتداخلة
    if ((hour >= 8 && hour <= 12) || (hour >= 13 && hour <= 17)) {
      score += 20; // High activity sessions
    } else if (hour >= 22 || hour <= 6) {
      score += 10; // Asian session
    }
    
    // تعديل بناءً على يوم الأسبوع
    const dayOfWeek = new Date().getDay();
    if (dayOfWeek >= 1 && dayOfWeek <= 4) {
      score += 10; // Mid-week is generally better
    } else if (dayOfWeek === 5) {
      score -= 5; // Friday can be unpredictable
    }
    
    return Math.max(0, Math.min(100, score));
  }

  // حساب احتمالية النجاح
  private calculateSuccessProbability(assetSymbol: string, historicalData: TradingResult[]): number {
    if (historicalData.length === 0) return 0.5;
    
    const recentData = historicalData.slice(-20); // آخر 20 صفقة
    const wins = recentData.filter(r => r.result === 'win').length;
    
    let probability = wins / recentData.length;
    
    // تطبيق تعديلات الثقة
    const confidenceAdj = this.confidenceAdjustments.get(assetSymbol) || 0;
    probability += confidenceAdj;
    
    return Math.max(0.1, Math.min(0.9, probability));
  }

  // حساب العائد المتوقع
  private calculateExpectedReturn(assetSymbol: string, historicalData: TradingResult[]): number {
    if (historicalData.length === 0) return 0.02;
    
    const profits = historicalData.filter(r => r.profit).map(r => r.profit!);
    const avgProfit = profits.reduce((a, b) => a + b, 0) / profits.length;
    
    return Math.max(-0.05, Math.min(0.1, avgProfit));
  }

  // حساب الحد الأقصى للخسارة
  private calculateMaxDrawdown(historicalData: TradingResult[]): number {
    if (historicalData.length === 0) return 0.02;
    
    const losses = historicalData.filter(r => r.result === 'loss' && r.profit);
    if (losses.length === 0) return 0.02;
    
    const maxLoss = Math.min(...losses.map(r => r.profit!));
    return Math.abs(maxLoss);
  }

  // حساب نسبة شارب
  private calculateSharpeRatio(historicalData: TradingResult[]): number {
    if (historicalData.length < 5) return 0;
    
    const returns = historicalData.filter(r => r.profit).map(r => r.profit!);
    const avgReturn = returns.reduce((a, b) => a + b, 0) / returns.length;
    
    const variance = returns.reduce((acc, ret) => acc + Math.pow(ret - avgReturn, 2), 0) / returns.length;
    const stdDev = Math.sqrt(variance);
    
    return stdDev > 0 ? avgReturn / stdDev : 0;
  }

  // حساب معدل الفوز
  private calculateWinRate(historicalData: TradingResult[]): number {
    if (historicalData.length === 0) return 0.5;
    
    const wins = historicalData.filter(r => r.result === 'win').length;
    return wins / historicalData.length;
  }

  // حساب نسبة المخاطرة إلى العائد
  private calculateRiskRewardRatio(historicalData: TradingResult[]): number {
    const wins = historicalData.filter(r => r.result === 'win' && r.profit);
    const losses = historicalData.filter(r => r.result === 'loss' && r.profit);
    
    if (wins.length === 0 || losses.length === 0) return 1;
    
    const avgWin = wins.reduce((acc, w) => acc + w.profit!, 0) / wins.length;
    const avgLoss = Math.abs(losses.reduce((acc, l) => acc + l.profit!, 0) / losses.length);
    
    return avgLoss > 0 ? avgWin / avgLoss : 1;
  }

  // حساب درجة معدلة للتقلبات
  private calculateVolatilityAdjustedScore(
    technical: number, 
    fundamental: number, 
    sentiment: number, 
    marketData: any
  ): number {
    const baseScore = (technical + fundamental + sentiment) / 3;
    
    // تعديل بناءً على التقلبات
    let volatilityFactor = 1;
    if (marketData.priceChangePercent) {
      const absChange = Math.abs(marketData.priceChangePercent);
      if (absChange > 3) volatilityFactor = 0.8; // High volatility = reduce confidence
      else if (absChange < 0.5) volatilityFactor = 0.9; // Low volatility = slightly reduce
      else volatilityFactor = 1.1; // Medium volatility = increase confidence
    }
    
    return baseScore * volatilityFactor;
  }

  // تحديث تعديلات الثقة
  private updateConfidenceAdjustments(assetSymbol: string, isSuccess: boolean): void {
    const currentAdj = this.confidenceAdjustments.get(assetSymbol) || 0;
    const adjustment = isSuccess ? 0.02 : -0.03; // Penalty higher for losses
    
    const newAdj = Math.max(-0.2, Math.min(0.2, currentAdj + adjustment));
    this.confidenceAdjustments.set(assetSymbol, newAdj);
  }

  // حساب مقاييس أداء الأصول
  private calculateAssetPerformanceMetrics(): void {
    for (const [assetSymbol, data] of this.learningData) {
      if (data.length === 0) continue;
      
      const winRate = this.calculateWinRate(data);
      const sharpeRatio = this.calculateSharpeRatio(data);
      const maxDrawdown = this.calculateMaxDrawdown(data);
      
      this.assetPerformance.set(assetSymbol, {
        winRate,
        sharpeRatio,
        maxDrawdown,
        totalTrades: data.length,
        recentPerformance: data.slice(-10)
      });
    }
  }

  // تحديث مقاييس أداء أصل محدد
  private async updateAssetPerformanceMetrics(assetSymbol: string): Promise<void> {
    const data = this.learningData.get(assetSymbol);
    if (!data || data.length === 0) return;
    
    const performance = {
      winRate: this.calculateWinRate(data),
      totalTrades: data.length,
      profitFactor: this.calculateProfitFactor(data),
      lastUpdated: new Date()
    };
    
    // حفظ في قاعدة البيانات
    try {
      const existing = await storage.getAssetPerformance(assetSymbol);
      if (existing) {
        await storage.updateAssetPerformance(assetSymbol, performance);
      } else {
        await storage.createAssetPerformance({
          assetSymbol,
          ...performance
        });
      }
    } catch (error) {
      console.error('Error updating asset performance:', error);
    }
  }

  // حساب عامل الربح
  private calculateProfitFactor(data: TradingResult[]): number {
    const profits = data.filter(r => r.result === 'win' && r.profit).reduce((acc, r) => acc + r.profit!, 0);
    const losses = Math.abs(data.filter(r => r.result === 'loss' && r.profit).reduce((acc, r) => acc + r.profit!, 0));
    
    return losses > 0 ? profits / losses : profits > 0 ? 10 : 1;
  }

  // إنتاج إشارة محسّنة
  async generateEnhancedSignal(assetSymbol: string, marketData: any): Promise<any> {
    const analysis = await this.analyzeMarketWithAI(assetSymbol, marketData);
    
    // حساب الدرجة الإجمالية
    const overallScore = (
      analysis.technicalScore * 0.25 +
      analysis.fundamentalScore * 0.15 +
      analysis.sentimentScore * 0.10 +
      analysis.volumeScore * 0.10 +
      analysis.momentumScore * 0.15 +
      analysis.riskScore * 0.15 +
      analysis.marketRegimeScore * 0.10
    );
    
    // تحديد الاتجاه والثقة
    let direction: 'BUY' | 'SELL';
    let confidence = Math.round(analysis.volatilityAdjustedScore);
    
    if (overallScore >= 65) {
      direction = 'BUY';
      confidence = Math.min(95, confidence + 10);
    } else if (overallScore <= 35) {
      direction = 'SELL';
      confidence = Math.min(95, confidence + 10);
    } else {
      // إشارة ضعيفة - لا ترسل
      return null;
    }
    
    // تطبيق تعديلات التعلم
    const confidenceAdj = this.confidenceAdjustments.get(assetSymbol) || 0;
    confidence = Math.max(60, Math.min(95, confidence + (confidenceAdj * 100)));
    
    // فلترة الإشارات الضعيفة
    if (confidence < 75 || analysis.probabilityOfSuccess < 0.6) {
      return null;
    }

    return {
      assetSymbol,
      direction,
      confidence,
      analysis,
      qualityGrade: this.calculateQualityGrade(overallScore, confidence),
      riskLevel: this.calculateRiskLevel(analysis.riskScore),
      expectedDuration: this.calculateExpectedDuration(assetSymbol),
      stopLoss: this.calculateStopLoss(marketData.price, direction),
      takeProfit: this.calculateTakeProfit(marketData.price, direction, analysis.expectedReturn)
    };
  }

  // حساب درجة الجودة
  private calculateQualityGrade(overallScore: number, confidence: number): string {
    const combinedScore = (overallScore + confidence) / 2;
    
    if (combinedScore >= 90) return 'A+';
    else if (combinedScore >= 85) return 'A';
    else if (combinedScore >= 80) return 'A-';
    else if (combinedScore >= 75) return 'B+';
    else if (combinedScore >= 70) return 'B';
    else return 'B-';
  }

  // حساب مستوى المخاطرة
  private calculateRiskLevel(riskScore: number): 'low' | 'medium' | 'high' {
    if (riskScore >= 75) return 'low';
    else if (riskScore >= 50) return 'medium';
    else return 'high';
  }

  // حساب المدة المتوقعة
  private calculateExpectedDuration(assetSymbol: string): string {
    const assetData = this.learningData.get(assetSymbol);
    if (!assetData || assetData.length === 0) return '5-15 دقائق';
    
    const avgDuration = assetData
      .filter(r => r.duration)
      .reduce((acc, r) => acc + r.duration!, 0) / assetData.length;
    
    if (avgDuration < 5) return '1-5 دقائق';
    else if (avgDuration < 15) return '5-15 دقائق';
    else if (avgDuration < 30) return '15-30 دقيقة';
    else return '30+ دقيقة';
  }

  // حساب وقف الخسارة
  private calculateStopLoss(price: number, direction: 'BUY' | 'SELL'): number {
    const stopLossPercent = 0.015; // 1.5%
    
    if (direction === 'BUY') {
      return price * (1 - stopLossPercent);
    } else {
      return price * (1 + stopLossPercent);
    }
  }

  // حساب جني الأرباح
  private calculateTakeProfit(price: number, direction: 'BUY' | 'SELL', expectedReturn: number): number {
    const takeProfitPercent = Math.max(0.02, Math.abs(expectedReturn));
    
    if (direction === 'BUY') {
      return price * (1 + takeProfitPercent);
    } else {
      return price * (1 - takeProfitPercent);
    }
  }

  // الحصول على إحصائيات النظام
  async getSystemStats(): Promise<any> {
    const allAssets = Array.from(this.learningData.keys());
    let totalTrades = 0;
    let totalWins = 0;
    
    for (const data of this.learningData.values()) {
      totalTrades += data.length;
      totalWins += data.filter(r => r.result === 'win').length;
    }
    
    return {
      totalAssets: allAssets.length,
      totalTrades,
      overallWinRate: totalTrades > 0 ? totalWins / totalTrades : 0,
      assetsTracked: allAssets,
      confidenceAdjustments: Object.fromEntries(this.confidenceAdjustments),
      learningDataSize: totalTrades,
      systemStatus: 'active'
    };
  }
}

export const professionalAI = new ProfessionalAISystem();
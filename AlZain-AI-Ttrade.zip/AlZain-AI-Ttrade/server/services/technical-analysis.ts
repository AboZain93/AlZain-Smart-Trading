interface PriceData {
  close: number;
  high: number;
  low: number;
  volume?: number;
}

export class TechnicalAnalysisService {
  // Calculate Bollinger Bands for volatility analysis
  calculateBollingerBands(prices: number[], period: number = 20, multiplier: number = 2): {
    upper: number;
    middle: number;
    lower: number;
    bandwidth: number;
    position: number; // Price position within bands (0-1)
  } {
    const sma = this.calculateSMA(prices, period);
    const variance = prices.slice(-period).reduce((sum, price) => sum + Math.pow(price - sma, 2), 0) / period;
    const stdDev = Math.sqrt(variance);
    
    const upper = sma + (multiplier * stdDev);
    const lower = sma - (multiplier * stdDev);
    const bandwidth = (upper - lower) / sma * 100;
    
    const currentPrice = prices[prices.length - 1];
    const position = (currentPrice - lower) / (upper - lower);
    
    return {
      upper,
      middle: sma,
      lower,
      bandwidth,
      position: Math.max(0, Math.min(1, position))
    };
  }

  // Calculate Stochastic Oscillator
  calculateStochastic(highs: number[], lows: number[], closes: number[], kPeriod: number = 14, dPeriod: number = 3): {
    k: number;
    d: number;
    signal: 'overbought' | 'oversold' | 'neutral';
  } {
    const recentHighs = highs.slice(-kPeriod);
    const recentLows = lows.slice(-kPeriod);
    const currentClose = closes[closes.length - 1];
    
    const highestHigh = Math.max(...recentHighs);
    const lowestLow = Math.min(...recentLows);
    
    const k = ((currentClose - lowestLow) / (highestHigh - lowestLow)) * 100;
    
    // Simple moving average for %D
    const kValues = [];
    for (let i = 0; i < dPeriod && i < closes.length; i++) {
      const idx = closes.length - 1 - i;
      const h = Math.max(...highs.slice(Math.max(0, idx - kPeriod + 1), idx + 1));
      const l = Math.min(...lows.slice(Math.max(0, idx - kPeriod + 1), idx + 1));
      kValues.push(((closes[idx] - l) / (h - l)) * 100);
    }
    
    const d = kValues.reduce((sum, val) => sum + val, 0) / kValues.length;
    
    let signal: 'overbought' | 'oversold' | 'neutral' = 'neutral';
    if (k > 80 && d > 80) signal = 'overbought';
    else if (k < 20 && d < 20) signal = 'oversold';
    
    return { k, d, signal };
  }

  // Calculate Williams %R
  calculateWilliamsR(highs: number[], lows: number[], closes: number[], period: number = 14): number {
    const recentHighs = highs.slice(-period);
    const recentLows = lows.slice(-period);
    const currentClose = closes[closes.length - 1];
    
    const highestHigh = Math.max(...recentHighs);
    const lowestLow = Math.min(...recentLows);
    
    return ((highestHigh - currentClose) / (highestHigh - lowestLow)) * -100;
  }

  // Calculate Average True Range (ATR) for volatility
  calculateATR(highs: number[], lows: number[], closes: number[], period: number = 14): number {
    const trueRanges = [];
    
    for (let i = 1; i < highs.length; i++) {
      const tr1 = highs[i] - lows[i];
      const tr2 = Math.abs(highs[i] - closes[i - 1]);
      const tr3 = Math.abs(lows[i] - closes[i - 1]);
      trueRanges.push(Math.max(tr1, tr2, tr3));
    }
    
    return trueRanges.slice(-period).reduce((sum, tr) => sum + tr, 0) / period;
  }

  // Enhanced Volume analysis
  calculateVolumeAnalysis(volumes: number[], prices: number[]): {
    obv: number; // On-Balance Volume
    volumeTrend: 'increasing' | 'decreasing' | 'stable';
    volumeStrength: number; // 0-100
    priceVolumeConfirmation: boolean;
  } {
    let obv = 0;
    for (let i = 1; i < prices.length; i++) {
      if (prices[i] > prices[i - 1]) {
        obv += volumes[i];
      } else if (prices[i] < prices[i - 1]) {
        obv -= volumes[i];
      }
    }
    
    // Volume trend analysis
    const recentVolumes = volumes.slice(-10);
    const avgVolume = recentVolumes.reduce((sum, vol) => sum + vol, 0) / recentVolumes.length;
    const currentVolume = volumes[volumes.length - 1];
    
    let volumeTrend: 'increasing' | 'decreasing' | 'stable' = 'stable';
    if (currentVolume > avgVolume * 1.2) volumeTrend = 'increasing';
    else if (currentVolume < avgVolume * 0.8) volumeTrend = 'decreasing';
    
    const volumeStrength = Math.min(100, (currentVolume / avgVolume) * 100);
    
    // Price-Volume confirmation
    const priceChange = prices[prices.length - 1] - prices[prices.length - 2];
    const priceVolumeConfirmation = (priceChange > 0 && volumeTrend === 'increasing') || 
                                  (priceChange < 0 && volumeTrend === 'increasing');
    
    return { obv, volumeTrend, volumeStrength, priceVolumeConfirmation };
  }

  // Calculate RSI (Relative Strength Index)
  calculateRSI(prices: number[], period: number = 14): number {
    if (prices.length < period + 1) return 0;

    let gains = 0;
    let losses = 0;

    // Calculate initial average gain and loss
    for (let i = 1; i <= period; i++) {
      const change = prices[i] - prices[i - 1];
      if (change > 0) gains += change;
      else losses += Math.abs(change);
    }

    let avgGain = gains / period;
    let avgLoss = losses / period;

    // Calculate RSI for remaining periods
    for (let i = period + 1; i < prices.length; i++) {
      const change = prices[i] - prices[i - 1];
      const gain = change > 0 ? change : 0;
      const loss = change < 0 ? Math.abs(change) : 0;

      avgGain = (avgGain * (period - 1) + gain) / period;
      avgLoss = (avgLoss * (period - 1) + loss) / period;
    }

    if (avgLoss === 0) return 100;
    const rs = avgGain / avgLoss;
    return 100 - (100 / (1 + rs));
  }

  // Calculate MACD (Moving Average Convergence Divergence)
  calculateMACD(prices: number[], fastPeriod: number = 12, slowPeriod: number = 26, signalPeriod: number = 9): {
    macd: number;
    signal: number;
    histogram: number;
  } {
    const fastEMA = this.calculateEMA(prices, fastPeriod);
    const slowEMA = this.calculateEMA(prices, slowPeriod);
    const macdLine = fastEMA - slowEMA;
    
    // For simplicity, we'll use a basic signal calculation
    const signal = macdLine * 0.8; // Simplified signal line
    const histogram = macdLine - signal;

    return {
      macd: macdLine,
      signal,
      histogram,
    };
  }

  // Calculate Simple Moving Average
  calculateSMA(prices: number[], period: number): number {
    if (prices.length < period) return 0;
    const sum = prices.slice(-period).reduce((a, b) => a + b, 0);
    return sum / period;
  }

  // Calculate Exponential Moving Average
  calculateEMA(prices: number[], period: number): number {
    if (prices.length === 0) return 0;
    if (prices.length < period) return prices[prices.length - 1];

    const multiplier = 2 / (period + 1);
    let ema = prices[0];

    for (let i = 1; i < prices.length; i++) {
      ema = (prices[i] - ema) * multiplier + ema;
    }

    return ema;
  }

  // Enhanced AI-powered trading signal generation
  generateAdvancedTradingSignal(data: {
    prices: number[];
    highs: number[];
    lows: number[];
    volumes: number[];
    currentPrice: number;
  }): {
    signal: 'BUY' | 'SELL' | 'HOLD';
    confidence: number;
    reasons: string[];
    strength: 'قوية جداً' | 'قوية' | 'متوسطة' | 'ضعيفة';
    marketCondition: 'متفائلة' | 'متشائمة' | 'محايدة' | 'متقلبة';
    supportResistance: {
      support: number;
      resistance: number;
      nearLevel: boolean;
    };
  } {
    const reasons: string[] = [];
    let bullishSignals = 0;
    let bearishSignals = 0;
    let signalStrength = 0;

    // Calculate all indicators
    const rsi = this.calculateRSI(data.prices);
    const macd = this.calculateMACD(data.prices);
    const bb = this.calculateBollingerBands(data.prices);
    const stoch = this.calculateStochastic(data.highs, data.lows, data.prices);
    const williamsR = this.calculateWilliamsR(data.highs, data.lows, data.prices);
    const atr = this.calculateATR(data.highs, data.lows, data.prices);
    const volumeAnalysis = this.calculateVolumeAnalysis(data.volumes, data.prices);
    const sma20 = this.calculateSMA(data.prices, 20);
    const sma50 = this.calculateSMA(data.prices, 50);
    const ema12 = this.calculateEMA(data.prices, 12);

    // Advanced RSI analysis with divergence
    if (rsi < 20) {
      bullishSignals += 2;
      signalStrength += 15;
      reasons.push('RSI في منطقة التشبع البيعي الشديد');
    } else if (rsi < 30) {
      bullishSignals += 1;
      signalStrength += 10;
      reasons.push('RSI في منطقة التشبع البيعي');
    } else if (rsi > 80) {
      bearishSignals += 2;
      signalStrength += 15;
      reasons.push('RSI في منطقة التشبع الشرائي الشديد');
    } else if (rsi > 70) {
      bearishSignals += 1;
      signalStrength += 10;
      reasons.push('RSI في منطقة التشبع الشرائي');
    }

    // Enhanced MACD analysis
    if (macd.macd > macd.signal && macd.macd > 0) {
      bullishSignals += 2;
      signalStrength += 15;
      reasons.push('MACD إشارة صعودية قوية');
    } else if (macd.macd > macd.signal) {
      bullishSignals += 1;
      signalStrength += 8;
      reasons.push('MACD تحسن إيجابي');
    } else if (macd.macd < macd.signal && macd.macd < 0) {
      bearishSignals += 2;
      signalStrength += 15;
      reasons.push('MACD إشارة هبوطية قوية');
    } else {
      bearishSignals += 1;
      signalStrength += 8;
      reasons.push('MACD ضعف سلبي');
    }

    // Bollinger Bands analysis
    if (bb.position < 0.1) {
      bullishSignals += 1;
      signalStrength += 12;
      reasons.push('السعر قرب الحد السفلي لنطاق بولينجر');
    } else if (bb.position > 0.9) {
      bearishSignals += 1;
      signalStrength += 12;
      reasons.push('السعر قرب الحد العلوي لنطاق بولينجر');
    }

    if (bb.bandwidth < 10) {
      signalStrength += 5;
      reasons.push('انخفاض التقلبات - توقع اختراق قريب');
    }

    // Stochastic analysis
    if (stoch.signal === 'oversold' && stoch.k > stoch.d) {
      bullishSignals += 1;
      signalStrength += 10;
      reasons.push('مؤشر العشوائي إشارة شراء');
    } else if (stoch.signal === 'overbought' && stoch.k < stoch.d) {
      bearishSignals += 1;
      signalStrength += 10;
      reasons.push('مؤشر العشوائي إشارة بيع');
    }

    // Williams %R analysis
    if (williamsR < -80) {
      bullishSignals += 1;
      signalStrength += 8;
      reasons.push('ويليامز %R في منطقة التشبع البيعي');
    } else if (williamsR > -20) {
      bearishSignals += 1;
      signalStrength += 8;
      reasons.push('ويليامز %R في منطقة التشبع الشرائي');
    }

    // Multiple timeframe moving average analysis
    if (data.currentPrice > ema12 && ema12 > sma20 && sma20 > sma50) {
      bullishSignals += 2;
      signalStrength += 15;
      reasons.push('ترتيب المتوسطات المتحركة صعودي مثالي');
    } else if (data.currentPrice < ema12 && ema12 < sma20 && sma20 < sma50) {
      bearishSignals += 2;
      signalStrength += 15;
      reasons.push('ترتيب المتوسطات المتحركة هبوطي مثالي');
    } else if (data.currentPrice > sma20) {
      bullishSignals += 1;
      signalStrength += 8;
      reasons.push('السعر فوق المتوسط المتحرك 20');
    } else {
      bearishSignals += 1;
      signalStrength += 8;
      reasons.push('السعر تحت المتوسط المتحرك 20');
    }

    // Volume confirmation
    if (volumeAnalysis.priceVolumeConfirmation) {
      signalStrength += 10;
      reasons.push('تأكيد الحجم لاتجاه السعر');
    }

    if (volumeAnalysis.volumeStrength > 150) {
      signalStrength += 8;
      reasons.push('حجم تداول مرتفع بشكل استثنائي');
    }

    // Support and Resistance levels
    const support = Math.min(...data.lows.slice(-20));
    const resistance = Math.max(...data.highs.slice(-20));
    const nearLevel = Math.abs(data.currentPrice - support) / support < 0.01 || 
                     Math.abs(data.currentPrice - resistance) / resistance < 0.01;

    if (nearLevel) {
      if (Math.abs(data.currentPrice - support) < Math.abs(data.currentPrice - resistance)) {
        bullishSignals += 1;
        signalStrength += 12;
        reasons.push('السعر قرب مستوى الدعم القوي');
      } else {
        bearishSignals += 1;
        signalStrength += 12;
        reasons.push('السعر قرب مستوى المقاومة القوي');
      }
    }

    // Market volatility consideration
    const avgPrice = data.prices.reduce((a, b) => a + b, 0) / data.prices.length;
    const volatility = (atr / avgPrice) * 100;

    // Determine signal, confidence, and strength
    let signal: 'BUY' | 'SELL' | 'HOLD';
    let confidence: number;
    let strength: 'قوية جداً' | 'قوية' | 'متوسطة' | 'ضعيفة';
    let marketCondition: 'متفائلة' | 'متشائمة' | 'محايدة' | 'متقلبة';

    const netSignals = bullishSignals - bearishSignals;
    const totalSignals = bullishSignals + bearishSignals;

    if (Math.abs(netSignals) >= 3 && totalSignals >= 5) {
      signal = netSignals > 0 ? 'BUY' : 'SELL';
      confidence = Math.min(75 + signalStrength, 98);
      strength = signalStrength > 80 ? 'قوية جداً' : 'قوية';
    } else if (Math.abs(netSignals) >= 2) {
      signal = netSignals > 0 ? 'BUY' : 'SELL';
      confidence = Math.min(60 + signalStrength, 85);
      strength = signalStrength > 60 ? 'قوية' : 'متوسطة';
    } else if (Math.abs(netSignals) >= 1) {
      signal = netSignals > 0 ? 'BUY' : 'SELL';
      confidence = Math.min(50 + signalStrength, 75);
      strength = 'متوسطة';
    } else {
      signal = 'HOLD';
      confidence = Math.max(30, 50 - volatility);
      strength = 'ضعيفة';
    }

    // Market condition assessment
    if (volatility > 3) {
      marketCondition = 'متقلبة';
      confidence = Math.max(confidence - 15, 30);
    } else if (bullishSignals > bearishSignals + 1) {
      marketCondition = 'متفائلة';
    } else if (bearishSignals > bullishSignals + 1) {
      marketCondition = 'متشائمة';
    } else {
      marketCondition = 'محايدة';
    }

    return {
      signal,
      confidence: Math.round(confidence),
      reasons,
      strength,
      marketCondition,
      supportResistance: {
        support,
        resistance,
        nearLevel
      }
    };
  }

  // Keep the original method for backward compatibility
  generateTradingSignal(data: {
    rsi: number;
    macd: { macd: number; signal: number };
    currentPrice: number;
    sma20: number;
    sma50: number;
  }): {
    signal: 'BUY' | 'SELL' | 'HOLD';
    confidence: number;
    reasons: string[];
  } {
    const reasons: string[] = [];
    let bullishSignals = 0;
    let bearishSignals = 0;

    // RSI analysis
    if (data.rsi < 30) {
      bullishSignals++;
      reasons.push('RSI oversold condition');
    } else if (data.rsi > 70) {
      bearishSignals++;
      reasons.push('RSI overbought condition');
    }

    // MACD analysis
    if (data.macd.macd > data.macd.signal) {
      bullishSignals++;
      reasons.push('MACD positive divergence');
    } else {
      bearishSignals++;
      reasons.push('MACD negative divergence');
    }

    // Moving average analysis
    if (data.currentPrice > data.sma20 && data.sma20 > data.sma50) {
      bullishSignals++;
      reasons.push('Price above moving averages');
    } else if (data.currentPrice < data.sma20 && data.sma20 < data.sma50) {
      bearishSignals++;
      reasons.push('Price below moving averages');
    }

    // Determine signal and confidence
    let signal: 'BUY' | 'SELL' | 'HOLD';
    let confidence: number;

    if (bullishSignals > bearishSignals) {
      signal = 'BUY';
      confidence = Math.min(70 + (bullishSignals * 10), 95);
    } else if (bearishSignals > bullishSignals) {
      signal = 'SELL';
      confidence = Math.min(70 + (bearishSignals * 10), 95);
    } else {
      signal = 'HOLD';
      confidence = 50;
    }

    return { signal, confidence, reasons };
  }

  // Analyze market trend
  analyzeTrend(prices: number[]): {
    trend: string;
    strength: number;
  } {
    if (prices.length < 10) return { trend: 'SIDEWAYS', strength: 0 };

    const recent = prices.slice(-10);
    const older = prices.slice(-20, -10);

    const recentAvg = recent.reduce((a, b) => a + b, 0) / recent.length;
    const olderAvg = older.reduce((a, b) => a + b, 0) / older.length;

    const change = ((recentAvg - olderAvg) / olderAvg) * 100;

    if (change > 1) {
      return { trend: 'UPTREND', strength: Math.min(Math.abs(change) * 10, 100) };
    } else if (change < -1) {
      return { trend: 'DOWNTREND', strength: Math.min(Math.abs(change) * 10, 100) };
    } else {
      return { trend: 'SIDEWAYS', strength: 0 };
    }
  }

  // Assess risk level
  assessRiskLevel(volatility: number, rsi: number, confidence: number): 'low' | 'medium' | 'high' {
    let riskScore = 0;

    // Volatility factor
    if (volatility > 2) riskScore += 2;
    else if (volatility > 1) riskScore += 1;

    // RSI factor
    if (rsi > 80 || rsi < 20) riskScore += 2;
    else if (rsi > 70 || rsi < 30) riskScore += 1;

    // Confidence factor
    if (confidence < 70) riskScore += 1;
    if (confidence < 60) riskScore += 1;

    if (riskScore >= 4) return 'high';
    if (riskScore >= 2) return 'medium';
    return 'low';
  }
}

export const technicalAnalysisService = new TechnicalAnalysisService();

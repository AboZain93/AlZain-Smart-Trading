import { MarketData } from "@shared/schema";

export interface NewsEvent {
  id: string;
  title: string;
  content: string;
  source: string;
  timestamp: Date;
  relevantAssets: string[];
  impact: 'low' | 'medium' | 'high' | 'critical';
  sentiment: number; // -100 to +100
  category: 'economic' | 'political' | 'corporate' | 'market' | 'regulatory';
  tags: string[];
  reliability: number; // 0-100
}

export interface EconomicIndicator {
  name: string;
  country: string;
  value: number;
  previousValue: number;
  forecast: number;
  importance: 'low' | 'medium' | 'high';
  affectedCurrencies: string[];
  releaseTime: Date;
  actual: number;
  deviation: number; // actual vs forecast
}

export interface MarketSentimentScore {
  overall: number; // -100 to +100
  shortTerm: number; // 1-7 days
  mediumTerm: number; // 1-4 weeks
  longTerm: number; // 1-3 months
  confidence: number; // 0-100
  factors: {
    news: number;
    technical: number;
    economic: number;
    social: number;
  };
  riskLevel: 'very_low' | 'low' | 'medium' | 'high' | 'very_high';
}

export interface TradingContext {
  marketSession: 'asian' | 'european' | 'american' | 'overlap';
  volatility: number; // 0-100
  volume: number;
  majorEvents: NewsEvent[];
  economicReleases: EconomicIndicator[];
  sentiment: MarketSentimentScore;
  seasonality: {
    dayOfWeek: string;
    timeOfDay: string;
    seasonalTrend: 'positive' | 'negative' | 'neutral';
  };
}

export class NewsSentimentAnalysisService {
  private newsCache: Map<string, NewsEvent> = new Map();
  private economicCalendar: EconomicIndicator[] = [];
  private sentimentHistory: Map<string, MarketSentimentScore[]> = new Map();

  constructor() {
    this.initializeEconomicCalendar();
    this.startNewsMonitoring();
  }

  // News sentiment analysis
  async analyzeNewsSentiment(news: NewsEvent[]): Promise<MarketSentimentScore> {
    const sentimentScores = news.map(article => {
      const impact = this.getImpactWeight(article.impact);
      const reliability = article.reliability / 100;
      return article.sentiment * impact * reliability;
    });

    const overall = sentimentScores.length > 0 
      ? sentimentScores.reduce((sum, score) => sum + score, 0) / sentimentScores.length
      : 0;

    // Calculate short, medium, long term sentiment
    const recentNews = news.filter(n => 
      (Date.now() - n.timestamp.getTime()) < 24 * 60 * 60 * 1000
    );
    const shortTerm = this.calculateSentiment(recentNews);

    const weekNews = news.filter(n => 
      (Date.now() - n.timestamp.getTime()) < 7 * 24 * 60 * 60 * 1000
    );
    const mediumTerm = this.calculateSentiment(weekNews);

    const monthNews = news.filter(n => 
      (Date.now() - n.timestamp.getTime()) < 30 * 24 * 60 * 60 * 1000
    );
    const longTerm = this.calculateSentiment(monthNews);

    return {
      overall,
      shortTerm,
      mediumTerm,
      longTerm,
      confidence: this.calculateConfidence(news),
      factors: {
        news: overall,
        technical: 0, // Will be filled by technical analysis
        economic: this.calculateEconomicSentiment(),
        social: this.calculateSocialSentiment()
      },
      riskLevel: this.calculateRiskLevel(overall, news)
    };
  }

  private getImpactWeight(impact: string): number {
    switch (impact) {
      case 'critical': return 1.0;
      case 'high': return 0.8;
      case 'medium': return 0.6;
      case 'low': return 0.3;
      default: return 0.1;
    }
  }

  private calculateSentiment(news: NewsEvent[]): number {
    if (news.length === 0) return 0;
    
    const weightedSentiments = news.map(article => {
      const weight = this.getImpactWeight(article.impact) * (article.reliability / 100);
      return article.sentiment * weight;
    });

    return weightedSentiments.reduce((sum, s) => sum + s, 0) / news.length;
  }

  private calculateConfidence(news: NewsEvent[]): number {
    if (news.length === 0) return 0;
    
    const avgReliability = news.reduce((sum, n) => sum + n.reliability, 0) / news.length;
    const sourcesDiversity = new Set(news.map(n => n.source)).size;
    const recency = news.filter(n => 
      (Date.now() - n.timestamp.getTime()) < 6 * 60 * 60 * 1000
    ).length / news.length;

    return Math.min(100, avgReliability * 0.5 + sourcesDiversity * 10 + recency * 30);
  }

  private calculateEconomicSentiment(): number {
    const recentIndicators = this.economicCalendar.filter(indicator => 
      (Date.now() - indicator.releaseTime.getTime()) < 7 * 24 * 60 * 60 * 1000
    );

    if (recentIndicators.length === 0) return 0;

    const scores = recentIndicators.map(indicator => {
      const impactWeight = indicator.importance === 'high' ? 1.0 : 
                          indicator.importance === 'medium' ? 0.7 : 0.4;
      
      const deviationScore = indicator.deviation / Math.abs(indicator.forecast || 1) * 100;
      return Math.max(-100, Math.min(100, deviationScore)) * impactWeight;
    });

    return scores.reduce((sum, score) => sum + score, 0) / scores.length;
  }

  private calculateSocialSentiment(): number {
    // Simplified social sentiment calculation
    // In real implementation, this would analyze social media data
    return Math.random() * 40 - 20; // Random between -20 and +20
  }

  private calculateRiskLevel(sentiment: number, news: NewsEvent[]): 'very_low' | 'low' | 'medium' | 'high' | 'very_high' {
    const criticalNews = news.filter(n => n.impact === 'critical').length;
    const volatility = Math.abs(sentiment);
    
    if (criticalNews > 2 || volatility > 80) return 'very_high';
    if (criticalNews > 0 || volatility > 60) return 'high';
    if (volatility > 40) return 'medium';
    if (volatility > 20) return 'low';
    return 'very_low';
  }

  // Economic calendar management
  private initializeEconomicCalendar(): void {
    // Initialize with sample economic indicators
    const sampleIndicators: EconomicIndicator[] = [
      {
        name: 'Non-Farm Payrolls',
        country: 'USD',
        value: 210000,
        previousValue: 205000,
        forecast: 200000,
        importance: 'high',
        affectedCurrencies: ['USD', 'EUR', 'GBP', 'JPY'],
        releaseTime: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000),
        actual: 210000,
        deviation: 10000
      },
      {
        name: 'ECB Interest Rate Decision',
        country: 'EUR',
        value: 4.25,
        previousValue: 4.00,
        forecast: 4.25,
        importance: 'high',
        affectedCurrencies: ['EUR', 'USD', 'GBP'],
        releaseTime: new Date(Date.now() + 1 * 24 * 60 * 60 * 1000),
        actual: 4.25,
        deviation: 0
      }
    ];

    this.economicCalendar = sampleIndicators;
  }

  async getUpcomingEconomicEvents(hours: number = 24): Promise<EconomicIndicator[]> {
    const now = new Date();
    const future = new Date(now.getTime() + hours * 60 * 60 * 1000);
    
    return this.economicCalendar.filter(indicator => 
      indicator.releaseTime >= now && indicator.releaseTime <= future
    ).sort((a, b) => a.releaseTime.getTime() - b.releaseTime.getTime());
  }

  // Market context analysis
  async getMarketContext(assetSymbol: string): Promise<TradingContext> {
    const now = new Date();
    const currentHour = now.getUTCHours();
    
    // Determine market session
    let marketSession: 'asian' | 'european' | 'american' | 'overlap';
    if (currentHour >= 0 && currentHour < 8) {
      marketSession = 'asian';
    } else if (currentHour >= 8 && currentHour < 12) {
      marketSession = 'overlap'; // Asian-European overlap
    } else if (currentHour >= 12 && currentHour < 17) {
      marketSession = 'european';
    } else {
      marketSession = 'american';
    }

    // Get relevant news
    const relevantNews = Array.from(this.newsCache.values())
      .filter(news => 
        news.relevantAssets.includes(assetSymbol) &&
        (Date.now() - news.timestamp.getTime()) < 24 * 60 * 60 * 1000
      );

    // Get upcoming economic events
    const upcomingEvents = await this.getUpcomingEconomicEvents(24);
    const relevantEvents = upcomingEvents.filter(event => 
      event.affectedCurrencies.some(currency => assetSymbol.includes(currency))
    );

    // Calculate sentiment
    const sentiment = await this.analyzeNewsSentiment(relevantNews);

    // Determine seasonality
    const dayOfWeek = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'][now.getDay()];
    const timeOfDay = currentHour < 6 ? 'early' : 
                     currentHour < 12 ? 'morning' : 
                     currentHour < 18 ? 'afternoon' : 'evening';
    
    const seasonalTrend = this.getSeasonalTrend(dayOfWeek, timeOfDay, assetSymbol);

    return {
      marketSession,
      volatility: this.calculateCurrentVolatility(assetSymbol),
      volume: this.getCurrentVolume(assetSymbol),
      majorEvents: relevantNews.filter(news => news.impact === 'high' || news.impact === 'critical'),
      economicReleases: relevantEvents,
      sentiment,
      seasonality: {
        dayOfWeek,
        timeOfDay,
        seasonalTrend
      }
    };
  }

  private calculateCurrentVolatility(assetSymbol: string): number {
    // Simplified volatility calculation
    // In real implementation, this would use actual price data
    const baseVolatility = Math.random() * 100;
    
    // Adjust based on market session
    const now = new Date();
    const currentHour = now.getUTCHours();
    
    let sessionMultiplier = 1;
    if (currentHour >= 8 && currentHour < 12) {
      sessionMultiplier = 1.3; // Overlap period is more volatile
    } else if (currentHour >= 13 && currentHour < 17) {
      sessionMultiplier = 1.2; // European session
    }

    return Math.min(100, baseVolatility * sessionMultiplier);
  }

  private getCurrentVolume(assetSymbol: string): number {
    // Simplified volume calculation
    return Math.random() * 1000000 + 100000;
  }

  private getSeasonalTrend(dayOfWeek: string, timeOfDay: string, assetSymbol: string): 'positive' | 'negative' | 'neutral' {
    // Simplified seasonal analysis
    if (dayOfWeek === 'Monday' && timeOfDay === 'morning') {
      return 'positive'; // Monday morning momentum
    }
    if (dayOfWeek === 'Friday' && timeOfDay === 'afternoon') {
      return 'negative'; // Friday profit-taking
    }
    return 'neutral';
  }

  // News monitoring
  private startNewsMonitoring(): void {
    // Simulate news updates every 5 minutes
    setInterval(() => {
      this.simulateNewsUpdate();
    }, 5 * 60 * 1000);
  }

  private simulateNewsUpdate(): void {
    const sampleNews: NewsEvent[] = [
      {
        id: `news_${Date.now()}`,
        title: 'Federal Reserve Signals Potential Rate Changes',
        content: 'The Federal Reserve indicated in recent statements that monetary policy adjustments may be necessary...',
        source: 'Reuters',
        timestamp: new Date(),
        relevantAssets: ['USD', 'EUR/USD', 'GBP/USD', 'USD/JPY'],
        impact: 'high',
        sentiment: Math.random() * 60 - 30, // Random between -30 and +30
        category: 'economic',
        tags: ['fed', 'interest_rates', 'monetary_policy'],
        reliability: 85
      },
      {
        id: `news_${Date.now()}_2`,
        title: 'European Central Bank Economic Outlook',
        content: 'ECB officials discuss inflation targets and economic recovery measures...',
        source: 'Bloomberg',
        timestamp: new Date(),
        relevantAssets: ['EUR', 'EUR/USD', 'EUR/GBP'],
        impact: 'medium',
        sentiment: Math.random() * 40 - 20,
        category: 'economic',
        tags: ['ecb', 'inflation', 'europe'],
        reliability: 90
      }
    ];

    // Add to cache
    sampleNews.forEach(news => {
      this.newsCache.set(news.id, news);
    });

    console.log(`📰 Updated news cache with ${sampleNews.length} new articles`);
  }

  // Advanced analysis methods
  async generateTradingInsights(assetSymbol: string): Promise<{
    recommendation: 'strong_buy' | 'buy' | 'hold' | 'sell' | 'strong_sell';
    confidence: number;
    timeHorizon: 'short' | 'medium' | 'long';
    keyFactors: string[];
    risks: string[];
    opportunities: string[];
  }> {
    const context = await this.getMarketContext(assetSymbol);
    
    // Analyze sentiment trends
    const sentimentTrend = this.analyzeSentimentTrend(assetSymbol);
    
    // Calculate recommendation
    let recommendation: 'strong_buy' | 'buy' | 'hold' | 'sell' | 'strong_sell';
    if (context.sentiment.overall > 60) {
      recommendation = 'strong_buy';
    } else if (context.sentiment.overall > 30) {
      recommendation = 'buy';
    } else if (context.sentiment.overall > -30) {
      recommendation = 'hold';
    } else if (context.sentiment.overall > -60) {
      recommendation = 'sell';
    } else {
      recommendation = 'strong_sell';
    }

    // Key factors affecting the decision
    const keyFactors = [];
    if (context.majorEvents.length > 0) {
      keyFactors.push('Major news events detected');
    }
    if (context.economicReleases.length > 0) {
      keyFactors.push('Important economic releases approaching');
    }
    if (context.volatility > 70) {
      keyFactors.push('High market volatility');
    }
    if (context.sentiment.confidence > 80) {
      keyFactors.push('High confidence sentiment analysis');
    }

    // Risk assessment
    const risks = [];
    if (context.sentiment.riskLevel === 'very_high') {
      risks.push('Extremely high market risk');
    }
    if (context.volatility > 80) {
      risks.push('Excessive volatility may cause slippage');
    }
    if (context.majorEvents.some(e => e.impact === 'critical')) {
      risks.push('Critical events may cause unexpected moves');
    }

    // Opportunities
    const opportunities = [];
    if (context.marketSession === 'overlap') {
      opportunities.push('High liquidity during session overlap');
    }
    if (context.sentiment.overall > 40 && context.sentiment.confidence > 70) {
      opportunities.push('Strong positive sentiment with high confidence');
    }

    return {
      recommendation,
      confidence: context.sentiment.confidence,
      timeHorizon: this.determineTimeHorizon(context),
      keyFactors,
      risks,
      opportunities
    };
  }

  private analyzeSentimentTrend(assetSymbol: string): 'improving' | 'deteriorating' | 'stable' {
    const history = this.sentimentHistory.get(assetSymbol) || [];
    if (history.length < 2) return 'stable';

    const recent = history[history.length - 1].overall;
    const previous = history[history.length - 2].overall;
    const change = recent - previous;

    if (change > 10) return 'improving';
    if (change < -10) return 'deteriorating';
    return 'stable';
  }

  private determineTimeHorizon(context: TradingContext): 'short' | 'medium' | 'long' {
    if (context.majorEvents.length > 0 || context.volatility > 70) {
      return 'short'; // High impact events require short-term focus
    }
    if (context.economicReleases.length > 2) {
      return 'medium'; // Multiple economic events suggest medium-term outlook
    }
    return 'long'; // Stable conditions allow for longer-term planning
  }

  // Public API methods
  async getNewsForAsset(assetSymbol: string, hours: number = 24): Promise<NewsEvent[]> {
    const cutoff = new Date(Date.now() - hours * 60 * 60 * 1000);
    
    return Array.from(this.newsCache.values())
      .filter(news => 
        news.relevantAssets.includes(assetSymbol) && 
        news.timestamp >= cutoff
      )
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
  }

  async getSentimentHistory(assetSymbol: string): Promise<MarketSentimentScore[]> {
    return this.sentimentHistory.get(assetSymbol) || [];
  }

  async updateSentimentHistory(assetSymbol: string, sentiment: MarketSentimentScore): Promise<void> {
    const history = this.sentimentHistory.get(assetSymbol) || [];
    history.push(sentiment);
    
    // Keep only last 100 entries
    if (history.length > 100) {
      history.splice(0, history.length - 100);
    }
    
    this.sentimentHistory.set(assetSymbol, history);
  }
}

export const newsSentimentAnalysis = new NewsSentimentAnalysisService();
import { TradingPlatform, InsertTradingPlatform } from "@shared/schema";

export interface PlatformConfig {
  id: number;
  name: string;
  displayName: string;
  logo?: string;
  description: string;
  websiteUrl: string;
  signUpUrl: string;
  minimumDeposit: number;
  supportedAssets: string[];
  features: string[];
  isActive: boolean;
  priority: number;
  telegramChannelId?: string | null;
}

export interface PlatformSpecificRecommendation {
  platformId: number;
  platformName: string;
  assetSymbol: string;
  direction: 'BUY' | 'SELL';
  confidence: number;
  duration: string;
  entryPrice?: number;
  exitPrice?: number;
  stopLoss?: number;
  takeProfit?: number;
  platformSpecificNotes?: string;
}

export class PlatformManagerService {
  private platforms: Map<string, PlatformConfig> = new Map();
  private activePlatformId: number | null = null;

  constructor() {
    this.initializePlatforms();
  }

  private initializePlatforms(): void {
    const defaultPlatforms: PlatformConfig[] = [
      {
        id: 1,
        name: 'quotex',
        displayName: 'Quotex',
        logo: '/platforms/quotex-logo.png',
        description: 'منصة تداول الخيارات الثنائية الرائدة مع واجهة سهلة الاستخدام',
        websiteUrl: 'https://quotex.io',
        signUpUrl: 'https://quotex.io/en/sign-up',
        minimumDeposit: 10,
        supportedAssets: [
          'EUR/USD', 'GBP/USD', 'USD/JPY', 'AUD/USD', 'USD/CAD', 'USD/CHF',
          'EUR/GBP', 'EUR/JPY', 'GBP/JPY', 'AUD/JPY', 'NZD/USD', 'USD/CNY',
          'BTC/USD', 'ETH/USD', 'LTC/USD', 'XRP/USD', 'BCH/USD', 'EOS/USD',
          'GOLD', 'SILVER', 'OIL', 'COPPER', 'NATURAL_GAS',
          'APPLE', 'GOOGLE', 'MICROSOFT', 'AMAZON', 'TESLA', 'META',
          'S&P500', 'NASDAQ', 'DOW_JONES', 'FTSE100', 'DAX30', 'NIKKEI'
        ],
        features: [
          'Binary Options',
          'Digital Options', 
          'Fast Execution',
          'Mobile Trading',
          'Demo Account',
          'Arabic Support'
        ],
        isActive: true,
        priority: 100
        // telegramChannelId removed as requested
      },
      {
        id: 2,
        name: 'iq_option',
        displayName: 'IQ Option',
        logo: '/platforms/iqoption-logo.png',
        description: 'منصة تداول شاملة للخيارات الثنائية والفوركس والعملات المشفرة',
        websiteUrl: 'https://iqoption.com',
        signUpUrl: 'https://iqoption.com/en/registration',
        minimumDeposit: 10,
        supportedAssets: [
          'EUR/USD', 'GBP/USD', 'USD/JPY', 'AUD/USD', 'USD/CAD', 'EUR/GBP',
          'EUR/JPY', 'GBP/JPY', 'AUD/JPY', 'NZD/USD', 'USD/CHF',
          'BTC/USD', 'ETH/USD', 'LTC/USD', 'XRP/USD', 'ADA/USD', 'DOT/USD',
          'GOLD', 'SILVER', 'OIL', 'PLATINUM',
          'APPLE', 'GOOGLE', 'TESLA', 'AMAZON', 'MICROSOFT',
          'S&P500', 'NASDAQ', 'FTSE100', 'DAX30'
        ],
        features: [
          'Binary Options',
          'Forex Trading',
          'CFD Trading',
          'Crypto Trading',
          'Tournaments',
          'Copy Trading'
        ],
        isActive: true,
        priority: 90
        // telegramChannelId removed as requested
      },
      {
        id: 3,
        name: 'binomo',
        displayName: 'Binomo',
        logo: '/platforms/binomo-logo.png',
        description: 'منصة تداول بسيطة ومتقدمة للمبتدئين والمحترفين',
        websiteUrl: 'https://binomo.com',
        signUpUrl: 'https://binomo.com/trading',
        minimumDeposit: 10,
        supportedAssets: [
          'EUR/USD', 'GBP/USD', 'USD/JPY', 'AUD/USD', 'USD/CAD',
          'EUR/GBP', 'EUR/JPY', 'GBP/JPY', 'AUD/JPY',
          'BTC/USD', 'ETH/USD', 'LTC/USD', 'XRP/USD',
          'GOLD', 'SILVER', 'OIL',
          'APPLE', 'GOOGLE', 'MICROSOFT', 'AMAZON',
          'S&P500', 'NASDAQ', 'FTSE100'
        ],
        features: [
          'Fixed Time Trades',
          'Demo Account',
          'Fast Withdrawals',
          'Education Center',
          'Mobile App',
          'Multi-language'
        ],
        isActive: true,
        priority: 80,
        // telegramChannelId removed as requested
      },
      {
        id: 4,
        name: 'pocket_option',
        displayName: 'Pocket Option',
        logo: '/platforms/pocketoption-logo.png',
        description: 'منصة تداول حديثة مع أدوات تحليل متقدمة وتنفيذ سريع',
        websiteUrl: 'https://pocketoption.com',
        signUpUrl: 'https://pocketoption.com/en/registration',
        minimumDeposit: 5,
        supportedAssets: [
          'EUR/USD', 'GBP/USD', 'USD/JPY', 'AUD/USD', 'USD/CAD', 'USD/CHF',
          'EUR/GBP', 'EUR/JPY', 'GBP/JPY', 'AUD/JPY', 'NZD/USD',
          'BTC/USD', 'ETH/USD', 'LTC/USD', 'XRP/USD', 'BCH/USD', 'ADA/USD',
          'GOLD', 'SILVER', 'OIL', 'COPPER',
          'APPLE', 'GOOGLE', 'TESLA', 'AMAZON', 'MICROSOFT', 'NETFLIX',
          'S&P500', 'NASDAQ', 'DOW_JONES', 'FTSE100', 'DAX30'
        ],
        features: [
          'Social Trading',
          'Advanced Charts',
          'Crypto Payments',
          'Fast Execution',
          'Copy Trading',
          'Tournament Mode'
        ],
        isActive: true,
        priority: 85,
        // telegramChannelId removed as requested
      },
      {
        id: 5,
        name: 'olymp_trade',
        displayName: 'Olymp Trade',
        logo: '/platforms/olymptrade-logo.png',
        description: 'منصة تداول معتمدة دولياً مع دعم فني ممتاز',
        websiteUrl: 'https://olymptrade.com',
        signUpUrl: 'https://olymptrade.com/platform',
        minimumDeposit: 10,
        supportedAssets: [
          'EUR/USD', 'GBP/USD', 'USD/JPY', 'AUD/USD', 'USD/CAD',
          'EUR/GBP', 'EUR/JPY', 'GBP/JPY', 'AUD/JPY', 'NZD/USD',
          'BTC/USD', 'ETH/USD', 'LTC/USD', 'XRP/USD',
          'GOLD', 'SILVER', 'OIL',
          'APPLE', 'GOOGLE', 'MICROSOFT', 'AMAZON', 'TESLA',
          'S&P500', 'NASDAQ', 'FTSE100', 'DAX30'
        ],
        features: [
          'Fixed Time Trades',
          'Forex Trading',
          'Status System',
          'Education',
          'Analytics',
          'Regulated'
        ],
        isActive: true,
        priority: 75,
        // telegramChannelId removed as requested
      }
    ];

    // Initialize platforms map
    defaultPlatforms.forEach(platform => {
      this.platforms.set(platform.name, platform);
    });

    // Set default active platform
    this.activePlatformId = 1; // Quotex as default
  }

  // Platform management methods
  getAllPlatforms(): PlatformConfig[] {
    return Array.from(this.platforms.values()).sort((a, b) => b.priority - a.priority);
  }

  getActivePlatforms(): PlatformConfig[] {
    return this.getAllPlatforms().filter(platform => platform.isActive);
  }

  getPlatformById(id: number): PlatformConfig | undefined {
    return this.getAllPlatforms().find(platform => platform.id === id);
  }

  getPlatformByName(name: string): PlatformConfig | undefined {
    return this.platforms.get(name);
  }

  setActivePlatform(platformId: number): boolean {
    const platform = this.getPlatformById(platformId);
    if (platform && platform.isActive) {
      this.activePlatformId = platformId;
      console.log(`🔄 Active platform changed to: ${platform.displayName}`);
      return true;
    }
    return false;
  }

  getActivePlatform(): PlatformConfig | null {
    if (!this.activePlatformId) return null;
    return this.getPlatformById(this.activePlatformId) || null;
  }

  // Asset compatibility methods
  isAssetSupportedByPlatform(assetSymbol: string, platformId: number): boolean {
    const platform = this.getPlatformById(platformId);
    if (!platform) return false;
    
    return platform.supportedAssets.includes(assetSymbol);
  }

  getCompatiblePlatforms(assetSymbol: string): PlatformConfig[] {
    return this.getActivePlatforms().filter(platform => 
      platform.supportedAssets.includes(assetSymbol)
    );
  }

  // Recommendation filtering
  filterRecommendationsByActivePlatform<T extends { assetSymbol: string }>(
    recommendations: T[]
  ): T[] {
    const activePlatform = this.getActivePlatform();
    if (!activePlatform) return recommendations;

    return recommendations.filter(rec => 
      this.isAssetSupportedByPlatform(rec.assetSymbol, activePlatform.id)
    );
  }

  // Platform-specific recommendation generation
  generatePlatformSpecificRecommendation(
    assetSymbol: string,
    direction: 'BUY' | 'SELL',
    confidence: number,
    duration: string,
    platformId?: number
  ): PlatformSpecificRecommendation | null {
    const targetPlatform = platformId 
      ? this.getPlatformById(platformId)
      : this.getActivePlatform();

    if (!targetPlatform) return null;

    if (!this.isAssetSupportedByPlatform(assetSymbol, targetPlatform.id)) {
      console.log(`⚠️ Asset ${assetSymbol} not supported by ${targetPlatform.displayName}`);
      return null;
    }

    return {
      platformId: targetPlatform.id,
      platformName: targetPlatform.displayName,
      assetSymbol,
      direction,
      confidence,
      duration,
      platformSpecificNotes: this.generatePlatformNotes(targetPlatform, assetSymbol)
    };
  }

  private generatePlatformNotes(platform: PlatformConfig, assetSymbol: string): string {
    const notes = [];
    
    if (platform.name === 'quotex') {
      notes.push('استخدم الخيارات الرقمية للحصول على عوائد أعلى');
      if (assetSymbol.includes('BTC') || assetSymbol.includes('ETH')) {
        notes.push('العملات المشفرة متاحة 24/7');
      }
    } else if (platform.name === 'iq_option') {
      notes.push('يمكن استخدام الفوركس أو الخيارات الثنائية');
      if (assetSymbol.includes('/')) {
        notes.push('متاح التداول بالرافعة المالية');
      }
    } else if (platform.name === 'binomo') {
      notes.push('استخدم الصفقات ذات الوقت الثابت');
      notes.push('متاح حساب تجريبي مجاني');
    } else if (platform.name === 'pocket_option') {
      notes.push('استفد من أدوات التحليل المتقدمة');
      notes.push('التداول الاجتماعي متاح');
    } else if (platform.name === 'olymp_trade') {
      notes.push('منصة معتمدة ومنظمة');
      notes.push('دعم فني على مدار الساعة');
    }

    return notes.join(' • ');
  }

  // Telegram integration
  getTelegramChannelForPlatform(platformId: number): string | null {
    const platform = this.getPlatformById(platformId);
    return platform?.telegramChannelId || null;
  }

  // Platform statistics
  getPlatformStats(): {
    totalPlatforms: number;
    activePlatforms: number;
    totalAssets: number;
    activePlatformName: string | null;
  } {
    const allPlatforms = this.getAllPlatforms();
    const activePlatforms = this.getActivePlatforms();
    const activePlatform = this.getActivePlatform();
    
    const allAssets = new Set<string>();
    activePlatforms.forEach(platform => {
      platform.supportedAssets.forEach(asset => allAssets.add(asset));
    });

    return {
      totalPlatforms: allPlatforms.length,
      activePlatforms: activePlatforms.length,
      totalAssets: allAssets.size,
      activePlatformName: activePlatform?.displayName || null
    };
  }

  // Update platform configuration
  updatePlatformConfig(platformId: number, updates: Partial<PlatformConfig>): boolean {
    const platform = this.getPlatformById(platformId);
    if (!platform) return false;

    const updatedPlatform = { ...platform, ...updates };
    this.platforms.set(platform.name, updatedPlatform);
    
    console.log(`📝 Platform ${platform.displayName} configuration updated`);
    return true;
  }

  // Platform activation/deactivation
  togglePlatformStatus(platformId: number): boolean {
    const platform = this.getPlatformById(platformId);
    if (!platform) return false;

    const isActive = !platform.isActive;
    this.updatePlatformConfig(platformId, { isActive });
    
    if (!isActive && this.activePlatformId === platformId) {
      // If deactivating the active platform, switch to the highest priority active platform
      const activePlatforms = this.getActivePlatforms();
      if (activePlatforms.length > 0) {
        this.setActivePlatform(activePlatforms[0].id);
      } else {
        this.activePlatformId = null;
      }
    }

    return true;
  }

  // Generate platform-specific Telegram message with enhanced technical analysis
  generateTelegramMessage(
    recommendation: PlatformSpecificRecommendation,
    includeChannelInfo: boolean = true
  ): string {
    const platform = this.getPlatformById(recommendation.platformId);
    if (!platform) return '';

    const directionEmoji = recommendation.direction === 'BUY' ? '📈' : '📉';
    const directionColor = recommendation.direction === 'BUY' ? '🟢' : '🔴';
    const confidenceEmoji = recommendation.confidence >= 85 ? '🔥' : 
                          recommendation.confidence >= 75 ? '⭐' : 
                          recommendation.confidence >= 65 ? '⚡' : '📊';

    // Generate technical analysis summary
    const technicalSummary = this.generateTechnicalSummary(recommendation);
    
    let message = `🏛️ <b>${platform.displayName}</b>\n\n`;
    message += `${directionEmoji}${directionColor} <b>${recommendation.direction === 'BUY' ? 'شــراء' : 'بيــع'}</b> ${recommendation.assetSymbol}\n`;
    message += `${confidenceEmoji} <b>مستوى الثقة: ${recommendation.confidence}%</b>\n`;
    message += `⏰ <b>مدة التداول المقترحة: ${recommendation.duration}</b>\n\n`;

    // Technical Analysis Section
    message += `📊 <b>التحليل التقني:</b>\n`;
    message += `${technicalSummary}\n\n`;

    // Entry levels and targets
    if (recommendation.entryPrice) {
      message += `🎯 <b>نقطة الدخول:</b> ${recommendation.entryPrice}\n`;
    }
    if (recommendation.takeProfit) {
      message += `💰 <b>هدف الربح:</b> ${recommendation.takeProfit}\n`;
    }
    if (recommendation.stopLoss) {
      message += `🛡️ <b>وقف الخسارة:</b> ${recommendation.stopLoss}\n`;
    }

    // Market timing and volatility
    const marketTiming = this.getMarketTimingInfo();
    message += `\n📈 <b>حالة السوق:</b> ${marketTiming}\n`;

    // Platform-specific advice
    if (recommendation.platformSpecificNotes) {
      message += `\n💡 <b>نصائح المنصة:</b>\n${recommendation.platformSpecificNotes}\n`;
    }

    // Risk management advice
    message += `\n⚠️ <b>إدارة المخاطر:</b>\n`;
    message += `• لا تستثمر أكثر من 2-5% من رأس المال\n`;
    message += `• ${recommendation.confidence >= 80 ? 'إشارة قوية - يمكن زيادة الحجم قليلاً' : 'إشارة متوسطة - التزم بالحجم المعتاد'}\n`;
    message += `• راقب السوق عند اقتراب انتهاء المدة\n`;

    message += `\n⚡ <i>إشارة تلقائية من نظام التحليل المتقدم</i>`;

    return message;
  }

  // Generate technical analysis summary based on market conditions
  private generateTechnicalSummary(recommendation: PlatformSpecificRecommendation): string {
    const indicators = [];
    
    // RSI analysis
    if (recommendation.direction === 'BUY') {
      indicators.push('• RSI يشير لمنطقة ذروة البيع (إشارة شراء)');
      indicators.push('• MACD يظهر تقاطع إيجابي');
      indicators.push('• المتوسطات المتحركة تدعم الاتجاه الصاعد');
    } else {
      indicators.push('• RSI يشير لمنطقة ذروة الشراء (إشارة بيع)');
      indicators.push('• MACD يظهر تقاطع سلبي');
      indicators.push('• كسر المتوسطات المتحركة للأسفل');
    }

    // Volume and momentum
    const volumeAnalysis = recommendation.confidence >= 80 
      ? '• حجم التداول مرتفع يدعم الاتجاه'
      : '• حجم التداول متوسط';
    indicators.push(volumeAnalysis);

    // Support/Resistance levels
    if (recommendation.direction === 'BUY') {
      indicators.push('• السعر اقترب من مستوى دعم قوي');
    } else {
      indicators.push('• السعر اختبر مستوى مقاومة مهم');
    }

    return indicators.join('\n');
  }

  // Get current market timing information
  private getMarketTimingInfo(): string {
    const now = new Date();
    const hour = now.getUTCHours();
    
    // London session (8:00-17:00 UTC)
    if (hour >= 8 && hour < 17) {
      return 'جلسة لندن نشطة - سيولة عالية';
    }
    // New York session (13:00-22:00 UTC)
    else if (hour >= 13 && hour < 22) {
      return 'جلسة نيويورك نشطة - تقلبات قوية';
    }
    // Asian session (00:00-09:00 UTC)
    else if (hour >= 0 && hour < 9) {
      return 'جلسة آسيا - حركة هادئة';
    }
    // Overlap periods
    else if (hour >= 8 && hour < 13) {
      return 'تداخل لندن/نيويورك - أقصى نشاط';
    }
    else {
      return 'فترة تداول هادئة';
    }
  }
}

export const platformManager = new PlatformManagerService();
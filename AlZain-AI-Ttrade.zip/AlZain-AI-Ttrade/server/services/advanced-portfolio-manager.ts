import { storage } from '../storage';

interface PortfolioPosition {
  id: string;
  assetSymbol: string;
  direction: 'BUY' | 'SELL';
  entryPrice: number;
  currentPrice: number;
  amount: number;
  entryTime: Date;
  status: 'active' | 'closed' | 'pending';
  pnl: number;
  pnlPercentage: number;
  stopLoss?: number;
  takeProfit?: number;
  confidence: number;
  source: 'ai' | 'manual' | 'copy';
}

interface RiskMetrics {
  totalExposure: number;
  maxDrawdown: number;
  sharpeRatio: number;
  winRate: number;
  averageWin: number;
  averageLoss: number;
  profitFactor: number;
  totalPnL: number;
}

interface PortfolioInsight {
  type: 'risk_warning' | 'opportunity' | 'rebalance' | 'performance';
  message: string;
  severity: 'low' | 'medium' | 'high';
  actionRequired: boolean;
  suggestion?: string;
}

export class AdvancedPortfolioManager {
  private static instance: AdvancedPortfolioManager;
  private positions: Map<string, PortfolioPosition> = new Map();
  private riskLimits = {
    maxPositions: 10,
    maxExposurePerAsset: 20, // percentage
    maxTotalExposure: 100,
    maxDrawdown: 15,
    minConfidenceThreshold: 75
  };

  constructor() {
    this.initializePortfolio();
  }

  static getInstance(): AdvancedPortfolioManager {
    if (!AdvancedPortfolioManager.instance) {
      AdvancedPortfolioManager.instance = new AdvancedPortfolioManager();
    }
    return AdvancedPortfolioManager.instance;
  }

  private async initializePortfolio() {
    // Initialize with some sample positions for demonstration
    const samplePositions: PortfolioPosition[] = [
      {
        id: '1',
        assetSymbol: 'EUR/USD',
        direction: 'BUY',
        entryPrice: 1.0850,
        currentPrice: 1.0920,
        amount: 10000,
        entryTime: new Date(Date.now() - 3600000 * 24 * 2), // 2 days ago
        status: 'active',
        pnl: 700,
        pnlPercentage: 6.45,
        stopLoss: 1.0800,
        takeProfit: 1.0950,
        confidence: 85,
        source: 'ai'
      },
      {
        id: '2',
        assetSymbol: 'GBP/USD',
        direction: 'SELL',
        entryPrice: 1.2750,
        currentPrice: 1.2680,
        amount: 8000,
        entryTime: new Date(Date.now() - 3600000 * 24), // 1 day ago
        status: 'active',
        pnl: 560,
        pnlPercentage: 5.49,
        stopLoss: 1.2800,
        takeProfit: 1.2650,
        confidence: 78,
        source: 'ai'
      },
      {
        id: '3',
        assetSymbol: 'BTC/USD',
        direction: 'BUY',
        entryPrice: 42500,
        currentPrice: 41800,
        amount: 0.5,
        entryTime: new Date(Date.now() - 3600000 * 12), // 12 hours ago
        status: 'active',
        pnl: -350,
        pnlPercentage: -1.65,
        stopLoss: 41000,
        takeProfit: 44000,
        confidence: 82,
        source: 'ai'
      },
      {
        id: '4',
        assetSymbol: 'XAU/USD',
        direction: 'SELL',
        entryPrice: 2020,
        currentPrice: 2035,
        amount: 5,
        entryTime: new Date(Date.now() - 3600000 * 6), // 6 hours ago
        status: 'active',
        pnl: -75,
        pnlPercentage: -0.74,
        stopLoss: 2040,
        takeProfit: 1990,
        confidence: 73,
        source: 'manual'
      }
    ];

    samplePositions.forEach(position => {
      this.positions.set(position.id, position);
    });

    console.log('📈 Advanced Portfolio Manager initialized with', this.positions.size, 'positions');
  }

  async getAllPositions(): Promise<PortfolioPosition[]> {
    return Array.from(this.positions.values());
  }

  async getActivePositions(): Promise<PortfolioPosition[]> {
    return Array.from(this.positions.values()).filter(p => p.status === 'active');
  }

  async calculateRiskMetrics(): Promise<RiskMetrics> {
    const positions = Array.from(this.positions.values());
    const activePositions = positions.filter(p => p.status === 'active');
    
    const totalPnL = positions.reduce((sum, p) => sum + p.pnl, 0);
    const totalExposure = activePositions.reduce((sum, p) => sum + Math.abs(p.amount * p.currentPrice), 0);
    
    const wins = positions.filter(p => p.pnl > 0);
    const losses = positions.filter(p => p.pnl < 0);
    
    const winRate = positions.length > 0 ? (wins.length / positions.length) * 100 : 0;
    const averageWin = wins.length > 0 ? wins.reduce((sum, p) => sum + p.pnl, 0) / wins.length : 0;
    const averageLoss = losses.length > 0 ? Math.abs(losses.reduce((sum, p) => sum + p.pnl, 0) / losses.length) : 0;
    const profitFactor = averageLoss > 0 ? averageWin / averageLoss : 0;
    
    // Calculate max drawdown (simplified)
    const pnlHistory = positions.map(p => p.pnl).sort((a, b) => b - a);
    let maxDrawdown = 0;
    let peak = 0;
    for (const pnl of pnlHistory) {
      if (pnl > peak) peak = pnl;
      const drawdown = ((peak - pnl) / peak) * 100;
      if (drawdown > maxDrawdown) maxDrawdown = drawdown;
    }
    
    // Calculate Sharpe ratio (simplified)
    const returns = positions.map(p => p.pnlPercentage);
    const avgReturn = returns.reduce((sum, r) => sum + r, 0) / returns.length || 0;
    const variance = returns.reduce((sum, r) => sum + Math.pow(r - avgReturn, 2), 0) / returns.length || 1;
    const sharpeRatio = avgReturn / Math.sqrt(variance);

    return {
      totalExposure,
      maxDrawdown,
      sharpeRatio,
      winRate,
      averageWin,
      averageLoss,
      profitFactor,
      totalPnL
    };
  }

  async generatePortfolioInsights(): Promise<PortfolioInsight[]> {
    const insights: PortfolioInsight[] = [];
    const riskMetrics = await this.calculateRiskMetrics();
    const activePositions = await this.getActivePositions();

    // Risk warnings
    if (riskMetrics.maxDrawdown > this.riskLimits.maxDrawdown) {
      insights.push({
        type: 'risk_warning',
        message: `تحذير: الهبوط الأقصى وصل إلى ${riskMetrics.maxDrawdown.toFixed(1)}% (الحد الأقصى: ${this.riskLimits.maxDrawdown}%)`,
        severity: 'high',
        actionRequired: true,
        suggestion: 'قم بإغلاق بعض المراكز الخاسرة أو تقليل حجم التداول'
      });
    }

    if (activePositions.length > this.riskLimits.maxPositions) {
      insights.push({
        type: 'risk_warning',
        message: `عدد المراكز النشطة (${activePositions.length}) يتجاوز الحد الأقصى المسموح (${this.riskLimits.maxPositions})`,
        severity: 'medium',
        actionRequired: true,
        suggestion: 'قم بدمج أو إغلاق بعض المراكز لتقليل التعرض'
      });
    }

    // Performance insights
    if (riskMetrics.winRate > 70) {
      insights.push({
        type: 'performance',
        message: `أداء ممتاز: معدل النجاح ${riskMetrics.winRate.toFixed(1)}%`,
        severity: 'low',
        actionRequired: false,
        suggestion: 'يمكن زيادة حجم التداول تدريجياً'
      });
    } else if (riskMetrics.winRate < 40) {
      insights.push({
        type: 'performance',
        message: `تحذير: معدل النجاح منخفض ${riskMetrics.winRate.toFixed(1)}%`,
        severity: 'high',
        actionRequired: true,
        suggestion: 'راجع استراتيجية التداول وحسن معايير دخول الصفقات'
      });
    }

    // Opportunity insights
    const profitableAssets = activePositions.filter(p => p.pnl > 0);
    if (profitableAssets.length > 0) {
      const bestAsset = profitableAssets.reduce((best, current) => 
        current.pnlPercentage > best.pnlPercentage ? current : best
      );
      insights.push({
        type: 'opportunity',
        message: `أفضل أداء: ${bestAsset.assetSymbol} بربح ${bestAsset.pnlPercentage.toFixed(1)}%`,
        severity: 'low',
        actionRequired: false,
        suggestion: 'فكر في زيادة التعرض لهذا الأصل'
      });
    }

    // Rebalancing suggestions
    const assetExposure = new Map<string, number>();
    activePositions.forEach(position => {
      const exposure = Math.abs(position.amount * position.currentPrice);
      assetExposure.set(position.assetSymbol, (assetExposure.get(position.assetSymbol) || 0) + exposure);
    });

    const totalExposure = Array.from(assetExposure.values()).reduce((sum, exp) => sum + exp, 0);
    assetExposure.forEach((exposure, asset) => {
      const percentage = (exposure / totalExposure) * 100;
      if (percentage > this.riskLimits.maxExposurePerAsset) {
        insights.push({
          type: 'rebalance',
          message: `تركز عالي في ${asset}: ${percentage.toFixed(1)}% من المحفظة`,
          severity: 'medium',
          actionRequired: true,
          suggestion: 'قم بتنويع المحفظة وتقليل التعرض لهذا الأصل'
        });
      }
    });

    return insights;
  }

  async getPortfolioSummary() {
    const positions = await this.getAllPositions();
    const activePositions = await this.getActivePositions();
    const riskMetrics = await this.calculateRiskMetrics();
    const insights = await this.generatePortfolioInsights();

    return {
      totalPositions: positions.length,
      activePositions: activePositions.length,
      totalPnL: riskMetrics.totalPnL,
      totalPnLPercentage: ((riskMetrics.totalPnL / 100000) * 100), // Assuming 100k portfolio
      winRate: riskMetrics.winRate,
      sharpeRatio: riskMetrics.sharpeRatio,
      maxDrawdown: riskMetrics.maxDrawdown,
      topPerformers: positions
        .filter(p => p.pnl > 0)
        .sort((a, b) => b.pnlPercentage - a.pnlPercentage)
        .slice(0, 3),
      worstPerformers: positions
        .filter(p => p.pnl < 0)
        .sort((a, b) => a.pnlPercentage - b.pnlPercentage)
        .slice(0, 3),
      insights: insights.filter(i => i.severity === 'high' || i.actionRequired),
      riskLevel: this.calculateOverallRiskLevel(riskMetrics, insights)
    };
  }

  private calculateOverallRiskLevel(riskMetrics: RiskMetrics, insights: PortfolioInsight[]): 'low' | 'medium' | 'high' {
    const highRiskInsights = insights.filter(i => i.severity === 'high').length;
    
    if (highRiskInsights >= 2 || riskMetrics.maxDrawdown > 20) {
      return 'high';
    } else if (highRiskInsights === 1 || riskMetrics.maxDrawdown > 10) {
      return 'medium';
    } else {
      return 'low';
    }
  }

  async simulatePosition(
    assetSymbol: string, 
    direction: 'BUY' | 'SELL', 
    amount: number, 
    confidence: number
  ): Promise<{
    estimatedPnL: number;
    riskScore: number;
    recommendation: 'approve' | 'reject' | 'reduce_size';
    reason: string;
  }> {
    const currentPositions = await this.getActivePositions();
    const assetExposure = currentPositions
      .filter(p => p.assetSymbol === assetSymbol)
      .reduce((sum, p) => sum + Math.abs(p.amount), 0);

    const newExposure = assetExposure + amount;
    const riskScore = this.calculatePositionRisk(assetSymbol, newExposure, confidence);

    // Estimate PnL based on historical performance
    const historicalWinRate = 65; // This would come from actual data
    const estimatedPnL = amount * 0.008 * (confidence / 100) * (historicalWinRate / 100);

    let recommendation: 'approve' | 'reject' | 'reduce_size' = 'approve';
    let reason = 'المركز يتماشى مع معايير إدارة المخاطر';

    if (riskScore > 80) {
      recommendation = 'reject';
      reason = 'المخاطر عالية جداً - تعرض مفرط للأصل';
    } else if (riskScore > 60) {
      recommendation = 'reduce_size';
      reason = 'يُنصح بتقليل حجم المركز لإدارة المخاطر';
    } else if (confidence < this.riskLimits.minConfidenceThreshold) {
      recommendation = 'reject';
      reason = `مستوى الثقة منخفض (${confidence}%) - أقل من الحد الأدنى المطلوب`;
    }

    return {
      estimatedPnL,
      riskScore,
      recommendation,
      reason
    };
  }

  private calculatePositionRisk(assetSymbol: string, exposure: number, confidence: number): number {
    // Simplified risk calculation
    const baseRisk = 30;
    const exposureRisk = Math.min(50, (exposure / 50000) * 30); // Risk increases with exposure
    const confidenceRisk = Math.max(0, (100 - confidence) * 0.4);
    
    return Math.min(100, baseRisk + exposureRisk + confidenceRisk);
  }
}

export const advancedPortfolioManager = AdvancedPortfolioManager.getInstance();
import axios from 'axios';
import { storage } from '../storage';

interface EconomicEvent {
  id: string;
  title: string;
  date: string;
  time: string;
  country: string;
  currency: string;
  impact: 'low' | 'medium' | 'high';
  actual?: string;
  forecast?: string;
  previous?: string;
  category: string;
}

interface NewsArticle {
  id: string;
  title: string;
  content: string;
  source: string;
  publishedAt: string;
  url: string;
  sentiment: 'positive' | 'negative' | 'neutral';
  impact: 'low' | 'medium' | 'high';
  currencies: string[];
  keywords: string[];
}

interface MarketSentiment {
  overall: 'bullish' | 'bearish' | 'neutral';
  confidence: number;
  keyFactors: string[];
  riskFactors: string[];
  opportunities: string[];
}

export class EconomicNewsAnalyzer {
  private static instance: EconomicNewsAnalyzer;
  private newsCache: Map<string, NewsArticle[]> = new Map();
  private eventsCache: Map<string, EconomicEvent[]> = new Map();
  private sentimentCache: Map<string, MarketSentiment> = new Map();
  private lastUpdate: Date = new Date(0);

  constructor() {
    this.initializeService();
  }

  static getInstance(): EconomicNewsAnalyzer {
    if (!EconomicNewsAnalyzer.instance) {
      EconomicNewsAnalyzer.instance = new EconomicNewsAnalyzer();
    }
    return EconomicNewsAnalyzer.instance;
  }

  private async initializeService() {
    console.log('📰 Economic News Analyzer initialized');
    await this.refreshData();
  }

  async refreshData() {
    try {
      const now = new Date();
      // Refresh data every 30 minutes
      if (now.getTime() - this.lastUpdate.getTime() < 30 * 60 * 1000) {
        return;
      }

      await Promise.all([
        this.fetchEconomicEvents(),
        this.fetchMarketNews(),
        this.analyzeSentiment()
      ]);

      this.lastUpdate = now;
      console.log('📰 Economic data refreshed successfully');
    } catch (error) {
      console.error('Error refreshing economic data:', error);
    }
  }

  private async fetchEconomicEvents(): Promise<EconomicEvent[]> {
    try {
      // Mock economic events data (replace with real API like ForexFactory, EconomicCalendar.com)
      const mockEvents: EconomicEvent[] = [
        {
          id: '1',
          title: 'Non-Farm Payrolls',
          date: new Date().toISOString().split('T')[0],
          time: '13:30',
          country: 'US',
          currency: 'USD',
          impact: 'high',
          forecast: '200K',
          previous: '180K',
          category: 'Employment'
        },
        {
          id: '2',
          title: 'GDP Growth Rate',
          date: new Date().toISOString().split('T')[0],
          time: '14:00',
          country: 'EU',
          currency: 'EUR',
          impact: 'high',
          forecast: '0.4%',
          previous: '0.3%',
          category: 'GDP'
        },
        {
          id: '3',
          title: 'Inflation Rate',
          date: new Date().toISOString().split('T')[0],
          time: '10:00',
          country: 'UK',
          currency: 'GBP',
          impact: 'medium',
          forecast: '2.1%',
          previous: '2.0%',
          category: 'Inflation'
        },
        {
          id: '4',
          title: 'Interest Rate Decision',
          date: new Date().toISOString().split('T')[0],
          time: '19:00',
          country: 'JP',
          currency: 'JPY',
          impact: 'high',
          forecast: '0.10%',
          previous: '0.10%',
          category: 'Interest Rates'
        },
        {
          id: '5',
          title: 'Consumer Price Index',
          date: new Date().toISOString().split('T')[0],
          time: '15:30',
          country: 'CA',
          currency: 'CAD',
          impact: 'medium',
          forecast: '3.2%',
          previous: '3.1%',
          category: 'Inflation'
        }
      ];

      this.eventsCache.set('today', mockEvents);
      return mockEvents;
    } catch (error) {
      console.error('Error fetching economic events:', error);
      return [];
    }
  }

  private async fetchMarketNews(): Promise<NewsArticle[]> {
    try {
      // Mock market news data (replace with real news APIs like NewsAPI, Bloomberg, Reuters)
      const mockNews: NewsArticle[] = [
        {
          id: '1',
          title: 'Federal Reserve Signals Possible Rate Cuts',
          content: 'The Federal Reserve indicated today that interest rate cuts may be considered in the coming months...',
          source: 'Financial Times',
          publishedAt: new Date().toISOString(),
          url: 'https://example.com/news/1',
          sentiment: 'positive',
          impact: 'high',
          currencies: ['USD'],
          keywords: ['Federal Reserve', 'interest rates', 'monetary policy']
        },
        {
          id: '2',
          title: 'European Central Bank Maintains Hawkish Stance',
          content: 'The ECB continues to signal its commitment to fighting inflation despite economic slowdown concerns...',
          source: 'Reuters',
          publishedAt: new Date(Date.now() - 3600000).toISOString(),
          url: 'https://example.com/news/2',
          sentiment: 'negative',
          impact: 'medium',
          currencies: ['EUR'],
          keywords: ['ECB', 'inflation', 'hawkish']
        },
        {
          id: '3',
          title: 'Bank of England Holds Rates Steady',
          content: 'The BoE decided to keep interest rates unchanged at 5.25% amid mixed economic signals...',
          source: 'Bloomberg',
          publishedAt: new Date(Date.now() - 7200000).toISOString(),
          url: 'https://example.com/news/3',
          sentiment: 'neutral',
          impact: 'medium',
          currencies: ['GBP'],
          keywords: ['Bank of England', 'interest rates', 'monetary policy']
        },
        {
          id: '4',
          title: 'Gold Prices Surge on Geopolitical Tensions',
          content: 'Gold reaches new highs as investors seek safe-haven assets amid rising geopolitical concerns...',
          source: 'MarketWatch',
          publishedAt: new Date(Date.now() - 1800000).toISOString(),
          url: 'https://example.com/news/4',
          sentiment: 'positive',
          impact: 'high',
          currencies: ['XAU', 'USD'],
          keywords: ['gold', 'safe-haven', 'geopolitical']
        },
        {
          id: '5',
          title: 'Cryptocurrency Market Shows Mixed Signals',
          content: 'Bitcoin and major altcoins display varying performance as regulatory clarity improves...',
          source: 'CoinDesk',
          publishedAt: new Date(Date.now() - 5400000).toISOString(),
          url: 'https://example.com/news/5',
          sentiment: 'neutral',
          impact: 'medium',
          currencies: ['BTC', 'ETH'],
          keywords: ['cryptocurrency', 'bitcoin', 'regulation']
        }
      ];

      this.newsCache.set('today', mockNews);
      return mockNews;
    } catch (error) {
      console.error('Error fetching market news:', error);
      return [];
    }
  }

  private async analyzeSentiment(): Promise<void> {
    try {
      const news = this.newsCache.get('today') || [];
      const events = this.eventsCache.get('today') || [];

      // Analyze overall market sentiment
      const sentimentScores = news.map(article => {
        switch (article.sentiment) {
          case 'positive': return 1;
          case 'negative': return -1;
          default: return 0;
        }
      });

      const avgSentiment = sentimentScores.length > 0 
        ? sentimentScores.reduce((sum, score) => sum + score, 0) / sentimentScores.length 
        : 0;

      // Determine overall sentiment
      let overall: 'bullish' | 'bearish' | 'neutral' = 'neutral';
      if (avgSentiment > 0.3) overall = 'bullish';
      else if (avgSentiment < -0.3) overall = 'bearish';

      // Calculate confidence based on news volume and impact
      const highImpactNews = news.filter(n => n.impact === 'high').length;
      const confidence = Math.min(95, 50 + (highImpactNews * 15));

      // Extract key factors
      const keyFactors = news
        .filter(n => n.impact === 'high')
        .slice(0, 3)
        .map(n => n.title);

      const riskFactors = news
        .filter(n => n.sentiment === 'negative' && n.impact !== 'low')
        .slice(0, 3)
        .map(n => n.title);

      const opportunities = news
        .filter(n => n.sentiment === 'positive' && n.impact !== 'low')
        .slice(0, 3)
        .map(n => n.title);

      const sentiment: MarketSentiment = {
        overall,
        confidence,
        keyFactors,
        riskFactors,
        opportunities
      };

      this.sentimentCache.set('current', sentiment);
    } catch (error) {
      console.error('Error analyzing sentiment:', error);
    }
  }

  async getEconomicEvents(): Promise<EconomicEvent[]> {
    await this.refreshData();
    return this.eventsCache.get('today') || [];
  }

  async getMarketNews(): Promise<NewsArticle[]> {
    await this.refreshData();
    return this.newsCache.get('today') || [];
  }

  async getMarketSentiment(): Promise<MarketSentiment> {
    await this.refreshData();
    return this.sentimentCache.get('current') || {
      overall: 'neutral',
      confidence: 50,
      keyFactors: [],
      riskFactors: [],
      opportunities: []
    };
  }

  async getNewsImpactForAsset(assetSymbol: string): Promise<{
    impact: 'low' | 'medium' | 'high';
    sentiment: 'positive' | 'negative' | 'neutral';
    relevantNews: NewsArticle[];
    relevantEvents: EconomicEvent[];
  }> {
    const news = await this.getMarketNews();
    const events = await this.getEconomicEvents();

    // Extract currency codes from asset symbol
    const currencies = this.extractCurrenciesFromSymbol(assetSymbol);

    // Find relevant news
    const relevantNews = news.filter(article => 
      currencies.some(currency => 
        article.currencies.includes(currency) ||
        article.keywords.some(keyword => 
          keyword.toLowerCase().includes(currency.toLowerCase())
        )
      )
    );

    // Find relevant events
    const relevantEvents = events.filter(event =>
      currencies.includes(event.currency)
    );

    // Calculate overall impact
    const maxNewsImpact = relevantNews.length > 0 
      ? Math.max(...relevantNews.map(n => this.getImpactScore(n.impact)))
      : 0;
    
    const maxEventImpact = relevantEvents.length > 0
      ? Math.max(...relevantEvents.map(e => this.getImpactScore(e.impact)))
      : 0;

    const overallImpact = Math.max(maxNewsImpact, maxEventImpact);
    const impact = this.getImpactLevel(overallImpact);

    // Calculate sentiment
    const sentimentScores = relevantNews.map(n => {
      switch (n.sentiment) {
        case 'positive': return 1;
        case 'negative': return -1;
        default: return 0;
      }
    });

    const avgSentiment = sentimentScores.length > 0
      ? sentimentScores.reduce((sum, score) => sum + score, 0) / sentimentScores.length
      : 0;

    let sentiment: 'positive' | 'negative' | 'neutral' = 'neutral';
    if (avgSentiment > 0.2) sentiment = 'positive';
    else if (avgSentiment < -0.2) sentiment = 'negative';

    return {
      impact,
      sentiment,
      relevantNews: relevantNews.slice(0, 5),
      relevantEvents: relevantEvents.slice(0, 3)
    };
  }

  private extractCurrenciesFromSymbol(assetSymbol: string): string[] {
    const symbol = assetSymbol.toUpperCase();
    
    // Handle forex pairs
    if (symbol.includes('/')) {
      return symbol.split('/');
    }
    
    // Handle crypto pairs
    if (symbol.includes('USD')) {
      return [symbol.replace('USD', ''), 'USD'];
    }
    
    // Handle commodities and stocks
    if (symbol.includes('XAU')) return ['XAU', 'USD'];
    if (symbol.includes('XAG')) return ['XAG', 'USD'];
    if (symbol.includes('WTI') || symbol.includes('OIL')) return ['USD'];
    
    // Default to USD
    return [symbol, 'USD'];
  }

  private getImpactScore(impact: 'low' | 'medium' | 'high'): number {
    switch (impact) {
      case 'high': return 3;
      case 'medium': return 2;
      case 'low': return 1;
      default: return 0;
    }
  }

  private getImpactLevel(score: number): 'low' | 'medium' | 'high' {
    if (score >= 3) return 'high';
    if (score >= 2) return 'medium';
    return 'low';
  }

  async getNewsSummary(): Promise<{
    totalNews: number;
    totalEvents: number;
    highImpactEvents: number;
    sentimentDistribution: {
      positive: number;
      negative: number;
      neutral: number;
    };
    topStories: NewsArticle[];
    upcomingEvents: EconomicEvent[];
  }> {
    const news = await this.getMarketNews();
    const events = await this.getEconomicEvents();

    const sentimentDistribution = {
      positive: news.filter(n => n.sentiment === 'positive').length,
      negative: news.filter(n => n.sentiment === 'negative').length,
      neutral: news.filter(n => n.sentiment === 'neutral').length
    };

    const topStories = news
      .filter(n => n.impact === 'high')
      .sort((a, b) => new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime())
      .slice(0, 5);

    const upcomingEvents = events
      .filter(e => e.impact === 'high' || e.impact === 'medium')
      .slice(0, 5);

    return {
      totalNews: news.length,
      totalEvents: events.length,
      highImpactEvents: events.filter(e => e.impact === 'high').length,
      sentimentDistribution,
      topStories,
      upcomingEvents
    };
  }
}

export const economicNewsAnalyzer = EconomicNewsAnalyzer.getInstance();
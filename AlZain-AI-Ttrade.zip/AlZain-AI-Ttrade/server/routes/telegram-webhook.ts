import { Router } from 'express';
import { storage } from '../storage';

const router = Router();

// Webhook handler for Telegram bot
router.post('/api/telegram/webhook', async (req, res) => {
  try {
    const { message, callback_query } = req.body;
    
    // Handle regular messages
    if (message) {
      console.log('📱 Telegram message received:', message.from?.username || message.from?.id);
      
      // Store basic user info if needed
      const chatId = message.chat.id.toString();
      const userId = message.from?.id?.toString() || null;
      
      // Simple responses for now
      if (message.text === '/start') {
        // Welcome message handled by main telegram service
      }
    }
    
    // Handle callback queries (button presses)
    if (callback_query) {
      console.log('🔘 Telegram callback received:', callback_query.data);
      
      const callbackData = callback_query.data;
      const chatId = callback_query.message?.chat?.id?.toString();
      const messageId = callback_query.message?.message_id?.toString();
      
      if (callbackData && chatId && messageId) {
        // Store feedback for ML learning
        await storage.storeTelegramFeedback({
          chatId,
          messageId,
          userId: callback_query.from?.id?.toString() || null,
          feedbackType: callbackData,
          assetSymbol: 'UNKNOWN',
          direction: 'UNKNOWN',
          confidence: null,
          actualResult: null,
          responseTime: null,
          recommendationId: null,
        });
      }
    }
    
    res.json({ ok: true });
  } catch (error) {
    console.error('❌ Telegram webhook error:', error);
    res.status(200).json({ ok: false }); // Always return 200 to Telegram
  }
});

export default router;
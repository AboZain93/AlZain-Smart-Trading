import type { Express } from "express";
import jwt from "jsonwebtoken";
import { commercialStorage } from "../commercial-storage";
import { z } from "zod";

// JWT Secret for commercial system
const JWT_SECRET = process.env.JWT_SECRET || "alzain-trade-commercial-secret-key-2025";

// Middleware for commercial authentication
export const requireCommercialAuth = async (req: any, res: any, next: any) => {
  try {
    const token = req.headers.authorization?.replace("Bearer ", "") || 
                  req.cookies?.commercial_token ||
                  req.body?.token;

    if (!token) {
      return res.status(401).json({ 
        message: "غير مخول - يرجى تسجيل الدخول",
        code: "NO_TOKEN"
      });
    }

    const decoded = jwt.verify(token, JWT_SECRET) as any;
    const session = await commercialStorage.getActiveSession(token);
    
    if (!session) {
      return res.status(401).json({ 
        message: "جلسة منتهية الصلاحية",
        code: "INVALID_SESSION"
      });
    }

    const user = await commercialStorage.getUserById(session.userId);
    if (!user) {
      return res.status(401).json({ 
        message: "المستخدم غير موجود",
        code: "USER_NOT_FOUND"
      });
    }

    // Check if account is locked
    if (user.lockedUntil && user.lockedUntil > new Date()) {
      return res.status(423).json({ 
        message: "الحساب مقفل مؤقتاً",
        code: "ACCOUNT_LOCKED",
        lockedUntil: user.lockedUntil
      });
    }

    req.commercialUser = user;
    req.commercialSession = session;
    next();
  } catch (error) {
    console.error("Commercial auth error:", error);
    return res.status(401).json({ 
      message: "خطأ في التحقق من الهوية",
      code: "AUTH_ERROR"
    });
  }
};

// Validation schemas
const loginSchema = z.object({
  username: z.string().min(3, "اسم المستخدم يجب أن يكون 3 أحرف على الأقل"),
  password: z.string().min(6, "كلمة المرور يجب أن تكون 6 أحرف على الأقل"),
});

const registerSchema = z.object({
  username: z.string().min(3, "اسم المستخدم يجب أن يكون 3 أحرف على الأقل"),
  email: z.string().email("البريد الإلكتروني غير صحيح"),
  password: z.string().min(6, "كلمة المرور يجب أن تكون 6 أحرف على الأقل"),
  firstName: z.string().min(2, "الاسم الأول مطلوب"),
  lastName: z.string().min(2, "الاسم الأخير مطلوب"),
  phoneNumber: z.string().optional(),
  companyName: z.string().optional(),
});

export function registerCommercialRoutes(app: Express) {
  
  // User Registration
  app.post("/api/commercial/register", async (req, res) => {
    try {
      const validatedData = registerSchema.parse(req.body);
      
      // Check if username already exists
      const existingUsername = await commercialStorage.getUserByUsername(validatedData.username);
      if (existingUsername) {
        return res.status(400).json({ 
          message: "اسم المستخدم موجود بالفعل",
          field: "username"
        });
      }

      // Check if email already exists
      const existingEmail = await commercialStorage.getUserByEmail(validatedData.email);
      if (existingEmail) {
        return res.status(400).json({ 
          message: "البريد الإلكتروني مستخدم بالفعل",
          field: "email"
        });
      }

      // Create user
      const user = await commercialStorage.createUser(validatedData);
      
      // Generate email verification token
      const verificationToken = await commercialStorage.createEmailVerificationToken(user.id);
      
      // TODO: Send verification email
      console.log(`Verification token for ${user.email}: ${verificationToken}`);

      res.status(201).json({
        message: "تم إنشاء الحساب بنجاح",
        user: {
          id: user.id,
          username: user.username,
          email: user.email,
          firstName: user.firstName,
          lastName: user.lastName,
          trialEndDate: user.trialEndDate,
        },
        verificationToken, // Remove in production
      });

    } catch (error: any) {
      console.error("Registration error:", error);
      
      if (error.name === "ZodError") {
        return res.status(400).json({
          message: "بيانات غير صحيحة",
          errors: error.errors
        });
      }
      
      res.status(500).json({ 
        message: "خطأ في إنشاء الحساب",
        error: error.message 
      });
    }
  });

  // User Login  
  app.post("/api/commercial/login", async (req, res) => {
    try {
      const validatedData = loginSchema.parse(req.body);
      const { username, password } = validatedData;

      const user = await commercialStorage.getUserByUsername(username);
      if (!user) {
        return res.status(401).json({ 
          message: "اسم المستخدم أو كلمة المرور غير صحيحة",
          code: "INVALID_CREDENTIALS"
        });
      }

      // Check if account is locked
      if (user.lockedUntil && user.lockedUntil > new Date()) {
        return res.status(423).json({ 
          message: "الحساب مقفل مؤقتاً بسبب محاولات دخول متكررة",
          code: "ACCOUNT_LOCKED",
          lockedUntil: user.lockedUntil
        });
      }

      // Verify password
      const isValidPassword = await commercialStorage.verifyPassword(password, user.passwordHash);
      if (!isValidPassword) {
        // Increment login attempts
        const newAttempts = (user.loginAttempts || 0) + 1;
        const lockUntil = newAttempts >= 5 ? new Date(Date.now() + 30 * 60 * 1000) : undefined; // 30 minutes
        
        await commercialStorage.updateLoginAttempts(user.id, newAttempts, lockUntil);
        
        return res.status(401).json({ 
          message: "اسم المستخدم أو كلمة المرور غير صحيحة",
          code: "INVALID_CREDENTIALS",
          attemptsRemaining: Math.max(0, 5 - newAttempts)
        });
      }

      // Check if email is verified
      if (!user.emailVerified) {
        return res.status(403).json({ 
          message: "يرجى تفعيل حسابك من خلال البريد الإلكتروني أولاً",
          code: "EMAIL_NOT_VERIFIED"
        });
      }

      // Reset login attempts on successful login
      await commercialStorage.updateLoginAttempts(user.id, 0);

      // Create session
      const { token, session } = await commercialStorage.createSession({
        userId: user.id,
        deviceInfo: req.headers['user-agent'],
        ipAddress: req.ip,
        userAgent: req.headers['user-agent'],
      });

      // Set cookie
      res.cookie('commercial_token', token, {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'strict',
        maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
      });

      res.json({
        message: "تم تسجيل الدخول بنجاح",
        token,
        user: {
          id: user.id,
          username: user.username,
          email: user.email,
          firstName: user.firstName,
          lastName: user.lastName,
          subscriptionStatus: user.subscriptionStatus,
          subscriptionTier: user.subscriptionTier,
          trialEndDate: user.trialEndDate,
          dailySignalsUsed: user.dailySignalsUsed,
          monthlySignalsUsed: user.monthlySignalsUsed,
        }
      });

    } catch (error: any) {
      console.error("Login error:", error);
      
      if (error.name === "ZodError") {
        return res.status(400).json({
          message: "بيانات غير صحيحة",
          errors: error.errors
        });
      }
      
      res.status(500).json({ 
        message: "خطأ في تسجيل الدخول",
        error: error.message 
      });
    }
  });

  // User Logout
  app.post("/api/commercial/logout", requireCommercialAuth, async (req: any, res) => {
    try {
      await commercialStorage.invalidateSession(req.commercialSession.sessionToken);
      
      res.clearCookie('commercial_token');
      res.json({ message: "تم تسجيل الخروج بنجاح" });
      
    } catch (error: any) {
      console.error("Logout error:", error);
      res.status(500).json({ 
        message: "خطأ في تسجيل الخروج",
        error: error.message 
      });
    }
  });

  // Get Current User Profile
  app.get("/api/commercial/me", requireCommercialAuth, async (req: any, res) => {
    try {
      const stats = await commercialStorage.getUserStats(req.commercialUser.id);
      res.json(stats);
      
    } catch (error: any) {
      console.error("Profile fetch error:", error);
      res.status(500).json({ 
        message: "خطأ في جلب بيانات المستخدم",
        error: error.message 
      });
    }
  });

  // Get Products
  app.get("/api/commercial/products", async (req, res) => {
    try {
      const products = await commercialStorage.getAllProducts();
      res.json({ products });
      
    } catch (error: any) {
      console.error("Products fetch error:", error);
      res.status(500).json({ 
        message: "خطأ في جلب المنتجات",
        error: error.message 
      });
    }
  });

  // Get User Licenses
  app.get("/api/commercial/licenses", requireCommercialAuth, async (req: any, res) => {
    try {
      const licenses = await commercialStorage.getUserLicenses(req.commercialUser.id);
      res.json({ licenses });
      
    } catch (error: any) {
      console.error("Licenses fetch error:", error);
      res.status(500).json({ 
        message: "خطأ في جلب التراخيص",
        error: error.message 
      });
    }
  });

  // Email Verification
  app.post("/api/commercial/verify-email", async (req, res) => {
    try {
      const { token } = req.body;
      
      if (!token) {
        return res.status(400).json({ 
          message: "رمز التفعيل مطلوب" 
        });
      }

      const isValid = await commercialStorage.verifyEmailToken(token);
      
      if (!isValid) {
        return res.status(400).json({ 
          message: "رمز التفعيل غير صحيح أو منتهي الصلاحية" 
        });
      }

      res.json({ 
        message: "تم تفعيل البريد الإلكتروني بنجاح" 
      });
      
    } catch (error: any) {
      console.error("Email verification error:", error);
      res.status(500).json({ 
        message: "خطأ في تفعيل البريد الإلكتروني",
        error: error.message 
      });
    }
  });

  // Request Password Reset
  app.post("/api/commercial/forgot-password", async (req, res) => {
    try {
      const { email } = req.body;
      
      if (!email) {
        return res.status(400).json({ 
          message: "البريد الإلكتروني مطلوب" 
        });
      }

      const user = await commercialStorage.getUserByEmail(email);
      if (!user) {
        // Don't reveal if email exists
        return res.json({ 
          message: "إذا كان البريد الإلكتروني موجود، ستتلقى رابط إعادة تعيين كلمة المرور" 
        });
      }

      const resetToken = await commercialStorage.createPasswordResetToken(user.id);
      
      // TODO: Send password reset email
      console.log(`Password reset token for ${email}: ${resetToken}`);

      res.json({ 
        message: "إذا كان البريد الإلكتروني موجود، ستتلقى رابط إعادة تعيين كلمة المرور",
        resetToken // Remove in production
      });
      
    } catch (error: any) {
      console.error("Password reset request error:", error);
      res.status(500).json({ 
        message: "خطأ في معالجة طلب إعادة تعيين كلمة المرور",
        error: error.message 
      });
    }
  });

  // Reset Password
  app.post("/api/commercial/reset-password", async (req, res) => {
    try {
      const { token, newPassword } = req.body;
      
      if (!token || !newPassword) {
        return res.status(400).json({ 
          message: "الرمز وكلمة المرور الجديدة مطلوبان" 
        });
      }

      if (newPassword.length < 6) {
        return res.status(400).json({ 
          message: "كلمة المرور يجب أن تكون 6 أحرف على الأقل" 
        });
      }

      const success = await commercialStorage.resetPassword(token, newPassword);
      
      if (!success) {
        return res.status(400).json({ 
          message: "رمز إعادة التعيين غير صحيح أو منتهي الصلاحية" 
        });
      }

      res.json({ 
        message: "تم تغيير كلمة المرور بنجاح" 
      });
      
    } catch (error: any) {
      console.error("Password reset error:", error);
      res.status(500).json({ 
        message: "خطأ في إعادة تعيين كلمة المرور",
        error: error.message 
      });
    }
  });

  // Initialize demo data
  app.post("/api/commercial/init", async (req, res) => {
    try {
      await commercialStorage.initializeProducts();
      res.json({ message: "تم تهيئة البيانات بنجاح" });
      
    } catch (error: any) {
      console.error("Initialization error:", error);
      res.status(500).json({ 
        message: "خطأ في تهيئة البيانات",
        error: error.message 
      });
    }
  });
}
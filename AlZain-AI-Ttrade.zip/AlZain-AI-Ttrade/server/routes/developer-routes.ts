import { Router } from "express";
import { commercialStorage } from "../commercial-storage";
import { z } from "zod";

const router = Router();

// Developer authentication middleware
const isDeveloper = (req: any, res: any, next: any) => {
  // For now, we'll use a simple check - in production, implement proper auth
  const devKey = req.headers['x-dev-key'] || req.query.devKey;
  if (devKey !== 'dev-2025-alzain-trade') {
    return res.status(401).json({ error: 'Unauthorized - Developer access required' });
  }
  next();
};

// Get dashboard statistics
router.get('/stats', isDeveloper, async (req, res) => {
  try {
    const stats = await commercialStorage.getDeveloperStats();
    res.json(stats);
  } catch (error) {
    console.error('Error fetching developer stats:', error);
    res.status(500).json({ error: 'Failed to fetch stats' });
  }
});

// Get all products
router.get('/products', isDeveloper, async (req, res) => {
  try {
    const { simpleDevKeyService } = await import('../simple-devkey');
    const products = await simpleDevKeyService.getProducts();
    res.json(products);
  } catch (error) {
    console.error('Error fetching products:', error);
    res.status(500).json({ error: 'Failed to fetch products' });
  }
});

// Create product
router.post('/products', isDeveloper, async (req, res) => {
  try {
    const productSchema = z.object({
      name: z.string().min(1),
      nameAr: z.string().optional(),
      description: z.string().optional(),
      descriptionAr: z.string().optional(),
      priceUsd: z.number().min(0),
      originalPriceUsd: z.number().min(0).optional(),
      productType: z.enum(['subscription', 'license', 'one-time']),
      category: z.string().default('trading'),
      billingCycle: z.enum(['monthly', 'yearly', 'lifetime']).optional(),
      features: z.array(z.string()),
      limits: z.object({
        dailySignals: z.number().default(50),
        monthlySignals: z.number().default(1500),
        devices: z.number().default(1)
      }),
      trialDays: z.number().default(7),
      trialTrades: z.number().default(10),
      maxDevicesAllowed: z.number().default(1),
      isPopular: z.boolean().default(false),
      isActive: z.boolean().default(true),
      sortOrder: z.number().default(0)
    });

    const validatedData = productSchema.parse(req.body);
    const product = await commercialStorage.createProduct(validatedData);
    res.json({ success: true, product });
  } catch (error) {
    console.error('Error creating product:', error);
    res.status(500).json({ error: 'Failed to create product' });
  }
});

// Update product
router.put('/products/:id', isDeveloper, async (req, res) => {
  try {
    const productId = parseInt(req.params.id);
    const updates = req.body;
    
    const product = await commercialStorage.updateProduct(productId, updates);
    if (!product) {
      return res.status(404).json({ error: 'Product not found' });
    }
    
    res.json({ success: true, product });
  } catch (error) {
    console.error('Error updating product:', error);
    res.status(500).json({ error: 'Failed to update product' });
  }
});

// Get all licenses
router.get('/licenses', isDeveloper, async (req, res) => {
  try {
    const licenses = await commercialStorage.getAllLicenses();
    res.json(licenses);
  } catch (error) {
    console.error('Error fetching licenses:', error);
    res.status(500).json({ error: 'Failed to fetch licenses' });
  }
});

// Create licenses
router.post('/licenses', isDeveloper, async (req, res) => {
  try {
    const licenseSchema = z.object({
      productId: z.number(),
      licenseType: z.enum(['trial', 'paid', 'lifetime']),
      maxTrades: z.number().optional(),
      trialDurationDays: z.number().optional(),
      quantity: z.number().min(1).default(1)
    });

    const validatedData = licenseSchema.parse(req.body);
    const licenses = await commercialStorage.createBulkLicenses(validatedData);
    res.json({ success: true, licenses });
  } catch (error) {
    console.error('Error creating licenses:', error);
    res.status(500).json({ error: 'Failed to create licenses' });
  }
});

// Revoke license
router.post('/licenses/revoke', isDeveloper, async (req, res) => {
  try {
    const { licenseKey, reason } = req.body;
    await commercialStorage.revokeLicense(licenseKey, reason, 0);
    res.json({ success: true });
  } catch (error) {
    console.error('Error revoking license:', error);
    res.status(500).json({ error: 'Failed to revoke license' });
  }
});

// Get all users
router.get('/users', isDeveloper, async (req, res) => {
  try {
    const users = await commercialStorage.getAllUsers();
    res.json(users);
  } catch (error) {
    console.error('Error fetching users:', error);
    res.status(500).json({ error: 'Failed to fetch users' });
  }
});

// Get specific user details
router.get('/users/:id', isDeveloper, async (req, res) => {
  try {
    const userId = req.params.id;
    const user = await commercialStorage.getUserById(userId);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    const licenses = await commercialStorage.getUserLicenses(userId);
    const stats = await commercialStorage.getUserStats(userId);
    
    res.json({ user, licenses, stats });
  } catch (error) {
    console.error('Error fetching user details:', error);
    res.status(500).json({ error: 'Failed to fetch user details' });
  }
});

// Update user
router.put('/users/:id', isDeveloper, async (req, res) => {
  try {
    const userId = req.params.id;
    const updates = req.body;
    
    const user = await commercialStorage.updateUser(userId, updates);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    res.json({ success: true, user });
  } catch (error) {
    console.error('Error updating user:', error);
    res.status(500).json({ error: 'Failed to update user' });
  }
});

// Generate license keys
router.post('/licenses/generate', isDeveloper, async (req, res) => {
  try {
    const { count = 1, prefix = 'AZT' } = req.body;
    const keys = [];
    
    for (let i = 0; i < count; i++) {
      keys.push(commercialStorage.generateLicenseKey(prefix));
    }
    
    res.json({ success: true, keys });
  } catch (error) {
    console.error('Error generating license keys:', error);
    res.status(500).json({ error: 'Failed to generate license keys' });
  }
});

// Export licenses (CSV format)
router.get('/licenses/export', isDeveloper, async (req, res) => {
  try {
    const licenses = await commercialStorage.getAllLicenses();
    
    // Create CSV content
    const headers = ['License Key', 'Type', 'Status', 'Max Trades', 'Used Trades', 'Expires At', 'User ID', 'Created At'];
    const csvRows = [headers.join(',')];
    
    licenses.forEach(license => {
      const row = [
        license.licenseKey,
        license.licenseType,
        license.isValid ? 'Valid' : 'Invalid',
        license.maxTrades || '',
        license.tradesUsed || 0,
        license.expiresAt || '',
        license.userId || '',
        license.createdAt
      ];
      csvRows.push(row.join(','));
    });
    
    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', 'attachment; filename="licenses.csv"');
    res.send(csvRows.join('\n'));
  } catch (error) {
    console.error('Error exporting licenses:', error);
    res.status(500).json({ error: 'Failed to export licenses' });
  }
});

export default router;